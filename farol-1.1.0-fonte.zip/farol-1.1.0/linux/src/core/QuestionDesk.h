#pragma once
#include "Scheduler.h"

#include <QJsonArray>
#include <QJsonObject>
#include <QObject>
#include <QStringList>
#include <QVariantList>
#include <functional>

namespace farol {

// An AskUserQuestion held by the island (its PermissionRequest hook waits) so the user can answer with a click:
// the questions are shown one by one and the hook gets the tool input back with "answers" filled in (question text
// -> label, several labels comma-separated). release(), the timeout and cancel() leave the question to the editor.
// One at a time; nothing is answered without a click.
class QuestionDesk : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool active READ active NOTIFY changed)
    Q_PROPERTY(QString sessionId READ sessionId NOTIFY changed)
    Q_PROPERTY(QString project READ project NOTIFY changed)
    Q_PROPERTY(int count READ count NOTIFY changed)
    Q_PROPERTY(int index READ index NOTIFY changed)
    Q_PROPERTY(QString header READ header NOTIFY changed)
    Q_PROPERTY(QString question READ question NOTIFY changed)
    Q_PROPERTY(bool multiSelect READ multiSelect NOTIFY changed)
    Q_PROPERTY(QVariantList options READ options NOTIFY changed)   // {label, description, selected}

public:
    using Reply = std::function<void(const QJsonObject &updatedInput)>;   // empty: decide in the editor
    // Below the hook's own 110 s wait, so the app releases first and the hook exits cleanly.
    static constexpr int kTimeoutMs = 105000;

    explicit QuestionDesk(IScheduler &scheduler, QObject *parent = nullptr);
    ~QuestionDesk() override;

    // Returns the id, or 0 when it cannot be held (another question is, or there is nothing to click): the caller
    // then answers the hook itself.
    qint64 hold(const QString &sessionId, const QString &project, const QJsonObject &toolInput, Reply reply);
    // The hook went away (answered in the editor, Claude Code killed it): drop it without a reply.
    void cancel(qint64 id);
    void forget(const QString &sessionId);

    bool active() const { return m_id != 0; }
    QString sessionId() const { return m_sessionId; }
    QString project() const { return m_project; }
    int count() const { return int(m_questions.size()); }
    int index() const { return m_index; }
    QString header() const { return current().value("header").toString(); }
    QString question() const { return current().value("question").toString(); }
    bool multiSelect() const { return current().value("multiSelect").toBool(); }
    QVariantList options() const;

public slots:
    void choose(const QString &label);   // single choice: answers and moves on; multi-select: toggles
    void confirm();                      // multi-select: done with this question (needs at least one choice)
    void release();

signals:
    void changed();
    void finished(const QString &sessionId, bool answered);

private:
    QJsonObject current() const { return m_index < m_questions.size() ? m_questions.at(m_index).toObject() : QJsonObject(); }
    QStringList labels() const;
    void answer(const QString &text);
    void finish(const QJsonObject &updatedInput, bool reply);

    IScheduler &m_sched;
    qint64 m_nextId = 0;
    qint64 m_id = 0;
    QString m_sessionId, m_project;
    QJsonObject m_input;
    QJsonArray m_questions;
    QJsonObject m_answers;
    QStringList m_selected;   // multi-select: labels ticked so far
    int m_index = 0;
    int m_timer = 0;
    Reply m_reply;
};

} // namespace farol
