# Coucou no Fedora — design do port Linux

Data: 2026-09-29 · Branch: `feat/for-fedora` · Status: aguardando revisão

## 0. Emenda de 2026-09-30 — alvo de fidelidade

Depois do L0, o pedido é "funcionar igual ao do GitHub". O app do GitHub é o **Swift entregue** (`NotchBuddy/Sources/App/`), e ele **diverge do `docs/SPEC.md`** (que é o plano original). Regra do port: **o comportamento e as constantes do Swift vencem o `SPEC.md`**; o `SPEC.md` e o protótipo HTML só valem onde o Swift concorda com eles. Diferenças que já encontramos:

- **FSM da ilha com 4 estados** — `hidden`, `petit` (compacta), `home` (expandida), `coucou` (saudação) — com atrasos `petit→hidden` 60 s, `home→petit` 15 s, saudação 0,6 s (10 s com o mouse em cima). **Clicar** na compacta abre; passar o mouse nela não abre (o `SPEC.md` dizia 200 ms de hover).
- **Geometria:** notch 184×32; largura compacta = notch + 160; expandida 640; altura das views 160 (upload/uploading/choose 176, mail 240, saudação 150, chat `min(300, 240 + 40·mensagens)`); cantos de baixo 14 (escondida/compacta) e 22 (expandida); cantos de cima retos.
- **Tarefas = "pílulas de integração" permanentes**, não uma tarefa por sessão: a pílula Claude ("VS Code") é fixa e as integrações são opcionais (no máximo 4 ativas). Os eventos do Claude Code atualizam **uma única pílula**, com o nome da pasta da sessão mais recente. **§6.2 desta spec muda de acordo.** O app do Mac ignora sessões que não são do VS Code; no Linux aceitamos todas as origens (no VSCodium o `TERM_PROGRAM` vem vazio), e isso é uma diferença deliberada.
- **Notch virtual: 184×32** (fallback do Swift quando não há notch), não 184×24 (**§4.2 muda**).
- Ícones: os SF Symbols não existem no Linux; usamos glifos desenhados em QML (casa, balão, mais, engrenagem, alto-falante).

**O L1 da §13 é dividido** (um plano por subsistema): **L1a** casca da ilha (janela, FSM, controlador, estado, sons, bandeja, cabeçalho e cartões provisórios, personagem provisório), **L1b** Mochi (motor + desenho + mini-Mochis + saudação), **L1c** as views (visão geral, aprovação, pergunta, erro, terminado, confuso, nota, configurações…), **L1d** upload/arquivos (canvas, DnD).

## 1. Objetivo e escopo

- **Uso próprio**, na máquina do autor do fork: Fedora 44, KDE Plasma 6.7, Wayland. Não há empacotamento para distribuição; os assets (nome, Mochi, ícone, sons) são usados só nesse contexto, como permite o `LICENSE-ASSETS.md`.
- **Paridade de funcionalidades** com o app macOS, dentro do que o Wayland/KDE permite: ilha + Mochi, Claude Code (sessões, aprovações, perguntas, fim/erro), chat com Claude, arquivos, as 7 integrações e os extras que dependem do KWin.
- Fora do escopo: GNOME (não suporta layer-shell), outras distros, X11, empacotamento RPM/Flatpak.
- O app macOS (`NotchBuddy/`) **não é alterado**, para o fork continuar recebendo o upstream sem conflito. O port vive em `linux/`.
- Referências de comportamento continuam valendo: `docs/SPEC.md`, `docs/INTEGRATIONS.md`, `design/prototype/notch-buddy.html`, `design/captures/`. O código Swift é a referência de constantes e tempos. Este documento só descreve o que **muda** no Linux.

## 2. Stack

C++20 + Qt 6.11 (Qt Quick/QML) + LayerShellQt 6.7, com KDE Frameworks 6 onde o Qt não cobre. Tudo vem do repositório do Fedora 44:

| Necessidade | Solução |
|---|---|
| Janela sobre tudo, no topo | LayerShellQt (`zwlr_layer_shell_v1`) |
| UI declarativa, animações | Qt Quick / QML, `Easing.BezierSpline`, `MultiEffect` |
| Desenho do Mochi | `QQuickPaintedItem` + `QPainter` |
| Som | `QSoundEffect` (Qt Multimedia) |
| Segredos | QtKeychain → KWallet / Secret Service |
| Bandeja | `KStatusNotifierItem` (KF6) |
| Atalho global | `KGlobalAccel` (KF6) |
| Ausência do usuário | `KIdleTime` (KF6) |
| Janela de configurações | QML + Kirigami `FormLayout` |
| Socket do hook | `QLocalServer` |
| HTTP/JSON | `QNetworkAccessManager`, `QJsonDocument` |
| KWin, Konsole | `QtDBus` |
| Preferências | `QSettings` |

Build: CMake + Ninja. Testes: Qt Test. Fonte da UI: Inter (`rsms-inter-fonts`), fallback Noto Sans.

Dependências de desenvolvimento (host):

```bash
sudo dnf install cmake ninja-build gcc-c++ extra-cmake-modules \
  qt6-qtbase-devel qt6-qtdeclarative-devel qt6-qtmultimedia-devel qt6-qtwayland-devel \
  layer-shell-qt-devel qtkeychain-qt6-devel \
  kf6-kstatusnotifieritem-devel kf6-kglobalaccel-devel kf6-kidletime-devel kf6-kirigami-devel \
  rsms-inter-fonts
```

## 3. Arquitetura

### 3.1 Processos

1. **`coucou`** (C++/Qt, no host, autostart): ilha, bandeja, configurações, servidor do socket, pollers, cliente Claude.
2. **`nb-hook`** (Python 3, só stdlib): chamado pelo Claude Code, no host (Konsole) ou dentro do Flatpak do VSCodium (`com.vscodium.codium`, que tem `filesystems=host`). Fala com o app pelo socket Unix.
3. **`coucou-bridge`** (script do KWin): carregado só enquanto a ilha está visível. Fornece posição do cursor, janela sob um ponto e ativação de janela.

### 3.2 Identificadores e caminhos

- ID do app (arquivo `.desktop`, nome D-Bus, serviço do KWallet): `fr.louisraille.NotchBuddy` (mesmo identificador do Mac, como pede o `CLAUDE.md`).
- `~/.local/share/coucou/` — `nb-hook`, `nb.sock` (pasta `0700`), `inbox/`.
  - **Todos os caminhos são montados a partir de `$HOME`**, nunca de `$XDG_DATA_HOME`/`$XDG_RUNTIME_DIR`: dentro do Flatpak do VSCodium essas variáveis apontam para `~/.var/app/...` e `/run/user/UID` não é compartilhado.
- `~/.config/coucou/coucou.conf` — preferências (`QSettings`).
- `~/.local/state/coucou/coucou.log` — log.
- `~/.config/autostart/fr.louisraille.NotchBuddy.desktop` — autostart.
- `~/.local/bin/coucou`, `~/.local/share/applications/fr.louisraille.NotchBuddy.desktop`, `~/.local/share/kwin/scripts/coucou-bridge/` — instalação local.

### 3.3 Estrutura do código

```
linux/
  CMakeLists.txt
  src/core/        biblioteca estática sem UI, coberta por testes:
                   IslandStateMachine, modelos (AgentTask, BotState, IslandView...),
                   HookProtocol (evento → estado, JSON de decisão), ClaudeSettingsMerger,
                   ApprovalQueue, pollers, ClaudeClient, parsers
  src/mochi/       BotEngine (update + paint), GreetingScene, UploadSequence, MochiItem
  src/platform/    IslandWindow (layer-shell + região de entrada), SoundEngine,
                   SecretStore, Tray, Shortcuts, Autostart, IdleWatcher,
                   KWinBridge, KonsoleBridge, HookServer
  src/main.cpp
  qml/             Island.qml, views/*.qml, components/*.qml, Settings.qml
  hook/nb-hook     script Python
  kwin/coucou-bridge/  metadata.json + contents/code/main.js
  resources/       ícones (os WAVs são lidos de NotchBuddy/Resources/sounds pelo CMake, sem cópia)
  tests/           Qt Test (core) + unittest (nb-hook)
  scripts/         install.sh, uninstall.sh
```

`AppState` vira um `QObject` com `Q_PROPERTY` expostas ao QML. Os `NotificationCenter` do Swift viram sinais Qt.

## 4. A ilha no Wayland

### 4.1 Janela

- Uma `QQuickWindow` transparente, transformada em layer surface via `LayerShellQt::Window`: camada `LayerOverlay`, âncora `AnchorTop`, 720 × 320, zona exclusiva `-1` (ignora zonas exclusivas de painéis e cola na borda de cima), `scope = "coucou"`, na tela primária.
- Janelas auxiliares (Mochi fantasma, contorno da janela-alvo) são layer surfaces pequenas, com âncora topo-esquerda e posição via margens.

### 4.2 Notch virtual

- Não há notch no hardware: `wN × hN = 184 × 32` (fallback do Swift; ver §0), centralizado no topo.
- `hidden`: nada desenhado. A região de entrada é uma faixa de 184 × 3 px na borda superior; encostar o mouse nela dispara o `peek` (SPEC §3.2).
- Preferência "Mostrar notch falso": desenha uma pílula preta 184 × 32 permanente e usa-a como zona de hover.
- Modos, tamanhos e regras de SPEC §2–§3 são mantidos.

### 4.3 Cliques atravessando

- Em vez de alternar `ignoresMouseEvents` a 60 Hz, a região de entrada da superfície (`QWindow::setMask`, que no Wayland vira `wl_surface.set_input_region`) é a forma atual da ilha + 6 px.
- Durante uma animação de tamanho, a região é a união da forma inicial e final; no fim da animação, volta à forma exata. Sem polling.
- Durante um arrastar de arquivo sobre a ilha, a região cobre a zona de upload (±220 px do centro, até 26 px abaixo).

### 4.4 Foco de teclado

- Padrão: `KeyboardInteractivityNone` — a ilha nunca rouba foco.
- `OnDemand` quando: o usuário clica na ilha, ou uma view com campo de texto (`prompt`, `mail`) fica ativa. Volta a `None` quando a ilha recolhe.
- `Esc` (fechar) e `Y`/`N` (aprovação) só funcionam com a ilha focada. **Um alerta nunca pega foco sozinho**: digitar "y" no editor não aprova nada.

### 4.5 Mouse, cursor e ausência

- Hover, clique e arrastar vêm dos eventos da própria superfície. Durante um arrastar, o grab implícito do Wayland mantém os eventos mesmo fora da superfície.
- Olhos seguindo o cursor na tela toda: só com `coucou-bridge` (§8). Sem ele, os olhos seguem o cursor quando está sobre a ilha e fazem o olhar ocioso fora dela.
- Ausência (SPEC §3.6, padrão 3 min): `KIdleTime`, não polling do mouse.

## 5. Mochi, views e som

- `BotEngine.swift` → `BotEngine` C++, tradução direta: `update(double dt)` (tweens, física, piscadas, partículas) e `paint(QPainter&, QSizeF)` (corpo superelipse, gradientes, sombreamento, bochechas, olhos projetados na esfera, badges, partículas, mãos). `GreetingCanvasView` e `UploadCanvasView` seguem o mesmo caminho.
- `MochiItem : QQuickPaintedItem` (render target FBO) desenha um `BotEngine`. Mini-Mochis usam o mesmo item.
- **Relógio único**: um `FrameClock` ligado ao `QQuickWindow::frameSwapped` avança todos os engines e só pede novo quadro enquanto algo anima. Ilha escondida → nenhum quadro → 0% CPU.
- Views em QML seguindo SPEC §5 e as capturas. Animações da ilha com as curvas exatas: abrir `[.32,1.22,.42,1]` 520 ms, fechar `[.45,0,.2,1]` 340 ms; conteúdo sai em 160 ms (opacidade, blur 8, escala 0,97) e entra em 300 ms com 160 ms de atraso; mini-Mochis são os mesmos itens animando entre grade, pílulas e coluna (35 ms por índice).
- `SoundEngine`: 3 `QSoundEffect` pré-carregados por WAV, volume 0–0,2 (padrão 0,12), respeita o botão de som e a preferência.

## 6. Claude Code

### 6.1 `nb-hook`

- Lê o JSON do stdin e acrescenta `coucou_source`:
  - `vscodium` se `CLAUDE_CODE_ENTRYPOINT` começa com `claude-vscode` (com `flatpak_id` = `FLATPAK_ID`);
  - `konsole` se existe `KONSOLE_DBUS_SERVICE` (guarda `KONSOLE_DBUS_SERVICE`, `KONSOLE_DBUS_SESSION`, `KONSOLE_DBUS_WINDOW`);
  - `terminal` caso contrário (guarda `TERM_PROGRAM`).
- Socket: `os.path.join(os.environ["HOME"], ".local/share/coucou/nb.sock")`.
- Eventos comuns: conecta, envia uma linha JSON, fecha. Limite total 0,3 s.
- `PermissionRequest`: envia e espera uma linha de resposta até o tempo de decisão, recebido como argumento na linha de comando que o instalador grava (`nb-hook --decision-timeout 110`; padrão 110 s). Se a resposta for `allow`/`deny`, imprime exatamente:
  ```json
  {"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"allow"}}}
  ```
  (ou `"deny"`, com `"message"` opcional). Qualquer outra resposta (`release`), falha, app ausente ou timeout → **não imprime nada e sai 0**: o Claude Code segue o fluxo normal.
- Nunca sai com código ≠ 0 e nunca imprime nada em stdout fora do caso acima.

### 6.2 Sessões

- Todas as origens são aceitas (o filtro "só VS Code" do Mac não se aplica — no VSCodium `TERM_PROGRAM` vem vazio).
- **Uma única pílula Claude** (fixa, chamada "VS Code" quando ociosa), com o nome da pasta do `cwd` da sessão mais recente e a tabela de aliases (ver §0); as demais pílulas são as integrações.
- Mapeamento de eventos conforme `INTEGRATIONS.md` §1, com dois ajustes:
  - `Notification`: decide pelo `notification_type` (`idle_prompt` → `question` se houver pergunta pendente; limite de uso → `ratelimit`), não pelo texto.
  - `Stop`: resumo = `last_assistant_message` quando presente.
- `SessionEnd` remove a tarefa. Eventos seguintes da mesma sessão limpam alertas já respondidos no editor.

### 6.3 Aprovações

- Fila `ApprovalQueue`: um alerta por vez, na ordem de chegada; a ilha abre na view `approval` e fica aberta até a decisão (SPEC §3.7, §3.9).
- Botões: **Negar**, **Sempre autorizar**, **Autorizar**, **Decidir no VSCodium** (ou "no terminal"). O último responde `release` ao hook (sem saída) e leva à sessão.
- **Sempre autorizar**: primeiro tentar `decision.updatedPermissions` com uma regra persistente (validar no L2 se o Claude Code aceita `addRules`). Se não for suportado: lista própria do app (projeto + ferramenta + padrão do comando), respondida automaticamente com `allow` e editável nas configurações.
- **Ponto a validar no L2**: se o Claude Code só mostra o próprio pedido depois que o hook termina, o editor fica mudo enquanto o hook espera. O botão "Decidir no VSCodium" e o tempo de decisão configurável cobrem isso; se o comportamento incomodar, reduzir o padrão.
- Nenhuma decisão é tomada sem clique (ou `Y`/`N` com a ilha já focada por clique).

### 6.4 Perguntas

- `PreToolUse` com `tool_name == "AskUserQuestion"` → view `question` com a pergunta e as opções (somente leitura) e o botão **Responder no VSCodium**. Um hook não pode responder a pergunta; nada de teclado simulado.

### 6.5 Voltar para a sessão

- `vscodium`: `KWinBridge.activate(resourceClass ~ "codium", caption contém o nome da pasta)`; sem bridge ou sem janela: `flatpak run com.vscodium.codium <cwd>`.
- `konsole`: D-Bus `org.kde.konsole.Window.setCurrentSession(id)` no serviço/janela capturados, depois `KWinBridge.activate` pela janela do Konsole.
- `terminal`: `KWinBridge.activate` pelo título; sem bridge, não faz nada.

### 6.6 Instalador dos hooks

Segue a regra do `CLAUDE.md`:
1. Lê `~/.claude/settings.json` (cria se não existir).
2. Monta o resultado: remove entradas antigas do Coucou (comando contendo `.local/share/coucou/nb-hook`) e acrescenta as novas, **sem tocar nas outras** (ex.: o hook `Stop` que já existe).
3. Mostra o diff numa janela; **só grava após "Confirmar"**, antes criando `settings.json.bak-AAAAMMDD-HHMM`.
4. Eventos: `SessionStart`, `SessionEnd`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`, `PostToolUseFailure`, `PermissionRequest`, `Notification`, `Stop`, `StopFailure`, `SubagentStart`, `SubagentStop`. Timeout 10 s para todos, exceto `PermissionRequest` = tempo de decisão + 10 s. Mudar o tempo de decisão nas configurações passa de novo por este fluxo (diff + confirmação).
5. "Desinstalar hooks" remove apenas as entradas do Coucou, com o mesmo fluxo de backup + diff + confirmação.

### 6.7 Segurança do socket

- Pasta `~/.local/share/coucou` com permissão `0700`; socket recriado a cada início.
- O servidor confere o UID do cliente (`SO_PEERCRED`) e recusa outros usuários.

## 7. Chat, arquivos e integrações

### 7.1 Chat

- `ClaudeClient`: `POST https://api.anthropic.com/v1/messages` com a ferramenta de busca web do servidor. Modelo configurável, padrão o Sonnet mais recente. **Versões da API, do modelo e da ferramenta de busca são confirmadas na documentação no momento de implementar** (o Swift usa `claude-sonnet-4-6` e `web_search_20250305`).
- Prompt de sistema e formato de resposta JSON (`title`, até 3 `items`, `note`) como em `INTEGRATIONS.md` §5; JSON inválido → texto bruto (3 linhas).
- Chave em `SecretStore` (QtKeychain, serviço `fr.louisraille.NotchBuddy`). Nunca em disco.
- Erro de rede ou chave inválida → estado `error`, view `note` com a razão em uma frase.

### 7.2 Arquivos

- Arrastar do Dolphin (`text/uri-list`) para a ilha → views `upload` → `uploading` (cópia para `inbox/`) → `choose`. Limpeza do que tiver mais de 7 dias.
- **Perguntar sobre o arquivo**: PDF como bloco `document`, imagem como `image`, texto/código até 200 KB como texto; outros formatos → mensagem de SPEC.
- **E-mail**: a view `mail` mantém os campos; o botão vira **Abrir no e-mail** e roda `xdg-email --subject … --body … --attach <arquivo> <destinatário>`. O rascunho abre no cliente de e-mail e o envio é um clique do usuário lá.
- Microfone/ditado: fora do escopo (era opcional no Mac).

### 7.3 Integrações

- Os 7 pollers (Stripe, n8n, GitHub, Vercel, Resend, Notion, Cal.com) portados com os mesmos endpoints, intervalos e mapeamentos do Swift, como `QObject` + `QTimer`.
- Só rodam os ativados e configurados. Chaves no `SecretStore`. Erros → estado da pílula + backoff.
- Abrir no navegador: `QDesktopServices::openUrl` (xdg-open).

## 8. Extras via KWin (`coucou-bridge`)

- Script do KWin instalado em `~/.local/share/kwin/scripts/coucou-bridge/`. O app o carrega via D-Bus `org.kde.KWin /Scripting` quando a ilha aparece e descarrega quando ela some (0% de CPU escondida).
- Funções, comunicando com o app por `callDBus` para o serviço `fr.louisraille.NotchBuddy`:
  - posição do cursor ~60 Hz (lissagem já existe no Mochi);
  - janela sob um ponto (caption, `resourceClass`, pid, geometria), ignorando as nossas;
  - ativar janela por critérios.
- **Arrastar o Mochi até uma janela** (SPEC §8): > 7 px de arraste → Mochi fantasma numa layer surface pequena que segue o cursor; contorno não clicável numa layer surface sobre a janela-alvo; ao soltar, contexto = app + título da janela → view `prompt`. **Não há URL do navegador no Linux** (sem AppleScript).
- Se a bridge não carregar: essas funções somem sem erro e o resto do app funciona.

## 9. Bandeja, configurações e sistema

- Bandeja (`KStatusNotifierItem`, ícone monocromático do Mochi): Abrir Coucou, Configurações…, Debug ▸ (forçar views, estados, emotes, tarefas falsas), Sair.
- Atalhos (`KGlobalAccel`, editáveis nas Configurações do Sistema): abrir a ilha; demo `Ctrl+Alt+Meta+D`.
- Configurações (QML + Kirigami): chave Anthropic e modelo; integrações (chaves, filtros); Claude Code (estado dos hooks, instalar/desinstalar, tempo de decisão, lista "sempre autorizar"); som e volume; fechamento automático; ausência; iniciar com a sessão; notch falso; aliases de projetos.
- Autostart: escreve/remove o `.desktop` em `~/.config/autostart/`.

## 10. Erros e regras que não podem quebrar

- O Claude Code nunca é bloqueado: toda falha do `nb-hook` → sem saída, código 0, dentro dos limites de tempo.
- Nenhuma aprovação e nenhum e-mail sem clique.
- `~/.claude/settings.json` só é escrito com backup, diff e confirmação.
- Segredos só no KWallet. Sem telemetria; rede só para serviços configurados.
- Crash do app → o hook cai no fluxo normal; no próximo início o socket é recriado.

## 11. Testes e verificação

- **Qt Test (core)**: transições e tempos da FSM com relógio falso; `HookProtocol` (cada evento → estado/view, JSON de decisão exato); `ApprovalQueue`; `ClaudeSettingsMerger` (merge, preservação de hooks alheios, remoção, backup); parsers dos pollers e do resultado do Claude com fixtures; física do `BotEngine` determinística com `dt` fixo.
- **`unittest` (nb-hook)**: app ausente → sem saída, código 0, < 0,5 s; `allow`/`deny` → JSON exato; `release` → sem saída; enriquecimento da origem.
- **Manual por marco**: captura da ilha (Spectacle) lado a lado com `design/captures/`; CPU com `pidstat` (escondida 0%, compacta < 3%); memória PSS por `/proc/PID/smaps_rollup` (< 100 MB); fluxo real com uma sessão do Claude Code no VSCodium.

## 12. Ambiente de desenvolvimento

- O Claude Code roda dentro do Flatpak do VSCodium: compilar, testar e executar com `flatpak-spawn --host` (ex.: `flatpak-spawn --host cmake --build linux/build`).
- O `toolbox` não funciona para o usuário de domínio (sem faixa de subuid); tudo é instalado no host.
- O `CLAUDE.md` do fork ganha uma seção Linux (build, execução, regras específicas).

## 13. Marcos

Cada marco tem o próprio plano de implementação e termina com build + testes + verificação manual + commit.

| Marco | Conteúdo | Pronto quando |
|---|---|---|
| **L0 Fundação + spike Wayland** | CMake, esqueleto, e prova isolada de: layer surface no topo acima de tudo; região de entrada (cliques atravessam); foco sob demanda; DnD do Dolphin na layer surface; `QSoundEffect`; QtKeychain/KWallet; script KWin enviando cursor por D-Bus; socket alcançável de dentro do Flatpak do VSCodium; memória base | nota com funciona/não funciona por mecanismo e alternativa para o que falhar |
| **L1a Casca da ilha** | tipos e geometria, FSM, controlador, estado, sons, janela layer-shell, bandeja, cabeçalho e cartões provisórios | ilha abre/fecha como no Mac (tamanhos, tempos, curvas), 0 % CPU escondida |
| **L1b Mochi** | `BotEngine`, desenho, mini-Mochis, saudação | Mochi igual às capturas, CPU/RAM dentro das metas |
| **L1c Views** | todas as views com dados falsos | capturas de `design/captures/` batem |
| **L1d Upload** | canvas de upload, DnD, escolha | fluxo de arrastar arquivo completo |
| **L2 Claude Code** | `nb-hook`, `HookServer`, sessões, aprovações, perguntas, fim/erro, instalador, voltar à sessão | sessão real no VSCodium aparece, aprova e nega pela ilha; app fechado não atrasa nada |
| **L3 Chat + arquivos** | `ClaudeClient`, SecretStore, prompt/searching/result, DnD, inbox, e-mail | pergunta com e sem arquivo funciona; rascunho abre com anexo |
| **L4 Integrações** | 7 pollers, pílulas e cartões, configurações | cada integração configurada mostra dados reais |
| **L5 Extras KWin** | bridge, olhos na tela toda, arrastar Mochi para janela | olhos seguem o cursor fora da ilha; janela anexada como contexto |
| **L6 Acabamento** | bandeja + debug + demo, atalhos, autostart, configurações completas, `install.sh`, medição final | app inicia com a sessão e passa nos critérios de SPEC §12 adaptados |

Caminho crítico: L0 → L1a → L1b → L1c → L2. L1d, L3, L4 e L5 são independentes entre si depois do L1c/L2.
