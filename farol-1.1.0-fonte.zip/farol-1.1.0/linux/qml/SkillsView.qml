import QtQuick

// The Skills tab. On the left the company's skills folder that Claude Code is kept linked to (core/Skills); on the
// right Claude Code's plugins (core/Plugins): the installed ones, each with its switch and "Remover", and
// "Adicionar plugin…", which turns the tab into the catalogue of the known marketplaces. Everything stays inside
// the island; every change to a plugin is a click that runs Claude Code's own program.
Item {
    id: view
    readonly property bool vertical: appState.vertical
    readonly property bool hasFolder: appState.skillsDir !== ""
    property bool confirmingOff: false     // "Desligar" asks before it takes the links away
    property bool adding: false            // the catalogue is on screen
    property string removing: ""           // the plugin whose "Remover" waits for a yes

    // the view is loaded each time the tab opens: links checked, folder updated if it is time, plugins read
    Component.onCompleted: { skills.refresh(); plugins.refresh() }
    Connections {
        target: appState
        function onSkillsDirChanged() { view.confirmingOff = false }
    }
    onAddingChanged: {
        plugins.filter = ""
        if (adding) {
            controller.requestKeyboard(true)   // the island only gets keys when asked
            field.forceActiveFocus()
        }
    }

    // ---- the company's skills ----
    Card {
        id: skillsCard
        visible: !view.adding
        width: view.vertical ? parent.width : 236
        height: view.vertical ? 212 : parent.height

        Column {
            anchors.fill: parent
            anchors.leftMargin: appState.vertical ? 12 : 16
            anchors.rightMargin: appState.vertical ? 12 : 16
            anchors.topMargin: 12
            spacing: 7

            Item {
                width: parent.width
                height: 18
                Text {
                    textFormat: Text.PlainText
                    text: "Skills da empresa"
                    color: theme.text
                    font.family: theme.titleFont
                    font.pixelSize: 14
                    font.weight: Font.DemiBold
                }
                Text {
                    objectName: "skillsCount"
                    anchors.right: parent.right
                    anchors.verticalCenter: parent.verticalCenter
                    visible: view.hasFolder
                    textFormat: Text.PlainText
                    text: skills.linked === 1 ? "1 ligada" : skills.linked + " ligadas"
                    color: theme.dim
                    font.family: theme.bodyFont
                    font.pixelSize: 11
                }
            }
            Text {
                objectName: "skillsPath"
                visible: view.hasFolder
                width: parent.width
                elide: Text.ElideLeft   // the end of a path says the most
                textFormat: Text.PlainText
                text: appState.skillsDirLabel
                color: theme.muted
                font.family: theme.bodyFont
                font.pixelSize: 12
            }
            Item {
                width: parent.width
                height: stateText.height
                Rectangle {
                    objectName: "skillsDot"
                    y: 5
                    width: 7
                    height: 7
                    radius: 3.5
                    visible: view.hasFolder
                    color: skills.status === "ok" ? theme.ok : (skills.status === "warn" ? theme.lamp : theme.muted)
                }
                Column {
                    id: stateText
                    x: view.hasFolder ? 14 : 0
                    width: parent.width - x
                    spacing: 1
                    Text {
                        objectName: "skillsMessage"
                        width: parent.width
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: skills.message
                        color: view.hasFolder ? theme.text : theme.muted
                        font.family: theme.bodyFont
                        font.pixelSize: 13
                    }
                    Text {
                        objectName: "skillsDetail"
                        visible: text !== ""
                        width: parent.width
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: skills.detail
                        color: theme.dim
                        font.family: theme.bodyFont
                        font.pixelSize: 11
                    }
                }
            }
            Flow {
                width: parent.width
                spacing: 8
                PillButton {
                    objectName: "skillsUpdate"
                    visible: view.hasFolder && skills.status !== "plain" && !view.confirmingOff
                    text: skills.status === "warn" ? "Tentar de novo" : "Atualizar agora"
                    primary: skills.status === "warn"
                    onClicked: skills.updateNow()
                }
                PillButton {
                    objectName: "skillsChoose"
                    visible: !view.confirmingOff
                    text: "Escolher…"
                    primary: !view.hasFolder
                    onClicked: appState.chooseSkillsDir()
                }
                PillButton {
                    objectName: "skillsOpen"
                    visible: view.hasFolder && skills.status === "warn" && !view.confirmingOff
                    text: "Abrir a pasta"
                    onClicked: skills.openFolder()
                }
                PillButton {
                    objectName: "skillsOff"
                    visible: view.hasFolder && !view.confirmingOff
                    text: "Desligar"
                    onClicked: view.confirmingOff = true
                }
                Text {
                    visible: view.confirmingOff
                    height: 28
                    verticalAlignment: Text.AlignVCenter
                    textFormat: Text.PlainText
                    text: "Desligar as skills da empresa?"
                    color: theme.text
                    font.family: theme.bodyFont
                    font.pixelSize: 13
                }
                PillButton {
                    objectName: "skillsOffYes"
                    visible: view.confirmingOff
                    text: "Sim"
                    primary: true
                    onClicked: appState.skillsDir = ""
                }
                PillButton {
                    objectName: "skillsOffNo"
                    visible: view.confirmingOff
                    text: "Não"
                    onClicked: view.confirmingOff = false
                }
            }
            Text {
                width: parent.width
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                text: view.hasFolder ? "Vale para as sessões do Claude Code abertas depois de cada mudança."
                                     : "O Farol liga cada skill da pasta ao Claude Code e mantém a pasta atualizada pelo git."
                color: theme.dim
                font.family: theme.bodyFont
                font.pixelSize: 11
            }
        }
    }

    // ---- the installed plugins ----
    Card {
        id: pluginsCard
        visible: !view.adding
        x: view.vertical ? 0 : skillsCard.width + 10
        y: view.vertical ? skillsCard.height + 10 : 0
        width: parent.width - x
        height: parent.height - y

        Text {
            x: 12
            y: 12
            textFormat: Text.PlainText
            text: "Plugins"
            color: theme.text
            font.family: theme.titleFont
            font.pixelSize: 14
            font.weight: Font.DemiBold
        }
        Text {
            objectName: "pluginsCount"
            anchors.right: parent.right
            anchors.rightMargin: 12
            y: 15
            visible: plugins.hasClaude && plugins.error === ""
            textFormat: Text.PlainText
            text: plugins.loading && plugins.installed.length === 0 ? "lendo…"
                  : plugins.installed.length === 1 ? "1 instalado" : plugins.installed.length + " instalados"
            color: theme.dim
            font.family: theme.bodyFont
            font.pixelSize: 11
        }
        Text {
            objectName: "pluginsProblem"
            x: 12
            y: 38
            width: parent.width - 24
            visible: text !== ""
            wrapMode: Text.Wrap
            textFormat: Text.PlainText
            text: !plugins.hasClaude ? "Não achei o Claude Code nesta máquina. Instale-o para gerenciar os plugins por aqui."
                                     : plugins.error
            color: theme.muted
            font.family: theme.bodyFont
            font.pixelSize: 12
        }
        ListView {
            id: installedList
            objectName: "pluginList"
            x: 12
            y: 38
            width: parent.width - 24
            height: parent.height - y - 48
            visible: plugins.hasClaude && plugins.error === ""
            clip: true
            spacing: 4
            boundsBehavior: Flickable.StopAtBounds
            model: plugins.installed
            delegate: Rectangle {
                id: row
                required property var modelData
                readonly property bool asking: view.removing === modelData.id
                width: installedList.width
                height: 30 + (rowError.visible ? rowError.height + 4 : 0)
                radius: 9
                color: theme.pillFill
                opacity: plugins.busy ? 0.55 : 1
                enabled: !plugins.busy
                Text {
                    x: 9
                    height: 30
                    verticalAlignment: Text.AlignVCenter
                    width: parent.width - 9 - rowControls.width - 14
                    elide: Text.ElideRight
                    textFormat: Text.PlainText
                    text: row.asking ? "Remover " + row.modelData.name + "?" : (row.modelData.busy ? row.modelData.name + "…" : row.modelData.name)
                    color: row.modelData.enabled ? theme.text : theme.dim
                    font.family: theme.bodyFont
                    font.pixelSize: 12
                    font.weight: Font.Medium
                }
                Row {
                    id: rowControls
                    anchors.right: parent.right
                    anchors.rightMargin: 8
                    height: 30
                    spacing: 10
                    Text {
                        objectName: "pluginRemove_" + row.modelData.name
                        signal clicked()
                        visible: !row.asking
                        height: 30
                        verticalAlignment: Text.AlignVCenter
                        textFormat: Text.PlainText
                        text: "Remover"
                        color: theme.dim
                        font.family: theme.bodyFont
                        font.pixelSize: 11
                        onClicked: view.removing = row.modelData.id
                        TapHandler { onTapped: parent.clicked() }
                    }
                    ToggleSwitch {
                        objectName: "pluginSwitch_" + row.modelData.name
                        visible: !row.asking
                        anchors.verticalCenter: parent.verticalCenter
                        checked: row.modelData.enabled
                        onToggled: plugins.setEnabled(row.modelData.id, checked)
                    }
                    Text {
                        objectName: "pluginRemoveYes_" + row.modelData.name
                        signal clicked()
                        visible: row.asking
                        height: 30
                        verticalAlignment: Text.AlignVCenter
                        textFormat: Text.PlainText
                        text: "Sim"
                        color: theme.alertText
                        font.family: theme.bodyFont
                        font.pixelSize: 12
                        font.weight: Font.DemiBold
                        onClicked: { view.removing = ""; plugins.remove(row.modelData.id) }
                        TapHandler { onTapped: parent.clicked() }
                    }
                    Text {
                        objectName: "pluginRemoveNo_" + row.modelData.name
                        signal clicked()
                        visible: row.asking
                        height: 30
                        verticalAlignment: Text.AlignVCenter
                        textFormat: Text.PlainText
                        text: "Não"
                        color: theme.text
                        font.family: theme.bodyFont
                        font.pixelSize: 12
                        onClicked: view.removing = ""
                        TapHandler { onTapped: parent.clicked() }
                    }
                }
                Text {
                    id: rowError
                    objectName: "pluginError_" + row.modelData.name
                    x: 9
                    y: 28
                    width: parent.width - 18
                    visible: row.modelData.error !== ""
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: row.modelData.error
                    color: theme.alertText
                    font.family: theme.bodyFont
                    font.pixelSize: 11
                }
            }
        }
        PillButton {
            objectName: "pluginsAdd"
            x: 12
            y: parent.height - 40
            visible: plugins.hasClaude
            text: "Adicionar plugin…"
            primary: true
            onClicked: { view.removing = ""; view.adding = true }
        }
        Text {
            objectName: "pluginsNotice"
            x: 12 + 150
            y: parent.height - 40
            width: parent.width - x - 12
            height: 28
            verticalAlignment: Text.AlignVCenter
            visible: !view.vertical && text !== ""
            elide: Text.ElideRight
            textFormat: Text.PlainText
            text: plugins.notice
            color: theme.dim
            font.family: theme.bodyFont
            font.pixelSize: 11
        }
    }

    // ---- the catalogue ----
    Card {
        id: catalogCard
        visible: view.adding
        anchors.fill: parent

        PillButton {
            id: back
            objectName: "catalogBack"
            x: 12
            y: 10
            text: "‹ Voltar"
            onClicked: view.adding = false
        }
        Text {
            id: count
            objectName: "catalogCount"
            anchors.right: parent.right
            anchors.rightMargin: 12
            y: 10
            height: 28
            verticalAlignment: Text.AlignVCenter
            textFormat: Text.PlainText
            text: plugins.catalog.length + " de " + plugins.catalogTotal
            color: theme.dim
            font.family: theme.bodyFont
            font.pixelSize: 11
        }
        // Filter: beside "Voltar", or under it in the portrait island.
        Rectangle {
            id: filterBox
            x: view.vertical ? 12 : back.x + back.width + 10
            y: view.vertical ? 46 : 9
            width: (view.vertical ? parent.width - 12 : count.x - 10) - x
            height: 30
            radius: 12
            color: theme.codeBg
            border.width: 1
            border.color: field.activeFocus ? theme.primary : theme.line
            TextInput {
                id: field
                objectName: "catalogFilter"
                anchors.fill: parent
                anchors.leftMargin: 12
                anchors.rightMargin: 12
                verticalAlignment: TextInput.AlignVCenter
                clip: true
                color: theme.text
                selectionColor: theme.primary
                selectedTextColor: theme.primaryText
                font.family: theme.bodyFont
                font.pixelSize: 13
                maximumLength: 60
                onTextChanged: plugins.filter = text
                Keys.onEscapePressed: text !== "" ? text = "" : view.adding = false
                Text {
                    anchors.fill: parent
                    verticalAlignment: Text.AlignVCenter
                    visible: field.text === "" && !field.activeFocus
                    textFormat: Text.PlainText
                    text: "Procurar plugin…"
                    color: theme.dim
                    font: field.font
                    elide: Text.ElideRight
                }
            }
        }
        Text {
            objectName: "catalogEmpty"
            x: 12
            y: catalogList.y + 4
            width: parent.width - 24
            visible: plugins.catalog.length === 0
            wrapMode: Text.Wrap
            textFormat: Text.PlainText
            text: plugins.loading ? "Lendo o catálogo…"
                  : plugins.catalogTotal === 0 ? "Nenhum plugin disponível nos marketplaces que o Claude Code conhece."
                  : "Nenhum plugin com “" + plugins.filter + "”."
            color: theme.muted
            font.family: theme.bodyFont
            font.pixelSize: 12
        }
        ListView {
            id: catalogList
            objectName: "catalogList"
            x: 12
            y: filterBox.y + filterBox.height + 8
            width: parent.width - 24
            height: parent.height - y - 30
            clip: true
            spacing: 4
            boundsBehavior: Flickable.StopAtBounds
            model: view.adding ? plugins.catalog : []
            delegate: Rectangle {
                id: item
                required property var modelData
                width: catalogList.width
                height: 46 + (itemError.visible ? itemError.height + 2 : 0)
                radius: 9
                color: theme.pillFill
                Text {
                    id: itemName
                    x: 9
                    y: 6
                    textFormat: Text.PlainText
                    text: item.modelData.name
                    width: Math.min(implicitWidth, parent.width - 18 - install.width - 10)
                    elide: Text.ElideRight
                    color: theme.text
                    font.family: theme.bodyFont
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                }
                Text {
                    x: itemName.x + itemName.width + 8
                    y: 7
                    width: Math.max(0, parent.width - x - install.width - 18)
                    elide: Text.ElideRight
                    textFormat: Text.PlainText
                    text: item.modelData.marketplace
                    color: theme.dim
                    font.family: theme.bodyFont
                    font.pixelSize: 11
                }
                Text {
                    x: 9
                    y: 24
                    width: parent.width - 18 - install.width - 10
                    elide: Text.ElideRight
                    textFormat: Text.PlainText
                    text: item.modelData.description
                    color: theme.muted
                    font.family: theme.bodyFont
                    font.pixelSize: 11
                }
                PillButton {
                    id: install
                    objectName: "catalogInstall_" + item.modelData.name
                    anchors.right: parent.right
                    anchors.rightMargin: 8
                    y: 9
                    text: item.modelData.busy ? "Instalando…" : "Instalar"
                    opacity: plugins.busy && !item.modelData.busy ? 0.5 : 1
                    enabled: !plugins.busy
                    onClicked: plugins.install(item.modelData.id)
                }
                Text {
                    id: itemError
                    objectName: "catalogError_" + item.modelData.name
                    x: 9
                    y: 44
                    width: parent.width - 18
                    visible: item.modelData.error !== ""
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: item.modelData.error
                    color: theme.alertText
                    font.family: theme.bodyFont
                    font.pixelSize: 11
                }
            }
        }
        Text {
            objectName: "catalogNotice"
            x: 12
            y: parent.height - 24
            width: parent.width - 24
            elide: Text.ElideRight
            textFormat: Text.PlainText
            text: plugins.notice !== "" ? plugins.notice : "Vale para as sessões do Claude Code abertas depois da instalação."
            color: theme.dim
            font.family: theme.bodyFont
            font.pixelSize: 11
        }
    }
}
