#include "Links.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>

#ifdef Q_OS_WIN
#include <QByteArray>
#include <qt_windows.h>
#include <winioctl.h>
#include <cstring>
#include <string>
#endif

namespace farol::links {

#ifdef Q_OS_WIN

namespace {

// REPARSE_DATA_BUFFER of a mount point (the SDK only has it for drivers): the header, then where both names are
// in the buffer that follows, then the names.
struct MountPointHeader {
    ULONG tag;
    USHORT dataLength;   // of what follows this field and `reserved`
    USHORT reserved;
    USHORT substituteNameOffset, substituteNameLength, printNameOffset, printNameLength;   // in bytes
};

bool setJunction(const QString &target, const QString &link)
{
    const std::wstring print = QDir::toNativeSeparators(QDir::cleanPath(target)).toStdWString();
    const std::wstring substitute = LR"(\??\)" + print;   // how the system itself names a path
    const size_t substituteBytes = substitute.size() * sizeof(wchar_t), printBytes = print.size() * sizeof(wchar_t);
    const size_t names = substituteBytes + sizeof(wchar_t) + printBytes + sizeof(wchar_t);
    if (sizeof(MountPointHeader) + names > MAXIMUM_REPARSE_DATA_BUFFER_SIZE)
        return false;
    QByteArray buffer(qsizetype(sizeof(MountPointHeader) + names), '\0');
    MountPointHeader header{};
    header.tag = IO_REPARSE_TAG_MOUNT_POINT;
    header.dataLength = USHORT(4 * sizeof(USHORT) + names);
    header.substituteNameLength = USHORT(substituteBytes);
    header.printNameOffset = USHORT(substituteBytes + sizeof(wchar_t));
    header.printNameLength = USHORT(printBytes);
    std::memcpy(buffer.data(), &header, sizeof(header));
    std::memcpy(buffer.data() + sizeof(header), substitute.data(), substituteBytes);
    std::memcpy(buffer.data() + sizeof(header) + header.printNameOffset, print.data(), printBytes);

    const HANDLE folder = CreateFileW(reinterpret_cast<const wchar_t *>(QDir::toNativeSeparators(link).utf16()), GENERIC_WRITE, 0,
                                      nullptr, OPEN_EXISTING, FILE_FLAG_BACKUP_SEMANTICS | FILE_FLAG_OPEN_REPARSE_POINT, nullptr);
    if (folder == INVALID_HANDLE_VALUE)
        return false;
    DWORD returned = 0;
    const bool ok = DeviceIoControl(folder, FSCTL_SET_REPARSE_POINT, buffer.data(), DWORD(buffer.size()), nullptr, 0, &returned, nullptr);
    CloseHandle(folder);
    return ok;
}

} // namespace

bool isLink(const QString &path)
{
    const QFileInfo f(path);
    return f.isJunction() || f.isSymbolicLink();
}

QString target(const QString &path)
{
    const QFileInfo f(path);
    const QString to = f.isJunction() ? f.junctionTarget() : f.isSymbolicLink() ? f.symLinkTarget() : QString();
    return to.isEmpty() ? to : QDir::cleanPath(to);
}

bool make(const QString &target, const QString &link)
{
    if (!QDir::isAbsolutePath(target) || !QDir().mkdir(link))   // a junction is an empty folder that is told where to lead
        return false;
    if (setJunction(target, link))
        return true;
    QDir().rmdir(link);
    return false;
}

bool remove(const QString &link)
{
    if (!isLink(link))
        return false;
    return QDir().rmdir(link) || QFile::remove(link);   // a junction goes as the folder it is; a link to a file as a file
}

#else

bool isLink(const QString &path) { return QFileInfo(path).isSymbolicLink(); }

QString target(const QString &path)
{
    const QFileInfo f(path);
    return f.isSymbolicLink() ? QDir::cleanPath(f.symLinkTarget()) : QString();
}

bool make(const QString &target, const QString &link) { return QFile::link(target, link); }

bool remove(const QString &link) { return QFile::remove(link); }

#endif

} // namespace farol::links
