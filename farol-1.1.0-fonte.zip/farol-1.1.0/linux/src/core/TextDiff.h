#pragma once
#include <QString>

namespace farol {

// Unified diff by lines (LCS). Empty when a == b. Past 4 million cells (n*m) it degrades to "all removed, all added".
QString unifiedDiff(const QString &a, const QString &b, const QString &labelA, const QString &labelB, int context = 3);

} // namespace farol
