#include "BridgeReceiver.h"

#include <QCoreApplication>
#include <QDBusConnection>
#include <QDBusInterface>
#include <QDBusReply>
#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QTemporaryFile>
#include <QTimer>
#include <cstdio>

static const QString kPlugin = QStringLiteral("farol-bridge-spike");

static void say(const QString &s) { std::printf("%s\n", qPrintable(s)); std::fflush(stdout); }

static QDBusInterface scripting()
{
    return QDBusInterface(QStringLiteral("org.kde.KWin"), QStringLiteral("/Scripting"),
                          QStringLiteral("org.kde.kwin.Scripting"));
}

static bool loadAndStart(const QString &file, const QString &plugin)
{
    auto kwin = scripting();
    kwin.call(QStringLiteral("unloadScript"), plugin);  // leftover from a crashed run
    QDBusReply<int> id = kwin.call(QStringLiteral("loadScript"), file, plugin);
    say(QStringLiteral("loadScript(%1) -> %2").arg(plugin).arg(id.isValid() ? QString::number(id.value())
                                                                              : id.error().message()));
    if (!id.isValid() || id.value() < 0)
        return false;
    kwin.call(QStringLiteral("start"));
    return true;
}

// One-shot script: activate the first normal window whose resourceClass contains `needle`.
static int runActivate(QCoreApplication &app, const QString &needle)
{
    QTemporaryFile js(QDir::tempPath() + "/farol-activate-XXXXXX.js");
    js.setAutoRemove(false);
    if (!js.open()) return 1;
    js.write(QStringLiteral(
        "for (const w of workspace.windowList()) {"
        "  if (w.normalWindow && String(w.resourceClass).toLowerCase().includes(%1)) {"
        "    workspace.activeWindow = w; console.info('farol-activate: ' + w.caption); break; } }")
                 .arg(QString::fromUtf8(QJsonDocument(QJsonArray{needle.toLower()}).toJson(QJsonDocument::Compact))
                          .mid(1).chopped(1))
                 .toUtf8());
    js.close();
    const QString plugin = QStringLiteral("farol-activate-spike");
    const bool ok = loadAndStart(js.fileName(), plugin);
    QTimer::singleShot(500, &app, [&]() {
        scripting().call(QStringLiteral("unloadScript"), plugin);
        QFile::remove(js.fileName());
        app.quit();
    });
    app.exec();
    return ok ? 0 : 1;
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    const QStringList args = app.arguments();
    if (args.value(1) == "--activate")
        return runActivate(app, args.value(2));

    const int seconds = args.value(1, "10").toInt();
    BridgeReceiver receiver;
    auto bus = QDBusConnection::sessionBus();
    if (!bus.registerService(QStringLiteral("local.joao.Farol.Spike")) ||
        !bus.registerObject(QStringLiteral("/Bridge"), &receiver, QDBusConnection::ExportAllSlots)) {
        say("D-Bus registration failed: " + bus.lastError().message());
        return 1;
    }

    const QString script = QStringLiteral(FAROL_BRIDGE_DIR) + "/contents/code/main.js";
    if (!loadAndStart(script, kPlugin))
        return 1;

    QElapsedTimer clock;
    clock.start();
    QTimer::singleShot(seconds * 1000, &app, [&]() {
        QDBusReply<bool> unloaded = scripting().call(QStringLiteral("unloadScript"), kPlugin);
        const double rate = receiver.cursorCalls * 1000.0 / clock.elapsed();
        say(QStringLiteral("cursor calls=%1 rate=%2/s unloaded=%3")
                .arg(receiver.cursorCalls).arg(rate, 0, 'f', 1).arg(unloaded.isValid() && unloaded.value()));
        app.quit();
    });
    return app.exec();
}
