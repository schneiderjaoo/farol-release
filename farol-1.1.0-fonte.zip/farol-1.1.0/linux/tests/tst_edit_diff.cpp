#include <QtTest>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include "EditDiff.h"

using namespace farol;
using namespace Qt::StringLiterals;

namespace {

const QString kFile = u"/work/farol/notes.txt"_s;

QJsonObject hunk(const QStringList &lines, int oldStart = 1, int newStart = 1)
{
    int oldLines = 0, newLines = 0;
    for (const QString &l : lines) {
        oldLines += !l.startsWith(u'+');
        newLines += !l.startsWith(u'-');
    }
    return {{"oldStart", oldStart}, {"oldLines", oldLines}, {"newStart", newStart}, {"newLines", newLines},
            {"lines", QJsonArray::fromStringList(lines)}};
}

HookEvent toolEvent(const QString &name, const QString &tool, const QJsonObject &input, const QJsonValue &response = {},
                const QJsonValue &farolEdit = {})
{
    QJsonObject o{{"hook_event_name", name}, {"session_id", "s1"}, {"cwd", "/work/farol"}, {"tool_name", tool},
                  {"tool_input", input}, {"tool_use_id", "toolu_01"}};
    if (!response.isUndefined() && !response.isNull())
        o["tool_response"] = response;
    if (!farolEdit.isUndefined() && !farolEdit.isNull())
        o["farol_edit"] = farolEdit;
    return *HookEvent::parse(QJsonDocument(o).toJson(QJsonDocument::Compact));
}

QJsonObject counts(int added, int removed, bool cut = false)
{
    return {{"added", added}, {"removed", removed}, {"cut", cut}};
}

// The PostToolUse of an Edit as farol-hook sends it: the patch, the counts, no whole file.
HookEvent edited(const QJsonArray &patch, const QJsonValue &farolEdit = {})
{
    return toolEvent("PostToolUse", "Edit", {{"file_path", kFile}, {"replace_all", false}},
                 QJsonObject{{"filePath", kFile}, {"structuredPatch", patch}, {"userModified", false}, {"replaceAll", false}}, farolEdit);
}

// The rows as text, one a line, each with its kind in front: easier to read in a failure than a list of structs.
QString shown(const EditDiff &diff)
{
    QStringList out;
    for (const DiffRow &row : diff.rows)
        out << QString(row.kind) + row.text;
    return out.join(u'\n');
}

} // namespace

class TestEditDiff : public QObject {
    Q_OBJECT
private slots:
    void anEditGivesTheRowsOfItsPatch()
    {
        const auto diff = editDiffOf(edited({hunk({" alpha", "-beta", "+beta2", "+beta3", " gamma", " delta"})}, counts(2, 1)));
        QVERIFY(diff);
        QCOMPARE(diff->file, kFile);
        QVERIFY(!diff->created);
        QCOMPARE(diff->added, 2);
        QCOMPARE(diff->removed, 1);
        QVERIFY(!diff->cut);
        QCOMPARE(shown(*diff), u"@@@ -1,4 +1,5 @@\n alpha\n-beta\n+beta2\n+beta3\n gamma\n delta"_s);
        QCOMPARE(diff->rows.at(0).kind, QChar(u'@'));
        QCOMPARE(diff->rows.at(0).text, u"@@ -1,4 +1,5 @@"_s);
        QCOMPARE(diff->rows.at(2).kind, QChar(u'-'));
        QCOMPARE(diff->rows.at(2).text, u"beta"_s);
    }

    void aReplaceAllIsOneHunkWithEveryLine()
    {
        const auto diff = editDiffOf(edited({hunk({"-foo", "+qux", " bar", "-foo", "+qux", " baz", "-foo", "+qux"})}, counts(3, 3)));
        QVERIFY(diff);
        QCOMPARE(shown(*diff), u"@@@ -1,5 +1,5 @@\n-foo\n+qux\n bar\n-foo\n+qux\n baz\n-foo\n+qux"_s);
        QCOMPARE(diff->added, 3);
        QCOMPARE(diff->removed, 3);
    }

    void everyHunkGetsItsHead()
    {
        const auto diff = editDiffOf(edited({hunk({" a", "-b", "+c"}, 10, 10), hunk({"+d", " e"}, 80, 81)}));
        QVERIFY(diff);
        QCOMPARE(shown(*diff), u"@@@ -10,2 +10,2 @@\n a\n-b\n+c\n@@@ -80,1 +81,2 @@\n+d\n e"_s);
        QCOMPARE(diff->added, 2);                                  // no farol_edit: counted here
        QCOMPARE(diff->removed, 1);
    }

    // A Write that creates a file: farol-hook sends its lines as one hunk of additions.
    void aNewFileIsAllAdditions()
    {
        const QJsonObject made{{"oldStart", 0}, {"oldLines", 0}, {"newStart", 1}, {"newLines", 4},
                               {"lines", QJsonArray{"+alpha", "+beta", "+", "+delta"}}};
        const auto diff = editDiffOf(toolEvent("PostToolUse", "Write", {{"file_path", kFile}},
                                           QJsonObject{{"type", "create"}, {"filePath", kFile}, {"structuredPatch", QJsonArray{made}}},
                                           counts(4, 0)));
        QVERIFY(diff);
        QVERIFY(diff->created);
        QCOMPARE(diff->file, kFile);
        QCOMPARE(diff->added, 4);
        QCOMPARE(diff->removed, 0);
        QCOMPARE(shown(*diff), u"@@@ -0,0 +1,4 @@\n+alpha\n+beta\n+\n+delta"_s);
    }

    // An older farol-hook sends what Claude Code sent: no patch for a new file, its content twice.
    void aNewFileFromAnOlderHookIsReadFromItsContent()
    {
        const QJsonObject response{{"type", "create"}, {"filePath", kFile}, {"content", "alpha\nbeta\n\ndelta\n"},
                                   {"structuredPatch", QJsonArray{}}, {"originalFile", QJsonValue::Null}, {"userModified", false}};
        const auto diff = editDiffOf(toolEvent("PostToolUse", "Write", {{"file_path", kFile}, {"content", "alpha\nbeta\n\ndelta\n"}}, response));
        QVERIFY(diff);
        QVERIFY(diff->created);
        QCOMPARE(diff->added, 4);
        QCOMPARE(diff->removed, 0);
        QCOMPARE(shown(*diff), u"@@@ -0,0 +1,4 @@\n+alpha\n+beta\n+\n+delta"_s);

        QJsonObject bare = response;                               // the content only in what the tool was given
        bare.remove("content");
        const auto fromInput = editDiffOf(toolEvent("PostToolUse", "Write", {{"file_path", kFile}, {"content", "one\ntwo"}}, bare));
        QVERIFY(fromInput);
        QCOMPARE(shown(*fromInput), u"@@@ -0,0 +1,2 @@\n+one\n+two"_s);
        QCOMPARE(fromInput->added, 2);
    }

    void aWriteOverAFileShowsWhatChanged()
    {
        const QJsonObject response{{"type", "update"}, {"filePath", kFile},
                                   {"structuredPatch", QJsonArray{hunk({" alpha", "-beta2", "-beta3", "-gamma", "+omega", " delta"})}}};
        const auto diff = editDiffOf(toolEvent("PostToolUse", "Write", {{"file_path", kFile}}, response, counts(1, 3)));
        QVERIFY(diff);
        QVERIFY(!diff->created);
        QCOMPARE(diff->added, 1);
        QCOMPARE(diff->removed, 3);
        QCOMPARE(shown(*diff), u"@@@ -1,5 +1,3 @@\n alpha\n-beta2\n-beta3\n-gamma\n+omega\n delta"_s);
    }

    // The same content written again: an edit that changed nothing, which the step says ("sem alterações").
    void aWriteThatChangesNothingHasNoRows()
    {
        for (const QJsonValue &farolEdit : {QJsonValue(counts(0, 0)), QJsonValue()}) {
            const auto diff = editDiffOf(toolEvent("PostToolUse", "Write", {{"file_path", kFile}},
                                               QJsonObject{{"type", "update"}, {"filePath", kFile}, {"structuredPatch", QJsonArray{}}}, farolEdit));
            QVERIFY(diff);
            QVERIFY(!diff->created);
            QCOMPARE(diff->added, 0);
            QCOMPARE(diff->removed, 0);
            QVERIFY(diff->rows.isEmpty());
            QCOMPARE(diff->file, kFile);
        }
    }

    // A notebook cell has no patch: the island makes one from the cell before and after.
    void aNotebookCellIsDiffedHere()
    {
        const QString nb = u"/work/farol/nb.ipynb"_s;
        const QJsonObject replaced{{"new_source", "import os\nprint('two')\nprint('end')"}, {"old_source", "import os\nprint('one')\nprint('end')\n"},
                                   {"cell_type", "code"}, {"edit_mode", "replace"}, {"cell_id", "c1"}, {"notebook_path", nb}};
        const auto diff = editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {{"notebook_path", nb}, {"cell_id", "c1"}}, replaced));
        QVERIFY(diff);
        QCOMPARE(diff->file, nb);
        QVERIFY(!diff->created);
        QCOMPARE(shown(*diff), u"@@@ -1,3 +1,3 @@\n import os\n-print('one')\n+print('two')\n print('end')"_s);
        QCOMPARE(diff->added, 1);
        QCOMPARE(diff->removed, 1);
        QVERIFY(!diff->cut);

        // a new cell: every line of it was added
        const QJsonObject inserted{{"new_source", "print('three')\nprint('four')"}, {"cell_type", "code"}, {"edit_mode", "insert"},
                                   {"cell_id", "f10285da"}, {"notebook_path", nb}};
        const auto added = editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {{"notebook_path", nb}}, inserted));
        QVERIFY(added);
        QCOMPARE(shown(*added), u"@@@ -0,0 +1,2 @@\n+print('three')\n+print('four')"_s);
        QCOMPARE(added->added, 2);
        QCOMPARE(added->removed, 0);

        // a cell that was empty, and one that was emptied: no line of nothing is counted
        const auto filled = editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {{"notebook_path", nb}},
                                                 QJsonObject{{"new_source", "a\nb"}, {"old_source", ""}, {"edit_mode", "replace"}}));
        QVERIFY(filled);
        QCOMPARE(shown(*filled), u"@@@ -0,0 +1,2 @@\n+a\n+b"_s);
        QCOMPARE(filled->removed, 0);
        const auto emptied = editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {{"notebook_path", nb}},
                                                  QJsonObject{{"new_source", ""}, {"old_source", "a\nb\n"}, {"edit_mode", "replace"}}));
        QVERIFY(emptied);
        QCOMPARE(shown(*emptied), u"@@@ -1,2 +0,0 @@\n-a\n-b"_s);
        QCOMPARE(emptied->added, 0);
        QCOMPARE(emptied->removed, 2);

        // the path from what the tool was given, a cell farol-hook cut, and a cell left as it was
        QJsonObject bare = replaced;
        bare.remove("notebook_path");
        const auto cut = editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {{"notebook_path", nb}}, bare, QJsonObject{{"cut", true}}));
        QVERIFY(cut);
        QCOMPARE(cut->file, nb);
        QVERIFY(cut->cut);
        QCOMPARE(cut->added, 1);
        const auto same = editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {{"notebook_path", nb}},
                                           QJsonObject{{"new_source", "x = 1"}, {"old_source", "x = 1\n"}, {"edit_mode", "replace"}}));
        QVERIFY(same);
        QVERIFY(same->rows.isEmpty());
        QCOMPARE(same->added + same->removed, 0);
    }

    // A hook installed before this one sends everything: the whole file, the whole patch, no counts.
    void anUnslimmedPayloadIsCountedAndCutHere()
    {
        QStringList lines;
        for (int i = 0; i < 6000; ++i)
            lines << u"-line %1 of the big file"_s.arg(i, 5, 10, QLatin1Char('0'));
        lines << u"+tiny now"_s;
        const QJsonObject response{{"type", "update"}, {"filePath", kFile}, {"content", "tiny now\n"},
                                   {"structuredPatch", QJsonArray{hunk(lines)}}, {"originalFile", QString(450000, u'x')}, {"userModified", false}};
        const auto diff = editDiffOf(toolEvent("PostToolUse", "Write", {{"file_path", kFile}, {"content", "tiny now\n"}}, response));
        QVERIFY(diff);
        QCOMPARE(diff->added, 1);                                  // over the whole patch,
        QCOMPARE(diff->removed, 6000);
        QVERIFY(diff->cut);                                        // of which the first 300 lines are kept
        QCOMPARE(diff->rows.size(), kDiffMaxLines + 1);
        QCOMPARE(diff->rows.first().text, u"@@ -1,6000 +1,1 @@"_s);
        QCOMPARE(diff->rows.last().text, u"line 00299 of the big file"_s);
    }

    void theCapCountsLinesOverAllTheHunksNotTheirHeads()
    {
        QJsonArray patch;
        for (int h = 0; h < 4; ++h) {
            QStringList lines;
            for (int i = 0; i < 100; ++i)
                lines << u"+h%1 line %2"_s.arg(h).arg(i);
            patch << hunk(lines, h * 1000 + 1, h * 1000 + 1);
        }
        const auto all = editDiffOf(edited({patch.at(0), patch.at(1), patch.at(2)}));
        QVERIFY(all);
        QVERIFY(!all->cut);                                        // exactly 300 lines: whole
        QCOMPARE(all->rows.size(), 303);
        const auto more = editDiffOf(edited(patch));
        QVERIFY(more);
        QVERIFY(more->cut);
        QCOMPARE(more->rows.size(), 303);                          // a hunk with no line left has no head either
        QCOMPARE(more->rows.last().text, u"h2 line 99"_s);
        QCOMPARE(more->added, 400);
    }

    void aLongLineIsCut()
    {
        const auto diff = editDiffOf(edited({hunk({u"+"_s + QString(239, u'x'), u"-"_s + QString(5000, u'y'), u" short"_s})}));
        QVERIFY(diff);
        QVERIFY(diff->cut);
        QCOMPARE(diff->rows.at(1).text, QString(239, u'x'));       // 240 with its marker: whole
        QCOMPARE(diff->rows.at(2).text, QString(239, u'y'));
        QCOMPARE(diff->rows.at(3).text, u"short"_s);
        QVERIFY(!editDiffOf(edited({hunk({u"+"_s + QString(239, u'x')})}))->cut);

        // never through a surrogate pair, whichever half the cut falls on
        for (const QString &head : {QString(), u"a"_s}) {
            const auto faces = editDiffOf(edited({hunk({u"+"_s + head + u"\U0001F600"_s.repeated(200)})}));
            const QString text = faces->rows.at(1).text;
            QVERIFY(text.size() == 239 || text.size() == 238);
            QCOMPARE(QString::fromUtf8(text.toUtf8()), text);
            QVERIFY(faces->cut);
        }
    }

    // farol-hook counted before it cut: its numbers are the edit's, whatever is left of the patch.
    void theHooksCountsWinOverWhatIsLeftOfThePatch()
    {
        const auto diff = editDiffOf(edited({hunk({"-a", "+b"})}, counts(450, 250, true)));
        QVERIFY(diff);
        QCOMPARE(diff->added, 450);
        QCOMPARE(diff->removed, 250);
        QVERIFY(diff->cut);                                        // it says so, though these rows are whole
        QCOMPARE(diff->rows.size(), 3);
    }

    // The lines of a file are shown one a row, as they are: nothing in them may move, hide or reorder the text.
    void everyLineIsSanitised_data()
    {
        QTest::addColumn<QString>("line");
        QTest::addColumn<QString>("text");
        const QString bad(QChar(0xFFFD));
        QTest::newRow("plain") << u"+int main()"_s << u"int main()"_s;
        QTest::newRow("markup stays as written") << u"+<b>x</b> &amp; <img src=\"http://example.org/a.png\">"_s
                                                 << u"<b>x</b> &amp; <img src=\"http://example.org/a.png\">"_s;
        QTest::newRow("tab") << u"+\tif (x)\treturn;"_s << u"    if (x)    return;"_s;
        QTest::newRow("escape sequence") << u"-\u001b[31mred\u001b[0m"_s << bad + u"[31mred"_s + bad + u"[0m"_s;
        QTest::newRow("nul and bell") << (u"+a"_s + QChar(0) + u"b\u0007"_s) << (u"a"_s + bad + u"b"_s + bad);
        QTest::newRow("c1 controls") << u"+a\u0085b\u009bc"_s << (u"a"_s + bad + u"b"_s + bad + u"c"_s);
        // (written as numbers: the compiler warns about a bidi control in a source file, and nobody would see it there)
        const auto ch = [](char16_t c) { return QString(QChar(c)); };
        QTest::newRow("bidi override") << (u"+access = "_s + ch(0x202E) + u"\"user\""_s + ch(0x202C) + u";"_s)
                                       << (u"access = "_s + bad + u"\"user\""_s + bad + u";"_s);
        QTest::newRow("bidi embeddings") << (u"+"_s + ch(0x202A) + ch(0x202B) + ch(0x202D)) << bad.repeated(3);
        QTest::newRow("bidi isolates") << (u"+"_s + ch(0x2066) + u"a"_s + ch(0x2067) + u"b"_s + ch(0x2068) + u"c"_s + ch(0x2069))
                                       << (bad + u"a"_s + bad + u"b"_s + bad + u"c"_s + bad);
        QTest::newRow("bidi marks") << (u"+a"_s + ch(0x200E) + u"b"_s + ch(0x200F) + u"c"_s + ch(0x061C) + u"d"_s)
                                    << (u"a"_s + bad + u"b"_s + bad + u"c"_s + bad + u"d"_s);
        QTest::newRow("line and paragraph separators") << (u"+a"_s + ch(0x2028) + u"b"_s + ch(0x2029) + u"c"_s)
                                                       << (u"a"_s + bad + u"b"_s + bad + u"c"_s);
        QTest::newRow("carriage return in the middle") << u"+a\rb"_s << (u"a"_s + bad + u"b"_s);
        QTest::newRow("windows line ending") << u"+int x;\r"_s << u"int x;"_s;
        QTest::newRow("half a surrogate pair") << (u"+a"_s + QChar(0xD83D) + u"b"_s + QChar(0xDE00)) << (u"a"_s + bad + u"b"_s + bad);
        const QString joined = u"😀 ação e"_s + ch(0x200D) + u"é"_s;        // the emoji joiner is not a bidi control
        QTest::newRow("a whole pair, accents, a joiner") << (u"+"_s + joined) << joined;
        QTest::newRow("right to left letters stay") << u"+שלום"_s << u"שלום"_s;
        QTest::newRow("an empty line") << u"+"_s << QString();
        QTest::newRow("a line without a marker") << QString() << QString();
        QTest::newRow("the note of a patch") << u"\\ No newline at end of file"_s << u"\\ No newline at end of file"_s;
    }

    void everyLineIsSanitised()
    {
        QFETCH(QString, line);
        QFETCH(QString, text);
        const auto diff = editDiffOf(edited({hunk({line})}));
        QVERIFY(diff);
        QCOMPARE(diff->rows.size(), 2);
        QCOMPARE(diff->rows.at(1).text, text);
        const QChar marker = line.isEmpty() ? QChar(u' ') : line.at(0);
        QCOMPARE(diff->rows.at(1).kind, marker == u'+' || marker == u'-' ? marker : QChar(u' '));
    }

    // What a JSON line may not bring this far (the half of a pair, a NUL), straight into the function.
    void aLineIsSanitisedWhateverItHolds()
    {
        const QString bad(QChar(0xFFFD));
        QCOMPARE(diffText(u"a"_s + QChar(0xD83D) + u"b"_s + QChar(0xDE00) + u"c"_s + QChar(0xD83D)), u"a"_s + bad + u"b"_s + bad + u"c"_s + bad);
        QCOMPARE(diffText(QString(3, QChar(0))), bad.repeated(3));
        QCOMPARE(diffText(u"\t"_s.repeated(3)), QString(12, u' '));
        QCOMPARE(diffText(u"a\r\r"_s), u"a"_s + bad);                   // one line ending, not two
        QCOMPARE(diffText(QString()), QString());
    }

    void aCellAndAFileNameAreSanitisedToo()
    {
        const QString bad(QChar(0xFFFD)), rlo(QChar(0x202E));        // a right-to-left override
        const QJsonObject cell{{"new_source", u"x\t= 1"_s + rlo}, {"edit_mode", "insert"}, {"notebook_path", u"/w/a"_s + rlo + u"b\nc.ipynb"_s}};
        const auto diff = editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {}, cell));
        QVERIFY(diff);
        QCOMPARE(diff->rows.at(1).text, u"x    = 1"_s + bad);
        QCOMPARE(diff->file, u"/w/a"_s + bad + u"b"_s + bad + u"c.ipynb"_s);
    }

    // The last guard of farol-hook sent the counts without the patch: the step still says how much changed.
    void countsWithoutAPatchGiveNoRows()
    {
        const auto diff = editDiffOf(toolEvent("PostToolUse", "Edit", {}, {}, counts(12, 3, true)));
        QVERIFY(diff);
        QCOMPARE(diff->added, 12);
        QCOMPARE(diff->removed, 3);
        QVERIFY(diff->rows.isEmpty());
        QVERIFY(diff->file.isEmpty());
    }

    void aShapeItDoesNotKnowGivesNothing()
    {
        const QJsonObject input{{"file_path", kFile}};
        const QJsonObject good{{"filePath", kFile}, {"structuredPatch", QJsonArray{hunk({"+a"})}}};
        QVERIFY(editDiffOf(toolEvent("PostToolUse", "Edit", input, good)));
        QVERIFY(editDiffOf(toolEvent("PostToolUse", "MultiEdit", input, good)));
        // not the end of a file tool
        QVERIFY(!editDiffOf(toolEvent("PreToolUse", "Edit", input, good)));
        QVERIFY(!editDiffOf(toolEvent("PostToolUseFailure", "Edit", input, good)));
        QVERIFY(!editDiffOf(toolEvent("PermissionRequest", "Write", input, good)));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Bash", {{"command", "sed -i s/a/b/ notes.txt"}}, good)));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Read", input, QJsonObject{{"type", "text"}, {"file", QJsonObject{{"content", "a\n"}}}})));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "", input, good)));
        // a file tool whose answer is not what it is today
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Edit", input)));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Edit", input, QStringLiteral("The file was updated"))));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Edit", input, QJsonObject{{"filePath", kFile}})));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Edit", input, QJsonObject{{"structuredPatch", "@@ -1 +1 @@"}})));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Edit", input, QJsonObject{{"structuredPatch", QJsonArray{"@@ -1 +1 @@", 3}}})));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Edit", input, QJsonObject{{"structuredPatch", QJsonArray{QJsonObject{{"lines", "+a"}}}}})));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "Write", input, QJsonObject{{"type", "create"}, {"structuredPatch", QJsonArray{}}})));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {}, QJsonObject{{"old_source", "x"}, {"edit_mode", "replace"}})));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {}, QJsonObject{{"new_source", 3}})));
        QVERIFY(!editDiffOf(toolEvent("PostToolUse", "NotebookEdit", {}, QJsonObject{{"new_source", ""}, {"edit_mode", "delete"}})));
        // lines that are no text are passed over, the rest of the hunk is read
        const auto mixed = editDiffOf(toolEvent("PostToolUse", "Edit", input,
                                            QJsonObject{{"structuredPatch", QJsonArray{QJsonObject{{"lines", QJsonArray{"+a", 7, QJsonValue::Null, "-b"}}}}}}));
        QVERIFY(mixed);
        QCOMPARE(shown(*mixed), u"@@@ -0,0 +0,0 @@\n+a\n-b"_s);
        QCOMPARE(mixed->file, kFile);
    }
};

QTEST_APPLESS_MAIN(TestEditDiff)
#include "tst_edit_diff.moc"
