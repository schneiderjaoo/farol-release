#include <QtTest>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include "SessionTitle.h"

using namespace farol;

class TestSessionTitle : public QObject {
    Q_OBJECT
    QTemporaryDir dir;

    QString transcript(const QByteArrayList &lines) const
    {
        static int n = 0;
        const QString path = dir.path() + QStringLiteral("/t%1.jsonl").arg(++n);
        QFile f(path);
        if (f.open(QIODevice::WriteOnly))
            f.write(lines.join('\n') + '\n');
        return path;
    }
    static QByteArray entry(const QJsonObject &o) { return QJsonDocument(o).toJson(QJsonDocument::Compact); }
    static QByteArray message(int size = 200)
    {
        return entry({{"type", "assistant"}, {"message", QJsonObject{{"content", QString(size, 'x')}}}});
    }
    static QByteArray aiTitle(const QString &title) { return entry({{"type", "ai-title"}, {"aiTitle", title}, {"sessionId", "s"}}); }

private slots:
    // What Claude Code 2.1 writes: the title again at every turn, between the messages.
    void theNewestAiTitleIsTheName()
    {
        const QString path = transcript({message(), aiTitle("Primeiro nome"),
                                         entry({{"type", "last-prompt"}, {"lastPrompt", "a -title\" in a prompt"}}),
                                         message(), aiTitle("Limpeza de sessões inativas"), message()});
        QCOMPARE(sessionTitle(path), QStringLiteral("Limpeza de sessões inativas"));
    }

    void aTitleGivenByTheUserWins()
    {
        const QString path = transcript({entry({{"type", "custom-title"}, {"customTitle", "Meu nome"}}), aiTitle("Nome da IA")});
        QCOMPARE(sessionTitle(path), QStringLiteral("Meu nome"));
    }

    void noTitleYetAndUnreadableFilesGiveNothing()
    {
        QCOMPARE(sessionTitle(transcript({message(), message()})), QString());
        QCOMPARE(sessionTitle(transcript({aiTitle("   "), "not json -title\""})), QString());
        QCOMPARE(sessionTitle(dir.path() + "/missing.jsonl"), QString());
        QCOMPARE(sessionTitle(dir.path()), QString());                    // a folder
        QCOMPARE(sessionTitle(QString()), QString());
    }

    void aLongTitleIsOneClippedLine()
    {
        const QString title = sessionTitle(transcript({aiTitle("  two\nlines " + QString(200, 'y'))}));
        QCOMPARE(title.size(), 80);
        QVERIFY(title.startsWith("two lines y"));
    }

    // The context in use is what the last answer of the main conversation was sent with.
    void contextIsTheInputOfTheLastMainAnswer()
    {
        const auto answer = [](int input, int cacheRead, int cacheNew, bool sidechain = false) {
            return entry({{"type", "assistant"}, {"isSidechain", sidechain},
                          {"message", QJsonObject{{"model", "claude-opus-5-5"},
                                                  {"usage", QJsonObject{{"input_tokens", input}, {"cache_read_input_tokens", cacheRead},
                                                                        {"cache_creation_input_tokens", cacheNew}, {"output_tokens", 900}}}}}});
        };
        const QString path = transcript({answer(10, 1000, 500), aiTitle("Nome"),
                                         entry({{"type", "user"}, {"message", QJsonObject{{"content", "the word \"usage\" in a prompt"}}}}),
                                         answer(4, 346579, 1078), answer(3, 20000, 100, true)});   // the last one is a subagent's
        const TranscriptInfo info = readTranscript(path);
        QCOMPARE(info.contextTokens, 4 + 346579 + 1078);
        QCOMPARE(info.model, QStringLiteral("claude-opus-5-5"));
        QCOMPARE(info.title, QStringLiteral("Nome"));
        QCOMPARE(readTranscript(transcript({aiTitle("Nome"), message()})).contextTokens, 0);   // no answer yet
        QCOMPARE(readTranscript(dir.path() + "/missing.jsonl").contextTokens, 0);
    }

    // Only the end of a long transcript is read: the title is found there, and a line cut in half is not parsed.
    void onlyTheEndOfABigTranscriptIsRead()
    {
        QByteArrayList lines{aiTitle("Far away")};
        for (int i = 0; i < 40; ++i)
            lines << message(10000);                                      // 400 kB: the first title is out of reach
        QCOMPARE(sessionTitle(transcript(lines)), QString());
        lines.insert(30, aiTitle("Near the end"));
        QCOMPARE(sessionTitle(transcript(lines)), QStringLiteral("Near the end"));
    }
};

QTEST_GUILESS_MAIN(TestSessionTitle)
#include "tst_session_title.moc"
