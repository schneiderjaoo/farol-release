#pragma once
#include <QStringList>

namespace farol {

// Same 28 names SoundEngine.swift preloads.
inline const QStringList &soundNames()
{
    static const QStringList names = {
        "peek", "open", "close", "hover", "blip", "slap", "annoyed", "dizzy", "greet",
        "work", "finish", "error", "approval", "question", "approve", "gulp", "tick",
        "send", "love", "pop", "proud", "wink", "yawn", "attach", "think", "search",
        "rate", "sleep"};
    return names;
}

} // namespace farol
