import QtQuick

// The diff of one edit (view "diff"): opened by a click on the step of an edit in the session card, or on the card's
// "N alterações"; "Voltar" goes back there. The head names the file and the session, says how many lines the edit
// added and removed, and walks the other diffs the session keeps (context object `diffs`, core/EditDiffs). Under it
// the lines, one a row: what a file holds is shown as text, never as markup. A long line is not wrapped; the list
// is flicked sideways to read it.
Item {
    id: view
    readonly property bool vertical: appState.vertical
    readonly property real sideX: vertical ? 12 : 16         // Lumi lives on the rail, outside the card
    readonly property color added: theme.ok
    readonly property color removed: theme.alert

    // ‹ and ›
    component Arrow: Rectangle {
        id: arrow
        property string glyph: ""
        signal clicked()
        anchors.verticalCenter: parent.verticalCenter
        width: 22
        height: 22
        radius: 8
        color: !enabled ? "transparent" : (arrowHover.hovered ? theme.pillHoverFill : theme.pillFill)
        Text {
            anchors.centerIn: parent
            textFormat: Text.PlainText
            text: arrow.glyph
            color: arrow.enabled ? theme.text : theme.dim
            font.family: theme.bodyFont
            font.pixelSize: 15
        }
        HoverHandler { id: arrowHover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: arrow.clicked() }
    }

    Card { anchors.fill: parent }

    // One row in the landscape island; in the portrait one "Voltar" and the file, then the rest under them.
    Flow {
        id: head
        x: view.sideX
        y: 10
        width: parent.width - 2 * view.sideX
        spacing: 8

        PillButton {
            id: back
            objectName: "diffBack"
            text: "Voltar"
            onClicked: diffs.close()
        }

        // the file, and under it the session that edited it
        Column {
            id: who
            visible: diffs.active
            // what "Voltar" leaves and, in the landscape island, what comes after the name needs
            readonly property real after: (counts.visible ? counts.width + head.spacing : 0) + (isNew.visible ? isNew.width + head.spacing : 0)
                                          + (walk.visible ? walk.width + head.spacing : 0)
            width: Math.max(60, head.width - back.width - head.spacing - (view.vertical ? 0 : after) - 1)
            height: 28
            Text {
                objectName: "diffFile"
                width: parent.width
                height: 16
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideMiddle          // the ending says what kind of file it is
                textFormat: Text.PlainText
                text: diffs.fileName
                color: theme.text
                font.family: theme.bodyFont
                font.pixelSize: 13
                font.weight: Font.DemiBold
            }
            Text {
                objectName: "diffSession"
                width: parent.width
                height: 12
                verticalAlignment: Text.AlignVCenter
                elide: Text.ElideRight
                textFormat: Text.PlainText
                text: diffs.session
                color: theme.muted
                font.family: theme.bodyFont
                font.pixelSize: 10
            }
        }

        Row {
            id: counts
            objectName: "diffCounts"
            visible: diffs.active
            height: 28
            spacing: 6
            Text {
                objectName: "diffAdded"
                height: parent.height
                verticalAlignment: Text.AlignVCenter
                textFormat: Text.PlainText
                text: "+" + diffs.added
                color: theme.ok
                font.family: theme.bodyFont
                font.pixelSize: 12
                font.weight: Font.DemiBold
            }
            Text {
                objectName: "diffRemoved"
                height: parent.height
                verticalAlignment: Text.AlignVCenter
                textFormat: Text.PlainText
                text: "−" + diffs.removed
                color: theme.alert
                font.family: theme.bodyFont
                font.pixelSize: 12
                font.weight: Font.DemiBold
            }
        }

        Text {
            id: isNew
            objectName: "diffCreated"
            visible: diffs.active && diffs.created
            height: 28
            verticalAlignment: Text.AlignVCenter
            textFormat: Text.PlainText
            text: "arquivo novo"
            color: theme.muted
            font.family: theme.bodyFont
            font.pixelSize: 11
        }

        // the other diffs of the session, oldest first; a diff that newer ones pushed out has no place among them
        Row {
            id: walk
            visible: diffs.active && (diffs.count > 1 || diffs.position < 0)
            height: 28
            spacing: 4
            Arrow {
                objectName: "diffPrev"
                glyph: "‹"
                enabled: diffs.position > 0
                onClicked: diffs.step(-1)
            }
            Text {
                objectName: "diffPlace"
                height: parent.height
                verticalAlignment: Text.AlignVCenter
                textFormat: Text.PlainText
                text: (diffs.position >= 0 ? diffs.position + 1 : "—") + " de " + diffs.count
                color: theme.muted
                font.family: theme.bodyFont
                font.pixelSize: 11
            }
            Arrow {
                objectName: "diffNext"
                glyph: "›"
                enabled: diffs.position < diffs.count - 1
                onClicked: diffs.step(1)
            }
        }
    }

    Rectangle {
        id: body
        visible: diffs.active
        x: view.sideX
        y: head.y + head.height + 8
        width: parent.width - 2 * view.sideX
        height: Math.max(0, parent.height - y - 10 - (foot.visible ? foot.height + 4 : 0))
        radius: 8
        color: theme.codeBg
        border.color: theme.line
        border.width: 1

        TextMetrics {
            id: glyph
            font.family: theme.monoFont
            font.pixelSize: 11
            text: "0"
        }

        ListView {
            id: list
            objectName: "diffRows"
            anchors.fill: parent
            anchors.leftMargin: 1
            anchors.rightMargin: 1
            anchors.topMargin: 5
            anchors.bottomMargin: 5
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            flickableDirection: Flickable.HorizontalAndVerticalFlick
            model: diffs.rows
            // As wide as its longest line: first by the count of its characters, then by the rows as they are drawn
            // (a character of another script is not as wide as the font's own).
            readonly property real textX: 20
            property real widest: 0
            property var widestOf: 0     // the diff `widest` was measured on
            function measured(width) {
                if (widestOf !== diffs.id) {
                    widestOf = diffs.id
                    widest = 0
                }
                if (width > widest)
                    widest = width
            }
            contentWidth: Math.max(width, widest, textX + diffs.columns * glyph.advanceWidth + 8)

            delegate: Rectangle {
                id: row
                required property var modelData
                required property int index
                objectName: "diffRow" + index
                width: list.contentWidth
                height: 15
                color: modelData.kind === "+" ? Qt.rgba(view.added.r, view.added.g, view.added.b, 0.16)
                       : modelData.kind === "-" ? Qt.rgba(view.removed.r, view.removed.g, view.removed.b, 0.16) : theme.codeBg
                Text {
                    objectName: "diffRowMark" + row.index
                    x: 7
                    height: parent.height
                    verticalAlignment: Text.AlignVCenter
                    textFormat: Text.PlainText
                    text: row.modelData.kind === "+" ? "+" : row.modelData.kind === "-" ? "−" : ""
                    color: row.modelData.kind === "+" ? theme.ok : theme.alert
                    font.family: theme.monoFont
                    font.pixelSize: 11
                }
                Text {
                    id: line
                    objectName: "diffRowText" + row.index
                    x: list.textX
                    height: parent.height
                    verticalAlignment: Text.AlignVCenter
                    textFormat: Text.PlainText
                    text: row.modelData.text
                    color: row.modelData.kind === "@" ? theme.dim : theme.text
                    font.family: theme.monoFont
                    font.pixelSize: 11
                    onContentWidthChanged: () => list.measured(line.x + line.contentWidth + 8)
                    Component.onCompleted: list.measured(line.x + line.contentWidth + 8)
                }
            }
        }

        Connections {
            target: diffs
            function onCurrentChanged() { list.contentX = 0 }   // another diff starts at the start of its lines
        }
    }

    Text {
        id: foot
        objectName: "diffCut"
        visible: diffs.active && diffs.cut
        x: view.sideX
        y: parent.height - 10 - height
        width: parent.width - 2 * view.sideX
        height: 14
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
        textFormat: Text.PlainText
        text: "Diff cortado: só as primeiras 300 linhas"
        color: theme.muted
        font.family: theme.bodyFont
        font.pixelSize: 11
    }

    // reached with nothing open (the view asked for by its name)
    Text {
        objectName: "diffEmpty"
        visible: !diffs.active
        x: view.sideX
        y: head.y + head.height + 12
        width: parent.width - 2 * view.sideX
        wrapMode: Text.Wrap
        textFormat: Text.PlainText
        text: "Nenhuma alteração aberta. As edições de uma sessão aparecem nos passos do cartão dela."
        color: theme.muted
        font.family: theme.bodyFont
        font.pixelSize: 13
    }
}
