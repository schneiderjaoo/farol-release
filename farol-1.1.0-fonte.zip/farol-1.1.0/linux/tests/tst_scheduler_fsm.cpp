#include <QtTest>
#include "FakeScheduler.h"
#include <memory>
#include "HoverDebouncer.h"
#include "IslandStateMachine.h"

using farol::HoverDebouncer;
using farol::IslandStateMachine;
using S = IslandStateMachine::State;

static QString str(S s)
{
    switch (s) {
    case S::Hidden: return "hidden";
    case S::Petit: return "petit";
    case S::Home: return "home";
    case S::Coucou: return "coucou";
    }
    return "?";
}

class TestFsm : public QObject {
    Q_OBJECT
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandStateMachine> fsm;
    QStringList log;

private slots:
    void init()
    {
        sched = std::make_unique<FakeScheduler>();
        fsm = std::make_unique<IslandStateMachine>(*sched);   // always starts in Hidden
        log.clear();
        fsm->onTransition = [this](S a, S b) { log << str(a) + ">" + str(b); };
    }

    void launchGoesToCoucou()
    {
        fsm->launch();
        QCOMPARE(log, QStringList{"hidden>coucou"});
        QCOMPARE(sched->pending(), 0);
    }

    void hoverFromHiddenPeeksThenHidesAfter60s()
    {
        fsm->mouseEntered();
        QCOMPARE(log, QStringList{"hidden>petit"});
        fsm->mouseLeft();
        sched->advance(59999);
        QVERIFY(fsm->state() == S::Petit);
        sched->advance(1);
        QVERIFY(fsm->state() == S::Hidden);
        QCOMPARE(log, (QStringList{"hidden>petit", "petit>hidden"}));
    }

    void enteringCompactCancelsHideTimer()
    {
        fsm->mouseEntered();
        fsm->mouseLeft();
        sched->advance(30000);
        fsm->mouseEntered();
        sched->advance(120000);
        QVERIFY(fsm->state() == S::Petit);
        QCOMPARE(sched->pending(), 0);
    }

    void clickOnlyWorksFromPetit()
    {
        fsm->click();                       // hidden: ignored
        QVERIFY(fsm->state() == S::Hidden);
        fsm->mouseEntered();                // -> petit
        fsm->click();
        QVERIFY(fsm->state() == S::Home);
        fsm->click();                       // home: ignored
        QCOMPARE(log, (QStringList{"hidden>petit", "petit>home"}));
    }

    void homeCollapsesTo_petitAfter15s_andHoverCancels()
    {
        fsm->mouseEntered();
        fsm->click();
        fsm->mouseLeft();
        sched->advance(14999);
        QVERIFY(fsm->state() == S::Home);
        fsm->mouseEntered();                // cancels the pending collapse
        sched->advance(60000);
        QVERIFY(fsm->state() == S::Home);
        fsm->mouseLeft();
        sched->advance(15000);
        QVERIFY(fsm->state() == S::Petit);
    }

    void greetingCollapsesAfter600msWhenNoHover()
    {
        fsm->launch();
        fsm->greetComplete();
        sched->advance(599);
        QVERIFY(fsm->state() == S::Coucou);
        sched->advance(1);
        QVERIFY(fsm->state() == S::Petit);
    }

    void greetingHoverExtendsTo10sAndGreetCompleteDoesNotOverride()
    {
        fsm->launch();
        fsm->mouseEntered();                // hover while greeting -> 10 s
        fsm->greetComplete();               // must NOT shorten it to 600 ms
        sched->advance(9999);
        QVERIFY(fsm->state() == S::Coucou);
        sched->advance(1);
        QVERIFY(fsm->state() == S::Petit);
    }

    void leavingDuringGreetingInterruptsAtOnce()
    {
        fsm->launch();
        fsm->mouseEntered();
        fsm->mouseLeft();
        QVERIFY(fsm->state() == S::Petit);
        const int transitions = log.size();
        sched->advance(120000);             // the greeting timers were cancelled
        QVERIFY(fsm->state() == S::Petit);
        QCOMPARE(log.size(), transitions);
    }

    void revealFromHiddenShowsCompactAndSchedulesHide()
    {
        fsm->reveal();
        QVERIFY(fsm->state() == S::Petit);
        sched->advance(60000);
        QVERIFY(fsm->state() == S::Hidden);
        fsm->mouseEntered();                // -> petit again
        const int n = log.size();
        fsm->reveal();                      // not hidden: ignored
        QCOMPARE(log.size(), n);
    }

    // Farol: with hiding turned off the compact island stays.
    void withoutHideWhenIdleTheCompactIslandStays()
    {
        fsm->mouseEntered();                          // Hidden -> Petit
        fsm->setHideWhenIdle(false);
        fsm->mouseLeft();
        sched->advance(10 * 60000);
        QVERIFY(fsm->state() == S::Petit);
        fsm->setHideWhenIdle(true);                   // back on: the minute starts when the pointer next leaves
        sched->advance(60000);
        QVERIFY(fsm->state() == S::Petit);
        fsm->mouseLeft();
        sched->advance(60000);
        QVERIFY(fsm->state() == S::Hidden);
        fsm->setHideWhenIdle(false);                  // turned off while hidden: reveal() brings it back to stay
        QVERIFY(fsm->state() == S::Hidden);
        fsm->reveal();
        sched->advance(10 * 60000);
        QVERIFY(fsm->state() == S::Petit);
    }

    void turningHidingOffCancelsARunningCountdown()
    {
        fsm->mouseEntered();
        fsm->mouseLeft();                             // 60 s countdown running
        sched->advance(30000);
        fsm->setHideWhenIdle(false);
        sched->advance(60000);
        QVERIFY(fsm->state() == S::Petit);
        fsm->reveal();                                // only acts on a hidden island
        QCOMPARE(sched->pending(), 0);
    }

    void openExternallySilentlyMovesHiddenToHome()
    {
        QVERIFY(fsm->openExternally());               // tray/debug/alert opened the island outside the FSM
        QVERIFY(fsm->state() == S::Home);
        QVERIFY(log.isEmpty());                       // silent: the caller already opened it
        QCOMPARE(sched->pending(), 0);
        QVERIFY(!fsm->openExternally());              // already home
        fsm->mouseEntered();                          // a pointer entering afterwards must not collapse it
        QVERIFY(fsm->state() == S::Home);
        QVERIFY(log.isEmpty());
    }

    void openExternallyFromPetitCancelsTheHideTimer()
    {
        fsm->mouseEntered();
        fsm->mouseLeft();
        QCOMPARE(sched->pending(), 1);                // 60 s hide timer
        QVERIFY(fsm->openExternally());
        QCOMPARE(sched->pending(), 0);
        sched->advance(120000);
        QVERIFY(fsm->state() == S::Home);
    }

    void openExternallyTakesOverTheGreeting()
    {
        fsm->launch();
        QVERIFY(fsm->openExternally());               // "Open Farol" mid-greeting: the FSM must follow
        QVERIFY(fsm->state() == S::Home);
        QCOMPARE(sched->pending(), 0);                // the greeting timers are gone
    }

    void closeExternallyMovesHomeAndCoucouToPetitSilently()
    {
        fsm->mouseEntered();
        fsm->click();                                 // Home
        const int n = log.size();
        QVERIFY(fsm->closeExternally());              // Esc collapsed the island outside the FSM
        QVERIFY(fsm->state() == S::Petit);
        QCOMPARE(log.size(), n);                      // silent
        QCOMPARE(sched->pending(), 0);
        QVERIFY(!fsm->closeExternally());             // already Petit
        fsm->launch();                                // Coucou
        QVERIFY(fsm->closeExternally());
        QVERIFY(fsm->state() == S::Petit);
        QCOMPARE(sched->pending(), 0);
    }

    void closeExternallyIgnoresHidden()
    {
        QVERIFY(!fsm->closeExternally());
        QVERIFY(fsm->state() == S::Hidden);
    }

    void relaunchLeavesNoStaleTimers()
    {
        fsm->mouseEntered();
        fsm->mouseLeft();                   // hide timer pending
        QCOMPARE(sched->pending(), 1);
        fsm->launch();
        QCOMPARE(sched->pending(), 0);
        sched->advance(120000);
        QVERIFY(fsm->state() == S::Coucou);
    }
};

class TestHover : public QObject {
    Q_OBJECT
private slots:
    void enterReportsOnce()
    {
        FakeScheduler s;
        HoverDebouncer d(s);
        QList<bool> seen;
        d.onChanged = [&](bool in) { seen << in; };
        d.enter();
        d.enter();
        QCOMPARE(seen, QList<bool>{true});
        QVERIFY(d.inside());
    }
    void leaveIsDelayed()
    {
        FakeScheduler s;
        HoverDebouncer d(s, 120);
        QList<bool> seen;
        d.onChanged = [&](bool in) { seen << in; };
        d.enter();
        d.leave();
        s.advance(119);
        QCOMPARE(seen, QList<bool>{true});
        s.advance(1);
        QCOMPARE(seen, (QList<bool>{true, false}));
        QVERIFY(!d.inside());
    }
    void flappingLeaveThenEnterIsInvisible()
    {
        // The L0 probe saw "hover exit" then "hover enter" ~100 ms later when the keyboard mode flipped.
        FakeScheduler s;
        HoverDebouncer d(s, 120);
        QList<bool> seen;
        d.onChanged = [&](bool in) { seen << in; };
        d.enter();
        d.leave();
        s.advance(97);
        d.enter();
        s.advance(500);
        QCOMPARE(seen, QList<bool>{true});
        QVERIFY(d.inside());
        QCOMPARE(s.pending(), 0);
    }
    void leaveWhileOutsideDoesNothing()
    {
        FakeScheduler s;
        HoverDebouncer d(s);
        QList<bool> seen;
        d.onChanged = [&](bool in) { seen << in; };
        d.leave();
        s.advance(1000);
        QVERIFY(seen.isEmpty());
    }
};

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    int rc = 0;
    { TestFsm t; rc |= QTest::qExec(&t, argc, argv); }
    { TestHover t; rc |= QTest::qExec(&t, argc, argv); }
    return rc;
}
#include "tst_scheduler_fsm.moc"
