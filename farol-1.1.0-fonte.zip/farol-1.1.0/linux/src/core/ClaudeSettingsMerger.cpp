#include "ClaudeSettingsMerger.h"

#include "JsonTree.h"

#include <algorithm>

namespace farol {

namespace {

bool isOurs(const JsonTree &hook, bool includeLegacy = true)
{
    if (hook.kind != JsonTree::Kind::Object)
        return false;
    const JsonTree *c = hook.find(QStringLiteral("command"));
    if (!c || !c->isString())
        return false;
    const QString command = c->stringValue();
    return command.contains(QLatin1String(ClaudeSettingsMerger::kMarker)) ||
           command.contains(QLatin1String(ClaudeSettingsMerger::kWindowsMarker)) ||
           (includeLegacy && command.contains(QLatin1String(ClaudeSettingsMerger::kLegacyMarker)));
}

// Removes our commands from a list of matcher groups; a group left without hooks goes away too.
int removeOurs(JsonTree &list)
{
    int removed = 0;
    for (size_t g = 0; g < list.items.size();) {
        JsonTree &group = list.items[g];
        JsonTree *inner = group.kind == JsonTree::Kind::Object ? group.find(QStringLiteral("hooks")) : nullptr;
        if (inner && inner->kind == JsonTree::Kind::Array) {
            const size_t before = inner->items.size();
            std::erase_if(inner->items, [](const JsonTree &h) { return isOurs(h); });
            const int n = int(before - inner->items.size());
            removed += n;
            if (n > 0 && inner->items.empty()) {
                list.items.erase(list.items.begin() + g);
                continue;
            }
        }
        ++g;
    }
    return removed;
}

JsonTree entryFor(const QString &command, int timeoutSec)
{
    JsonTree hook = JsonTree::object();
    hook.set(QStringLiteral("type"), JsonTree::string(QStringLiteral("command")));
    hook.set(QStringLiteral("command"), JsonTree::string(command));
    hook.set(QStringLiteral("timeout"), JsonTree::number(timeoutSec));
    JsonTree hooks = JsonTree::array();
    hooks.items.push_back(std::move(hook));
    JsonTree group = JsonTree::object();
    group.set(QStringLiteral("hooks"), std::move(hooks));
    return group;
}

QString quotedPath(const QString &path)
{
    QString p = path;
    p.replace('"', QStringLiteral("\\\""));
    return QLatin1Char('"') + p + QLatin1Char('"');
}

MergeResult failure(const QString &message)
{
    MergeResult r;
    r.error = message;
    return r;
}

// Parses the file into an object (an empty file becomes a new one); fills the error otherwise.
bool loadRoot(const QString &existing, JsonTree &root, QString &error)
{
    if (existing.trimmed().isEmpty()) {
        root = JsonTree::object();
        return true;
    }
    auto parsed = JsonTree::parse(existing, &error);
    if (!parsed)
        return false;
    if (parsed->kind != JsonTree::Kind::Object) {
        error = QStringLiteral("settings.json is not a JSON object");
        return false;
    }
    root = std::move(*parsed);
    return true;
}

} // namespace

const QStringList &ClaudeSettingsMerger::events()
{
    static const QStringList list = {"SessionStart", "SessionEnd", "UserPromptSubmit", "PreToolUse", "PostToolUse",
                                     "PostToolUseFailure", "PermissionRequest", "Notification", "Stop", "StopFailure",
                                     "SubagentStart", "SubagentStop"};
    return list;
}

MergeResult ClaudeSettingsMerger::install(const QString &existing, const QString &hookPath, int decisionTimeoutSec,
                                          const QString &interpreter)
{
    JsonTree root;
    QString error;
    if (!loadRoot(existing, root, error))
        return failure(error);

    JsonTree *hooks = root.find(QStringLiteral("hooks"));
    if (!hooks)
        hooks = &root.set(QStringLiteral("hooks"), JsonTree::object());
    else if (hooks->kind != JsonTree::Kind::Object)
        return failure(QStringLiteral("\"hooks\" in settings.json is not an object"));

    for (const QString &event : events()) {
        JsonTree *list = hooks->find(event);
        if (!list)
            list = &hooks->set(event, JsonTree::array());
        else if (list->kind != JsonTree::Kind::Array)
            return failure(QStringLiteral("\"hooks.%1\" in settings.json is not an array").arg(event));
        removeOurs(*list);
        // PermissionRequest waits for a click; every other event is fire-and-forget.
        QString command = interpreter.isEmpty() ? quotedPath(hookPath) : quotedPath(interpreter) + QLatin1Char(' ') + quotedPath(hookPath);
        int timeout = 10;
        if (event == QLatin1String("PermissionRequest")) {
            command += QStringLiteral(" --decision-timeout %1").arg(decisionTimeoutSec);
            timeout = decisionTimeoutSec + 10;
        }
        list->items.push_back(entryFor(command, timeout));
    }
    MergeResult r;
    r.ok = true;
    r.text = root.serialize() + QLatin1Char('\n');
    r.changed = r.text != existing;
    return r;
}

MergeResult ClaudeSettingsMerger::uninstall(const QString &existing)
{
    JsonTree root;
    QString error;
    if (!loadRoot(existing, root, error))
        return failure(error);
    MergeResult r;
    r.ok = true;
    r.text = existing;
    JsonTree *hooks = root.find(QStringLiteral("hooks"));
    if (!hooks || hooks->kind != JsonTree::Kind::Object)
        return r;

    int removed = 0;
    for (const QString &event : hooks->keyList()) {
        JsonTree *list = hooks->find(event);
        if (!list || list->kind != JsonTree::Kind::Array)
            continue;
        const int n = removeOurs(*list);
        removed += n;
        if (n > 0 && list->items.empty())
            hooks->remove(event);
    }
    if (removed == 0)
        return r;
    if (hooks->values.empty())
        root.remove(QStringLiteral("hooks"));
    r.text = root.serialize() + QLatin1Char('\n');
    r.changed = true;
    return r;
}

bool ClaudeSettingsMerger::isInstalled(const QString &existing)
{
    JsonTree root;
    QString error;
    if (existing.trimmed().isEmpty() || !loadRoot(existing, root, error))
        return false;
    const JsonTree *hooks = root.find(QStringLiteral("hooks"));
    if (!hooks || hooks->kind != JsonTree::Kind::Object)
        return false;
    for (const JsonTree &list : hooks->values) {
        if (list.kind != JsonTree::Kind::Array)
            continue;
        for (const JsonTree &group : list.items) {
            const JsonTree *inner = group.kind == JsonTree::Kind::Object ? group.find(QStringLiteral("hooks")) : nullptr;
            if (inner && inner->kind == JsonTree::Kind::Array &&
                std::any_of(inner->items.begin(), inner->items.end(), [](const JsonTree &h) { return isOurs(h, false); }))
                return true;
        }
    }
    return false;
}

} // namespace farol
