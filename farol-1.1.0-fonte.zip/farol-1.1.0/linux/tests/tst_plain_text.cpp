#include <QtTest>
#include <QDir>
#include <QFile>
#include <QRegularExpression>

// What the island shows comes from outside (a model, a hook payload, a file name, a marketplace), and a Text left at
// its default format reads anything that looks like markup as rich text: an <img> in it is fetched the moment it is
// shown. So every Text and TextEdit under qml/ says its format, and the format is plain. Rich text is only what
// core/AnswerText made of an answer.

namespace {

// The source with comments and strings blanked out (same length, same lines), so braces and names in them count for
// nothing.
QString codeOnly(const QString &source)
{
    QString out = source;
    enum { Code, Line, Block, String } in = Code;
    QChar quote;
    for (qsizetype i = 0; i < source.size(); ++i) {
        const QChar c = source.at(i);
        const QChar next = i + 1 < source.size() ? source.at(i + 1) : QChar();
        const auto blank = [&](qsizetype at) {
            if (out.at(at) != QLatin1Char('\n'))
                out[at] = QLatin1Char(' ');
        };
        switch (in) {
        case Code:
            if (c == QLatin1Char('/') && next == QLatin1Char('/')) {
                in = Line;
                blank(i);
            } else if (c == QLatin1Char('/') && next == QLatin1Char('*')) {
                in = Block;
                blank(i);
            } else if (c == QLatin1Char('"') || c == QLatin1Char('\'') || c == QLatin1Char('`')) {
                in = String;
                quote = c;
            }
            break;
        case Line:
            if (c == QLatin1Char('\n'))
                in = Code;
            else
                blank(i);
            break;
        case Block:
            blank(i);
            if (c == QLatin1Char('*') && next == QLatin1Char('/')) {
                blank(++i);
                in = Code;
            }
            break;
        case String:
            if (c == QLatin1Char('\\')) {
                blank(i);
                if (i + 1 < source.size())
                    blank(++i);
            } else if (c == quote) {
                in = Code;
            } else {
                blank(i);
            }
            break;
        }
    }
    return out;
}

struct TextElement {
    QString type;       // Text or TextEdit
    int line = 0;
    QString format;     // what its own textFormat is bound to; empty: it has none
    bool converted = false;   // its text comes from answers.html()
};

// Every Text and TextEdit element of a QML source, with the textFormat it sets itself (not the one of an element
// inside it). `ok` is false for a source whose braces do not match.
QList<TextElement> textElements(const QString &source, bool *ok)
{
    static const QRegularExpression opening(QStringLiteral("(?<![A-Za-z0-9_])(Text|TextEdit)\\s*\\{"));
    static const QRegularExpression format(QStringLiteral("(?<![A-Za-z0-9_.])textFormat\\s*:([^;\\n]*)"));
    const QString code = codeOnly(source);
    QList<TextElement> found;
    *ok = code.count(QLatin1Char('{')) == code.count(QLatin1Char('}'));
    for (auto it = opening.globalMatch(code); it.hasNext();) {
        const QRegularExpressionMatch match = it.next();
        QString own;                               // what is written right inside the element's braces
        int depth = 0;
        for (qsizetype i = match.capturedEnd() - 1; i < code.size(); ++i) {
            const QChar c = code.at(i);
            if (c == QLatin1Char('{'))
                ++depth;
            if (depth == 1 && c != QLatin1Char('{'))
                own += c == QLatin1Char('}') ? QLatin1Char('\n') : c;   // an inner element or block leaves a line break
            if (c == QLatin1Char('}') && --depth == 0)
                break;
        }
        TextElement element;
        element.type = match.captured(1);
        element.line = int(code.left(match.capturedStart()).count(QLatin1Char('\n'))) + 1;
        element.format = format.match(own).captured(1).simplified();
        element.converted = own.contains(QLatin1String("answers.html("));
        found.append(element);
    }
    return found;
}

// Why an element is not as it must be; empty when it is.
QString complaint(const TextElement &e)
{
    if (e.format.isEmpty())
        return QStringLiteral("%1 has no textFormat of its own").arg(e.type);
    if (e.format == e.type + QLatin1String(".PlainText"))
        return {};
    if (e.converted && e.format.contains(QLatin1String("PlainText")) && e.format.contains(QLatin1String("RichText")))
        return {};                                 // the answer: rich only for what answers.html() made
    return QStringLiteral("%1 has textFormat: %2 (only %1.PlainText, or rich text made by answers.html())").arg(e.type, e.format);
}

} // namespace

class TestPlainText : public QObject {
    Q_OBJECT
private slots:
    // The check itself: it must see what is wrong, and only that.
    void theCheckSeesATextWithoutAFormat()
    {
        const QString source = QStringLiteral(R"(import QtQuick
Item {
    // Text { in a comment }
    property string note: "Text { in a string }"
    Text {
        text: "no format"
        Rectangle { Text { textFormat: Text.PlainText; text: "inner" } }
    }
    Text {
        textFormat: Text.PlainText
        text: "fine"
    }
    Text { text: "auto"; textFormat: Text.AutoText }
    Text { text: "styled"; textFormat: Text.StyledText }
    TextEdit {
        onLinkActivated: (link) => { answers.open(link) }
        textFormat: TextEdit.RichText
        text: "<b>rich</b>"
    }
    TextEdit {
        textFormat: modelData.user ? TextEdit.PlainText : TextEdit.RichText
        text: modelData.user ? modelData.text : answers.html(modelData.text, theme.dark)
    }
    TextInput { text: "typed" }
    component Label: Text { textFormat: Text.MarkdownText }
}
)");
        bool ok = false;
        const QList<TextElement> elements = textElements(source, &ok);
        QVERIFY(ok);
        QStringList report;
        for (const TextElement &e : elements)
            report << QStringLiteral("%1 %2").arg(e.line).arg(complaint(e).isEmpty() ? QStringLiteral("ok") : complaint(e).section(' ', 0, 2));
        QCOMPARE(report, (QStringList{"5 Text has no", "7 ok", "9 ok", "13 Text has textFormat:", "14 Text has textFormat:", "15 TextEdit has textFormat:",
                                      "20 ok", "25 Text has textFormat:"}));
        textElements(QStringLiteral("Item { Text { text: \"}\" }"), &ok);
        QVERIFY(!ok);                              // a source it cannot read is said, not passed over
    }

    void everyTextInTheIslandIsPlain()
    {
        const QDir dir(QStringLiteral(FAROL_QML_DIR));
        const QStringList files = dir.entryList({QStringLiteral("*.qml")}, QDir::Files, QDir::Name);
        QVERIFY2(files.size() >= 20, qPrintable(dir.path()));
        QStringList wrong;
        int texts = 0, converted = 0;
        for (const QString &name : files) {
            QFile file(dir.filePath(name));
            QVERIFY2(file.open(QIODevice::ReadOnly), qPrintable(name));
            bool ok = false;
            const QList<TextElement> elements = textElements(QString::fromUtf8(file.readAll()), &ok);
            QVERIFY2(ok, qPrintable(name + ": the braces do not match (a brace in a regular expression?)"));
            for (const TextElement &e : elements) {
                ++texts;
                converted += e.converted;
                if (const QString why = complaint(e); !why.isEmpty())
                    wrong << QStringLiteral("%1:%2: %3").arg(name).arg(e.line).arg(why);
            }
        }
        QVERIFY2(texts >= 60, qPrintable(QStringLiteral("only %1 Text elements found in %2").arg(texts).arg(dir.path())));
        QVERIFY2(wrong.isEmpty(), qPrintable(QStringLiteral("\n") + wrong.join(QLatin1Char('\n'))));
        QCOMPARE(converted, 1);                    // the answer of the "Perguntar" tab, and nothing else
    }
};

QTEST_APPLESS_MAIN(TestPlainText)
#include "tst_plain_text.moc"
