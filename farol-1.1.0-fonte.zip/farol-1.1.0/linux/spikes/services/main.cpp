#include <QDateTime>
#include <QElapsedTimer>
#include <QGuiApplication>
#include <QSoundEffect>
#include <QTimer>
#include <QUrl>
#include <qt6keychain/keychain.h>
#include <cstdio>
#include <memory>
#include <vector>

static void say(const QString &s) { std::printf("%s\n", qPrintable(s)); std::fflush(stdout); }

// sound: preload a pool of 3 effects per WAV (like the macOS AVAudioPlayer pool),
// play "greet" then three overlapping "peek" 60 ms apart, report play()->playing latency.
static int runSound(QGuiApplication &app)
{
    const QString dir = QStringLiteral(FAROL_SOUNDS_DIR);
    std::vector<std::unique_ptr<QSoundEffect>> pool;
    for (const char *name : {"greet", "peek", "peek", "peek"}) {
        auto fx = std::make_unique<QSoundEffect>();
        fx->setSource(QUrl::fromLocalFile(dir + "/" + name + ".wav"));
        fx->setVolume(0.12f);
        pool.push_back(std::move(fx));
    }
    auto *timer = new QElapsedTimer;
    QTimer::singleShot(800, &app, [&pool, timer]() {  // give the effects time to load
        for (size_t i = 0; i < pool.size(); ++i) {
            say(QStringLiteral("status[%1]=%2").arg(i).arg(pool[i]->status()));
            QTimer::singleShot(int(i) * 60, pool[i].get(), [fx = pool[i].get(), timer, i]() {
                timer->start();
                QObject::connect(fx, &QSoundEffect::playingChanged, fx, [fx, timer, i]() {
                    if (fx->isPlaying())
                        say(QStringLiteral("effect %1 playing after %2 ms").arg(i).arg(timer->elapsed()));
                });
                fx->play();
            });
        }
    });
    QTimer::singleShot(3000, &app, &QGuiApplication::quit);
    return app.exec();
}

// secret: write, read back and delete a throwaway key in the Secret Service / KWallet.
static int runSecret(QGuiApplication &app)
{
    const QString service = QStringLiteral("local.joao.Farol.Spike");
    const QString key = QStringLiteral("probe");
    const QString value = QStringLiteral("s3cret-%1").arg(QDateTime::currentMSecsSinceEpoch());
    int exitCode = 1;

    auto *write = new QKeychain::WritePasswordJob(service);
    write->setKey(key);
    write->setTextData(value);
    QObject::connect(write, &QKeychain::Job::finished, &app, [&, service, key, value](QKeychain::Job *w) {
        say(QStringLiteral("write: %1").arg(w->error() ? w->errorString() : "ok"));
        auto *read = new QKeychain::ReadPasswordJob(service);
        read->setKey(key);
        QObject::connect(read, &QKeychain::Job::finished, &app, [&, service, key, value](QKeychain::Job *r) {
            const auto *rj = static_cast<QKeychain::ReadPasswordJob *>(r);
            const bool same = !r->error() && rj->textData() == value;
            say(QStringLiteral("read: %1 match=%2").arg(r->error() ? r->errorString() : "ok").arg(same));
            auto *del = new QKeychain::DeletePasswordJob(service);
            del->setKey(key);
            QObject::connect(del, &QKeychain::Job::finished, &app, [&, same](QKeychain::Job *d) {
                say(QStringLiteral("delete: %1").arg(d->error() ? d->errorString() : "ok"));
                exitCode = same && !d->error() ? 0 : 1;
                QGuiApplication::quit();
            });
            del->start();
        });
        read->start();
    });
    write->start();
    app.exec();
    return exitCode;
}

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    const QString cmd = app.arguments().value(1);
    if (cmd == "sound")
        return runSound(app);
    if (cmd == "secret")
        return runSecret(app);
    say("usage: probe-services sound|secret");
    return 2;
}
