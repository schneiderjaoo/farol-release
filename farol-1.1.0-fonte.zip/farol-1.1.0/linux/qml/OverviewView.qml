import QtQuick

// Overview: left card = the focused session (name, source, last steps, context, "Ir à sessão"); right card = the
// list of sessions, one row each: its boat (the one it has in the compact island), its name and what it is doing.
// A session that ended its turn shows what Claude said last in place of the steps, until it moves again.
// The step of an edit says how many lines it added and removed, and a click on it opens its diff (DiffView.qml);
// "N alterações" under the steps, or under the message, opens the newest diff the session keeps.
// A click puts it in the card. Dormant sessions are left out and counted at the foot; a click there shows them
// until the island closes. In the portrait island the session card is on top and the list below it.
Item {
    id: overview
    readonly property var task: appState.focusTask
    readonly property var steps: task.steps || []
    readonly property var tail: (task.stepList || []).slice(-3)   // {label, file, added, removed, diff}
    // how many diffs the session keeps (core/EditDiffs), asked again whenever one comes or goes
    readonly property int changes: diffs.revision >= 0 && task.id ? diffs.kept(task.id) : 0
    // what Claude said when the turn ended, already plain text and cut (AgentTask::finalMessage); "" = the steps
    readonly property string message: task.finalMessage || ""
    readonly property string hint: task.id === "integration_claude" ? "Nenhuma sessão do Claude Code ainda"
                                   : (task.isIntegration ? "Ainda não conectado" : (task.state === "idle" ? "Parada" : "Trabalhando…"))

    readonly property bool vertical: appState.vertical
    // "farol 2": cut in the middle, so the number that tells two sessions apart stays. Any other name keeps its start.
    // the context window fills up: fine, getting full (Claude Code will compact soon), nearly full
    function contextColor(used) { return used >= 0.9 ? theme.alert : (used >= 0.7 ? theme.lamp : theme.ok) }
    function tokens(n) { return n >= 1000000 ? (n / 1000000).toFixed(1) + "M" : Math.round(n / 1000) + "k" }
    function elideFor(name) { return / \d+$/.test(name) ? Text.ElideMiddle : Text.ElideRight }
    readonly property real textX: vertical ? 12 : 14   // Lumi lives on the rail, outside the card
    readonly property real cardHeight: 140             // of the session card in the portrait island
    property bool showDormant: false                   // the view is loaded each time the island opens: hidden again then
    // dormant sessions without a line (the one in the card keeps its line)
    readonly property int hiddenCount: appState.sessionCount - appState.awakeSessionCount - (task.dormant ? 1 : 0)
    function stateLabel(state) {
        return ({working: "trabalha", thinking: "trabalha", searching: "trabalha", approval: "permissão", question: "pergunta",
                 finished: "terminou", error: "erro", ratelimit: "erro", dizzy: "erro"})[state] || "parada"
    }

    Item {
        anchors.fill: parent

        Card {
            id: sessionCard
            width: overview.vertical ? parent.width : 260
            height: overview.vertical ? overview.cardHeight : parent.height

            Row {
                id: head
                x: overview.textX
                y: 10
                width: parent.width - overview.textX - 12
                spacing: 6
                // The name gets what the step counter leaves. "Claude Code" is only said when the whole name fits
                // beside it: a long repository name, or a session's own title, takes its place instead of pushing
                // the counter out of the card.
                readonly property real counterRoom: stepCounter.visible ? stepCounter.implicitWidth + 6 : 0
                readonly property bool saysSource: !overview.task.isIntegration && !overview.vertical && !overview.task.titled
                                                   && nameText.implicitWidth <= width - 13 - counterRoom - sourceLabel.implicitWidth - 6
                Item {
                    width: 7
                    height: 16
                    Rectangle { anchors.centerIn: parent; width: 7; height: 7; radius: 3.5; color: overview.task.color || theme.muted }
                }
                Text {
                    id: nameText
                    objectName: "overviewName"
                    height: 16
                    verticalAlignment: Text.AlignVCenter
                    width: Math.min(implicitWidth, Math.max(30, head.width - 13 - head.counterRoom
                                                                    - (head.saysSource ? sourceLabel.implicitWidth + 6 : 0)))
                    elide: overview.elideFor(text)
                    textFormat: Text.PlainText
                    text: overview.task.name || ""
                    color: theme.text
                    font.family: theme.bodyFont
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                }
                Text {
                    id: sourceLabel
                    objectName: "overviewSource"
                    height: 16
                    verticalAlignment: Text.AlignVCenter
                    visible: head.saysSource
                    textFormat: Text.PlainText
                    text: "Claude Code"
                    color: theme.muted
                    font.family: theme.bodyFont
                    font.pixelSize: 11
                }
                Text {
                    id: stepCounter
                    objectName: "overviewCounter"
                    height: 16
                    verticalAlignment: Text.AlignVCenter
                    visible: overview.steps.length > 1 && overview.message === ""   // it counts the steps, not shown then
                    textFormat: Text.PlainText
                    text: (overview.task.stepIndex + 1) + "/" + overview.steps.length
                    color: theme.dim
                    font.family: theme.bodyFont
                    font.pixelSize: 11
                }
            }

            Column {
                objectName: "overviewTicker"
                visible: overview.message === ""
                x: overview.textX
                y: 34
                width: parent.width - overview.textX - 12
                spacing: 3
                Repeater {
                    model: overview.tail
                    Item {
                        id: step
                        required property var modelData
                        required property int index
                        readonly property bool edit: modelData.added >= 0          // a file tool that has run
                        readonly property bool same: edit && modelData.added === 0 && modelData.removed === 0
                        // its diff is still kept: the step is a button
                        readonly property bool opens: modelData.diff > 0 && diffs.revision >= 0 && diffs.has(modelData.diff)
                        readonly property bool last: index === overview.tail.length - 1
                        signal clicked()
                        objectName: "overviewStep" + index
                        width: parent.width
                        height: 15
                        onClicked: if (opens) diffs.open(modelData.diff)
                        Text {
                            objectName: "overviewStepLabel" + step.index
                            width: parent.width - (facts.width > 0 ? facts.width + 8 : 0)
                            height: parent.height
                            verticalAlignment: Text.AlignVCenter
                            elide: Text.ElideRight
                            textFormat: Text.PlainText
                            text: step.modelData.label
                            color: step.last || stepHover.hovered ? theme.text : theme.dim
                            font.family: theme.bodyFont
                            font.pixelSize: 12
                        }
                        Row {
                            id: facts
                            anchors.right: parent.right
                            height: parent.height
                            spacing: 5
                            Text {
                                objectName: "overviewStepAdded" + step.index
                                visible: step.edit && !step.same
                                height: parent.height
                                verticalAlignment: Text.AlignVCenter
                                textFormat: Text.PlainText
                                text: "+" + step.modelData.added
                                color: theme.ok
                                font.family: theme.bodyFont
                                font.pixelSize: 11
                                font.weight: Font.DemiBold
                            }
                            Text {
                                objectName: "overviewStepRemoved" + step.index
                                visible: step.edit && !step.same
                                height: parent.height
                                verticalAlignment: Text.AlignVCenter
                                textFormat: Text.PlainText
                                text: "−" + step.modelData.removed
                                color: theme.alert
                                font.family: theme.bodyFont
                                font.pixelSize: 11
                                font.weight: Font.DemiBold
                            }
                            Text {
                                objectName: "overviewStepSame" + step.index
                                visible: step.same
                                height: parent.height
                                verticalAlignment: Text.AlignVCenter
                                textFormat: Text.PlainText
                                text: "sem alterações"
                                color: theme.dim
                                font.family: theme.bodyFont
                                font.pixelSize: 11
                            }
                            Text {
                                objectName: "overviewStepOpen" + step.index
                                visible: step.opens
                                height: parent.height
                                verticalAlignment: Text.AlignVCenter
                                textFormat: Text.PlainText
                                text: "›"
                                color: stepHover.hovered ? theme.text : theme.muted
                                font.family: theme.bodyFont
                                font.pixelSize: 13
                            }
                        }
                        HoverHandler { id: stepHover; enabled: step.opens; cursorShape: Qt.PointingHandCursor }
                        TapHandler { enabled: step.opens; onTapped: step.clicked() }
                    }
                }
                Text {
                    visible: overview.steps.length === 0
                    width: parent.width
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: overview.hint
                    color: theme.dim
                    font.family: theme.bodyFont
                    font.pixelSize: 12
                }
            }

            // Four lines of 15 px end at y 94, clear of the button (y 104) in both shapes of the island; a fifth
            // would run into it. With "N alterações" under it there is room for three.
            Text {
                objectName: "overviewMessage"
                visible: overview.message !== ""
                x: overview.textX
                y: 34
                width: parent.width - overview.textX - 12
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                maximumLineCount: changesRow.visible ? 3 : 4
                elide: Text.ElideRight
                text: overview.message
                color: theme.text
                font.family: theme.bodyFont
                font.pixelSize: 12
            }

            // The diffs of the session, within reach whatever is above: three steps end at y 85 and three lines of
            // the message at y 79; this row ends at y 102, clear of the button and of the context line (y 116).
            Text {
                id: changesRow
                objectName: "overviewChanges"
                signal clicked()
                visible: overview.changes > 0
                x: overview.textX
                y: 88
                height: 14
                verticalAlignment: Text.AlignVCenter
                textFormat: Text.PlainText
                text: (overview.changes === 1 ? "1 alteração" : overview.changes + " alterações") + " ›"
                color: changesHover.hovered ? theme.text : theme.muted
                font.family: theme.bodyFont
                font.pixelSize: 11
                onClicked: diffs.openLatest(overview.task.id)
                HoverHandler { id: changesHover; cursorShape: Qt.PointingHandCursor }
                TapHandler { onTapped: changesRow.clicked() }
            }

            Text {
                objectName: "overviewContext"
                visible: (overview.task.contextUsed || 0) > 0
                x: overview.textX
                y: parent.height - 24
                width: parent.width - overview.textX - 12 - (jump.visible ? jump.width + 8 : 0)
                elide: Text.ElideRight
                textFormat: Text.PlainText
                text: "Contexto " + Math.round((overview.task.contextUsed || 0) * 100) + "% · " + overview.tokens(overview.task.contextTokens || 0)
                color: overview.contextColor(overview.task.contextUsed || 0)
                font.family: theme.bodyFont
                font.pixelSize: 11
            }

            PillButton {
                id: jump
                objectName: "jumpButton"
                visible: !overview.task.isIntegration
                x: parent.width - width - 10
                y: parent.height - height - 8
                text: "Ir à sessão"
                onClicked: { sessions.jump(appState.focusId); controller.collapse() }
            }
        }

        Card {
            x: overview.vertical ? 0 : 270
            y: overview.vertical ? overview.cardHeight + 10 : 0
            width: overview.vertical ? parent.width : parent.width - 270
            height: overview.vertical ? parent.height - overview.cardHeight - 10 : parent.height

            Flickable {
                id: list
                objectName: "sessionList"
                anchors.fill: parent
                anchors.margins: 8
                anchors.bottomMargin: hidden.visible ? 26 : 8
                contentHeight: rows.height
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: rows
                    objectName: "sessionRows"
                    width: parent.width
                    spacing: 4
                    Repeater {
                        model: appState.tasks
                        Rectangle {
                            id: row
                            property color tint: model.color
                            readonly property bool focused: model.taskId === appState.focusId
                            readonly property var look: lumiLooks.look(model.state)
                            // a dormant session (at rest for a while) has no line, unless the card beside shows it
                            // or the user asked to see them
                            visible: !model.dormant || focused || overview.showDormant
                            width: rows.width
                            height: 36          // the name on top, what the session is doing under it
                            radius: 10
                            color: focused ? Qt.rgba(tint.r, tint.g, tint.b, 0.16) : (rowHover.hovered ? theme.hoverFill : "transparent")
                            border.width: focused ? 1 : 0
                            border.color: Qt.rgba(tint.r, tint.g, tint.b, 0.5)

                            // the boat this session has in the compact island, tied up
                            Boat {
                                objectName: "rowBoat" + index
                                // a boat is drawn whole or not at all: a row half scrolled out keeps its text only
                                visible: !model.isIntegration && row.y >= list.contentY - 1
                                         && row.y + row.height <= list.contentY + list.height + 1
                                x: 6
                                y: 4
                                moored: true
                                size: 2
                                kind: model.boat
                                tint: row.tint
                                mood: row.look.signal
                            }
                            StateBadge {
                                visible: model.isIntegration
                                x: 9
                                anchors.verticalCenter: parent.verticalCenter
                                size: 16
                                signal: row.look.signal
                            }
                            Text {
                                x: 50
                                y: 4
                                objectName: "pillName" + index
                                width: parent.width - 50 - 10
                                elide: overview.elideFor(text)
                                textFormat: Text.PlainText
                                text: model.name
                                color: row.focused ? theme.text : Qt.lighter(row.tint, 1.25)
                                font.family: theme.bodyFont
                                font.pixelSize: 12
                            }
                            Text {
                                id: stateText
                                objectName: "pillState" + index
                                x: 50
                                y: 19
                                visible: !model.isIntegration
                                textFormat: Text.PlainText
                                text: overview.stateLabel(model.state)
                                color: row.look.signal === "idle" ? theme.dim : theme[row.look.lamp]
                                font.family: theme.bodyFont
                                font.pixelSize: 10
                            }
                            // how full the session's context window is
                            Rectangle {
                                objectName: "pillContext" + index
                                visible: model.contextUsed > 0
                                x: 16
                                y: parent.height - 4
                                height: 2
                                radius: 1
                                width: Math.max(2, (parent.width - 32) * model.contextUsed)
                                color: overview.contextColor(model.contextUsed)
                            }
                            HoverHandler { id: rowHover }
                            TapHandler { onTapped: appState.setFocus(model.taskId) }
                        }
                    }
                }
            }
            Text {
                id: hidden
                objectName: "hiddenSessions"
                signal clicked()
                visible: overview.hiddenCount > 0 && !overview.showDormant
                x: 16
                y: parent.height - 22
                textFormat: Text.PlainText
                text: overview.hiddenCount === 1 ? "1 inativa oculta" : overview.hiddenCount + " inativas ocultas"
                color: hiddenHover.hovered ? theme.text : theme.dim
                font.family: theme.bodyFont
                font.pixelSize: 11
                onClicked: overview.showDormant = true
                HoverHandler { id: hiddenHover }
                TapHandler { onTapped: hidden.clicked() }
            }
        }
    }
}
