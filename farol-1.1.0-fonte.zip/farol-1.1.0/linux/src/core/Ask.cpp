#include "Ask.h"

#include "ClaudeLocator.h"

#include <QFile>
#include <QFileInfo>
#include <QMimeDatabase>
#include <QMimeType>
#include <QSettings>
#include <QStringDecoder>

namespace farol {

Ask::Ask(QSettings *settings, ISecretStore *secrets, IHttpClient *http, ICommandRunner *runner, std::function<QString()> locate,
         const QString &path, QObject *parent)
    : QObject(parent), m_settings(settings), m_secrets(secrets), m_http(http), m_runner(runner), m_locate(std::move(locate)), m_path(path)
{
    m_provider = m_settings->value("ai/provider").toString();
    if (!aiProviders().contains(m_provider))
        m_provider = aiProviders().first();
    for (const QString &p : m_settings->value("ai/keys").toStringList())
        if (aiProviders().contains(p) && aiNeedsKey(p) && !m_keys.contains(p))
            m_keys.append(p);
}

void Ask::setProvider(const QString &provider)
{
    if (provider == m_provider || !aiProviders().contains(provider))
        return;
    m_provider = provider;
    m_settings->setValue("ai/provider", provider);
    emit providerChanged();
    emit keysChanged();   // hasKey is about the chosen service
}

QString Ask::modelOf(const QString &provider) const
{
    // a model that is no longer offered falls back to the default
    const QString saved = m_settings->value("ai/model_" + provider).toString();
    for (const AiModel &m : aiModels(provider))
        if (m.id == saved)
            return saved;
    return aiDefaultModel(provider);
}

QString Ask::modelLabel() const
{
    const QString id = model();
    for (const AiModel &m : aiModels(m_provider))
        if (m.id == id)
            return m.label;
    return id;
}

QVariantList Ask::models() const
{
    QVariantList list;
    for (const AiModel &m : aiModels(m_provider))
        list.append(QVariantMap{{"id", m.id}, {"label", m.label}});
    return list;
}

void Ask::setModel(const QString &provider, const QString &model)
{
    if (!aiProviders().contains(provider))
        return;
    bool listed = false;
    for (const AiModel &m : aiModels(provider))
        listed = listed || m.id == model;
    if (!listed)
        return;
    m_settings->setValue("ai/model_" + provider, model);
    emit providerChanged();
}

void Ask::saveKey(const QString &provider, const QString &key)
{
    if (!aiProviders().contains(provider) || !aiNeedsKey(provider))
        return;
    const QString k = key.trimmed();
    if (k.isEmpty()) {
        setKeyError(QStringLiteral("Cole a chave antes de guardar."));
        return;
    }
    if (k.startsWith(QLatin1String("sk-ant-oat"))) {   // what `claude setup-token` gives: the web API refuses it
        setKeyError(QStringLiteral("Este é um token da assinatura do Claude, não uma chave de API. Para usar a assinatura, escolha "
                                   "o serviço Claude Code, que não precisa de chave."));
        return;
    }
    setKeyError({});
    m_secrets->write(provider, k, [this, provider](bool ok) {
        if (!ok) {
            setKeyError(QStringLiteral("Não consegui guardar a chave no cofre de senhas do sistema."));
            return;
        }
        if (!m_keys.contains(provider)) {
            m_keys.append(provider);
            m_settings->setValue("ai/keys", m_keys);
        }
        emit keysChanged();
    });
}

void Ask::removeKey(const QString &provider)
{
    setKeyError({});
    m_secrets->remove(provider, [this, provider](bool ok) {
        if (!ok) {
            setKeyError(QStringLiteral("Não consegui apagar a chave no cofre de senhas do sistema."));
            return;
        }
        m_keys.removeAll(provider);
        m_settings->setValue("ai/keys", m_keys);
        emit keysChanged();
    });
}

QVariantList Ask::files() const
{
    QVariantList list;
    for (const AskFile &f : m_files) {
        const qint64 kb = (f.data.size() + 1023) / 1024;
        list.append(QVariantMap{{"name", f.name},
                                {"kind", f.kind == AskFile::Text ? "texto" : f.kind == AskFile::Pdf ? "PDF" : "imagem"},
                                {"size", kb >= 1024 ? QStringLiteral("%1 MB").arg(kb / 1024.0, 0, 'f', 1) : QStringLiteral("%1 kB").arg(kb)}});
    }
    return list;
}

QVariantList Ask::turns() const
{
    QVariantList list;
    for (const AskTurn &t : m_turns)
        list.append(QVariantMap{{"user", t.user}, {"text", t.text}});
    return list;
}

qint64 Ask::totalBytes() const
{
    qint64 n = 0;
    for (const AskFile &f : m_files)
        n += f.data.size();
    return n;
}

void Ask::addUrls(const QList<QUrl> &urls)
{
    for (const QUrl &u : urls)
        if (u.isLocalFile())
            addFile(u.toLocalFile());
}

void Ask::addFile(const QString &path)
{
    const QFileInfo info(path);
    const QString name = info.fileName();
    if (!info.isFile()) {
        setNotice(QStringLiteral("%1: só arquivos, não pastas.").arg(name));
        return;
    }
    if (m_files.size() >= kMaxFiles) {
        setNotice(QStringLiteral("No máximo %1 arquivos por conversa.").arg(kMaxFiles));
        return;
    }
    if (info.size() + totalBytes() > kMaxTotalBytes) {
        setNotice(QStringLiteral("%1: passa do limite de 20 MB por conversa.").arg(name));
        return;
    }
    QFile file(path);
    if (!file.open(QIODevice::ReadOnly)) {
        setNotice(QStringLiteral("%1: não consegui abrir.").arg(name));
        return;
    }
    AskFile f;
    f.name = name;
    f.data = file.readAll();
    const QString mime = QMimeDatabase().mimeTypeForFileNameAndData(name, f.data).name();
    static const QStringList images{QStringLiteral("image/png"), QStringLiteral("image/jpeg"), QStringLiteral("image/gif"),
                                    QStringLiteral("image/webp")};
    if (images.contains(mime)) {
        f.kind = AskFile::Image;
        f.mime = mime;
    } else if (mime == QLatin1String("application/pdf")) {
        f.kind = AskFile::Pdf;
        f.mime = mime;
    } else {
        // anything that reads as text goes as text: source code, logs, CSV, JSON, Markdown...
        QStringDecoder utf8(QStringDecoder::Utf8);
        const QString text = utf8.decode(f.data);
        if (f.data.contains('\0') || utf8.hasError()) {
            setNotice(QStringLiteral("%1: não sei ler este tipo de arquivo (aceito texto, imagem e PDF).").arg(name));
            return;
        }
        if (f.data.size() > kMaxTextBytes) {
            setNotice(QStringLiteral("%1: texto grande demais (mais de 2 MB).").arg(name));
            return;
        }
        f.kind = AskFile::Text;
    }
    m_files.append(f);
    setNotice({});
    emit filesChanged();
}

void Ask::removeFile(int index)
{
    if (index < 0 || index >= m_files.size())
        return;
    m_files.removeAt(index);
    emit filesChanged();
}

void Ask::ask(const QString &question)
{
    const QString q = question.trimmed();
    if (m_busy || q.isEmpty())
        return;
    if (!ready()) {
        setError(QStringLiteral("Guarde uma chave de %1 em Ajustes → IA.").arg(providerLabel()));
        emit failed(q);
        return;
    }
    setError({});
    m_turns.append({true, q});
    emit turnsChanged();
    setBusy(true);
    const int round = ++m_round;
    const QString provider = m_provider;
    m_asked = provider;
    if (!aiNeedsKey(provider)) {
        askClaude(round);
        return;
    }
    m_secrets->read(provider, [this, round, provider](bool ok, const QString &key) {
        if (round != m_round)
            return;
        if (!ok || key.isEmpty()) {
            giveUp(QStringLiteral("Não consegui ler a chave de %1 no cofre de senhas do sistema.").arg(aiProviderLabel(provider)));
            return;
        }
        m_http->post(buildAiRequest(provider, modelOf(provider), key, m_files, m_turns), kTimeoutMs,
                     [this, round, provider](const IHttpClient::Reply &reply) {
            if (round != m_round)
                return;
            if (reply.cancelled) {
                giveUp({});
                return;
            }
            if (reply.timedOut) {
                giveUp(QStringLiteral("%1 não respondeu em 3 minutos.").arg(aiProviderLabel(provider)));
                return;
            }
            if (reply.status == 0) {
                giveUp(QStringLiteral("Não consegui falar com %1: %2").arg(aiProviderLabel(provider), reply.error));
                return;
            }
            const AiAnswer answer = parseAiReply(provider, reply.status, reply.body);
            if (reply.status == 401) {
                giveUp(QStringLiteral("%1 recusou a chave guardada (%2). Confira-a em Ajustes → IA, ou escolha lá o serviço Claude "
                                      "Code, que usa a sua conta do Claude e não precisa de chave.")
                           .arg(aiProviderLabel(provider), answer.text));
                return;
            }
            answerWith(provider, answer);
        });
    });
}

// The question goes to the Claude Code installed here, which answers with the account it is logged in with.
void Ask::askClaude(int round)
{
    const QString claude = m_runner && m_locate ? m_locate() : QString();
    if (claude.isEmpty()) {
        giveUp(QStringLiteral("Não encontrei o Claude Code nesta máquina. Instale-o, ou escolha outro serviço em Ajustes → IA."));
        return;
    }
    const QString provider = m_provider;
    m_runner->run(claude, claudeArguments(modelOf(provider)), claudeEnvironment(claude, m_path), kTimeoutMs,
                  [this, round, provider](const ICommandRunner::Result &r) {
        if (round != m_round)
            return;
        if (!r.started) {
            giveUp(QStringLiteral("Não consegui abrir o Claude Code."));
            return;
        }
        if (r.timedOut) {
            giveUp(QStringLiteral("%1 não respondeu em 3 minutos.").arg(aiProviderLabel(provider)));
            return;
        }
        answerWith(provider, parseClaudeOutput(r.exitCode, r.out, r.err));
    }, claudeInput(m_files, m_turns));
}

void Ask::answerWith(const QString &provider, const AiAnswer &answer)
{
    if (!answer.ok) {
        giveUp(QStringLiteral("%1: %2").arg(aiProviderLabel(provider), answer.text));
        return;
    }
    m_turns.append({false, answer.text});
    emit turnsChanged();
    setBusy(false);
    emit answered();
}

// The question under way did not get an answer: it leaves the conversation and goes back to the field.
void Ask::giveUp(const QString &error)
{
    QString question;
    if (!m_turns.isEmpty() && m_turns.last().user) {
        question = m_turns.takeLast().text;
        emit turnsChanged();
    }
    setBusy(false);
    setError(error);
    emit failed(question);
}

// Ends the request or the program the question under way went to.
void Ask::stop()
{
    if (aiNeedsKey(m_asked))
        m_http->cancel();
    else if (m_runner)
        m_runner->cancel();
}

void Ask::cancel()
{
    if (!m_busy)
        return;
    ++m_round;          // whatever still comes back is dropped
    stop();
    giveUp({});
}

void Ask::clear()
{
    if (m_busy) {
        ++m_round;
        stop();
        setBusy(false);
    }
    m_files.clear();
    m_turns.clear();
    emit filesChanged();
    emit turnsChanged();
    setError({});
    setNotice({});
}

void Ask::copy(int index)
{
    if (index >= 0 && index < m_turns.size() && !m_turns.at(index).user)
        emit copyRequested(m_turns.at(index).text);
}

void Ask::setBusy(bool busy)
{
    if (busy == m_busy)
        return;
    m_busy = busy;
    emit busyChanged();
}

void Ask::setError(const QString &error)
{
    if (error == m_error)
        return;
    m_error = error;
    emit errorChanged();
}

void Ask::setNotice(const QString &notice)
{
    if (notice == m_notice)
        return;
    m_notice = notice;
    emit noticeChanged();
}

void Ask::setKeyError(const QString &error)
{
    if (error == m_keyError)
        return;
    m_keyError = error;
    emit keyErrorChanged();
}

} // namespace farol
