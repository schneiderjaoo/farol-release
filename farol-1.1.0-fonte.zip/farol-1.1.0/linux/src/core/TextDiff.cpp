#include "TextDiff.h"

#include <QList>
#include <QStringList>
#include <QVector>

namespace farol {

namespace {
struct Op {
    QChar kind;   // ' ', '-', '+'
    int ai, bi;   // line index in A / B, -1 when absent
};
} // namespace

QString unifiedDiff(const QString &a, const QString &b, const QString &labelA, const QString &labelB, int context)
{
    if (a == b)
        return {};
    const QStringList A = a.split('\n');
    const QStringList B = b.split('\n');
    const int n = int(A.size()), m = int(B.size());

    QList<Op> ops;
    if (qint64(n) * m > 4'000'000) {
        for (int i = 0; i < n; ++i)
            ops.append({'-', i, -1});
        for (int j = 0; j < m; ++j)
            ops.append({'+', -1, j});
    } else {
        QVector<int> L(qsizetype(n + 1) * (m + 1), 0);
        auto at = [&](int i, int j) -> int & { return L[qsizetype(i) * (m + 1) + j]; };
        for (int i = n - 1; i >= 0; --i)
            for (int j = m - 1; j >= 0; --j)
                at(i, j) = A[i] == B[j] ? at(i + 1, j + 1) + 1 : qMax(at(i + 1, j), at(i, j + 1));
        int i = 0, j = 0;
        while (i < n && j < m) {
            if (A[i] == B[j]) {
                ops.append({' ', i++, j++});
            } else if (at(i + 1, j) >= at(i, j + 1)) {
                ops.append({'-', i++, -1});
            } else {
                ops.append({'+', -1, j++});
            }
        }
        while (i < n)
            ops.append({'-', i++, -1});
        while (j < m)
            ops.append({'+', -1, j++});
    }

    const int N = int(ops.size());
    QVector<int> aBefore(N + 1, 0), bBefore(N + 1, 0);
    for (int k = 0; k < N; ++k) {
        aBefore[k + 1] = aBefore[k] + (ops[k].kind != '+' ? 1 : 0);
        bBefore[k + 1] = bBefore[k] + (ops[k].kind != '-' ? 1 : 0);
    }

    QStringList out;
    out << QStringLiteral("--- ") + labelA << QStringLiteral("+++ ") + labelB;
    int k = 0;
    while (k < N) {
        if (ops[k].kind == ' ') {
            ++k;
            continue;
        }
        const int start = qMax(0, k - context);
        int end = k;
        int scan = k;
        while (scan < N) {
            if (ops[scan].kind != ' ') {
                end = scan++;
                continue;
            }
            int next = scan;
            while (next < N && ops[next].kind == ' ')
                ++next;
            if (next < N && next - scan <= 2 * context) {
                scan = next;
                continue;
            }
            break;
        }
        const int stop = qMin(N, end + 1 + context);
        out << QStringLiteral("@@ -%1,%2 +%3,%4 @@")
                   .arg(aBefore[start] + 1).arg(aBefore[stop] - aBefore[start])
                   .arg(bBefore[start] + 1).arg(bBefore[stop] - bBefore[start]);
        for (int t = start; t < stop; ++t)
            out << QString(ops[t].kind) + (ops[t].kind == '+' ? B[ops[t].bi] : A[ops[t].ai]);
        k = stop;
    }
    return out.join('\n') + '\n';
}

} // namespace farol
