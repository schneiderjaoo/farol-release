#pragma once
#include <QString>

namespace farol {

// The name Claude Code gave a session (the title of its tab in the editor), read from the end of its transcript:
// the newest "custom-title" entry (the user renamed it), otherwise the newest "ai-title". Empty when the session
// has none yet or the file cannot be read. Only the last kTitleTailBytes are looked at: Claude Code writes the
// title again at every turn.
inline constexpr qint64 kTitleTailBytes = 256 * 1024;
QString sessionTitle(const QString &transcriptPath);

// What the end of a transcript says about its session. contextTokens is what the last answer of the main
// conversation (not of a subagent) had in its context window: input + cached tokens of that request; 0 when there
// is no answer in reach. model is the model of that answer.
struct TranscriptInfo {
    QString title;
    int contextTokens = 0;
    QString model;
};
TranscriptInfo readTranscript(const QString &transcriptPath);

} // namespace farol
