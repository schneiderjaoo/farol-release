#include "GlobalShortcuts.h"

#include "X11.h"

#include <QAbstractNativeEventFilter>
#include <QAction>
#include <QCoreApplication>
#include <QHash>
#include <QKeySequence>
#if FAROL_KDE
#include <KGlobalAccel>
#endif

namespace farol {

namespace {
const QStringList kActions = {QStringLiteral("toggle"), QStringLiteral("jump")};

#if FAROL_KDE
const QString kComponent = QStringLiteral("farol");

class KdeShortcuts : public GlobalShortcuts::Backend {
public:
    explicit KdeShortcuts(GlobalShortcuts *owner)
    {
        const QStringList texts = {QStringLiteral("Open or close the island"), QStringLiteral("Go to the session that waits")};
        for (int i = 0; i < kActions.size(); ++i) {
            const QString id = kActions[i];
            auto *a = new QAction(texts[i], owner);
            a->setObjectName(id);                                  // KGlobalAccel's key for the action
            a->setProperty("componentName", kComponent);
            a->setProperty("componentDisplayName", QStringLiteral("Farol"));
            QObject::connect(a, &QAction::triggered, owner, [owner, id] { emit owner->triggered(id); });
            m_actions.insert(id, a);
        }
    }

    QString bind(const QString &action, int combo) override
    {
        QAction *a = m_actions.value(action);
        if (!a)
            return {};
        if (combo == 0) {
            KGlobalAccel::self()->setShortcut(a, {}, KGlobalAccel::NoAutoloading);
            return QStringLiteral("-");
        }
        const QKeySequence keys(QKeyCombination::fromCombined(combo));
        if (!KGlobalAccel::isGlobalShortcutAvailable(keys, kComponent))
            return {};
        if (!KGlobalAccel::self()->setShortcut(a, {keys}, KGlobalAccel::NoAutoloading))
            return {};
        return keys.toString(QKeySequence::NativeText);
    }

private:
    QHash<QString, QAction *> m_actions;
};
#endif

// Keys grabbed from the X server: the press comes to Farol whatever window has the keyboard.
class X11Shortcuts : public GlobalShortcuts::Backend, public QAbstractNativeEventFilter {
public:
    explicit X11Shortcuts(GlobalShortcuts *owner) : m_owner(owner)
    {
        QCoreApplication::instance()->installNativeEventFilter(this);
    }
    ~X11Shortcuts() override
    {
        for (const x11::Key &key : std::as_const(m_keys))
            x11::ungrabKey(key);
        if (QCoreApplication::instance())
            QCoreApplication::instance()->removeNativeEventFilter(this);
    }

    QString bind(const QString &action, int combo) override
    {
        if (!kActions.contains(action))
            return {};
        if (combo == 0) {
            x11::ungrabKey(m_keys.take(action));
            return QStringLiteral("-");
        }
        const x11::Key before = m_keys.value(action);
        x11::ungrabKey(before);                    // the same keys asked for again are still Farol's
        const x11::Key key = x11::grabKey(combo);
        if (!key.code) {
            if (before.code)                       // refused: what worked until now goes on working
                m_keys[action] = x11::grabKey(m_combos.value(action));
            return {};
        }
        m_keys[action] = key;
        m_combos[action] = combo;
        return QKeySequence(QKeyCombination::fromCombined(combo)).toString(QKeySequence::NativeText);
    }

    bool nativeEventFilter(const QByteArray &eventType, void *message, qintptr *) override
    {
        x11::Key pressed;
        if (m_keys.isEmpty() || !x11::keyPress(eventType, message, &pressed))
            return false;
        const QString action = m_keys.key(pressed);
        if (action.isEmpty())
            return false;
        emit m_owner->triggered(action);
        return true;
    }

private:
    GlobalShortcuts *m_owner;
    QHash<QString, x11::Key> m_keys;
    QHash<QString, int> m_combos;
};
} // namespace

GlobalShortcuts::GlobalShortcuts(QObject *parent) : QObject(parent)
{
#if FAROL_KDE
    if (desktopIsKde()) {
        m_backend = std::make_unique<KdeShortcuts>(this);
        return;
    }
#endif
    m_backend = std::make_unique<X11Shortcuts>(this);   // without X11 every key is refused
}

GlobalShortcuts::~GlobalShortcuts() = default;

QString GlobalShortcuts::bind(const QString &action, int combo)
{
    return m_backend->bind(action, combo);
}

} // namespace farol
