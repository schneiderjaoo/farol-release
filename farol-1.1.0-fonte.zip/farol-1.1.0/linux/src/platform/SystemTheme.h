#pragma once
#include <QObject>

class QDBusVariant;

namespace farol {

// Whether the desktop asks for the dark look (anything but an explicit "light" counts as dark), and when that
// changes. Qt says so itself from 6.5 on; an older Qt (6.4 on Linux Mint 22) does not, and there the desktop's
// portal is asked (org.freedesktop.appearance color-scheme), once and then at each change it announces.
class SystemTheme : public QObject {
    Q_OBJECT
public:
    explicit SystemTheme(QObject *parent = nullptr);
    bool dark() const { return m_dark; }

signals:
    void changed();

private slots:
    void portalSetting(const QString &group, const QString &key, const QDBusVariant &value);

private:
    void set(bool dark);
    bool m_dark = true;
};

} // namespace farol
