import QtQuick

// ApprovalView: the permission request in front of the queue. Nothing is decided without a click (or Y/N).
Item {
    Card { anchors.fill: parent; wash: theme.lamp }
    Column {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: appState.vertical ? 12 : 16
        anchors.rightMargin: appState.vertical ? 12 : 16
        spacing: 5

        AgentWho {
            nameObjectName: "approvalProject"
            name: approvals.project
            label: approvals.waiting > 0 ? "pede permissão · +" + approvals.waiting + " na fila" : "pede permissão"
            dot: appState.focusTask.color || theme.muted
        }
        CodeBlock {
            id: block
            objectName: "approvalCommand"
            width: parent.width
            text: approvals.command !== "" ? approvals.command : approvals.tool
        }
        Text {   // "Permitir" is for all of the command: when the card does not show all of it, it says so
            objectName: "approvalCut"
            visible: block.cut || approvals.commandCut   // the two lines were not enough, or the text given was not all
            width: parent.width
            wrapMode: Text.Wrap
            textFormat: Text.PlainText
            text: "Cortado: " + approvals.commandChars + " caracteres" + (approvals.commandLines > 1 ? " em " + approvals.commandLines + " linhas" : "")
                  + ". Veja inteiro no editor."
            color: theme.lamp
            font.family: theme.bodyFont
            font.pixelSize: 11
        }
        Flow {   // the buttons wrap onto more lines in the portrait island
            width: parent.width
            spacing: 8
            PillButton { text: "Negar"; hint: "N"; onClicked: approvals.deny() }
            PillButton { text: "Permitir"; hint: "Y"; primary: true; onClicked: approvals.allow() }
            PillButton { text: "Sempre"; onClicked: approvals.always() }
            PillButton {
                text: "Decidir no editor"
                onClicked: {
                    const id = appState.focusId
                    approvals.release()            // the hook prints nothing: Claude Code asks in its own UI
                    sessions.jump(id)
                    controller.collapse()
                }
            }
        }
    }
}
