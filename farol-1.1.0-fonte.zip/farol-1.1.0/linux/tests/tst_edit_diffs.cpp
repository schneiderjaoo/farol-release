#include <QtTest>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "AppState.h"
#include "EditDiffs.h"
#include "FakeScheduler.h"
#include "IslandController.h"

using namespace farol;

class TestEditDiffs : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandController> ctl;
    std::unique_ptr<EditDiffs> diffs;

    // An edit of `file` that put `text` where "old" was.
    static EditDiff edit(const QString &file, const QString &text = QStringLiteral("new"))
    {
        EditDiff d;
        d.file = file;
        d.added = 1;
        d.removed = 1;
        d.rows = {{QChar(u'@'), QStringLiteral("@@ -1,2 +1,2 @@")}, {QChar(u' '), QStringLiteral("same")},
                  {QChar(u'-'), QStringLiteral("old")}, {QChar(u'+'), text}};
        return d;
    }
    // A session in the island, by the id of its task.
    void session(const QString &id, const QString &name)
    {
        AgentTask t;
        t.id = id;
        t.name = name;
        state->addTask(t);
    }
    QStringList rowsShown() const
    {
        QStringList out;
        for (const QVariant &row : diffs->rows())
            out << row.toMap().value("kind").toString() + row.toMap().value("text").toString();
        return out;
    }

private slots:
    void init()
    {
        diffs.reset();
        QFile::remove(dir.path() + "/d.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/d.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        sched = std::make_unique<FakeScheduler>();
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [] { return qint64(0); });
        diffs = std::make_unique<EditDiffs>(state.get(), ctl.get());
    }

    void everyDiffGetsAnIdOfItsOwn()
    {
        QSignalSpy changed(diffs.get(), &EditDiffs::changed);
        const int before = diffs->revision();
        const qint64 a = diffs->add("session_a", edit("/w/a.txt"));
        const qint64 b = diffs->add("session_a", edit("/w/b.txt"));
        const qint64 c = diffs->add("session_b", edit("/w/c.txt"));
        QVERIFY(a > 0 && b > a && c > b);
        QVERIFY(diffs->has(a) && diffs->has(b) && diffs->has(c));
        QVERIFY(!diffs->has(0) && !diffs->has(c + 1) && !diffs->has(-1));
        QCOMPARE(diffs->kept("session_a"), 2);
        QCOMPARE(diffs->kept("session_b"), 1);
        QCOMPARE(diffs->kept("session_c"), 0);
        QCOMPARE(changed.count(), 3);                              // what QML binds to: has() and kept() may say something else now
        QVERIFY(diffs->revision() != before);
        QVERIFY(!diffs->active());                                 // keeping a diff opens nothing
        QVERIFY(state->view() == IslandView::Overview);
        QVERIFY(state->mode() != IslandMode::Expanded);
    }

    void theTwentyFirstPushesTheOldestOut()
    {
        QList<qint64> ids;
        const qint64 other = diffs->add("session_b", edit("/w/other.txt"));
        for (int i = 0; i < EditDiffs::kPerSession + 1; ++i)
            ids << diffs->add("session_a", edit(QStringLiteral("/w/f%1.txt").arg(i)));
        QCOMPARE(EditDiffs::kPerSession, 20);
        QCOMPARE(diffs->kept("session_a"), 20);
        QVERIFY(!diffs->has(ids.first()));
        QVERIFY(diffs->has(ids.at(1)) && diffs->has(ids.last()));
        QVERIFY(diffs->has(other));                                // each session has its own twenty
        QCOMPARE(diffs->kept("session_b"), 1);
        QVERIFY(!diffs->open(ids.first()));                        // gone is gone
        QVERIFY(!diffs->active());
    }

    void forgettingASessionLeavesTheOthers()
    {
        const qint64 a = diffs->add("session_a", edit("/w/a.txt"));
        const qint64 b = diffs->add("session_b", edit("/w/b.txt"));
        QSignalSpy changed(diffs.get(), &EditDiffs::changed);
        diffs->forget("session_a");
        QVERIFY(!diffs->has(a));
        QVERIFY(diffs->has(b));
        QCOMPARE(diffs->kept("session_a"), 0);
        QCOMPARE(changed.count(), 1);
        diffs->forget("session_a");                                // nothing of it left: nothing to say
        diffs->forget("session_never");
        QCOMPARE(changed.count(), 1);
        QVERIFY(!diffs->openLatest("session_a"));
    }

    void openingADiffShowsItInTheIsland()
    {
        EditDiff made = edit("/work/farol/linux/qml/DiffView.qml", "a rather longer line");
        made.created = true;
        made.cut = true;
        made.added = 12;
        made.removed = 3;
        session("session_a", "farol 2");
        const qint64 id = diffs->add("session_a", made);
        diffs->add("session_a", edit("/w/later.txt"));
        QSignalSpy current(diffs.get(), &EditDiffs::currentChanged);
        QVERIFY(diffs->open(id));
        QCOMPARE(current.count(), 1);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Diff);
        QVERIFY(diffs->active());
        QCOMPARE(diffs->id(), id);
        QCOMPARE(diffs->file(), QStringLiteral("/work/farol/linux/qml/DiffView.qml"));
        QCOMPARE(diffs->fileName(), QStringLiteral("DiffView.qml"));
        QCOMPARE(diffs->session(), QStringLiteral("farol 2"));
        QCOMPARE(diffs->added(), 12);
        QCOMPARE(diffs->removed(), 3);
        QVERIFY(diffs->created());
        QVERIFY(diffs->cut());
        QCOMPARE(rowsShown(), (QStringList{"@@@ -1,2 +1,2 @@", " same", "-old", "+a rather longer line"}));
        QCOMPARE(diffs->columns(), 20);                            // its longest line, for the width of the list
        QCOMPARE(diffs->position(), 0);
        QCOMPARE(diffs->count(), 2);

        QVERIFY(!diffs->open(id + 99));                            // an id nobody has: the one on screen stays
        QCOMPARE(diffs->id(), id);
        QCOMPARE(current.count(), 1);
    }

    void aFileWithoutAFolderIsItsOwnName()
    {
        QVERIFY(diffs->open(diffs->add("session_a", edit("notes.txt"))));
        QCOMPARE(diffs->fileName(), QStringLiteral("notes.txt"));
        QVERIFY(diffs->open(diffs->add("session_a", edit(QString()))));
        QCOMPARE(diffs->fileName(), QString());
    }

    // The diff on screen is a copy: the session goes on editing, and what the user reads stays whole.
    void theOpenDiffIsASnapshot()
    {
        const qint64 first = diffs->add("session_a", edit("/w/first.txt", "first"));
        QVERIFY(diffs->open(first));
        QSignalSpy current(diffs.get(), &EditDiffs::currentChanged);
        QSignalSpy changed(diffs.get(), &EditDiffs::changed);
        for (int i = 0; i < EditDiffs::kPerSession; ++i)
            diffs->add("session_a", edit(QStringLiteral("/w/f%1.txt").arg(i)));
        QVERIFY(!diffs->has(first));
        QVERIFY(diffs->active());
        QCOMPARE(diffs->id(), first);
        QCOMPARE(diffs->fileName(), QStringLiteral("first.txt"));
        QCOMPARE(rowsShown().last(), QStringLiteral("+first"));
        QCOMPARE(current.count(), 0);                              // the rows on screen were not handed out again
        QCOMPARE(changed.count(), EditDiffs::kPerSession);         // but "1 de 1" is no longer true
        QCOMPARE(diffs->position(), -1);                           // it is none of the twenty kept
        QCOMPARE(diffs->count(), 20);
    }

    void stepWalksTheDiffsOfThatSession()
    {
        const qint64 a = diffs->add("session_a", edit("/w/a.txt"));
        diffs->add("session_b", edit("/w/other.txt"));
        const qint64 b = diffs->add("session_a", edit("/w/b.txt"));
        const qint64 c = diffs->add("session_a", edit("/w/c.txt"));
        diffs->step(1);                                            // nothing open: nothing to walk from
        QVERIFY(!diffs->active());
        QVERIFY(diffs->open(b));
        QCOMPARE(diffs->position(), 1);
        QCOMPARE(diffs->count(), 3);
        QSignalSpy current(diffs.get(), &EditDiffs::currentChanged);
        diffs->step(1);
        QCOMPARE(diffs->id(), c);
        QCOMPARE(diffs->fileName(), QStringLiteral("c.txt"));
        QCOMPARE(diffs->position(), 2);
        QCOMPARE(current.count(), 1);
        diffs->step(1);                                            // the newest: there is no next
        QCOMPARE(diffs->id(), c);
        QCOMPARE(current.count(), 1);
        diffs->step(-2);
        QCOMPARE(diffs->id(), a);
        QCOMPARE(diffs->position(), 0);
        diffs->step(-1);                                           // the oldest: there is none before
        QCOMPARE(diffs->id(), a);
        diffs->step(0);
        QCOMPARE(current.count(), 2);
        diffs->step(5);                                            // further than there are: the last one
        QCOMPARE(diffs->id(), c);
        QVERIFY(state->view() == IslandView::Diff);
    }

    // The open diff was pushed out meanwhile: "next" is the oldest that is still kept, and there is no "previous".
    void steppingFromADiffThatIsGone()
    {
        const qint64 first = diffs->add("session_a", edit("/w/first.txt"));
        QVERIFY(diffs->open(first));
        QList<qint64> ids;
        for (int i = 0; i < EditDiffs::kPerSession; ++i)
            ids << diffs->add("session_a", edit(QStringLiteral("/w/f%1.txt").arg(i)));
        diffs->step(-1);
        QCOMPARE(diffs->id(), first);
        diffs->step(1);
        QCOMPARE(diffs->id(), ids.first());
        QCOMPARE(diffs->position(), 0);
    }

    void openLatestIsTheNewestOfThatSession()
    {
        QVERIFY(!diffs->openLatest("session_a"));
        QVERIFY(state->view() == IslandView::Overview);
        session("session_a", "farol");
        session("session_b", "site");
        diffs->add("session_a", edit("/w/a.txt"));
        const qint64 newest = diffs->add("session_a", edit("/w/b.txt"));
        diffs->add("session_b", edit("/w/other.txt"));
        QVERIFY(diffs->openLatest("session_a"));
        QCOMPARE(diffs->id(), newest);
        QCOMPARE(diffs->session(), QStringLiteral("farol"));
        QCOMPARE(diffs->position(), 1);
        QCOMPARE(diffs->count(), 2);
        QVERIFY(state->view() == IslandView::Diff);
    }

    // The head of the view names the session as the island does now: Claude Code may give it a title, or a second
    // session may open in its repository, while the diff is on screen.
    void theSessionGoesByTheNameItHasNow()
    {
        session("session_a", "farol");
        const qint64 id = diffs->add("session_a", edit("/w/a.txt"));
        state->modifyTask("session_a", [](AgentTask &t) { t.name = QStringLiteral("farol 2"); });   // before it is opened
        QVERIFY(diffs->open(id));
        QCOMPARE(diffs->session(), QStringLiteral("farol 2"));
        QSignalSpy named(diffs.get(), &EditDiffs::sessionChanged);
        QSignalSpy current(diffs.get(), &EditDiffs::currentChanged);
        state->modifyTask("session_a", [](AgentTask &t) { t.name = QStringLiteral("Lista de sessões"); });
        QCOMPARE(diffs->session(), QStringLiteral("Lista de sessões"));
        QCOMPARE(named.count(), 1);
        QCOMPARE(current.count(), 0);                              // the rows on screen are not handed out again for a name
        state->modifyTask("session_a", [](AgentTask &t) { t.state = BotState::Working; });       // something else of it changed
        state->modifyTask("integration_claude", [](AgentTask &t) { t.name = QStringLiteral("outra"); });
        QCOMPARE(named.count(), 1);
        QCOMPARE(diffs->session(), QStringLiteral("Lista de sessões"));

        diffs->add("session_gone", edit("/w/b.txt"));              // a session the island does not list: no name, no harm
        QVERIFY(diffs->openLatest("session_gone"));
        QCOMPARE(diffs->session(), QString());
    }

    void closeGoesBackToTheOverview()
    {
        const qint64 id = diffs->add("session_a", edit("/w/a.txt"));
        QVERIFY(diffs->open(id));
        diffs->close();
        QVERIFY(state->view() == IslandView::Overview);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(diffs->has(id));                                   // a click on its step opens it again
        QVERIFY(diffs->open(id));
        QVERIFY(state->view() == IslandView::Diff);

        ctl->showView("settings");                                 // the user went elsewhere: close() takes no view from them
        diffs->close();
        QVERIFY(state->view() == IslandView::Settings);
    }

    void theOpenDiffIsDroppedWhenTheIslandCloses()
    {
        const qint64 id = diffs->add("session_a", edit("/w/a.txt"));
        QVERIFY(diffs->open(id));
        QSignalSpy current(diffs.get(), &EditDiffs::currentChanged);
        ctl->collapse();
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(!diffs->active());
        QVERIFY(diffs->rows().isEmpty());
        QCOMPARE(diffs->id(), qint64(0));
        QCOMPARE(diffs->file(), QString());
        QCOMPARE(diffs->position(), -1);
        QCOMPARE(diffs->count(), 0);
        QCOMPARE(current.count(), 1);
        QVERIFY(state->view() == IslandView::Overview);            // the next open is the overview, not an empty diff
        QVERIFY(diffs->has(id));                                   // it is still kept

        QVERIFY(diffs->open(id));                                  // hidden straight from the open island, too
        state->setMode(IslandMode::Hidden);
        QVERIFY(!diffs->active());
        QVERIFY(state->view() == IslandView::Overview);

        QVERIFY(diffs->open(id));                                  // another view over it, then closed: that view is not touched
        ctl->showView("settings");
        ctl->collapse();
        QVERIFY(!diffs->active());
        QVERIFY(state->view() == IslandView::Settings);
    }

    void forgettingTheSessionOfTheOpenDiffLeavesTheView()
    {
        const qint64 a = diffs->add("session_a", edit("/w/a.txt"));
        diffs->add("session_b", edit("/w/b.txt"));
        QVERIFY(diffs->open(a));
        diffs->forget("session_b");                                // not the one on screen
        QVERIFY(diffs->active());
        QVERIFY(state->view() == IslandView::Diff);
        diffs->forget("session_a");
        QVERIFY(!diffs->active());
        QVERIFY(diffs->rows().isEmpty());
        QVERIFY(state->view() == IslandView::Overview);
        QVERIFY(state->mode() == IslandMode::Expanded);
    }

    // A session whose kept diffs all left (twenty newer ones, then the open one is its last trace) still ends cleanly.
    void forgettingASessionThatOnlyHasTheOpenSnapshot()
    {
        const qint64 a = diffs->add("session_a", edit("/w/a.txt"));
        QVERIFY(diffs->open(a));
        for (int i = 0; i < EditDiffs::kPerSession; ++i)
            diffs->add("session_a", edit("/w/x.txt"));
        diffs->forget("session_a");
        QVERIFY(!diffs->active());
        QCOMPARE(diffs->kept("session_a"), 0);
        QVERIFY(state->view() == IslandView::Overview);
    }
};

QTEST_MAIN(TestEditDiffs)
#include "tst_edit_diffs.moc"
