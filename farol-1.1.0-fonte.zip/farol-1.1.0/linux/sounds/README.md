# Sounds

Farol plays short WAV effects (28 names, listed in `src/core/SoundNames.h`: `peek`, `open`, `close`, `finish`,
`approval`, `question`, `error`, ...). **The sound files are not part of this repository**: put your own `<name>.wav`
files in this folder (or point `FAROL_SOUNDS_DIR` at another one). Without them Farol runs silent and the sound tests
are skipped. `*.wav` files here are ignored by git.
