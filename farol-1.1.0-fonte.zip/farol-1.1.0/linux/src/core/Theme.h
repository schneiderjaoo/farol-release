#pragma once
#include <QObject>
#include <QString>

namespace farol {

class AppState;

// Colour and font tokens of the Farol identity (docs: "Farol — identidade visual").
// Colours are strings ("#RRGGBB" or "#AARRGGBB") so QML reads them as `color` without a QtGui dependency here.
// Dark is "Noite no cais", light is "Amanhecer"; the session signals are the same in both.
class Theme : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool dark READ dark NOTIFY changed)
    Q_PROPERTY(QString bodyFont READ bodyFont CONSTANT)
    Q_PROPERTY(QString titleFont READ titleFont CONSTANT)
    Q_PROPERTY(QString monoFont READ monoFont CONSTANT)

#define FAROL_THEME_TOKEN(name) \
    Q_PROPERTY(QString name READ name NOTIFY changed) \
public: \
    QString name() const { return pick(&Palette::name); } \
private:

    FAROL_THEME_TOKEN(islandBg)     // island surface
    FAROL_THEME_TOKEN(card)         // cards, selected tab
    FAROL_THEME_TOKEN(line)         // hairlines
    FAROL_THEME_TOKEN(codeBg)       // command block
    FAROL_THEME_TOKEN(text)
    FAROL_THEME_TOKEN(textHover)    // text of a hovered control
    FAROL_THEME_TOKEN(muted)
    FAROL_THEME_TOKEN(dim)
    FAROL_THEME_TOKEN(hoverFill)    // translucent fills over the island
    FAROL_THEME_TOKEN(pillFill)
    FAROL_THEME_TOKEN(pillHoverFill)
    FAROL_THEME_TOKEN(subtleFill)
    FAROL_THEME_TOKEN(countdown)
    FAROL_THEME_TOKEN(primary)      // primary button
    FAROL_THEME_TOKEN(primaryHover)
    FAROL_THEME_TOKEN(primaryText)
    FAROL_THEME_TOKEN(primaryDim)   // secondary text on a primary button
    FAROL_THEME_TOKEN(alertText)    // error text
    FAROL_THEME_TOKEN(link)         // a link in an answer (underlined)
    // Session signals (same in both themes).
    FAROL_THEME_TOKEN(lamp)         // waiting for you
    FAROL_THEME_TOKEN(ok)           // finished
    FAROL_THEME_TOKEN(alert)        // error
    FAROL_THEME_TOKEN(working)      // working
    FAROL_THEME_TOKEN(idle)         // idle
#undef FAROL_THEME_TOKEN

public:
    explicit Theme(AppState *state, QObject *parent = nullptr);

    bool dark() const;
    // What the desktop asks for; only matters while the mode is "system".
    void setSystemDark(bool dark);

    QString bodyFont() const { return QStringLiteral("Instrument Sans"); }
    QString titleFont() const { return QStringLiteral("Bricolage Grotesque"); }
    QString monoFont() const { return QStringLiteral("monospace"); }   // the system's fixed-width font: commands, code

signals:
    void changed();

private:
    struct Palette {
        QString islandBg, card, line, codeBg, text, textHover, muted, dim, hoverFill, pillFill, pillHoverFill, subtleFill, countdown,
            primary, primaryHover, primaryText, primaryDim, alertText, link, lamp, ok, alert, working, idle;
    };
    static const Palette &darkPalette();
    static const Palette &lightPalette();
    QString pick(QString Palette::*member) const { return (dark() ? darkPalette() : lightPalette()).*member; }

    AppState *m_state;
    bool m_systemDark = true;   // the desktop did not say: dark
};

} // namespace farol
