#include <QtTest>
#include <QJsonArray>
#include <QJsonDocument>
#include "FakeScheduler.h"
#include "QuestionDesk.h"

using namespace farol;

class TestQuestionDesk : public QObject {
    Q_OBJECT
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<QuestionDesk> desk;
    QList<QJsonObject> replies;   // what the held hook got back ({} = "decide in the editor")

    QuestionDesk::Reply recorder()
    {
        return [this](const QJsonObject &o) { replies << o; };
    }
    static QJsonObject input(const char *json) { return QJsonDocument::fromJson(json).object(); }
    static QJsonObject one()
    {
        return input(R"({"questions":[{"question":"Qual banco?","header":"Banco","multiSelect":false,
            "options":[{"label":"Postgres","description":"Robusto"},{"label":"SQLite","description":"Simples"}]}]})");
    }
    static QJsonObject two()
    {
        return input(R"({"questions":[
            {"question":"Qual banco?","header":"Banco","multiSelect":false,"options":[{"label":"Postgres"},{"label":"SQLite"}]},
            {"question":"Quais telas?","header":"Telas","multiSelect":true,"options":[{"label":"Login"},{"label":"Painel"},{"label":"Ajuda"}]}]})");
    }
    QStringList labels() const
    {
        QStringList out;
        for (const QVariant &o : desk->options())
            out << o.toMap().value("label").toString();
        return out;
    }
    bool selected(const QString &label) const
    {
        for (const QVariant &o : desk->options())
            if (o.toMap().value("label").toString() == label)
                return o.toMap().value("selected").toBool();
        return false;
    }

private slots:
    void init()
    {
        desk.reset();                                // it holds a reference to the scheduler: it goes first
        sched = std::make_unique<FakeScheduler>();
        desk = std::make_unique<QuestionDesk>(*sched);
        replies.clear();
    }

    void holdShowsTheFirstQuestion()
    {
        QVERIFY(desk->hold("s1", "farol", one(), recorder()) != 0);
        QVERIFY(desk->active());
        QCOMPARE(desk->sessionId(), QStringLiteral("s1"));
        QCOMPARE(desk->project(), QStringLiteral("farol"));
        QCOMPARE(desk->count(), 1);
        QCOMPARE(desk->index(), 0);
        QCOMPARE(desk->question(), QStringLiteral("Qual banco?"));
        QCOMPARE(desk->header(), QStringLiteral("Banco"));
        QVERIFY(!desk->multiSelect());
        QCOMPARE(labels(), (QStringList{"Postgres", "SQLite"}));
        QCOMPARE(desk->options().first().toMap().value("description").toString(), QStringLiteral("Robusto"));
        QVERIFY(replies.isEmpty());                  // nothing is answered without a click
    }

    void choosingAnswersWithTheWholeInputPlusTheAnswer()
    {
        QSignalSpy finished(desk.get(), &QuestionDesk::finished);
        desk->hold("s1", "farol", one(), recorder());
        desk->choose("SQLite");
        QCOMPARE(replies.size(), 1);
        QCOMPARE(replies.first().value("questions").toArray(), one().value("questions").toArray());
        QCOMPARE(replies.first().value("answers").toObject(), (QJsonObject{{"Qual banco?", "SQLite"}}));
        QVERIFY(!desk->active());
        QCOMPARE(finished.count(), 1);
        QCOMPARE(finished.at(0).at(0).toString(), QStringLiteral("s1"));
        QCOMPARE(finished.at(0).at(1).toBool(), true);
        QCOMPARE(sched->pending(), 0);
    }

    void aLabelThatIsNotAnOptionIsIgnored()
    {
        desk->hold("s1", "farol", one(), recorder());
        desk->choose("MongoDB");
        QVERIFY(replies.isEmpty());
        QVERIFY(desk->active());
    }

    void severalQuestionsAreAskedOneByOne()
    {
        desk->hold("s1", "farol", two(), recorder());
        QCOMPARE(desk->count(), 2);
        desk->choose("Postgres");
        QVERIFY(replies.isEmpty());                  // one more to go
        QCOMPARE(desk->index(), 1);
        QCOMPARE(desk->question(), QStringLiteral("Quais telas?"));
        QVERIFY(desk->multiSelect());
        desk->choose("Painel");                      // multi-select: a click toggles
        desk->choose("Login");
        desk->choose("Ajuda");
        desk->choose("Ajuda");                       // off again
        QVERIFY(selected("Painel") && selected("Login") && !selected("Ajuda"));
        QVERIFY(replies.isEmpty());
        desk->confirm();
        QCOMPARE(replies.size(), 1);
        // in the order of the options, comma-separated
        QCOMPARE(replies.first().value("answers").toObject(),
                 (QJsonObject{{"Qual banco?", "Postgres"}, {"Quais telas?", "Login, Painel"}}));
    }

    void confirmNeedsAtLeastOneChoiceAndOnlyAppliesToMultiSelect()
    {
        desk->hold("s1", "farol", two(), recorder());
        desk->confirm();                             // single-select: confirm does nothing
        QCOMPARE(desk->index(), 0);
        desk->choose("Postgres");
        desk->confirm();                             // nothing ticked yet
        QCOMPARE(desk->index(), 1);
        QVERIFY(replies.isEmpty());
    }

    void releaseHandsTheQuestionToTheEditor()
    {
        QSignalSpy finished(desk.get(), &QuestionDesk::finished);
        desk->hold("s1", "farol", one(), recorder());
        desk->release();
        QCOMPARE(replies.size(), 1);
        QVERIFY(replies.first().isEmpty());
        QVERIFY(!desk->active());
        QCOMPARE(finished.at(0).at(1).toBool(), false);
    }

    void timeoutReleases()
    {
        desk->hold("s1", "farol", one(), recorder());
        sched->advance(QuestionDesk::kTimeoutMs - 1);
        QVERIFY(replies.isEmpty());
        sched->advance(1);
        QCOMPARE(replies.size(), 1);
        QVERIFY(replies.first().isEmpty());
    }

    void cancelDropsItWithoutReplying()
    {
        const qint64 id = desk->hold("s1", "farol", one(), recorder());
        desk->cancel(id + 1);
        QVERIFY(desk->active());
        desk->cancel(id);
        QVERIFY(!desk->active());
        QVERIFY(replies.isEmpty());
        QCOMPARE(sched->pending(), 0);
    }

    void onlyOneQuestionIsHeldAndUnusableInputIsRefused()
    {
        QCOMPARE(desk->hold("s1", "farol", input(R"({"questions":[]})"), recorder()), qint64(0));
        QCOMPARE(desk->hold("s1", "farol", input(R"({"questions":[{"question":"Sem opções?","options":[]}]})"), recorder()), qint64(0));
        QCOMPARE(desk->hold("s1", "farol", input(R"({"questions":[{"question":"","options":[{"label":"a"}]}]})"), recorder()), qint64(0));
        QVERIFY(desk->hold("s1", "farol", one(), recorder()) != 0);
        QCOMPARE(desk->hold("s2", "other", one(), recorder()), qint64(0));
        QCOMPARE(desk->sessionId(), QStringLiteral("s1"));
        QVERIFY(replies.isEmpty());                  // a refused hold is answered by the caller, not here
    }

    void forgetReleasesTheQuestionOfAnEndedSession()
    {
        desk->hold("s1", "farol", one(), recorder());
        desk->forget("other");
        QVERIFY(desk->active());
        desk->forget("s1");
        QVERIFY(!desk->active());
    }
};

QTEST_GUILESS_MAIN(TestQuestionDesk)
#include "tst_question_desk.moc"
