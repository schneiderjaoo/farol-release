#!/bin/sh
# Runs a command inside the Linux Mint 22 image, with the repository at /src and as the user who calls it, so that
# what it builds belongs to that user. Build the image first (see the Dockerfile).
#   linux/packaging/mint22/run.sh cmake -S linux -B linux/build-mint22 -G Ninja
repo=$(cd "$(dirname "$0")/../../.." && pwd)
# The image does not know the caller: a line for them in its list of users (a session bus refuses a nameless one).
users=$(mktemp)
docker run --rm farol-mint22 cat /etc/passwd > "$users"
echo "farol:x:$(id -u):$(id -g):Farol:/tmp:/bin/sh" >> "$users"
docker run --rm --network host --security-opt label=disable --user "$(id -u):$(id -g)" -e HOME=/tmp \
    -v "$users":/etc/passwd:ro -v "$repo":/src -w /src farol-mint22 "$@"
status=$?
rm -f "$users"
exit $status
