#include "SkillsFolder.h"

#include "Links.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QSet>
#include <algorithm>

namespace farol {

namespace {

// The `name:` of a SKILL.md's front matter, if it can be a file name.
QString declaredName(const QString &skillFile)
{
    QFile f(skillFile);
    if (!f.open(QIODevice::ReadOnly))
        return {};
    const QStringList lines = QString::fromUtf8(f.read(8192)).split(QLatin1Char('\n'));
    if (lines.isEmpty() || lines.first().trimmed() != QLatin1String("---"))
        return {};
    for (int i = 1; i < lines.size(); ++i) {
        const QString line = lines.at(i).trimmed();
        if (line == QLatin1String("---"))
            break;
        if (!line.startsWith(QLatin1String("name:")))
            continue;
        QString name = line.mid(5).trimmed();
        if (name.size() >= 2 && (name.startsWith(QLatin1Char('"')) || name.startsWith(QLatin1Char('\''))) && name.endsWith(name.at(0)))
            name = name.mid(1, name.size() - 2).trimmed();
        if (name.isEmpty() || name.startsWith(QLatin1Char('.')) || name.contains(QLatin1Char('/')) || name.contains(QLatin1Char('\\')))
            return {};
        return name;
    }
    return {};
}

#ifdef Q_OS_WIN
constexpr Qt::CaseSensitivity kPathCase = Qt::CaseInsensitive;   // "C:/Work" and "c:/work" are one folder
#else
constexpr Qt::CaseSensitivity kPathCase = Qt::CaseSensitive;
#endif

bool same(const QString &a, const QString &b)
{
    return QDir::cleanPath(a).compare(QDir::cleanPath(b), kPathCase) == 0;
}

bool inside(const QString &path, const QString &dir)
{
    if (dir.isEmpty())
        return false;
    const QString d = QDir::cleanPath(dir), p = QDir::cleanPath(path);
    return p.compare(d, kPathCase) == 0 || p.startsWith(d + QLatin1Char('/'), kPathCase);
}

} // namespace

QList<SkillEntry> scanSkills(const QString &skillsDir)
{
    QList<SkillEntry> out;
    if (skillsDir.isEmpty())
        return out;
    const QDir dir(skillsDir);
    for (const QString &folder : dir.entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name)) {   // no hidden ones
        if (folder.startsWith(QLatin1Char('.')))   // hidden by its name: Windows lists it like any other
            continue;
        const QString path = dir.absoluteFilePath(folder);
        if (!QFileInfo(path + QStringLiteral("/SKILL.md")).isFile())
            continue;
        const QString declared = declaredName(path + QStringLiteral("/SKILL.md"));
        out.append({declared.isEmpty() ? folder : declared, QDir::cleanPath(path)});
    }
    return out;
}

LinkPlan planLinks(const QString &skillsDir, const QString &claudeSkillsDir, const QString &previousDir)
{
    LinkPlan plan;
    const auto ours = [&](const QString &link) {
        const QString target = links::target(link);
        return inside(target, skillsDir) || inside(target, previousDir);
    };
    QSet<QString> wanted;
    for (const SkillEntry &skill : scanSkills(skillsDir)) {
        if (wanted.contains(skill.name)) {   // two folders declare one name: the first has it
            plan.conflicts << skill.name;
            continue;
        }
        wanted.insert(skill.name);
        const QString there = claudeSkillsDir + QLatin1Char('/') + skill.name;
        if (links::isLink(there)) {
            if (same(links::target(there), skill.path))
                ++plan.linked;
            else if (ours(there)) {
                plan.relink.insert(skill.name, skill.path);
                ++plan.linked;
            } else {
                plan.conflicts << skill.name;
            }
        } else if (QFileInfo::exists(there)) {
            plan.conflicts << skill.name;   // a folder (or file) of the user's own
        } else {
            plan.create.insert(skill.name, skill.path);
            ++plan.linked;
        }
    }
    const QDir links(claudeSkillsDir);
    for (const QFileInfo &entry : links.entryInfoList(QDir::AllEntries | QDir::System | QDir::NoDotAndDotDot, QDir::Name))
        if (links::isLink(entry.absoluteFilePath()) && !wanted.contains(entry.fileName()) && ours(entry.absoluteFilePath()))
            plan.remove << entry.fileName();
    std::sort(plan.conflicts.begin(), plan.conflicts.end());
    plan.conflicts.removeDuplicates();
    return plan;
}

bool applyLinks(const LinkPlan &plan, const QString &claudeSkillsDir, QString *error)
{
    const auto fail = [&](const QString &what) {
        if (error)
            *error = what;
        return false;
    };
    if (!plan.changes())
        return true;
    if (!QDir().mkpath(claudeSkillsDir))
        return fail(QStringLiteral("could not create ") + claudeSkillsDir);
    const auto at = [&](const QString &name) { return claudeSkillsDir + QLatin1Char('/') + name; };
    for (const QString &name : plan.remove)
        if (!links::remove(at(name)))   // the link itself, never what it points to
            return fail(QStringLiteral("could not remove the link ") + at(name));
    for (auto it = plan.relink.cbegin(); it != plan.relink.cend(); ++it)
        if (!links::remove(at(it.key())) || !links::make(it.value(), at(it.key())))
            return fail(QStringLiteral("could not change the link ") + at(it.key()));
    for (auto it = plan.create.cbegin(); it != plan.create.cend(); ++it)
        if (!links::make(it.value(), at(it.key())))
            return fail(QStringLiteral("could not create the link ") + at(it.key()));
    return true;
}

} // namespace farol
