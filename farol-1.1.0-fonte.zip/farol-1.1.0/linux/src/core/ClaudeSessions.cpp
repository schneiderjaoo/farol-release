#include "ClaudeSessions.h"

#include "AppState.h"
#include "IslandController.h"
#include "SessionTitle.h"

#include <QJsonArray>
#include <algorithm>

namespace farol {

namespace {
const QString kClaudeId = QStringLiteral("integration_claude");
const QStringList kPalette = {"#34D399", "#22D3EE", "#F59E0B", "#A78BFA", "#F472B6", "#60A5FA"};

// The first line of a message plainMessage() made, cut to max characters (never through a surrogate pair).
QString firstLine(const QString &plain, int max)
{
    QString line = plain.section(QLatin1Char('\n'), 0, 0).left(max);
    if (!line.isEmpty() && line.back().isHighSurrogate())
        line.chop(1);
    return line.trimmed();
}

// What a permission request is about: the command for Bash, otherwise the most telling field of the tool input.
// All of it: ApprovalQueue gives the card its beginning and keeps the whole of a command for "Sempre".
QString approvalCommand(const HookEvent &e)
{
    for (const char *key : {"command", "file_path", "path", "url", "pattern", "query"}) {
        const QString v = e.toolInput.value(QLatin1String(key)).toString();
        if (!v.isEmpty())
            return v;
    }
    return e.toolName.isEmpty() ? QStringLiteral("Tool") : e.toolName;
}

// The first question of an AskUserQuestion tool input and its option labels.
void questionOf(const QJsonObject &toolInput, QString &text, QStringList &options)
{
    const QJsonArray questions = toolInput.value("questions").toArray();
    const QJsonObject q = questions.isEmpty() ? QJsonObject() : questions.first().toObject();
    text = clip(q.value("question").toString(), 200);
    options.clear();
    for (const QJsonValue &o : q.value("options").toArray())
        options << o.toObject().value("label").toString();
}

// Tools whose "permission" is how Claude Code draws its own answer UI: a decision from the island would skip it.
bool isEditorDecision(const QString &tool)
{
    return tool == QLatin1String("AskUserQuestion") || tool == QLatin1String("ExitPlanMode");
}

bool isRateLimitNotice(const HookEvent &e)
{
    const QString lower = e.message.toLower();
    return e.notificationType.startsWith(QLatin1String("rate")) || lower.contains(QLatin1String("rate limit")) ||
           lower.contains(QLatin1String("usage limit"));
}

bool isQuestionNotice(const HookEvent &e)
{
    return e.notificationType == QLatin1String("elicitation_dialog") || e.message.trimmed().endsWith('?');
}

// The session cannot go on until the user answers.
bool isWaiting(BotState s) { return s == BotState::Approval || s == BotState::Question; }

QString sessionName(const QString &project, int number)
{
    return number <= 1 ? project : project + QLatin1Char(' ') + QString::number(number);
}
} // namespace

ClaudeSessions::ClaudeSessions(AppState *state, IslandController *controller, IScheduler *scheduler,
                               ApprovalQueue *queue, QuestionDesk *questions, IProcessWatch *processes, EditDiffs *diffs,
                               QObject *parent)
    : QObject(parent), m_state(state), m_controller(controller), m_sched(scheduler), m_queue(queue),
      m_questions(questions), m_processes(processes), m_diffs(diffs)
{
    connect(m_state, &AppState::sessionIdleSecondsChanged, this, [this] {
        for (const QString &sid : m_sessions.keys())
            arm(sid);                                    // the new time counts from now
    });
    connect(m_queue, &ApprovalQueue::shown, this, &ClaudeSessions::onShown);
    connect(m_queue, &ApprovalQueue::resolved, this, &ClaudeSessions::onResolved);
    connect(m_queue, &ApprovalQueue::leftToEditor, this, &ClaudeSessions::onLeftToEditor);
    if (m_questions)
        connect(m_questions, &QuestionDesk::finished, this, &ClaudeSessions::onQuestionFinished);
}

QString ClaudeSessions::nextColor() const
{
    QStringList used;
    for (const AgentTask &t : m_state->taskModel()->all())
        used << t.color;
    for (const QString &c : kPalette)
        if (!used.contains(c, Qt::CaseInsensitive))
            return c;
    return kPalette.at(int(m_sessions.size()) % kPalette.size());
}

// No two sessions look alike in the compact island: the first of the eight boats no live session has (the first
// session is the saveiro, the second the pirata...); once all are out, the first one no session has in this colour.
int ClaudeSessions::nextBoat(const QString &color) const
{
    constexpr int kBoats = 8;
    QList<int> used, usedInColor;
    for (const AgentTask &t : m_state->taskModel()->all()) {
        if (t.isIntegration)
            continue;
        used << t.boat;
        if (t.color.compare(color, Qt::CaseInsensitive) == 0)
            usedInColor << t.boat;
    }
    for (int b = 0; b < kBoats; ++b)
        if (!used.contains(b))
            return b;
    for (int b = 0; b < kBoats; ++b)
        if (!usedInColor.contains(b))
            return b;
    return int(m_sessions.size()) % kBoats;
}

void ClaudeSessions::ensure(const HookEvent &e)
{
    const QString sid = e.sessionId;
    if (!m_sessions.contains(sid)) {
        Session s;
        s.project = e.project();
        s.number = freeNumber(s.project);
        AgentTask t;
        t.id = taskId(sid);
        t.name = sessionName(s.project, s.number);   // refreshNames() below has the last word
        t.color = nextColor();
        t.boat = nextBoat(t.color);
        t.source = AgentSource::ClaudeCode;
        t.isIntegration = false;
        t.sessionCwd = e.cwd;
        const bool first = m_sessions.isEmpty();
        m_sessions.insert(sid, s);
        m_order.append(sid);
        m_state->addTask(t);
        if (first) {
            m_state->removeTask(kClaudeId);   // the "VS Code" placeholder gives way to real sessions
            m_state->setFocus(t.id);
        }
    } else if (!e.cwd.isEmpty()) {
        Session &s = m_sessions[sid];
        if (s.project != e.project()) {       // the session moved to another folder
            const QString left = s.project;
            s.number = freeNumber(e.project(), sid);
            s.project = e.project();
            refreshNames(left);
        }
        if (s.jump.cwd != e.cwd)
            m_state->modifyTask(taskId(sid), [&](AgentTask &t) { t.sessionCwd = e.cwd; });
    }
    Session &s = m_sessions[sid];
    s.jump = {e.source, e.cwd.isEmpty() ? s.jump.cwd : e.cwd, e.flatpakId, e.konsoleService, e.konsoleSession, e.konsoleWindow,
              e.editor, e.ancestors.isEmpty() ? s.jump.ancestors : e.ancestors};
    if (e.source == QLatin1String("vscodium"))
        m_lastEditor = {e.source, {}, e.flatpakId, {}, {}, {}, e.editor, {}};
    readTitle(sid, e);
    refreshNames(s.project);
    watchProcess(sid, e);
}

// What the transcript says about the session. Claude Code names a session after its first prompt and may rename
// it later: the title is taken at every event until there is one, then whenever a turn starts or ends. The use of
// the context window is read at every event.
void ClaudeSessions::readTitle(const QString &sid, const HookEvent &e)
{
    Session &s = m_sessions[sid];
    if (!e.transcriptPath.isEmpty())
        s.transcript = e.transcriptPath;
    if (s.transcript.isEmpty())
        return;
    const bool turn = e.name == QLatin1String("Stop") || e.name == QLatin1String("UserPromptSubmit") ||
                      e.name == QLatin1String("SessionStart");
    const TranscriptInfo info = readTranscript(s.transcript);
    if (!info.title.isEmpty() && (s.title.isEmpty() || turn))
        s.title = info.title;
    // how full the context window is, after every answer
    const AgentTask *t = m_state->taskModel()->find(taskId(sid));
    if (info.contextTokens > 0 && t && t->contextTokens != info.contextTokens) {
        const int window = m_state->contextWindowFor(info.model, info.contextTokens);
        m_state->modifyTask(taskId(sid), [&](AgentTask &x) {
            x.contextTokens = info.contextTokens;
            x.contextWindow = window;
        });
    }
}

// What the island calls a session: its project while it is the only session there; with several sessions in one
// project, each one's own title, which is what tells them apart ("farol 2" until Claude Code has named it).
QString ClaudeSessions::nameOf(const QString &sid, bool *titled) const
{
    const auto it = m_sessions.constFind(sid);
    if (it == m_sessions.constEnd())
        return {};
    bool shared = false;
    for (auto other = m_sessions.constBegin(); other != m_sessions.constEnd() && !shared; ++other)
        shared = other.key() != sid && other->project == it->project;
    const bool useTitle = shared && !it->title.isEmpty();
    if (titled)
        *titled = useTitle;
    return useTitle ? it->title : sessionName(it->project, shared ? it->number : 1);
}

// A session that comes, goes or gets its title changes how its neighbours of the same project are called.
void ClaudeSessions::refreshNames(const QString &project)
{
    for (auto it = m_sessions.constBegin(); it != m_sessions.constEnd(); ++it) {
        if (it->project != project)
            continue;
        bool titled = false;
        const QString name = nameOf(it.key(), &titled);
        const AgentTask *t = m_state->taskModel()->find(taskId(it.key()));
        if (t && (t->name != name || t->titled != titled))
            m_state->modifyTask(t->id, [&](AgentTask &x) {
                x.name = name;
                x.titled = titled;
            });
    }
}

// The lowest number no other live session of that project has: a second session in one repository is "farol 2".
// A session keeps its number for life, so the names do not shuffle when another one ends.
int ClaudeSessions::freeNumber(const QString &project, const QString &exceptSid) const
{
    QList<int> used;
    for (auto it = m_sessions.constBegin(); it != m_sessions.constEnd(); ++it)
        if (it.key() != exceptSid && it->project == project)
            used << it->number;
    int n = 1;
    while (used.contains(n))
        ++n;
    return n;
}

// The process that sent the event is the session's: when it exits the session is over, SessionEnd or not (a killed
// Claude Code, a closed editor window and a crash say nothing).
void ClaudeSessions::watchProcess(const QString &sid, const HookEvent &e)
{
    Session &s = m_sessions[sid];
    if (!m_processes || e.claudePid == 0 || (e.claudePid == s.pid && e.claudeStart == s.start))
        return;
    m_processes->cancel(s.watch);
    s.pid = e.claudePid;
    s.start = e.claudeStart;
    s.watch = m_processes->watch(s.pid, s.start, [this, sid] {
        const auto it = m_sessions.find(sid);
        if (it == m_sessions.end())
            return;
        it->watch = 0;
        end(sid);
    });
}

bool ClaudeSessions::atRest(const QString &sid) const
{
    const AgentTask *t = m_state->taskModel()->find(taskId(sid));
    return t && (t->state == BotState::Idle || t->state == BotState::Finished);
}

// (Re)starts the countdown after which a silent session leaves the island. None for a session that is busy or
// kept by the setting while its process is watched: that one stays for as long as Claude Code runs.
void ClaudeSessions::arm(const QString &sid)
{
    const auto it = m_sessions.find(sid);
    if (it == m_sessions.end())
        return;
    m_sched->cancel(it->expiry);
    it->expiry = 0;
    const int idle = m_state->sessionIdleSeconds();
    const bool leavesAtRest = atRest(sid) && idle > 0;
    if (!leavesAtRest && it->watch != 0)
        return;
    it->expiry = m_sched->singleShot(leavesAtRest ? idle * 1000 : kExpiryMs, [this, sid] {
        const auto s = m_sessions.find(sid);
        if (s == m_sessions.end())
            return;
        s->expiry = 0;
        if (s->watch != 0 && atRest(sid))
            setDormant(sid, true);     // Claude Code still runs: the session only steps back
        else
            end(sid);
    });
}

void ClaudeSessions::setDormant(const QString &sid, bool dormant)
{
    const AgentTask *t = m_state->taskModel()->find(taskId(sid));
    if (!t || t->dormant == dormant)
        return;
    m_state->modifyTask(taskId(sid), [dormant](AgentTask &x) { x.dormant = dormant; });
    if (!dormant || m_state->focusId() != taskId(sid))
        return;
    for (const QString &other : std::as_const(m_order)) {   // the island turns to a session that is still about
        const AgentTask *o = m_state->taskModel()->find(taskId(other));
        if (o && !o->dormant) {
            m_state->setFocus(o->id);
            return;
        }
    }
}

void ClaudeSessions::end(const QString &sid)
{
    const Session s = m_sessions.take(sid);
    m_sched->cancel(s.expiry);
    m_sched->cancel(s.finish);
    m_sched->cancel(s.remind);
    if (m_processes)
        m_processes->cancel(s.watch);
    m_order.removeAll(sid);
    if (m_questions)
        m_questions->forget(sid);
    if (m_diffs)
        m_diffs->forget(taskId(sid));                    // and the island leaves the diff it was showing, if it is one of these
    const bool wasFocus = m_state->focusId() == taskId(sid);
    if (m_sessions.isEmpty())
        m_state->addTask(integrationAgents().first());   // the placeholder is back while nothing runs
    m_state->removeTask(taskId(sid));
    refreshNames(s.project);
    if (!wasFocus)
        return;
    m_state->setFocus(m_order.isEmpty() ? kClaudeId : taskId(m_order.first()));
    // Its alert was on screen: the session that is in focus now has nothing to show there.
    const IslandView view = m_state->view();
    if (view == IslandView::Finished || view == IslandView::Error || view == IslandView::Question)
        m_state->setView(IslandView::Overview);
}

void ClaudeSessions::setState(const QString &sid, BotState state)
{
    const AgentTask *t = m_state->taskModel()->find(taskId(sid));
    const bool wasWaiting = t && isWaiting(t->state);
    m_state->modifyTask(taskId(sid), [state](AgentTask &x) {
        x.state = state;
        if (state != BotState::Finished)
            x.finalMessage.clear();   // the session moved: what it said at the end of the turn before is old
    });
    arm(sid);   // at rest or not decides how long it may stay silent
    const auto it = m_sessions.find(sid);
    if (it == m_sessions.end() || isWaiting(state) == wasWaiting)
        return;
    m_sched->cancel(it->remind);            // a wait begins or is over
    it->remind = 0;
    it->reminders = 0;
    if (isWaiting(state))
        scheduleReminder(sid);
}

void ClaudeSessions::scheduleReminder(const QString &sid)
{
    const int seconds = m_state->waitReminderSeconds();
    if (seconds <= 0)
        return;
    m_sessions[sid].remind = m_sched->singleShot(seconds * 1000, [this, sid] { remind(sid); });
}

// The session still waits for an answer: the island says so again, the way it did the first time (sound, and the
// island opens on that session), unless something else is being asked there right now.
void ClaudeSessions::remind(const QString &sid)
{
    const auto it = m_sessions.find(sid);
    const AgentTask *t = m_state->taskModel()->find(taskId(sid));
    if (it == m_sessions.end() || !t || !isWaiting(t->state))
        return;
    it->remind = 0;
    if (m_state->waitReminderSeconds() <= 0)
        return;                               // turned off while this one was counting
    const bool question = t->state == BotState::Question;
    emit playSound(question ? QStringLiteral("question") : QStringLiteral("approval"));
    emit attention(nameOf(sid), QStringLiteral("Ainda espera a sua resposta"));
    if (!m_queue->active() && !(m_questions && m_questions->active())) {
        focus(sid);
        m_controller->expand(question ? IslandView::Question : IslandView::Overview);
    } else {
        m_controller->reveal();
    }
    if (++it->reminders < kMaxReminders)
        scheduleReminder(sid);
}

void ClaudeSessions::appendStep(const QString &sid, const QString &label, const QString &toolUseId)
{
    m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
        t.steps.append({label, toolUseId});
        while (t.steps.size() > 20)
            t.steps.removeFirst();
        t.stepIndex = int(t.steps.size()) - 1;
    });
}

// A file tool has run: its step says how many lines it added and removed, and the diff is kept for the island to
// show. The step is the one its PreToolUse made, found by the id of the call (two edits may run at once, and end
// in any order); an edit whose step is not there gets one. Only here does a step get counts: an edit that was
// denied or refused has no PostToolUse.
void ClaudeSessions::recordEdit(const QString &sid, const HookEvent &e)
{
    const std::optional<EditDiff> diff = editDiffOf(e);
    if (!diff)
        return;
    const qint64 id = m_diffs && !diff->rows.isEmpty() ? m_diffs->add(taskId(sid), *diff) : 0;
    m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
        auto step = std::find_if(t.steps.rbegin(), t.steps.rend(),
                                 [&](const Step &s) { return !e.toolUseId.isEmpty() && s.toolUseId == e.toolUseId; });
        if (step == t.steps.rend()) {
            t.steps.append({stepLabel(e.toolName, e.toolInput), e.toolUseId});
            while (t.steps.size() > 20)
                t.steps.removeFirst();
            t.stepIndex = int(t.steps.size()) - 1;
            step = t.steps.rbegin();
        }
        step->file = diff->file;
        step->added = diff->added;
        step->removed = diff->removed;
        step->diff = id;
    });
}

// A later event from the same session means the question was answered in the editor.
void ClaudeSessions::dismissStale(const QString &sid)
{
    const AgentTask *t = m_state->taskModel()->find(taskId(sid));
    if (!t || (t->alertText.isEmpty() && t->options.isEmpty()))
        return;
    if (m_questions && m_questions->active() && m_questions->sessionId() == sid)
        return;   // still waiting for a click in the island: a tool that ran in parallel does not answer it
    const bool wasQuestion = t->state == BotState::Question;
    m_state->modifyTask(taskId(sid), [](AgentTask &x) {
        x.alertText.clear();
        x.options.clear();
    });
    if (wasQuestion && m_state->focusId() == taskId(sid) && m_state->view() == IslandView::Question)
        m_state->setView(IslandView::Overview);
}

void ClaudeSessions::focus(const QString &sid)
{
    m_order.removeAll(sid);
    m_order.prepend(sid);
    m_state->setFocus(taskId(sid));
}

void ClaudeSessions::focusUnlessBusy(const QString &sid)
{
    const AgentTask *cur = m_state->taskModel()->find(m_state->focusId());
    const bool curIsLiveSession = cur && cur->id.startsWith(QLatin1String("session_")) &&
                                  m_sessions.contains(cur->id.mid(8));
    if (waitsElsewhere(sid))
        return;
    if (!cur || !curIsLiveSession || cur->state == BotState::Idle)
        focus(sid);
}

void ClaudeSessions::showQuestion(const QString &sid, const QString &text, const QStringList &options)
{
    const AgentTask *t = m_state->taskModel()->find(taskId(sid));
    if (t && t->state == BotState::Question && t->alertText == text && t->options == options)
        return;   // PreToolUse and PermissionRequest announce the same question: show it once
    setState(sid, BotState::Question);
    m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
        t.alertText = text;
        t.options = options;
    });
    emit playSound(QStringLiteral("question"));
    emit attention(nameOf(sid), text.isEmpty() ? QStringLiteral("Tem uma pergunta para você") : QStringLiteral("Pergunta: ") + text);
    if (waitsElsewhere(sid))
        return;                                      // its pill shows it; the island stays with what is waiting
    focus(sid);
    if (!m_queue->active())
        m_controller->expand(IslandView::Question);
}

// A question of another session is held for the user: the island (focus and view) stays with it, whatever the other
// sessions do meanwhile.
bool ClaudeSessions::waitsElsewhere(const QString &sid) const
{
    return m_questions && m_questions->active() && m_questions->sessionId() != sid;
}

// The turn is over. What Claude said last stays on the session's card until the session moves again (setState());
// the alert and the notification say its first line. No step: it would say the same again.
void ClaudeSessions::onStop(const QString &sid, const HookEvent &e)
{
    const QString message = plainMessage(e.lastAssistantMessage);
    const QString summary = firstLine(message, 120);
    setState(sid, BotState::Finished);
    m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
        t.finalMessage = message;
        t.alertText = summary.isEmpty() ? QStringLiteral("Sessão concluída") : summary;
    });
    emit playSound(QStringLiteral("finish"));
    emit attention(nameOf(sid), summary.isEmpty() ? QStringLiteral("Terminou") : QStringLiteral("Terminou: ") + summary);
    if (!waitsElsewhere(sid)) {
        focus(sid);
        if (!m_queue->active())
            m_controller->expand(IslandView::Finished);
    }
    // The finished state lasts kFinishedMs, then the session is idle.
    Session &s = m_sessions[sid];
    m_sched->cancel(s.finish);
    s.finish = m_sched->singleShot(kFinishedMs, [this, sid] {
        const AgentTask *t = m_state->taskModel()->find(taskId(sid));
        if (!t || t->state != BotState::Finished)
            return;
        // not setState(): the time at rest counts from the Stop, and the final message stays on the card
        m_state->updateTask(taskId(sid), BotState::Idle);
        m_state->modifyTask(taskId(sid), [](AgentTask &x) { x.alertText.clear(); });
    });
}

void ClaudeSessions::handleEvent(const HookEvent &e)
{
    if (e.name == QLatin1String("SessionEnd")) {
        if (m_sessions.contains(e.sessionId))
            end(e.sessionId);
        return;
    }
    // "Claude is waiting for your input" and the like: nothing happened in the session. It does not bring back a
    // session that already left the island and does not count as activity.
    const bool passive = e.name == QLatin1String("Notification") && !isRateLimitNotice(e) && !isQuestionNotice(e);
    if (passive && !m_sessions.contains(e.sessionId))
        return;
    ensure(e);
    const QString sid = e.sessionId;

    if (e.name == QLatin1String("SessionStart")) {
        setState(sid, BotState::Idle);
        emit playSound(QStringLiteral("work"));
    } else if (e.name == QLatin1String("UserPromptSubmit")) {
        dismissStale(sid);
        setState(sid, BotState::Thinking);
        if (!e.prompt.isEmpty())
            appendStep(sid, clip(e.prompt, 60));
        focusUnlessBusy(sid);
    } else if (e.name == QLatin1String("PreToolUse")) {
        if (e.toolName == QLatin1String("AskUserQuestion")) {
            QString text;
            QStringList options;
            questionOf(e.toolInput, text, options);
            showQuestion(sid, text, options);
        } else {
            dismissStale(sid);
            setState(sid, BotState::Working);
            appendStep(sid, stepLabel(e.toolName, e.toolInput), e.toolUseId);
        }
    } else if (e.name == QLatin1String("PostToolUse")) {
        dismissStale(sid);
        setState(sid, BotState::Working);
        recordEdit(sid, e);
    } else if (e.name == QLatin1String("PostToolUseFailure")) {
        setState(sid, BotState::Working);
        appendStep(sid, QStringLiteral("⚠ failed"));
    } else if (e.name == QLatin1String("Notification")) {
        if (isRateLimitNotice(e)) {
            setState(sid, BotState::Ratelimit);
            emit playSound(QStringLiteral("rate"));
        } else if (isQuestionNotice(e)) {
            showQuestion(sid, clip(e.message, 200), {});
        }
    } else if (e.name == QLatin1String("Stop")) {
        onStop(sid, e);
    } else if (e.name == QLatin1String("StopFailure")) {
        if (e.errorType == QLatin1String("rate_limit")) {
            setState(sid, BotState::Ratelimit);
            emit playSound(QStringLiteral("rate"));
        } else {
            const QString text = !e.errorMessage.isEmpty() ? e.errorMessage : e.message;
            setState(sid, BotState::Error);
            m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
                t.alertText = text.isEmpty() ? QStringLiteral("Claude Code stopped with an error") : clip(text, 200);
            });
            emit playSound(QStringLiteral("error"));
            emit attention(nameOf(sid), text.isEmpty() ? QStringLiteral("Parou com um erro") : QStringLiteral("Erro: ") + clip(text, 160));
            if (!waitsElsewhere(sid)) {
                focus(sid);
                m_controller->expand(IslandView::Error);
            }
        }
    } else if (e.name == QLatin1String("SubagentStart")) {
        appendStep(sid, QStringLiteral("+ subagent"));
    } else if (e.name == QLatin1String("SubagentStop")) {
        appendStep(sid, QStringLiteral("• subagent done"));
    }
    if (!passive) {
        setDormant(sid, false);
        arm(sid);
    }
    m_controller->reveal();   // no-op unless the island is hidden: a peek, never an expansion
}

qint64 ClaudeSessions::handlePermission(const HookEvent &e, ApprovalQueue::Reply reply)
{
    ensure(e);
    if (isEditorDecision(e.toolName)) {
        // Show it in the island, but never decide: the hook prints nothing and Claude Code shows its own UI.
        QString text;
        QStringList options;
        if (e.toolName == QLatin1String("AskUserQuestion"))
            questionOf(e.toolInput, text, options);
        else
            text = QStringLiteral("Plan ready: review it in the editor");
        showQuestion(e.sessionId, text, options);
        reply(Decision::Release);
        return 0;
    }
    setDormant(e.sessionId, false);
    if (atRest(e.sessionId))
        setState(e.sessionId, BotState::Working);    // it asks, so it runs: it must not leave the island while it waits
    else
        arm(e.sessionId);
    ApprovalRequest r;
    r.sessionId = e.sessionId;
    r.project = nameOf(e.sessionId);
    r.cwd = e.cwd;
    r.tool = e.toolName.isEmpty() ? QStringLiteral("Tool") : e.toolName;
    r.command = approvalCommand(e);
    return m_queue->enqueue(r, std::move(reply));
}

void ClaudeSessions::onShown(const ApprovalRequest &r)
{
    if (!m_sessions.contains(r.sessionId))
        return;
    setState(r.sessionId, BotState::Approval);
    focus(r.sessionId);
    m_state->setPinned(true);                       // before expand(): a pinned alert arms no idle timer
    emit playSound(QStringLiteral("approval"));
    emit attention(nameOf(r.sessionId), QStringLiteral("Pede permissão: %1 %2").arg(r.tool, clip(r.command, 120)).trimmed());
    m_controller->expand(IslandView::Approval);
}

void ClaudeSessions::onResolved(const ApprovalRequest &r, Decision decision)
{
    if (m_sessions.contains(r.sessionId))
        setState(r.sessionId, BotState::Working);
    if (decision == Decision::Allow)
        emit playSound(QStringLiteral("approve"));
    if (m_queue->active())
        return;                                      // the next request is shown next
    const bool showing = m_state->mode() == IslandMode::Expanded && m_state->view() == IslandView::Approval;
    if (showWaiting())
        return;
    m_state->setPinned(false);
    if (showing)
        m_controller->expand(m_controller->defaultView());   // back to the overview; restarts the idle timer
}

// Its request is in Claude Code's own prompt now: the session waits for the user there. The next event of the
// session (the tool ran, the turn ended) moves it on.
void ClaudeSessions::onLeftToEditor(const ApprovalRequest &r)
{
    if (m_sessions.contains(r.sessionId))
        setState(r.sessionId, BotState::Approval);
}

// A held question still waits for the user: the island goes (back) to it, pinned.
bool ClaudeSessions::showWaiting()
{
    if (m_questions && m_questions->active()) {
        focus(m_questions->sessionId());
        m_state->setPinned(true);
        m_controller->expand(IslandView::Question);
        return true;
    }
    return false;
}

qint64 ClaudeSessions::handleQuestion(const HookEvent &e, QuestionDesk::Reply reply)
{
    ensure(e);
    const QString sid = e.sessionId;
    QString text;
    QStringList options;
    questionOf(e.toolInput, text, options);
    setDormant(sid, false);
    const qint64 id = m_questions ? m_questions->hold(sid, nameOf(sid), e.toolInput, reply) : 0;
    if (id != 0 && !m_queue->active())
        m_state->setPinned(true);                    // before expand(): a pinned alert arms no idle timer
    showQuestion(sid, text, options);
    if (id == 0) {
        reply(QJsonObject());                        // nothing to click, or another question is held: the editor asks
        return 0;
    }
    if (!m_queue->active()) {
        focus(sid);
        m_controller->expand(IslandView::Question);
    }
    m_controller->reveal();
    return id;
}

void ClaudeSessions::cancelQuestion(qint64 id)
{
    if (m_questions)
        m_questions->cancel(id);
}

void ClaudeSessions::onQuestionFinished(const QString &sid, bool answered)
{
    if (answered && m_sessions.contains(sid)) {
        m_state->modifyTask(taskId(sid), [](AgentTask &t) {
            t.alertText.clear();
            t.options.clear();
        });
        setState(sid, BotState::Working);
        emit playSound(QStringLiteral("approve"));
    }
    if (m_queue->active())
        return;                                      // a permission request is in front and stays
    const bool showing = m_state->mode() == IslandMode::Expanded && m_state->view() == IslandView::Question;
    if (showWaiting())
        return;
    m_state->setPinned(false);
    if (!showing)
        return;
    // Answered: back to the overview. Left to the editor: the question stays, read-only. Both restart the idle timer.
    m_controller->expand(answered ? m_controller->defaultView() : IslandView::Question);
}

bool ClaudeSessions::jumpToWaiting()
{
    QString target;
    for (const QString &sid : std::as_const(m_order)) {
        const AgentTask *t = m_state->taskModel()->find(taskId(sid));
        if (t && isWaiting(t->state)) {
            target = sid;
            break;
        }
    }
    if (target.isEmpty() && m_state->focusId().startsWith(QLatin1String("session_")))
        target = m_state->focusId().mid(8);
    const auto it = m_sessions.constFind(target);
    if (it == m_sessions.constEnd())
        return false;
    emit jumpRequested(it->jump);
    return true;
}

void ClaudeSessions::jump(const QString &id)
{
    if (!id.startsWith(QLatin1String("session_")))
        return;
    const auto it = m_sessions.constFind(id.mid(8));
    if (it != m_sessions.constEnd())
        emit jumpRequested(it->jump);
}

} // namespace farol
