#include "SessionTitle.h"

#include "HookEvent.h"

#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>

namespace farol {

QString sessionTitle(const QString &transcriptPath)
{
    return readTranscript(transcriptPath).title;
}

TranscriptInfo readTranscript(const QString &transcriptPath)
{
    TranscriptInfo info;
    if (!QFileInfo(transcriptPath).isFile())   // the path comes from a hook payload: never open a pipe or a device
        return info;
    QFile f(transcriptPath);
    if (!f.open(QIODevice::ReadOnly))
        return info;
    const qint64 from = qMax<qint64>(0, f.size() - kTitleTailBytes);
    f.seek(from);
    QList<QByteArray> lines = f.readAll().split('\n');
    if (from > 0 && !lines.isEmpty())
        lines.removeFirst();                   // cut somewhere in the middle of a line
    QString ai, custom;
    bool usageFound = false;
    for (auto it = lines.crbegin(); it != lines.crend(); ++it) {
        // almost every line is a message, some of them long: only the ones that can matter are parsed
        if (it->contains("-title\"")) {
            if (!custom.isEmpty())
                continue;
            const QJsonObject o = QJsonDocument::fromJson(*it).object();
            const QString type = o.value("type").toString();
            if (type == QLatin1String("custom-title"))
                custom = clip(o.value("customTitle").toString(), 80);
            else if (type == QLatin1String("ai-title") && ai.isEmpty())
                ai = clip(o.value("aiTitle").toString(), 80);
        } else if (!usageFound && it->contains("\"usage\"")) {
            const QJsonObject o = QJsonDocument::fromJson(*it).object();
            if (o.value("type").toString() != QLatin1String("assistant") || o.value("isSidechain").toBool())
                continue;
            const QJsonObject message = o.value("message").toObject();
            const QJsonObject usage = message.value("usage").toObject();
            const double tokens = usage.value("input_tokens").toDouble() + usage.value("cache_read_input_tokens").toDouble() +
                                  usage.value("cache_creation_input_tokens").toDouble();
            if (tokens <= 0)
                continue;
            usageFound = true;
            info.contextTokens = int(qMin(tokens, 2e9));
            info.model = message.value("model").toString();
        }
    }
    info.title = custom.isEmpty() ? ai : custom;
    return info;
}

} // namespace farol
