#pragma once
#include "HttpClient.h"
#include <QNetworkAccessManager>
#include <QObject>
#include <QPointer>

class QNetworkReply;

namespace farol {

// IHttpClient with QNetworkAccessManager: one POST at a time, a limit on the whole exchange, no redirects followed
// (the request carries the user's API key).
class NetworkClient : public QObject, public IHttpClient {
    Q_OBJECT
public:
    explicit NetworkClient(QObject *parent = nullptr);
    void post(const HttpRequest &request, int timeoutMs, std::function<void(const Reply &)> done) override;
    void cancel() override;

private:
    QNetworkAccessManager m_manager;
    QPointer<QNetworkReply> m_reply;
    bool m_cancelled = false;
    bool m_timedOut = false;
};

} // namespace farol
