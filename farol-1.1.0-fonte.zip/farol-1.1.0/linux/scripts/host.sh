#!/bin/sh
# Runs a command on the host session. Inside the VSCodium Flatpak (/.flatpak-info exists)
# the toolchain and the Wayland/D-Bus session live on the host, so we hop out with flatpak-spawn.
if [ -f /.flatpak-info ]; then
    exec flatpak-spawn --host "$@"
fi
exec "$@"
