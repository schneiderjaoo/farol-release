#pragma once
#include "JumpCommand.h"

#include <QByteArray>
#include <QList>
#include <QRect>

namespace farol {

// Whether the KDE Plasma pieces are the ones to use: they were built in, and this is a Plasma session or a Wayland
// one (where nothing else of Farol's works). A build with both kinds runs on either desktop.
bool desktopIsKde();

// What Farol asks of an X11 desktop that is not Plasma (Cinnamon on Linux Mint): the windows the window manager
// knows, a window brought forward, a key that works with any window in front, how long the user has been away.
// Without X11 (built without it, or running on another platform) every function does nothing and says so.
namespace x11 {

bool available();

QList<DesktopWindow> windows();          // _NET_CLIENT_LIST, as the window manager lists them
quint64 activeWindow();                  // 0 when not known
void activate(quint64 window);           // unminimized, on its workspace, with the keyboard
void showOnEveryWorkspace(quint64 window);   // to be called before the window is shown
// Where the window takes the pointer, in device pixels of the window; clicks anywhere else go to what is under it.
void setInputRegion(quint64 window, const QRect &rect);

// Whether a compositor is running: without one a window cannot be see-through.
bool composited();

int idleMs();                            // since the last key or pointer move; -1 when the server does not say

// A key grabbed on the whole screen. `code` 0 means there is none.
struct Key {
    quint8 code = 0;
    quint16 modifiers = 0;
    bool operator==(const Key &) const = default;
};
// Qt key | modifiers. Nothing is grabbed (and `code` is 0) when the keyboard has no such key or another program
// already has the combination.
Key grabKey(int combo);
void ungrabKey(Key key);
// The key of a native event that is a key press (QAbstractNativeEventFilter).
bool keyPress(const QByteArray &eventType, void *message, Key *key);

} // namespace x11
} // namespace farol
