import QtQuick
import QtQuick.Shapes

// The stage of the demo films (tests/film.cpp): a made-up desktop with an editor window, the island docked at the
// top like in the real thing, a pointer and a caption. Not part of the app: the colours here are the film's own.
Item {
    id: stage
    width: 960
    height: 540
    property string caption: ""
    property real pointerX: 620
    property real pointerY: 380
    property bool pressed: false
    property string dragging: ""       // a file name carried by the pointer
    property bool tick: false          // flipped before each frame: the software renderer then repaints everything

    // the desktop behind the island: a wallpaper and an editor window, as a sketch
    component Backdrop: Item {
        width: stage.width
        height: stage.height
        Rectangle {
            anchors.fill: parent
            gradient: Gradient {
                GradientStop { position: 0.0; color: stage.tick ? "#27405C" : "#27405D" }
                GradientStop { position: 1.0; color: "#5E7C99" }
            }
        }
        // an editor window, as a sketch
        Rectangle {
            x: 110; y: 150; width: 740; height: 300; radius: 10
            color: stage.tick ? "#16202B" : "#16202C"; border.color: "#2A3A4B"; border.width: 1
            Rectangle { width: parent.width; height: 26; radius: 10; color: "#1E2B38" }
            Row { x: 12; y: 9; spacing: 6; Repeater { model: ["#FF5F57", "#FEBC2E", "#28C840"]; Rectangle { required property string modelData; width: 8; height: 8; radius: 4; color: modelData } } }
            Rectangle { x: 0; y: 26; width: 150; height: parent.height - 26; color: "#131C26" }
            Column {
                x: 14; y: 42; spacing: 9
                Repeater { model: [90, 70, 110, 60, 96, 80, 50, 104]; Rectangle { required property int modelData; width: modelData; height: 6; radius: 3; color: "#2A3A4B" } }
            }
            Column {
                x: 172; y: 44; spacing: 10
                Repeater {
                    model: [[220, "#5BC0EB"], [340, "#3C5066"], [300, "#3C5066"], [180, "#2FBF8F"], [380, "#3C5066"], [260, "#3C5066"], [120, "#FFC233"], [330, "#3C5066"],
                            [290, "#3C5066"], [200, "#5BC0EB"], [360, "#3C5066"], [240, "#3C5066"]]
                    Rectangle { required property var modelData; width: modelData[0]; height: 7; radius: 3.5; color: modelData[1]; opacity: 0.8 }
                }
            }
        }
    }
    Backdrop {}

    // The island, larger than life so it reads on a phone, and cut to its own rectangle: the software renderer
    // these films are made with leaves marks of the closing island outside it.
    Item {
        x: (stage.width - 720) / 2
        y: 0
        width: 720
        height: 320
        scale: 1.4
        transformOrigin: Item.Top
        Item {
            readonly property rect r: host.item ? host.item.islandRect : Qt.rect(0, 0, 0, 0)
            x: r.x
            y: r.y
            width: r.width
            height: r.height
            clip: true
            Loader {
                id: host
                objectName: "islandHost"
                x: -parent.x
                y: -parent.y
                source: islandUrl
            }
        }
    }

    // The software renderer keeps drawing icons of the closed island under it: the desktop is drawn again over
    // everything below the island.
    Item {
        y: Math.ceil((host.item ? host.item.islandRect.height : 0) * 1.4) + 1
        width: stage.width
        height: stage.height - y
        clip: true
        Backdrop { y: -parent.y }
    }

    // caption
    Rectangle {
        visible: stage.caption !== ""
        anchors.horizontalCenter: parent.horizontalCenter
        y: parent.height - height - 28
        width: Math.min(parent.width - 80, label.implicitWidth + 44)
        height: label.height + 22
        radius: 14
        color: "#E6071627"
        Text {
            id: label
            anchors.centerIn: parent
            width: Math.min(implicitWidth, stage.width - 124)
            horizontalAlignment: Text.AlignHCenter
            wrapMode: Text.Wrap
            text: stage.caption
            color: "#EAF3F4"
            font.family: "Instrument Sans"
            font.pixelSize: 19
            font.weight: Font.Medium
        }
    }
    // pointer
    Item {
        x: stage.pointerX
        y: stage.pointerY
        z: 100
        Behavior on x { NumberAnimation { duration: 600; easing.type: Easing.InOutCubic } }
        Behavior on y { NumberAnimation { duration: 600; easing.type: Easing.InOutCubic } }
        Rectangle {
            visible: stage.dragging !== ""
            x: 14; y: 12; width: fileName.implicitWidth + 20; height: 24; radius: 6
            color: "#EAF3F4"
            Text { id: fileName; anchors.centerIn: parent; text: stage.dragging; color: "#0E2A47"; font.family: "Instrument Sans"; font.pixelSize: 12; font.weight: Font.Medium }
        }
        Rectangle { visible: stage.pressed; x: -14; y: -14; width: 28; height: 28; radius: 14; color: "#66FFC233" }
        Shape {
            preferredRendererType: Shape.CurveRenderer
            ShapePath { fillColor: "#FFFFFF"; strokeColor: "#0E2A47"; strokeWidth: 1.2; joinStyle: ShapePath.RoundJoin; PathSvg { path: "M0 0L0 17L4.6 12.8L7.8 19.6L10.6 18.3L7.5 11.7L13.4 11.4Z" } }
        }
    }
}
