# Packages for download

Farol runs on two kinds of desktop, and each has its package:

| Package | For | Desktop side |
|---|---|---|
| `farol-<version>-1.x86_64.rpm` | Fedora, KDE Plasma 6 on Wayland | layer-shell, KWin, KGlobalAccel (KF6); the distribution's Qt (6.8 or newer) |
| `farol_<version>_mint22_amd64.deb` | Linux Mint 22, Cinnamon on X11 | an X11 window above the others, the window manager (EWMH), key grabs; its own Qt |

`.github/workflows/build.yml` builds, tests and packages both on every push and pull request (artifacts
`farol-fedora` and `farol-mint22`), and attaches them to the release of a tag `v<version>`.

## Fedora (RPM)

On Fedora, with the build dependencies of the main README installed (and `rpm-build`):

```sh
cmake -S linux -B linux/build-release -G Ninja -DCMAKE_BUILD_TYPE=Release -DFAROL_BUILD_SPIKES=OFF -DCMAKE_INSTALL_PREFIX=/usr
cmake --build linux/build-release --target farol
cd linux/build-release && cpack -G RPM
```

It holds `/usr/bin/farol`, the application menu entry and the icon, and asks for the Qt and KDE libraries of the
distribution it was built on: it only fits that one. `cpack -G DEB` does the same on Debian 13 or Ubuntu 25.04 and
newer with Plasma 6.

## Linux Mint 22 (DEB)

Mint 22 has Qt 6.4 and no KF6; the island's QML needs Qt 6.8. So this package is built in a Mint 22 image that also
holds the Qt that Qt itself publishes (the version Farol is developed with, `QT_VERSION` in the Dockerfile), and it
carries that Qt along. Anywhere with Docker:

```sh
docker build --network host -t farol-mint22 linux/packaging/mint22      # once, and after a change to the Dockerfile
linux/packaging/mint22/run.sh linux/packaging/mint22/package.sh         # -> linux/build-mint22/farol_<version>_mint22_amd64.deb
```

| File in `mint22/` | What it does |
|---|---|
| `Dockerfile` | Mint 22, the compiler, Qt from `aqtinstall`, and Cinnamon's window manager for the tests |
| `run.sh` | runs a command in that image, with the repository at `/src`, as the caller |
| `package.sh` | builds, runs every test, runs `tst_x11` in a real X11 session, and writes the `.deb` |
| `session.sh` | an X server nobody sees with muffin (Cinnamon's window manager and compositor) and a session bus |
| `look.sh` | a picture of the island in that session: `run.sh look.sh <farol> <picture.png> [view] [edge]` |

Everything is under `/opt/farol`: `bin/farol` (with `qt.conf` beside it), `lib/` (the Qt libraries it links to, ICU
included), `plugins/` (the X11 platform, SVG, TLS, the GTK theme) and `qml/` (QtQml, QtQuick, Window, Shapes).
`/usr/bin/farol` is a link, the menu entry and the icon are in `/usr/share`. The system libraries it asks for are
worked out by `dpkg-shlibdeps`. Qt is used under the LGPL, as shared libraries that can be replaced in `lib/`.

A new Qt: change `QT_VERSION`, rebuild the image, run `package.sh` (the tests run against that Qt), then look at
the island with `look.sh`.

## In both

The hook script, the fonts and the QML are inside the executable. The sounds are not in the repository (see
`linux/sounds/README.md`), so a package is silent.

## What does not exist

- Windows and macOS: they need a platform layer of their own (window, tray, shortcuts, secrets, process watching,
  the hook's transport), not another package.
- GNOME on Wayland and Cinnamon on Wayland: no layer-shell Farol can use; the island would be an ordinary window.
- Flatpak: Farol watches Claude Code's processes, writes under `~/.claude` and runs `git`, `claude` and the editor,
  which a sandbox is there to prevent.
