#include "ProcessRunner.h"

#include <QProcess>
#include <QVariant>
#include <QTimer>

namespace farol {

void ProcessRunner::run(const QString &program, const QStringList &arguments, const QStringList &env, int timeoutMs,
                        std::function<void(const Result &)> done, const QByteArray &input)
{
    auto *process = new QProcess(this);
    QProcessEnvironment environment = QProcessEnvironment::systemEnvironment();
    for (const QString &entry : env) {
        const int eq = entry.indexOf(QLatin1Char('='));
        if (eq > 0)
            environment.insert(entry.left(eq), entry.mid(eq + 1));
    }
    process->setProcessEnvironment(environment);
    if (input.isEmpty())
        process->setStandardInputFile(QProcess::nullDevice());   // nothing to type into
    auto *timer = new QTimer(process);
    timer->setSingleShot(true);
    connect(timer, &QTimer::timeout, process, [process] {
        process->setProperty("timedOut", true);
        process->kill();
    });
    connect(process, &QProcess::errorOccurred, this, [process, done](QProcess::ProcessError error) {
        if (error != QProcess::FailedToStart)
            return;   // a crash or a kill also ends in finished()
        done(Result{});
        process->deleteLater();
    });
    connect(process, &QProcess::finished, this, [process, done](int exitCode, QProcess::ExitStatus status) {
        Result r;
        r.started = true;
        r.timedOut = process->property("timedOut").toBool();
        r.exitCode = status == QProcess::NormalExit ? exitCode : -1;
        r.out = QString::fromUtf8(process->readAllStandardOutput());
        r.err = QString::fromUtf8(process->readAllStandardError());
        done(r);
        process->deleteLater();
    });
    process->start(program, arguments);
    if (!input.isEmpty()) {
        process->write(input);
        process->closeWriteChannel();
    }
    timer->start(timeoutMs);
}

void ProcessRunner::cancel()
{
    for (QProcess *process : findChildren<QProcess *>(Qt::FindDirectChildrenOnly))
        process->kill();
}

} // namespace farol
