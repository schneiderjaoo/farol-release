import QtQuick

// PrimaryButton / SecondaryButton of the Swift views: 28 pt pill, 12.5 pt medium, pressed scale 0.94.
Rectangle {
    id: btn
    property string text: ""
    property string hint: ""       // keyboard shortcut shown small after the label ("Y", "N")
    property bool primary: false
    property real maxWidth: 0      // > 0: the label is cut with "…" so the button never gets wider than this
    signal clicked()

    implicitWidth: row.implicitWidth + 28
    implicitHeight: 28
    width: implicitWidth
    height: 28
    radius: 14
    color: primary ? (hover.hovered ? theme.primaryHover : theme.primary) : (hover.hovered ? theme.pillHoverFill : theme.pillFill)
    scale: tap.pressed ? 0.94 : 1
    Behavior on scale { NumberAnimation { duration: 90 } }

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 6
        Text {
            height: btn.height
            width: btn.maxWidth > 0 ? Math.min(implicitWidth, btn.maxWidth - 28) : implicitWidth
            elide: Text.ElideRight
            verticalAlignment: Text.AlignVCenter
            textFormat: Text.PlainText
            text: btn.text
            color: btn.primary ? theme.primaryText : theme.text
            font.family: theme.bodyFont
            font.pixelSize: 13
            font.weight: Font.Medium
        }
        Text {
            visible: btn.hint !== ""
            height: btn.height
            verticalAlignment: Text.AlignVCenter
            textFormat: Text.PlainText
            text: btn.hint
            color: btn.primary ? theme.primaryDim : theme.muted
            font.family: theme.bodyFont
            font.pixelSize: 11
        }
    }
    // Keyboard: Tab reaches the button, Space/Enter press it, and the focus ring shows where it is.
    activeFocusOnTab: true
    border.width: activeFocus ? 2 : 0
    border.color: theme.text
    Keys.onSpacePressed: btn.clicked()
    Keys.onReturnPressed: btn.clicked()
    HoverHandler { id: hover }
    TapHandler { id: tap; onTapped: { btn.forceActiveFocus(); btn.clicked() } }
}
