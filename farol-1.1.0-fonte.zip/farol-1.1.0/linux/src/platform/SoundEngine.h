#pragma once
#include <QHash>
#include <QList>
#include <QObject>

class QSoundEffect;

namespace farol {

// Up to 3 QSoundEffect per WAV so the same sound can overlap (L0 finding 6). A voice is only created when its sound
// is played: each QSoundEffect can hold an audio stream of its own, and opening all 28 x 3 at start ran the process
// out of file descriptors (Qt then crashes) when the output device was a Bluetooth headset.
class SoundEngine : public QObject {
    Q_OBJECT
public:
    explicit SoundEngine(const QString &soundsDir, QObject *parent = nullptr);

    static constexpr int kMaxVoices = 3;

    bool isLoaded(const QString &name) const;   // played at least once and ready
    int voiceCount() const;                     // QSoundEffects created so far
    bool enabled() const { return m_enabled; }
    double volume() const { return m_volume; }

public slots:
    void setEnabled(bool on) { m_enabled = on; }
    void setVolume(double v);   // clamped to 0..0.2
    void play(const QString &name);

private:
    QString m_dir;
    QHash<QString, QList<QSoundEffect *>> m_pool;
    bool m_enabled = true;
    double m_volume = 0.12;
};

} // namespace farol
