#pragma once
#include <QString>
#include <QStringList>
#include <optional>
#include <vector>

namespace farol {

// Minimal JSON tree that keeps member order and the exact source text of every scalar, so a settings file can be
// edited and written back without reordering or re-escaping anything the editor did not touch. (QJsonObject
// sorts its keys, which would shuffle the whole file.)
class JsonTree {
public:
    enum class Kind { Raw, Object, Array };

    Kind kind = Kind::Raw;
    QString raw;                       // Raw: the token as written ("12", "true", "\"a\\nb\"")
    std::vector<QString> keys;         // Object: decoded keys, rawKeys (with quotes) and values are parallel
    std::vector<QString> rawKeys;
    std::vector<JsonTree> values;
    std::vector<JsonTree> items;       // Array

    static JsonTree object();
    static JsonTree array();
    static JsonTree string(const QString &text);   // a Raw token: quoted and escaped
    static JsonTree number(int n);

    // Validates with QJsonDocument first, then keeps the layout. On failure: nullopt and *error set.
    static std::optional<JsonTree> parse(const QString &text, QString *error);
    // 2-space indentation, "key": value, [] and {} for empty containers. No trailing newline.
    QString serialize(int indent = 2) const;

    JsonTree *find(const QString &key);
    const JsonTree *find(const QString &key) const;
    JsonTree &set(const QString &key, JsonTree value);   // replace in place, or append; returns the stored value
    bool remove(const QString &key);
    QStringList keyList() const;
    bool isString() const { return kind == Kind::Raw && raw.startsWith('"'); }
    QString stringValue() const;                          // decoded; empty unless isString()

    static QString decodeString(const QString &rawToken);
    static QString quote(const QString &text);
};

} // namespace farol
