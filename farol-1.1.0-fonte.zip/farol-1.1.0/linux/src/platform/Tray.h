#pragma once
#include <QObject>
#include <functional>

class QMenu;

namespace farol {

class AppState;
class IslandController;

struct TrayHooks {
    std::function<void()> install;
    std::function<void()> uninstall;
    std::function<bool()> installed;   // asked each time the menu opens
    std::function<bool()> upToDate;    // installed by this version (optional; an older install needs Install… again)
};

// System tray icon: Open, Settings, Claude Code hooks, Quit. (Screenshots and measurements use the FAROL_DEBUG_* variables.)
class Tray : public QObject {
    Q_OBJECT
public:
    Tray(AppState *state, IslandController *controller, TrayHooks hooks = {}, QObject *parent = nullptr);
    QMenu *menu() const { return m_menu; }
    ~Tray() override;

private:
    QObject *m_item = nullptr;   // KStatusNotifierItem on KDE Plasma, QSystemTrayIcon elsewhere
    QMenu *m_menu = nullptr;     // KStatusNotifierItem deletes the menu it is given; QSystemTrayIcon does not
    bool m_ownsMenu = false;
};

} // namespace farol
