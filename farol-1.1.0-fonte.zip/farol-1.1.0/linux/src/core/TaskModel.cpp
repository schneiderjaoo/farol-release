#include "TaskModel.h"

namespace farol {

TaskModel::TaskModel(QObject *parent) : QAbstractListModel(parent) {}

int TaskModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : int(m_tasks.size());
}

QVariant TaskModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_tasks.size())
        return {};
    const AgentTask &t = m_tasks.at(index.row());
    switch (role) {
    case IdRole: return t.id;
    case NameRole: return t.name;
    case ColorRole: return t.color;
    case StateRole: return enumKey(t.state);
    case PillBadgeRole: return t.pillBadge;
    case IsIntegrationRole: return t.isIntegration;
    case StepRole: return t.steps.value(t.stepIndex).label;
    case TitledRole: return t.titled;
    case BoatRole: return t.boat;
    case DormantRole: return t.dormant;
    case ContextUsedRole: return t.contextWindow > 0 ? qMin(1.0, double(t.contextTokens) / t.contextWindow) : 0.0;
    }
    return {};
}

QHash<int, QByteArray> TaskModel::roleNames() const
{
    return {{IdRole, "taskId"}, {NameRole, "name"}, {ColorRole, "color"},
            {StateRole, "state"}, {PillBadgeRole, "pillBadge"}, {IsIntegrationRole, "isIntegration"}, {StepRole, "step"},
            {TitledRole, "titled"}, {BoatRole, "boat"}, {DormantRole, "dormant"},
            {ContextUsedRole, "contextUsed"}};
}

int TaskModel::indexOf(const QString &id) const
{
    for (int i = 0; i < m_tasks.size(); ++i)
        if (m_tasks.at(i).id == id)
            return i;
    return -1;
}

const AgentTask *TaskModel::find(const QString &id) const
{
    const int i = indexOf(id);
    return i < 0 ? nullptr : &m_tasks.at(i);
}

void TaskModel::append(const AgentTask &task)
{
    beginInsertRows({}, int(m_tasks.size()), int(m_tasks.size()));
    m_tasks.append(task);
    endInsertRows();
}

bool TaskModel::removeById(const QString &id)
{
    const int i = indexOf(id);
    if (i < 0)
        return false;
    beginRemoveRows({}, i, i);
    m_tasks.removeAt(i);
    endRemoveRows();
    return true;
}

bool TaskModel::update(const QString &id, const std::function<void(AgentTask &)> &fn)
{
    const int i = indexOf(id);
    if (i < 0)
        return false;
    fn(m_tasks[i]);
    emit dataChanged(index(i), index(i));
    return true;
}

} // namespace farol
