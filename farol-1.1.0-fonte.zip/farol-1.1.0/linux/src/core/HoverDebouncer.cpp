#include "HoverDebouncer.h"

namespace farol {

HoverDebouncer::HoverDebouncer(IScheduler &scheduler, int leaveDelayMs)
    : m_sched(scheduler), m_leaveDelayMs(leaveDelayMs)
{
}

void HoverDebouncer::enter()
{
    if (m_pendingLeave != 0) {
        m_sched.cancel(m_pendingLeave);
        m_pendingLeave = 0;
    }
    if (!m_inside) {
        m_inside = true;
        if (onChanged)
            onChanged(true);
    }
}

void HoverDebouncer::leave()
{
    if (!m_inside || m_pendingLeave != 0)
        return;
    m_pendingLeave = m_sched.singleShot(m_leaveDelayMs, [this] {
        m_pendingLeave = 0;
        m_inside = false;
        if (onChanged)
            onChanged(false);
    });
}

} // namespace farol
