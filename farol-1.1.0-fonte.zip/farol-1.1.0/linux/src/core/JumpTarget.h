#pragma once
#include <QList>
#include <QMetaType>
#include <QPair>
#include <QString>

namespace farol {

// Where a Claude Code session lives, so the island can take the user back to it.
struct JumpTarget {
    QString source;   // "vscodium" | "konsole" | "terminal"
    QString cwd;
    QString flatpakId;
    QString konsoleService, konsoleSession, konsoleWindow;
    QString editor;   // the editor's program when it is not a Flatpak: "code", "codium", "cursor", ...
    // The processes above Claude Code, closest first, as (pid, start time) seen by farol-hook: one of them owns the
    // session's window.
    QList<QPair<qint64, qint64>> ancestors;
};

} // namespace farol

Q_DECLARE_METATYPE(farol::JumpTarget)
