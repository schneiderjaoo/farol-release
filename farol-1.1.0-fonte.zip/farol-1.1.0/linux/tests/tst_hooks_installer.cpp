#include <QtTest>
#include <QDateTime>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include "HooksInstaller.h"

using namespace farol;

namespace {
const QString kHook = QStringLiteral("/home/u/.local/share/farol/farol-hook");
const QString kOriginal = QStringLiteral("{\n  \"model\": \"opus\",\n  \"theme\": \"dark\"\n}\n");

QDateTime fixedClock() { return QDateTime(QDate(2026, 9, 30), QTime(12, 15)); }

void writeFile(const QString &path, const QString &text)
{
    QFile f(path);
    QVERIFY(f.open(QIODevice::WriteOnly));
    f.write(text.toUtf8());
}
QString readFile(const QString &path)
{
    QFile f(path);
    return f.open(QIODevice::ReadOnly) ? QString::fromUtf8(f.readAll()) : QString();
}
} // namespace

class TestHooksInstaller : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    QString settings() const { return dir.path() + "/.claude/settings.json"; }
    HooksInstaller installer() const { return HooksInstaller(settings(), kHook, 110, fixedClock); }

private slots:
    void init()
    {
        QDir(dir.path() + "/.claude").removeRecursively();
        QDir().mkpath(dir.path() + "/.claude");
    }

    void planInstallShowsADiffAndChangesNothingOnDisk()
    {
        writeFile(settings(), kOriginal);
        const HooksPlan p = installer().planInstall();
        QVERIFY2(p.ok, qPrintable(p.error));
        QVERIFY(p.changes);
        QVERIFY(p.settingsExisted);
        QCOMPARE(p.before, kOriginal);
        QVERIFY(p.diff.contains("+  \"hooks\": {"));
        QVERIFY(p.diff.contains("--- settings.json (current)"));
        QCOMPARE(readFile(settings()), kOriginal);                         // planning writes nothing
        QVERIFY(QDir(dir.path() + "/.claude").entryList({"*.bak-*"}).isEmpty());
    }

    void applyBacksUpThenWrites()
    {
        writeFile(settings(), kOriginal);
        const HooksPlan p = installer().planInstall();
        QString err, backup;
        QVERIFY2(installer().apply(p, &err, &backup), qPrintable(err));
        QCOMPARE(readFile(settings()), p.after);
        QCOMPARE(backup, dir.path() + "/.claude/settings.json.bak-20260930-1215");
        QCOMPARE(readFile(backup), kOriginal);
        QVERIFY(installer().installed());
        QVERIFY(installer().upToDate());
    }

    // Hooks written by another version of Farol (other arguments or timeouts): installed, but Install… has work to do.
    void anOlderInstallIsInstalledButNotUpToDate()
    {
        writeFile(settings(), kOriginal);
        QVERIFY(!installer().upToDate());                    // nothing installed is not "up to date" either
        QString after = installer().planInstall().after;
        QVERIFY(after.contains(" --decision-timeout 110"));
        after.replace(QStringLiteral(" --decision-timeout 110"), QStringLiteral(" --decision-timeout 60"));
        writeFile(settings(), after);
        QVERIFY(installer().installed());
        QVERIFY(!installer().upToDate());
    }

    void backupNamesDoNotCollideWithinTheSameMinute()
    {
        writeFile(settings(), kOriginal);
        writeFile(settings() + ".bak-20260930-1215", "earlier");
        QString backup;
        QString err;
        QVERIFY(installer().apply(installer().planInstall(), &err, &backup));
        QCOMPARE(backup, dir.path() + "/.claude/settings.json.bak-20260930-1215-2");
        QCOMPARE(readFile(settings() + ".bak-20260930-1215"), QStringLiteral("earlier"));
    }

    void missingFileIsCreatedWithoutABackup()
    {
        QFile::remove(settings());
        QDir(dir.path() + "/.claude").removeRecursively();
        const HooksPlan p = installer().planInstall();
        QVERIFY(p.ok);
        QVERIFY(!p.settingsExisted);
        QString err;
        QVERIFY2(installer().apply(p, &err), qPrintable(err));
        QVERIFY(QJsonDocument::fromJson(readFile(settings()).toUtf8()).object().contains("hooks"));
        QVERIFY(QDir(dir.path() + "/.claude").entryList({"*.bak-*"}).isEmpty());
    }

    void applyRefusesWhenTheFileChangedAfterThePreview()
    {
        writeFile(settings(), kOriginal);
        const HooksPlan p = installer().planInstall();
        const QString edited = QStringLiteral("{\n  \"model\": \"sonnet\"\n}\n");
        writeFile(settings(), edited);                                     // e.g. Claude Code rewrote it meanwhile
        QString err;
        QVERIFY(!installer().apply(p, &err));
        QVERIFY(err.contains("changed"));
        QCOMPARE(readFile(settings()), edited);                            // untouched
        QVERIFY(QDir(dir.path() + "/.claude").entryList({"*.bak-*"}).isEmpty());
    }

    void invalidJsonIsRefusedAndLeftAlone()
    {
        writeFile(settings(), "{ broken");
        const HooksPlan p = installer().planInstall();
        QVERIFY(!p.ok);
        QVERIFY(!p.error.isEmpty());
        QString err;
        QVERIFY(!installer().apply(p, &err));
        QCOMPARE(readFile(settings()), QStringLiteral("{ broken"));
    }

    void uninstallFlowAndNoOp()
    {
        writeFile(settings(), kOriginal);
        QString err;
        QVERIFY(installer().apply(installer().planInstall(), &err));
        const HooksPlan off = installer().planUninstall();
        QVERIFY(off.ok);
        QVERIFY(off.changes);
        QVERIFY(installer().apply(off, &err));
        QCOMPARE(readFile(settings()), kOriginal);
        QVERIFY(!installer().installed());
        const HooksPlan again = installer().planUninstall();
        QVERIFY(again.ok);
        QVERIFY(!again.changes);
        QVERIFY(!installer().apply(again, &err));                          // nothing to write
    }

    void permissionsAreKept()
    {
#ifdef Q_OS_WIN
        QSKIP("Windows has no file modes");
#endif
        writeFile(settings(), kOriginal);
        QFile::setPermissions(settings(), QFile::ReadOwner | QFile::WriteOwner);   // 0600
        QString err;
        QVERIFY(installer().apply(installer().planInstall(), &err));
        QCOMPARE(QFile::permissions(settings()) & (QFile::ReadGroup | QFile::ReadOther | QFile::WriteGroup | QFile::WriteOther),
                 QFile::Permissions());
    }

    void symlinkedSettingsKeepTheLinkAndWriteTheTarget()
    {
#ifdef Q_OS_WIN
        QSKIP("a symbolic link to a file needs developer mode or an administrator on Windows");
#endif
        QDir().mkpath(dir.path() + "/dotfiles");
        const QString real = dir.path() + "/dotfiles/claude-settings.json";
        writeFile(real, kOriginal);
        QFile::remove(settings());
        QVERIFY(QFile::link(real, settings()));
        const HooksPlan p = installer().planInstall();
        QVERIFY(p.ok);
        QString err;
        QVERIFY2(installer().apply(p, &err), qPrintable(err));
        QVERIFY(QFileInfo(settings()).isSymLink());
        QCOMPARE(readFile(real), p.after);
    }
};

QTEST_MAIN(TestHooksInstaller)
#include "tst_hooks_installer.moc"
