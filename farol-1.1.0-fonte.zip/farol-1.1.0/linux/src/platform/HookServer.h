#pragma once
#include <QHash>
#include <QLocalServer>
#include <QObject>

class QLocalSocket;

namespace farol {

class ApprovalQueue;
class ClaudeSessions;

// Unix-socket server for farol-hook: one JSON line per connection (see the L2 plan, Task 7).
class HookServer : public QObject {
    Q_OBJECT
public:
    enum class StartResult { Started, AlreadyRunning, Failed };
    static constexpr int kMaxLine = 1 << 20;

    HookServer(ClaudeSessions *sessions, ApprovalQueue *queue, QObject *parent = nullptr);
    ~HookServer() override;
    StartResult start(const QString &socketPath);
    QString errorString() const { return m_error; }
    // Development aid (FAROL_DEBUG_EVENTS): appends every raw event line to this file.
    void setEventLog(const QString &path) { m_eventLog = path; }

private:
    struct Conn {
        QByteArray buffer;
        qint64 requestId = 0;   // a PermissionRequest waiting for a click
        qint64 questionId = 0;  // an AskUserQuestion held for a click on an option
        bool handled = false;
    };
    void onNewConnection();
    void onReadyRead(QLocalSocket *s);
    void onDisconnected(QLocalSocket *s);
    void dispatch(QLocalSocket *s, const QByteArray &line);

    QLocalServer m_server;
    ClaudeSessions *m_sessions;
    ApprovalQueue *m_queue;
    QHash<QLocalSocket *, Conn> m_conns;
    QString m_error;
    QString m_eventLog;
};

} // namespace farol
