#pragma once
#include "AppState.h"
#include "HoverDebouncer.h"
#include "IslandStateMachine.h"
#include "Scheduler.h"

#include <QObject>
#include <functional>

namespace farol {

// Port of the wiring in IslandWindowController.swift (wireFSM, setMode, expand, collapse, pointer handling)
// plus the layout numbers the QML island binds to.
class IslandController : public QObject {
    Q_OBJECT
    Q_PROPERTY(qreal islandWidth READ islandWidth NOTIFY layoutChanged)
    Q_PROPERTY(qreal islandHeight READ islandHeight NOTIFY layoutChanged)
    Q_PROPERTY(qreal cornerRadius READ cornerRadius NOTIFY layoutChanged)
    Q_PROPERTY(bool shrinking READ shrinking NOTIFY shrinkingChanged)
    Q_PROPERTY(qreal botX READ botX NOTIFY layoutChanged)
    Q_PROPERTY(qreal botY READ botY NOTIFY layoutChanged)
    Q_PROPERTY(qreal botDiameter READ botDiameter NOTIFY layoutChanged)
    Q_PROPERTY(qreal botOpacity READ botOpacity NOTIFY layoutChanged)

public:
    using NowFn = std::function<qint64()>;
    IslandController(AppState *state, IScheduler *scheduler, NowFn now, QObject *parent = nullptr);

    IslandStateMachine &fsm() { return m_fsm; }
    bool wasInIsland() const { return m_wasInIsland; }
    IslandView defaultView() const;

    qreal islandWidth() const { return m_w; }
    qreal islandHeight() const { return m_h; }
    qreal cornerRadius() const { return m_corner; }
    bool shrinking() const { return m_shrinking; }
    qreal botX() const { return m_bot.cx; }
    qreal botY() const { return m_bot.cy; }
    qreal botDiameter() const { return m_bot.diameter; }
    qreal botOpacity() const { return m_bot.opacity; }

    void expand(IslandView view);
    void setMode(IslandMode mode);
    void pointerEntered();
    void pointerLeft();

public slots:
    void setPointerInside(bool inside);   // raw hover from the window; debounced before it reaches the FSM
    void islandClicked();
    void escapePressed();
    void greetComplete();
    void requestKeyboard(bool onDemand);
    void showView(const QString &viewName);
    void expandTo(const QString &viewName);
    void collapse();
    void launch();
    void reveal();
    void resetActivity();

signals:
    void shrinkingChanged();   // emitted BEFORE layoutChanged so the Behavior animations see the new curve
    void layoutChanged();
    void playSound(const QString &name);
    void greetingInterrupt();
    void greetingHover();
    void keyboardOnDemandChanged(bool onDemand);

private:
    void onFsmTransition(IslandStateMachine::State from, IslandStateMachine::State to);
    void applyExpand(IslandView view);   // the FSM-independent part of expand()
    void updateLayout(bool shrinking);
    static int modeLevel(IslandMode m);

    AppState *m_state;
    NowFn m_now;
    IslandStateMachine m_fsm;
    HoverDebouncer m_hover;
    bool m_wasInIsland = false;
    bool m_shrinking = false;
    int m_lastLevel = 0;
    qreal m_w = 0, m_h = 0, m_corner = 0;
    BotPlacement m_bot{0, 0, 0, 0};
};

} // namespace farol
