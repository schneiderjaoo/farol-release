#include <QtTest>
#include "JumpCommand.h"

using namespace farol;
using K = JumpCommand::Kind;

class TestJumpCommand : public QObject {
    Q_OBJECT
private slots:
    void vscodiumOpensTheFolderThroughFlatpak()
    {
        const JumpCommand c = jumpCommandFor({"vscodium", "/home/u/proj", "com.vscodium.codium", {}, {}, {}});
        QVERIFY(c.kind == K::Process);
        QCOMPARE(c.program, QStringLiteral("flatpak"));
        QCOMPARE(c.args, (QStringList{"run", "com.vscodium.codium", "/home/u/proj"}));
    }

    void vscodiumDefaultsTheFlatpakId()
    {
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "", {}, {}, {}}).args.at(1), QStringLiteral("com.vscodium.codium"));
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "bad id;rm", {}, {}, {}}).args.at(1), QStringLiteral("com.vscodium.codium"));
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "com.visualstudio.code", {}, {}, {}}).args.at(1), QStringLiteral("com.visualstudio.code"));
    }

    void vscodiumNeedsAnAbsoluteFolder()
    {
        QVERIFY(jumpCommandFor({"vscodium", "", "", {}, {}, {}}).kind == K::None);
        QVERIFY(jumpCommandFor({"vscodium", "--new-window", "", {}, {}, {}}).kind == K::None);   // never an option
        QVERIFY(jumpCommandFor({"vscodium", "relative/dir", "", {}, {}, {}}).kind == K::None);
    }

    // The window of a session is found by the folder in its title ("farol - VSCodium"), trying the session's folder
    // first and then the ones above it (a session started in a sub-folder of the open workspace).
    void windowFolderCandidatesWalkUpFromTheSessionFolder()
    {
        QCOMPARE(windowFolderCandidates("/home/u/workspace/farol"), (QStringList{"farol", "workspace", "u"}));
        QCOMPARE(windowFolderCandidates("/home/u/workspace/farol/linux/"), (QStringList{"linux", "farol", "workspace"}));
        QCOMPARE(windowFolderCandidates("/a"), (QStringList{"a"}));
        QVERIFY(windowFolderCandidates("").isEmpty());
        QVERIFY(windowFolderCandidates("relative").isEmpty());
        QVERIFY(windowFolderCandidates("/").isEmpty());
    }

    void kwinScriptTargetsTheEditorClassAndCallsBack()
    {
        const QString js = kwinActivateScript({"farol", "workspace"}, {"com.vscodium.codium"});
        QVERIFY(js.contains(R"(const folders = ["farol","workspace"];)"));
        QVERIFY(js.contains(R"(const classes = ["com.vscodium.codium"];)"));
        QVERIFY(js.contains("const pids = [];"));
        QVERIFY(js.contains("const anyWindow = false;"));
        QVERIFY(js.contains("workspace.activeWindow = hit"));
        QVERIFY(js.contains("callDBus(\"local.joao.Farol\", \"/Jumper\", \"local.joao.Farol.Jumper\", \"WindowResult\""));
    }

    void kwinScriptNeverLetsAFolderNameBecomeCode()
    {
        const QString js = kwinActivateScript({"x\"]; evil(); #", "a\\b"}, {"c\"d"});
        QVERIFY(js.contains("const folders = [\"x\\\"]; evil(); #\",\"a\\\\b\"];"));   // JSON-escaped strings
        QVERIFY(js.contains("const classes = [\"c\\\"d\"];"));
        QVERIFY(!js.contains("[\"x\"]; evil"));                                          // the raw quote never reaches the source
    }

    void konsoleSwitchesTheTab()
    {
        const JumpCommand c = jumpCommandFor({"konsole", "/p", "", ":1.77", "/Sessions/3", "/Windows/2"});
        QVERIFY(c.kind == K::KonsoleDBus);
        QCOMPARE(c.service, QStringLiteral(":1.77"));
        QCOMPARE(c.objectPath, QStringLiteral("/Windows/2"));
        QCOMPARE(c.sessionId, 3);
    }

    void konsoleFallsBackToWindow1AndRejectsBadInput()
    {
        QCOMPARE(jumpCommandFor({"konsole", "/p", "", ":1.7", "/Sessions/9", ""}).objectPath, QStringLiteral("/Windows/1"));
        QCOMPARE(jumpCommandFor({"konsole", "/p", "", ":1.7", "/Sessions/9", "/etc/passwd"}).objectPath, QStringLiteral("/Windows/1"));
        QVERIFY(jumpCommandFor({"konsole", "/p", "", "", "/Sessions/3", "/Windows/1"}).kind == K::None);
        QVERIFY(jumpCommandFor({"konsole", "/p", "", ":1.7", "garbage", "/Windows/1"}).kind == K::None);
        QVERIFY(jumpCommandFor({"konsole", "/p", "", ":1.7", "/Sessions/x", "/Windows/1"}).kind == K::None);
    }

    // "Nova sessão": the Claude Code extension opens a new tab when the editor is handed its own URI.
    void aNewClaudeTabIsAskedThroughTheExtensionUri()
    {
        const JumpCommand c = newClaudeTabCommand();
        QVERIFY(c.kind == K::Process);
        QCOMPARE(c.program, QStringLiteral("flatpak"));
        QCOMPARE(c.args, (QStringList{"run", "com.vscodium.codium", "--open-url", "vscodium://anthropic.claude-code/open"}));
        QCOMPARE(newClaudeTabCommand("com.visualstudio.code").args,
                 (QStringList{"run", "com.visualstudio.code", "--open-url", "vscode://anthropic.claude-code/open"}));
        QCOMPARE(newClaudeTabCommand("bad id;rm").args.at(1), QStringLiteral("com.vscodium.codium"));
    }

    // The window of a new session must be the repository's own, never one of a folder above it.
    void aNewSessionOnlyTakesTheWindowOfTheRepositoryItself()
    {
        QCOMPARE(sessionWindowFolders("/home/u/workspace/farol/"), (QStringList{"farol"}));
        QVERIFY(sessionWindowFolders("relative").isEmpty());
        QVERIFY(sessionWindowFolders("/").isEmpty());
    }

    // Any terminal: the window of one of the processes above Claude Code comes forward. Nothing to go by without them.
    void otherTerminalsRaiseTheWindowOfTheirProcess()
    {
        QVERIFY(jumpCommandFor({"terminal", "/p", "", {}, {}, {}}).kind == K::None);
        QVERIFY(jumpCommandFor({"", "/p", "", {}, {}, {}}).kind == K::None);
        const JumpTarget kitty{"terminal", "/p", "", {}, {}, {}, {}, {{30, 800}, {20, 700}}};
        QVERIFY(jumpCommandFor(kitty).kind == K::RaiseWindow);
        // a Konsole that did not say which tab is treated like any terminal
        QVERIFY(jumpCommandFor({"konsole", "/p", "", "", "", "", {}, {{30, 800}}}).kind == K::RaiseWindow);
        QVERIFY(jumpCommandFor({"konsole", "/p", "", ":1.7", "/Sessions/3", "/Windows/1", {}, {{30, 800}}}).kind == K::KonsoleDBus);
    }

    void kwinScriptFindsWindowsByProcessAndTakesAnyOfATerminal()
    {
        const QString js = kwinActivateScript({"proj"}, {}, {4242, 77}, true);
        QVERIFY(js.contains("const classes = [];"));
        QVERIFY(js.contains("const pids = [4242,77];"));
        QVERIFY(js.contains("const anyWindow = true;"));
        QVERIFY(js.contains("pids.indexOf(w.pid) >= 0"));
    }

    // VS Code and its relatives installed as plain programs: their own program, window class and URI scheme.
    void nativeEditorsAreStartedByTheirOwnProgram()
    {
        const auto code = jumpCommandFor({"vscodium", "/home/u/proj", "", {}, {}, {}, "code", {}});
        QVERIFY(code.kind == K::Process);
        QCOMPARE(code.program, QStringLiteral("code"));
        QCOMPARE(code.args, (QStringList{"/home/u/proj"}));
        QVERIFY(code.windowClasses.contains("code"));
        QCOMPARE(newClaudeTabCommand("", "code").program, QStringLiteral("code"));
        QCOMPARE(newClaudeTabCommand("", "code").args, (QStringList{"--open-url", "vscode://anthropic.claude-code/open"}));
        QCOMPARE(newClaudeTabCommand("", "cursor").args, (QStringList{"--open-url", "cursor://anthropic.claude-code/open"}));
        QCOMPARE(newClaudeTabCommand("", "codium").args.at(1), QStringLiteral("vscodium://anthropic.claude-code/open"));
        // a Flatpak id wins over the program name; an unknown program falls back to VSCodium's Flatpak
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "com.visualstudio.code", {}, {}, {}, "code", {}}).program, QStringLiteral("flatpak"));
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "com.visualstudio.code", {}, {}, {}, "code", {}}).windowClasses, (QStringList{"com.visualstudio.code"}));
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "", {}, {}, {}, "rm -rf", {}}).args, (QStringList{"run", "com.vscodium.codium", "/p"}));
    }

    // Without KWin the windows are read here and the choice is the script's: an editor's window by its class and
    // the folder in its title, a terminal's by its process.
    void theWindowChosenWithoutKWinIsTheOneTheScriptWouldChoose()
    {
        const QList<DesktopWindow> windows = {
            {1, "Code", "main.cpp - outro - Visual Studio Code", 10},
            {2, "Code", "README.md - farol - Visual Studio Code", 10},
            {3, "Gnome-terminal", "joao@mint: ~/workspace/farol", 20},
            {4, "firefox", "farol - Mozilla Firefox", 30},
        };
        QCOMPARE(windowToRaise(windows, {"farol", "workspace"}, {"code"}), 1);
        QCOMPARE(windowToRaise(windows, {"workspace", "outro"}, {"code"}), 0);        // folders in order of preference
        QCOMPARE(windowToRaise(windows, {"nenhuma"}, {"code"}), -1);                  // the class alone is not enough
        QCOMPARE(windowToRaise(windows, {"farol"}, {"cursor"}), -1);                  // the browser's title names it too
        QCOMPARE(windowToRaise(windows, {"Visual Studio Code"}, {"code"}), -1);       // the app name is not a folder
        // a terminal: the folder anywhere in the title, else the window of the closest process
        QCOMPARE(windowToRaise(windows, {"farol"}, {}, {20}, true), 2);
        QCOMPARE(windowToRaise(windows, {"nenhuma"}, {}, {99, 20, 10}, true), 2);
        QCOMPARE(windowToRaise(windows, {"nenhuma"}, {}, {99}, true), -1);
        QCOMPARE(windowToRaise({}, {"farol"}, {"code"}), -1);
    }
};

QTEST_APPLESS_MAIN(TestJumpCommand)
#include "tst_jump_command.moc"
