#include <QtTest>
#include <QProcess>
#include <QTemporaryDir>
#include "ProcessWatcher.h"

using namespace farol;

// Start time of a live process, the way farol-hook reads it.
static qint64 startOf(qint64 pid)
{
    QFile f(QStringLiteral("/proc/%1/stat").arg(pid));
    if (!f.open(QIODevice::ReadOnly))
        return 0;
    const QByteArray stat = f.readAll();
    return stat.mid(stat.lastIndexOf(')') + 2).split(' ').value(19).toLongLong();
}

class TestProcessWatcher : public QObject {
    Q_OBJECT

    static void writeProc(const QString &dir, qint64 pid, qint64 start, const QByteArray &nspid)
    {
        QDir().mkpath(dir + QLatin1Char('/') + QString::number(pid));
        QFile stat(QStringLiteral("%1/%2/stat").arg(dir).arg(pid));
        QVERIFY(stat.open(QIODevice::WriteOnly));
        // the name holds a space and a parenthesis, like a real one may
        stat.write(QByteArray::number(pid) + " (a) b) S 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 " +
                   QByteArray::number(start) + " 20 21\n");
        QFile status(QStringLiteral("%1/%2/status").arg(dir).arg(pid));
        QVERIFY(status.open(QIODevice::WriteOnly));
        status.write("Name:\ta) b\nNSpid:\t" + nspid + "\nThreads:\t1\n");
    }

private slots:
    void tellsWhenTheProcessExits()
    {
        QProcess child;
        child.start("sleep", {"60"});
        QVERIFY(child.waitForStarted());
        ProcessWatcher watcher;
        int gone = 0;
        QVERIFY(watcher.watch(child.processId(), startOf(child.processId()), [&] { ++gone; }) != 0);
        QTest::qWait(150);
        QCOMPARE(gone, 0);                                   // alive: nothing is said
        child.kill();                                        // SIGKILL, the exit Claude Code cannot announce
        QTRY_COMPARE_WITH_TIMEOUT(gone, 1, 3000);
        child.waitForFinished();
        QTest::qWait(100);
        QCOMPARE(gone, 1);                                   // once
    }

    void aCancelledWatchSaysNothing()
    {
        QProcess child;
        child.start("sleep", {"60"});
        QVERIFY(child.waitForStarted());
        ProcessWatcher watcher;
        int gone = 0;
        const int id = watcher.watch(child.processId(), startOf(child.processId()), [&] { ++gone; });
        QVERIFY(id != 0);
        watcher.cancel(id);
        watcher.cancel(id);                                  // twice, and an id that never existed: no-ops
        watcher.cancel(0);
        child.kill();
        child.waitForFinished();
        QTest::qWait(200);
        QCOMPARE(gone, 0);
    }

    void aProcessThatIsNotThereIsNotWatched()
    {
        QProcess child;
        child.start("sleep", {"60"});
        QVERIFY(child.waitForStarted());
        const qint64 pid = child.processId();
        const qint64 start = startOf(pid);
        ProcessWatcher watcher;
        QCOMPARE(watcher.watch(pid, start + 1, [] {}), 0);   // that pid, but another process (the pid was reused)
        QCOMPARE(watcher.watch(0, 0, [] {}), 0);
        child.kill();
        child.waitForFinished();
        QCOMPARE(watcher.watch(pid, start, [] {}), 0);       // already gone
    }

    // Claude Code in the VSCodium Flatpak: farol-hook reports the pid of the sandbox, the host knows another one.
    void findsAProcessOfAnotherPidNamespace()
    {
        QTemporaryDir proc;
        writeProc(proc.path(), 1548, 500, "1548");                      // a host process that happens to have that pid
        writeProc(proc.path(), 1622787, 10907223, "1622787\t1548");     // the sandboxed one
        writeProc(proc.path(), 1622983, 10907466, "1622983\t1740");
        QDir().mkpath(proc.path() + "/self");
        QCOMPARE(ProcessWatcher::hostPid(1548, 10907223, proc.path()), 1622787);
        QCOMPARE(ProcessWatcher::hostPid(1740, 10907466, proc.path()), 1622983);
        QCOMPARE(ProcessWatcher::hostPid(1548, 500, proc.path()), 1548);        // same namespace
        QCOMPARE(ProcessWatcher::hostPid(1740, 10907223, proc.path()), 0);      // start time of another process
        QCOMPARE(ProcessWatcher::hostPid(9, 9, proc.path()), 0);
    }
};

QTEST_GUILESS_MAIN(TestProcessWatcher)
#include "tst_process_watcher.moc"
