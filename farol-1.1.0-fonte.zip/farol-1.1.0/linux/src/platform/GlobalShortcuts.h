#pragma once
#include <QObject>
#include <QString>
#include <memory>

namespace farol {

// The desktop side of core/Shortcuts: makes Farol's two actions answer to their keys with any window in front (the
// island itself only has the keyboard after a click). On KDE Plasma they are registered with KGlobalAccel; on
// another X11 desktop the keys are grabbed from the server.
class GlobalShortcuts : public QObject {
    Q_OBJECT
public:
    explicit GlobalShortcuts(QObject *parent = nullptr);
    ~GlobalShortcuts() override;

    // Shortcuts::Bind: combo is Qt key | modifiers, 0 unregisters. Returns the keys as the desktop writes them
    // ("Meta+F"), or an empty string when another program already has that combination.
    QString bind(const QString &action, int combo);

    struct Backend {
        virtual ~Backend() = default;
        virtual QString bind(const QString &action, int combo) = 0;
    };

signals:
    void triggered(const QString &action);   // "toggle" | "jump"

private:
    std::unique_ptr<Backend> m_backend;
};

} // namespace farol
