import QtQuick
import QtQuick.Window

// Window content, transparent: 720x320 when the island is docked to the top or bottom, 320x720 on the sides
// (Farol setting "Posição"; the Swift app always hangs from the top centre). On the sides the island is a portrait
// column with its own layout (appState.vertical), not the landscape one turned.
Item {
    id: root
    readonly property bool sideways: appState.vertical
    width: sideways ? 320 : 720
    height: sideways ? 720 : 320
    focus: true

    readonly property bool expanded: appState.modeName === "expanded"
    readonly property bool compact: appState.modeName === "compact"
    readonly property bool hiddenMode: appState.modeName === "hidden"
    // Island rectangle in window coordinates; the platform layer turns it into the input region.
    readonly property rect islandRect: Qt.rect(dock.x, dock.y, dock.width, dock.height)
    readonly property var viewNames: ["overview", "empty", "approval", "question", "error", "finished", "confused",
                                      "upload", "uploading", "choose", "mail", "prompt", "searching", "result",
                                      "note", "settings", "skills", "ask", "diff", "greeting"]
    // Views with a real implementation; the others keep the provisional card until their L1c port.
    readonly property var contentViews: ({
        approval: "ApprovalView.qml", question: "QuestionView.qml", finished: "FinishedView.qml",
        error: "ErrorView.qml", overview: "OverviewView.qml", settings: "SettingsView.qml", skills: "SkillsView.qml", ask: "AskView.qml",
        diff: "DiffView.qml",            // Farol: the diff of an edit, opened from the session card
        upload: "RepositoriesView.qml"   // Farol: the + tab starts a new session instead of uploading a file
    })
    // 520 ms with a small overshoot to open, 340 ms without overshoot to close (SPEC §4 / IslandContainer).
    component MoveAnim: NumberAnimation {
        duration: controller.shrinking ? 340 : 520
        easing.type: Easing.BezierSpline
        easing.bezierCurve: controller.shrinking ? [0.45, 0.0, 0.2, 1.0, 1.0, 1.0] : [0.32, 1.22, 0.42, 1.0, 1.0, 1.0]
    }

    Keys.onEscapePressed: controller.escapePressed()
    // Y / N answer the permission request in front; the island only has the keyboard after a click.
    Keys.onPressed: (event) => {
        if (appState.viewName !== "approval" || !approvals.active)
            return
        if (event.key === Qt.Key_Y) { approvals.allow(); event.accepted = true }
        else if (event.key === Qt.Key_N) { approvals.deny(); event.accepted = true }
    }

    HoverHandler { onHoveredChanged: controller.setPointerInside(hovered) }

    // The frame the island occupies on screen, docked to appState.edge: hugging that edge of the window and
    // centred along it.
    Item {
        id: dock
        objectName: "dock"
        readonly property string edge: appState.edge
        width: controller.islandWidth
        height: controller.islandHeight
        x: edge === "left" ? 0 : edge === "right" ? root.width - width : (root.width - width) / 2
        y: edge === "top" ? 0 : edge === "bottom" ? root.height - height : (root.height - height) / 2
        Behavior on width { MoveAnim {} }
        Behavior on height { MoveAnim {} }
        Rectangle {
            id: island
            objectName: "island"
            anchors.fill: parent
            color: theme.islandBg
            clip: true   // Lumi's beam is wider than its placement square
            // The two corners on the docked edge stay square; the other two are rounded.
            topLeftRadius: dock.edge === "bottom" || dock.edge === "right" ? controller.cornerRadius : 0
            topRightRadius: dock.edge === "bottom" || dock.edge === "left" ? controller.cornerRadius : 0
            bottomLeftRadius: dock.edge === "top" || dock.edge === "right" ? controller.cornerRadius : 0
            bottomRightRadius: dock.edge === "top" || dock.edge === "left" ? controller.cornerRadius : 0
            opacity: root.hiddenMode ? 0 : 1

            Behavior on topLeftRadius { MoveAnim {} }
            Behavior on topRightRadius { MoveAnim {} }
            Behavior on bottomLeftRadius { MoveAnim {} }
            Behavior on bottomRightRadius { MoveAnim {} }
            Behavior on opacity { NumberAnimation { duration: 200 } }

            // Compact: the night scene behind Lumi and the boats (the near wave comes after the fleet).
            NightSea {
                objectName: "nightSea"
                anchors.fill: parent
                landscape: !appState.vertical
                day: !theme.dark
                beam: appState.awakeSessionCount > 0 ? theme.lamp : "transparent"
                topLeftRadius: island.topLeftRadius
                topRightRadius: island.topRightRadius
                bottomLeftRadius: island.bottomLeftRadius
                bottomRightRadius: island.bottomRightRadius
                opacity: root.compact ? 1 : 0
                visible: opacity > 0.001
                Behavior on opacity { NumberAnimation { duration: 250 } }
            }

            TapHandler {
                onTapped: {
                    // a click beside a text field leaves the keyboard in it, and so does the click that starts
                    // something waiting for a key press (keepsKeyboard: the shortcut being defined in Settings)
                    const holder = root.Window.activeFocusItem
                    if (!(holder instanceof TextInput) && !(holder && holder.keepsKeyboard))
                        root.forceActiveFocus()
                    if (root.expanded)
                        controller.requestKeyboard(true)   // clicking the open island lets it receive keys (Esc)
                    controller.islandClicked()
                }
            }

            // Rail + views, only while open.
            Item {
                id: content
                anchors.fill: parent
                opacity: root.expanded ? 1 : 0
                visible: opacity > 0.001
                Behavior on opacity { NumberAnimation { duration: root.expanded ? 200 : 120 } }

                IslandRail {
                    id: rail
                    objectName: "rail"
                    x: 10
                    y: 10
                    width: root.sideways ? parent.width - 20 : 88
                    height: root.sideways ? 66 : Math.max(0, parent.height - 20)
                    // no tabs in the greeting (Lumi is in the middle of it) nor while Lumi is confused
                    opacity: appState.viewName === "confused" || appState.viewName === "greeting" ? 0 : 1
                    enabled: opacity === 1   // a tab fading out takes no click
                    visible: opacity > 0.001
                    Behavior on opacity { NumberAnimation { duration: 200 } }
                }

                Item {
                    id: views
                    // beside the rail (under it on a side edge); the greeting has no rail and takes the whole island
                    readonly property bool railed: appState.viewName !== "greeting"
                    x: root.sideways || !railed ? 10 : 106
                    y: root.sideways && railed ? 86 : 10
                    width: parent.width - 10 - x
                    height: Math.max(0, parent.height - 10 - y)
                    Repeater {
                        model: root.viewNames
                        ViewPlaceholder {
                            required property string modelData
                            objectName: "view-" + modelData
                            anchors.fill: parent
                            viewName: modelData
                            active: appState.viewName === modelData
                            contentSource: root.contentViews[modelData] || ""
                        }
                    }
                }
            }

            // Lumi, riding the bot placement of the current view. It is a child of the island so it moves with it
            // (in Swift, BotPlacement lives inside the island frame). `bot` keeps the placement square; Lumi is taller.
            Item {
                id: bot
                objectName: "bot"
                readonly property real d: controller.botDiameter
                width: d
                height: d
                x: controller.botX - d / 2
                y: controller.botY - d / 2
                opacity: controller.botOpacity * (root.hiddenMode ? 0 : 1)
                visible: opacity > 0.001 && d > 0
                Behavior on x { MoveAnim {} }
                Behavior on y { MoveAnim {} }
                Behavior on width { MoveAnim {} }
                Behavior on height { MoveAnim {} }
                Behavior on opacity { NumberAnimation { duration: 200 } }

                Lumi {
                    anchors.centerIn: parent
                    height: bot.d * 1.25   // Lumi is taller than its placement square
                    botState: appState.effectiveStateName
                    // the small island tells at a glance whether a session is out there: lamp and beam only then
                    lit: !root.compact || appState.awakeSessionCount > 0
                }
            }

            CountdownBar { objectName: "countdownBar" }

            // Compact: one boat per session beside Lumi, each with its own hull and colour. A boat at work crosses
            // the whole island and back, at its own pace; any other lies at its own berth along the lane, and what the
            // session is doing sets its scene (see Boat.qml). On a side edge there is no room to cross: the first four
            // sit one above the other and only rock.
            Item {
                id: fleet
                objectName: "fleet"
                // the lane ends before the chip that says a session calls for the user
                readonly property real lane: island.width - 46 - 12 - (chip.visible ? chip.width + 6 : 0)
                readonly property int sessions: appState.sessionCount
                readonly property int berths: appState.vertical ? 4 : 10
                opacity: root.compact && appState.sessionCount > 0 ? 1 : 0
                visible: opacity > 0.001
                Behavior on opacity { NumberAnimation { duration: 250 } }
                Repeater {
                    id: boats
                    model: appState.tasks
                    Boat {
                        // sessions come after the integration pills in the list
                        readonly property int slot: index - (boats.count - fleet.sessions)
                        objectName: "boat" + slot
                        hullObjectName: "boatHull" + slot
                        // a dormant session has no boat (it fades out); its berth is kept for when it wakes
                        visible: !model.isIntegration && slot >= 0 && slot < fleet.berths && opacity > 0.001
                        dormant: model.dormant
                        kind: model.boat
                        tint: model.color
                        mood: lumiLooks.look(model.state).signal
                        x: appState.vertical ? (island.width - width) / 2 : 46
                        y: appState.vertical ? 32 + slot * 16 : island.height - 17   // on the water, the near wave over its keel
                        lane: appState.vertical ? width : fleet.lane
                        // side by side from Lumi on, closer together when there are many
                        berth: appState.vertical ? 0 : slot * Math.min(27, (fleet.lane - width) / Math.max(1, Math.min(fleet.sessions, fleet.berths) - 1))
                    }
                }
            }

            NightSea {
                front: true
                anchors.fill: parent
                landscape: !appState.vertical
                day: !theme.dark
                bottomLeftRadius: island.bottomLeftRadius
                bottomRightRadius: island.bottomRightRadius
                opacity: root.compact ? 1 : 0
                visible: opacity > 0.001
                Behavior on opacity { NumberAnimation { duration: 250 } }
            }

            // Compact: how many sessions call for the user. "1 espera" (a permission request or a question), or
            // "1 erro": with both the error wins and the number is the sum. On a side edge there is no room for
            // words: a dot of that colour at Lumi's corner.
            Rectangle {
                id: chip
                objectName: "compactChip"
                readonly property int calls: appState.waitingCount + appState.errorCount
                readonly property bool failed: appState.errorCount > 0
                readonly property color tone: failed ? theme.alert : theme.lamp
                visible: root.compact && calls > 0
                width: appState.vertical ? 6 : chipText.implicitWidth + 14
                height: appState.vertical ? 6 : 18
                radius: height / 2
                x: appState.vertical ? island.width - 10 : island.width - width - 8
                y: appState.vertical ? 4 : (island.height - height) / 2
                color: appState.vertical ? tone : Qt.rgba(tone.r, tone.g, tone.b, 0.18)
                Text {
                    id: chipText
                    objectName: "compactChipText"
                    visible: !appState.vertical
                    anchors.centerIn: parent
                    textFormat: Text.PlainText
                    text: chip.failed ? (appState.errorCount === 1 ? "1 erro" : appState.errorCount + " erros")
                                      : (chip.calls === 1 ? "1 espera" : chip.calls + " esperam")
                    color: chip.failed ? theme.alertText : theme.lamp
                    font.family: theme.bodyFont
                    font.pixelSize: 10
                    font.weight: Font.Medium
                }
            }

            // A file dropped on the island (the compact one too) goes to the "Perguntar" tab, which opens with it.
            // It is only read: nothing is sent before a question is asked there. The tab has its own drop area.
            DropArea {
                objectName: "islandDrop"
                anchors.fill: parent
                enabled: !root.hiddenMode && !(root.expanded && appState.viewName === "ask") && !approvals.active && !questions.active
                function take(urls) {
                    ask.addUrls(urls)
                    controller.expandTo("ask")
                }
                onDropped: (drop) => {
                    if (drop.hasUrls) {
                        take(drop.urls)
                        drop.accept()
                    }
                }
            }
        }
    }

    // Provisional greeting: the real animation calls controller.greetComplete() when it ends (~4.6 s).
    Timer {
        interval: 4600
        running: root.expanded && appState.viewName === "greeting"
        onTriggered: controller.greetComplete()
    }
}
