# Farol — aba Skills: skills da empresa e plugins do Claude Code

Data: 2026-10-03 · Status: aguardando revisão · Desenho das telas: https://claude.ai/artifact/Hr1r29DaUxjLHeYAqek86d

## 1. Objetivo

Quem usa o Farol na empresa aponta uma vez a pasta onde clonou o repositório de skills (`minha-empresa/skills`) e, daí em diante, o Claude Code usa sempre essas skills, atualizadas, em qualquer repositório. Na mesma aba a pessoa vê e administra os plugins do Claude Code e instala novos por um catálogo.

Hoje isso é manual: um link por skill em `~/.claude/skills`, feito à mão, e um `git pull` que ninguém lembra de dar (na máquina do autor o clone estava 3 commits atrás).

Sucesso: numa máquina nova, escolher a pasta basta para as 12 skills aparecerem numa sessão nova do Claude Code; uma skill adicionada ao repositório chega a todos sem ninguém fazer nada; quando a atualização não é possível, a pessoa fica sabendo o motivo.

## 2. Escopo

Dentro:

- Pasta de skills da empresa: escolher, ligar as skills, atualizar pelo git, avisar quando algo impede.
- Plugins do usuário: listar os instalados, ligar, desligar, remover.
- Catálogo: instalar plugins dos marketplaces que o Claude Code já conhece.

Fora (não entra nesta versão):

- Adicionar ou remover marketplaces.
- Criar ou editar skills pela ilha.
- Plugins de escopo de projeto ou local (só `user`).
- Estatística de uso de skills.
- Mais de uma pasta de skills.

## 3. Telas

### 3.1 Aba "Skills" na ilha

Terceira aba da coluna do Lumi (redesenho "Cais", `2026-10-03-redesenho-cais-design.md`; chave de view `skills`, `SkillsView.qml`), com uma estrela como ícone. Dois cartões ao lado da coluna; na ilha lateral (retrato) ficam um sobre o outro.

**Skills da empresa**

- Caminho da pasta (cortado pelo início, como o do Workspace) e quantas skills estão ligadas.
- Uma linha de estado com ponto colorido: verde "Em dia com o GitHub · atualizado há N min", amarelo com o motivo quando a atualização não foi possível (§5.3).
- Botões: "Atualizar agora" (vira "Tentar de novo" quando há aviso), "Escolher…" (o diálogo de pastas do desktop, como o do Workspace) e, com aviso, "Abrir a pasta".
- Sem pasta escolhida: o texto "Escolha a pasta das skills da empresa" e só o botão "Escolher…".

**Plugins**

- Lista rolável dos plugins instalados no escopo `user`: nome, "Remover" e um interruptor (ligado/desligado).
- "Remover" pede confirmação na própria linha ("Remover? Sim / Não"); nada é removido com um clique só.
- Botão "Adicionar plugin…" abre a janela do catálogo.
- Sem o programa `claude` (§6.1): a seção mostra "Não achei o Claude Code nesta máquina" no lugar da lista.

**Marca de aviso**: um ponto amarelo no ícone da aba enquanto houver aviso das skills, visível com qualquer aba aberta. Não há som nem notificação do sistema.

### 3.2 Catálogo "Adicionar plugin"

Emenda de 2026-10-03: o catálogo seria uma janela própria; o autor recusou janelas fora da ilha ("não pode ser um modal"). "Adicionar plugin…" troca a própria aba pelo catálogo, com "‹ Voltar".

- Campo de busca (nome, descrição e marketplace) com contagem "4 de 310".
- Lista rolável: nome, marketplace, descrição numa linha e, à direita, "Instalar" / "Instalando…"; embaixo da linha, a mensagem de erro do Claude Code quando falha.
- Rodapé: o que a última ação fez, ou "Vale para as sessões do Claude Code abertas depois da instalação."

O catálogo não atualiza marketplaces: mostra o que o Claude Code lista.

## 4. Regras da casa que se aplicam

- **Nada sem clique**: instalar, remover, ligar e desligar plugin só com clique. A atualização das skills é a exceção pedida pelo autor (§5.2) e fica restrita a um `git pull --ff-only` na pasta que a pessoa escolheu.
- **`settings.json`**: o Farol continua sem escrever nele. Quem altera `enabledPlugins` é o próprio programa `claude`, chamado pelo clique.
- **Rede**: só o `git` falando com o remoto que a pessoa configurou no clone, e o `claude` baixando o plugin que ela mandou instalar.
- **0 % de CPU escondido**: nenhum temporizador. A atualização dispara em eventos (início do app, abertura da aba).
- **Comando declarado por marketplace**: quando a instalação exige aprovar um comando (`--accept-command`), o Farol não aprova; a linha diz para instalar pelo Claude Code.

## 5. Skills da empresa

### 5.1 O que é uma skill na pasta

Cada subpasta direta com um `SKILL.md`. O nome do link é o `name:` do cabeçalho do `SKILL.md`; sem ele, o nome da subpasta. (Na máquina do autor a pasta `superloja-loja-api-sql` declara `ords-rest-superloja`.) Pastas ocultas e subpastas sem `SKILL.md` são ignoradas.

### 5.2 Ligar

`~/.claude/skills/<nome>` é um link simbólico para a subpasta. O Farol calcula um plano e o aplica:

| Situação em `~/.claude/skills/<nome>` | Ação |
|---|---|
| Não existe | Cria o link |
| Link para a subpasta certa | Nada |
| Link para dentro da pasta escolhida, mas a skill mudou de subpasta | Refaz o link |
| Link para dentro da pasta escolhida, e a skill não existe mais | Remove o link |
| Pasta de verdade, ou link para fora da pasta escolhida | Conflito: não toca, avisa |

O Farol só cria, refaz ou remove links que apontam para dentro da pasta escolhida. Trocar de pasta remove os links da pasta antiga e cria os da nova. Limpar a pasta (deixar vazia) remove os links.

O plano é aplicado sem pergunta quando a pessoa escolhe a pasta e depois de cada atualização. Conflitos viram aviso, com os nomes.

### 5.3 Atualizar

Quando: ao iniciar o Farol e ao abrir a aba, no máximo uma vez por hora; e sempre no clique em "Atualizar agora".

Como: `git -C <pasta> pull --ff-only`, sem terminal (`GIT_TERMINAL_PROMPT=0`, `ssh -o BatchMode=yes`) e com limite de 30 s. Depois, o plano de links (§5.2).

| Resultado | O que a aba mostra |
|---|---|
| Atualizou ou já estava em dia | Verde, "Em dia com o GitHub" e há quanto tempo |
| Mudanças locais ou commits que impedem o avanço | Amarelo, "Não atualizei: há mudanças suas no clone" |
| Sem rede, sem acesso ou tempo esgotado | Amarelo, "Não consegui falar com o GitHub" |
| A pasta não é um clone git | Sem aviso: as skills são ligadas e a linha diz "Pasta sem git: atualize por conta própria" |
| `git` não instalado | Amarelo, "Instale o git para atualizar" |

O Farol nunca faz `stash`, `reset`, `merge` nem `rebase`. Uma falha não desfaz os links que já existem.

## 6. Plugins

### 6.1 Achar o Claude Code

O Farol aberto pelo menu não herda o `PATH` do terminal (na máquina do autor o `claude` está no nvm). Ordem de procura: o caminho guardado em `farol.conf` (`claudePath`), o `PATH`, `~/.local/bin`, `~/.claude/local`, `~/.nvm/versions/node/*/bin` (a versão mais nova) e o binário que vem na extensão do VSCodium/VS Code. O primeiro que responder a `--version` é guardado.

### 6.2 Ler

`claude plugin list --json --available`, ao abrir a aba e ao abrir a janela, nunca em segundo plano. A saída (conferida na versão 2.1.284) é um objeto com duas listas: `installed`, com `id` (`plugin@marketplace`), `scope`, `enabled` e `version` por item, e `available`, com `pluginId`, `name` e `description` (os que ainda não estão instalados). Só os itens de `scope: "user"` entram na lista; o marketplace é o que vem depois do `@`. Campos desconhecidos são ignorados e uma saída que não dá para ler mostra "Não entendi a resposta do Claude Code (versão X)".

### 6.3 Agir

| Clique | Comando |
|---|---|
| Interruptor | `claude plugin enable <plugin@marketplace>` / `disable` |
| Remover (confirmado) | `claude plugin uninstall <plugin@marketplace>` |
| Instalar | `claude plugin install <plugin@marketplace>` |

Um comando por vez; a linha fica "…" até ele terminar. Depois de cada um a lista é lida de novo. Um erro mostra a última linha útil da saída do `claude` na própria linha.

## 7. Componentes

| Peça | Faz | Depende de |
|---|---|---|
| `core/SkillsFolder` | Lê a pasta, lê `~/.claude/skills`, devolve o plano de links (puro) e o aplica | sistema de arquivos |
| `core/PluginCatalog` | Interpreta o JSON do `claude plugin list` em instalados e disponíveis; filtra por texto e marketplace | nada |
| `core/Skills` | Objeto de contexto `skills` da view: estado, avisos, listas, ações invocáveis | as duas acima, `ICommandRunner`, `IScheduler` |
| `core/CommandRunner.h` | Interface `ICommandRunner::run(programa, argumentos, ambiente, limite, retorno)` | — |
| `platform/ProcessRunner` | `ICommandRunner` com `QProcess`, sem bloquear | Qt |
| `platform/ClaudeLocator` | Acha o `claude` (§6.1) | sistema de arquivos |
| `qml/SkillsView.qml` | A aba | `skills`, `theme`, `appState` |
| `AppState` | `skillsDir` (chave `skillsDir`), com "Escolher…" emitindo `skillsDirRequested` | — |

`main.cpp` liga o diálogo de pastas e a janela, como já faz para o Workspace e os hooks.

## 8. Testes

- `tst_skills_folder`: plano de links em pastas temporárias, uma linha da tabela de §5.2 por caso; nome vindo do `SKILL.md`; troca e limpeza de pasta; nada fora da pasta escolhida é tocado.
- `tst_plugin_catalog`: saída gravada do `claude plugin list --json --available`; JSON truncado; campos a mais; filtro.
- `tst_skills`: com `FakeCommandRunner` e `FakeScheduler`: cada linha da tabela de §5.3; o limite de uma atualização por hora; um comando por vez; releitura depois de cada ação; `claude` ausente.
- `tst_island_qml`: a aba em paisagem e retrato (nada sai da ilha), a marca de aviso no ícone, a confirmação do "Remover", o estado sem pasta e sem `claude`.
- `tst_app_state`: `skillsDir` (padrão, persistência, valores recusados).
- Nenhum teste fala com a rede nem roda o `git` ou o `claude` de verdade.

## 9. Ordem de entrega

1. Skills da empresa completas (pasta, links, atualização, avisos, aba com a seção de plugins vazia).
2. Plugins instalados (ler, ligar, desligar, remover).
3. Janela do catálogo e instalação.

Cada etapa é utilizável sozinha; a primeira já resolve o pedido da empresa.
