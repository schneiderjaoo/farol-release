#include <QtTest>
#include <QDir>
#include <QTemporaryDir>
#include <QFileInfo>
#include <QFile>
#include "Paths.h"

using farol::Paths;

namespace {
constexpr QFile::Permissions kGroupOrOther =
    QFile::ReadGroup | QFile::WriteGroup | QFile::ExeGroup |
    QFile::ReadOther | QFile::WriteOther | QFile::ExeOther;
constexpr QFile::Permissions kOwnerRwx = QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner;
}

class TestPaths : public QObject {
    Q_OBJECT
private slots:
    void derivesFromHomeNotXdg() {
        QTemporaryDir tmp;
        QVERIFY(tmp.isValid());
        qputenv("HOME", tmp.path().toUtf8());
        qputenv("XDG_DATA_HOME", "/elsewhere/data");
        qputenv("XDG_CONFIG_HOME", "/elsewhere/config");
        qputenv("XDG_RUNTIME_DIR", "/elsewhere/run");

        QCOMPARE(Paths::home(), tmp.path());
#ifdef Q_OS_WIN
        // Windows: one folder of Farol's own under %LOCALAPPDATA%, and the name of a pipe for the hook.
        qputenv("LOCALAPPDATA", QDir::toNativeSeparators(tmp.path() + "/AppData/Local").toUtf8());
        qputenv("USERNAME", "First.Last");
        QCOMPARE(Paths::dataDir(), tmp.path() + "/AppData/Local/Farol");
        QCOMPARE(Paths::socketPath(), QStringLiteral("farol-first_last"));
        QCOMPARE(Paths::configFile(), tmp.path() + "/AppData/Local/Farol/farol.conf");
        QCOMPARE(Paths::logFile(), tmp.path() + "/AppData/Local/Farol/farol.log");
        QCOMPARE(Paths::claudeSettingsPath(), tmp.path() + "/.claude/settings.json");
        qunsetenv("LOCALAPPDATA");
        QCOMPARE(Paths::dataDir(), tmp.path() + "/AppData/Local/Farol");   // not said: the usual place in the profile
        return;
#endif
        QCOMPARE(Paths::dataDir(), tmp.path() + "/.local/share/farol");
        QCOMPARE(Paths::socketPath(), tmp.path() + "/.local/share/farol/farol.sock");
        QCOMPARE(Paths::hookScriptPath(), tmp.path() + "/.local/share/farol/farol-hook");
        QCOMPARE(Paths::inboxDir(), tmp.path() + "/.local/share/farol/inbox");
        QCOMPARE(Paths::configFile(), tmp.path() + "/.config/farol/farol.conf");
        QCOMPARE(Paths::logFile(), tmp.path() + "/.local/state/farol/farol.log");
        QCOMPARE(Paths::claudeSettingsPath(), tmp.path() + "/.claude/settings.json");
    }

    void homeWithAtSign() {
        QTemporaryDir tmp;
        const QString home = tmp.path() + "/first.last@corp.example";
        QVERIFY(QDir().mkpath(home));
        qputenv("HOME", home.toUtf8());
#ifdef Q_OS_WIN
        qunsetenv("LOCALAPPDATA");
        QCOMPARE(Paths::dataDir(), home + "/AppData/Local/Farol");
#else
        QCOMPARE(Paths::socketPath(), home + "/.local/share/farol/farol.sock");
#endif
        QVERIFY(Paths::ensurePrivateDir(Paths::dataDir()));
        QVERIFY(QFileInfo(Paths::dataDir()).isDir());
    }

    void ensurePrivateDirCreatesWith0700() {
#ifdef Q_OS_WIN
        QSKIP("Windows has no mode to set: a folder of the profile is the user's alone");
#endif
        QTemporaryDir tmp;
        const QString dir = tmp.path() + "/a/b/farol";
        QVERIFY(Paths::ensurePrivateDir(dir));
        const auto perms = QFileInfo(dir).permissions();
        QCOMPARE(perms & kOwnerRwx, kOwnerRwx);
        QCOMPARE(perms & kGroupOrOther, QFile::Permissions());
    }

    void ensurePrivateDirTightensExisting() {
#ifdef Q_OS_WIN
        QSKIP("Windows has no mode to set: a folder of the profile is the user's alone");
#endif
        QTemporaryDir tmp;
        const QString dir = tmp.path() + "/farol";
        QVERIFY(QDir().mkpath(dir));
        QVERIFY(QFile::setPermissions(dir, kOwnerRwx | QFile::ReadGroup | QFile::ExeGroup |
                                               QFile::ReadOther | QFile::ExeOther));
        QVERIFY(Paths::ensurePrivateDir(dir));
        QCOMPARE(QFileInfo(dir).permissions() & kGroupOrOther, QFile::Permissions());
    }

    void socketPathLimit() {
        // sockaddr_un.sun_path is 108 bytes including the terminating NUL.
        QVERIFY(Paths::fitsUnixSocket(QString(107, 'a')));
        QVERIFY(!Paths::fitsUnixSocket(QString(108, 'a')));
        QVERIFY(Paths::fitsUnixSocket("/home/first.last@corp.example/.local/share/farol/farol.sock"));
    }
};

QTEST_APPLESS_MAIN(TestPaths)
#include "tst_paths.moc"
