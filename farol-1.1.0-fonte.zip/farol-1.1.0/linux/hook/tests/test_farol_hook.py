import importlib.machinery
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest

HOOK = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "farol-hook"))


def load_module():
    loader = importlib.machinery.SourceFileLoader("farol_hook", HOOK)
    spec = importlib.util.spec_from_loader("farol_hook", loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


class FakeApp:
    """Listens on $HOME/.local/share/farol/farol.sock like the island does."""

    def __init__(self, home, reply=None, delay=0.0):
        folder = os.path.join(home, ".local/share/farol")
        os.makedirs(folder)
        self.path = os.path.join(folder, "farol.sock")
        self.server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.server.bind(self.path)
        self.server.listen(4)
        self.received = []
        self.reply = reply      # dict -> sent as one JSON line; None -> just close (after `delay`)
        self.delay = delay
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        while True:
            try:
                conn, _ = self.server.accept()
            except OSError:
                return
            try:
                conn.settimeout(5)
                buf = b""
                while b"\n" not in buf:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    buf += chunk
                if buf:
                    self.received.append(json.loads(buf.split(b"\n")[0]))
                time.sleep(self.delay)
                if self.reply is not None:
                    conn.sendall(json.dumps(self.reply).encode() + b"\n")
            except Exception:
                pass
            finally:
                conn.close()

    def close(self):
        self.server.close()


class HookTestCase(unittest.TestCase):
    def setUp(self):
        self.home = tempfile.mkdtemp(prefix="nbh")
        self.addCleanup(shutil.rmtree, self.home, True)

    def env(self, **extra):
        # Built from scratch: the session running these tests has CLAUDE_CODE_ENTRYPOINT and friends set.
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": self.home}
        env.update(extra)
        return env

    def run_hook(self, payload, env=None, args=(), stdin=None):
        data = stdin if stdin is not None else json.dumps(payload).encode()
        start = time.monotonic()
        proc = subprocess.run([sys.executable, HOOK, *args], input=data, capture_output=True,
                              env=env if env is not None else self.env(), timeout=20)
        return proc, time.monotonic() - start


def permission(tool="Bash", command="ls"):
    return {"hook_event_name": "PermissionRequest", "session_id": "s1", "cwd": "/tmp/x",
            "tool_name": tool, "tool_input": {"command": command}}


class TestSilentFailures(HookTestCase):
    def test_app_absent_is_silent_and_fast(self):
        proc, elapsed = self.run_hook({"hook_event_name": "SessionStart", "session_id": "s1"})
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        self.assertLess(elapsed, 0.5)

    def test_orphan_socket_file_is_silent(self):
        folder = os.path.join(self.home, ".local/share/farol")
        os.makedirs(folder)
        orphan = socket.socket(socket.AF_UNIX)
        orphan.bind(os.path.join(folder, "farol.sock"))
        orphan.close()                                  # the file stays, nobody listens
        proc, elapsed = self.run_hook(permission())
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        self.assertLess(elapsed, 0.5)

    def test_missing_home_is_silent(self):
        proc, _ = self.run_hook(permission(), env={"PATH": os.environ.get("PATH", "/usr/bin")})
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))

    def test_invalid_or_empty_stdin_is_silent(self):
        for data in (b"not json", b"", b"[1,2]", b"\xff\xfe"):
            proc, _ = self.run_hook(None, stdin=data)
            self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""), data)

    def test_closed_stdout_still_exits_zero(self):
        app = FakeApp(self.home, reply={"decision": "allow"})
        self.addCleanup(app.close)
        cmd = ["sh", "-c", 'exec "$0" "$1" >&-', sys.executable, HOOK]
        proc = subprocess.run(cmd, input=json.dumps(permission()).encode(), capture_output=True,
                              env=self.env(), timeout=20)
        self.assertEqual(proc.returncode, 0)

    def test_deleted_cwd_does_not_break_the_hook(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        gone = os.path.join(self.home, "gone")
        os.makedirs(gone)
        cmd = ["sh", "-c", 'cd "$2" && rmdir "$2" && exec "$0" "$1"', sys.executable, HOOK, gone]
        proc = subprocess.run(cmd, input=json.dumps({"hook_event_name": "SessionStart", "session_id": "s1"}).encode(),
                              capture_output=True, env=self.env(), timeout=20)
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        time.sleep(0.2)
        self.assertEqual(app.received[0]["cwd"], "")


class TestForwarding(HookTestCase):
    def test_common_event_sends_one_line_and_prints_nothing(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        proc, _ = self.run_hook({"hook_event_name": "SessionStart", "session_id": "s1", "cwd": "/tmp/p"},
                                env=self.env(TERM_PROGRAM="konsole-ish"))
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        time.sleep(0.2)
        sent = app.received[0]
        self.assertEqual(sent["hook_event_name"], "SessionStart")
        self.assertEqual(sent["farol_source"], "terminal")
        self.assertEqual(sent["term_program"], "konsole-ish")
        self.assertEqual(sent["cwd"], "/tmp/p")

    def test_source_vscodium(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        self.run_hook({"hook_event_name": "Stop", "session_id": "s1"},
                      env=self.env(CLAUDE_CODE_ENTRYPOINT="claude-vscode", FLATPAK_ID="com.vscodium.codium"))
        time.sleep(0.2)
        self.assertEqual(app.received[0]["farol_source"], "vscodium")
        self.assertEqual(app.received[0]["flatpak_id"], "com.vscodium.codium")

    def test_source_konsole(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        self.run_hook({"hook_event_name": "Stop", "session_id": "s1"},
                      env=self.env(KONSOLE_DBUS_SERVICE=":1.77", KONSOLE_DBUS_SESSION="/Sessions/3",
                                   KONSOLE_DBUS_WINDOW="/Windows/1"))
        time.sleep(0.2)
        sent = app.received[0]
        self.assertEqual(sent["farol_source"], "konsole")
        self.assertEqual((sent["konsole_dbus_service"], sent["konsole_dbus_session"], sent["konsole_dbus_window"]),
                         (":1.77", "/Sessions/3", "/Windows/1"))

    def test_missing_cwd_falls_back_to_the_process_cwd(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        self.run_hook({"hook_event_name": "Stop", "session_id": "s1"})
        time.sleep(0.2)
        self.assertTrue(app.received[0]["cwd"])


class TestClaudeProcess(HookTestCase):
    """The hook names the Claude Code process it runs for, so the island can watch it."""

    def test_the_closest_ancestor_named_claude_is_reported(self):
        table = {40: ("python3", 30, 900), 30: ("sh", 20, 800), 20: ("claude", 10, 700), 10: ("claude", 1, 600)}
        self.assertEqual(load_module().claude_process(40, table.__getitem__), (20, 700))

    def test_no_claude_ancestor_reports_nothing(self):
        hook = load_module()
        table = {40: ("python3", 30, 900), 30: ("bash", 1, 800)}
        self.assertIsNone(hook.claude_process(40, table.__getitem__))
        self.assertIsNone(hook.claude_process(40, {}.__getitem__))          # the process is already gone
        endless = {pid: ("sh", pid + 1, 1) for pid in range(2, 100)}
        self.assertIsNone(hook.claude_process(2, endless.__getitem__))      # gives up after a few ancestors

    def test_ancestors_are_listed_closest_first_up_to_init(self):
        hook = load_module()
        table = {40: ("claude", 30, 900), 30: ("zsh", 20, 800), 20: ("kitty", 10, 700), 10: ("systemd", 1, 600)}
        self.assertEqual(hook.ancestors(40, table.__getitem__), [(30, 800, "zsh"), (20, 700, "kitty"), (10, 600, "systemd")])
        self.assertEqual(hook.ancestors(99, table.__getitem__), [])                 # already gone
        endless = {pid: ("sh", pid + 1, 1) for pid in range(2, 100)}
        self.assertEqual(len(hook.ancestors(2, endless.__getitem__)), hook.MAX_WINDOW_ANCESTORS)

    def test_stat_is_read_from_proc_even_with_an_odd_process_name(self):
        hook = load_module()
        name, parent, start = hook.read_stat(os.getpid())
        self.assertEqual(parent, os.getppid())
        self.assertGreater(start, 0)
        with open("/proc/%d/stat" % os.getpid()) as f:
            self.assertEqual(start, int(f.read().rsplit(")", 1)[1].split()[19]))

    def test_event_carries_the_claude_process(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        # A process named "claude" (a link to the interpreter) that runs the hook through a shell, like Claude Code.
        claude = os.path.join(self.home, "claude")
        os.symlink(sys.executable, claude)
        runner = ("import json, os, subprocess, sys\n"
                  "subprocess.run(['/bin/sh', '-c', sys.argv[1] + ' ' + sys.argv[2] + '; true'], "
                  "input=json.dumps({'hook_event_name': 'Stop', 'session_id': 's1'}).encode())\n"
                  "print(os.getpid(), open('/proc/self/stat').read().rsplit(')', 1)[1].split()[19])\n")
        proc = subprocess.run([claude, "-c", runner, sys.executable, HOOK], capture_output=True, env=self.env(),
                              timeout=20)
        pid, start = map(int, proc.stdout.split())
        time.sleep(0.2)
        self.assertEqual((app.received[0]["claude_pid"], app.received[0]["claude_start"]), (pid, start))
        # the processes above it, this test among them: where its window is looked for
        self.assertIn(os.getpid(), [p for p, _ in app.received[0]["farol_ancestors"]])
        self.assertNotIn("farol_editor", app.received[0])                           # a terminal session


class TestPermission(HookTestCase):
    def decision(self, reply, **kw):
        app = FakeApp(self.home, reply=reply, **kw)
        self.addCleanup(app.close)
        return self.run_hook(permission())

    def test_allow_prints_the_exact_json(self):
        proc, _ = self.decision({"decision": "allow"})
        self.assertEqual(proc.stdout, b'{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"allow"}}}\n')
        self.assertEqual((proc.returncode, proc.stderr), (0, b""))

    def test_deny_prints_the_exact_json(self):
        proc, _ = self.decision({"decision": "deny"})
        self.assertEqual(proc.stdout, b'{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"deny"}}}\n')

    def test_deny_carries_the_message(self):
        proc, _ = self.decision({"decision": "deny", "message": "Denied from the island"})
        self.assertEqual(proc.stdout, b'{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"deny","message":"Denied from the island"}}}\n')

    def test_allow_carries_the_answers_of_a_question(self):
        # AskUserQuestion answered in the island: the tool input comes back with the chosen answers filled in.
        updated = {"questions": [{"question": "Qual banco?", "options": [{"label": "Postgres"}, {"label": "SQLite"}]}],
                   "answers": {"Qual banco?": "Postgres"}}
        proc, _ = self.decision({"decision": "allow", "updatedInput": updated})
        self.assertEqual(json.loads(proc.stdout), {"hookSpecificOutput": {
            "hookEventName": "PermissionRequest", "decision": {"behavior": "allow", "updatedInput": updated}}})

    def test_updated_input_is_ignored_unless_it_is_an_object_on_allow(self):
        proc, _ = self.decision({"decision": "allow", "updatedInput": "rm -rf /"})
        self.assertEqual(json.loads(proc.stdout)["hookSpecificOutput"]["decision"], {"behavior": "allow"})
        self.setUp()
        proc, _ = self.decision({"decision": "deny", "updatedInput": {"a": 1}})
        self.assertEqual(json.loads(proc.stdout)["hookSpecificOutput"]["decision"], {"behavior": "deny"})

    def test_release_garbage_and_silence_print_nothing(self):
        for reply in ({"decision": "release"}, {"decision": "maybe"}, {"nothing": 1}, ["allow"], None):
            self.setUp()
            proc, _ = self.decision(reply)
            self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""), reply)

    def test_waits_for_the_decision_timeout_then_stays_silent(self):
        app = FakeApp(self.home, reply=None, delay=4)
        self.addCleanup(app.close)
        proc, elapsed = self.run_hook(permission(), args=("--decision-timeout", "1"))
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        self.assertGreater(elapsed, 0.9)
        self.assertLess(elapsed, 2.5)


def stop():
    return {"hook_event_name": "Stop", "session_id": "s1", "cwd": "/tmp/x", "last_assistant_message": "Done."}


def post_tool_use():
    return {"hook_event_name": "PostToolUse", "session_id": "s1", "cwd": "/tmp/x", "tool_name": "Bash",
            "tool_input": {"command": "ls"}}


class TestOnlyPermissionRequestsWait(HookTestCase):
    """Stop and PostToolUse are fire-and-forget: whatever the app sends back, nothing is printed and nothing waits."""

    def test_stop_and_post_tool_use_report_and_leave(self):
        for payload in (stop(), post_tool_use()):
            self.setUp()
            app = FakeApp(self.home, reply={"message": "ignored"}, delay=2)
            self.addCleanup(app.close)
            # "--reply-timeout" is what an earlier install wrote for the Stop hook: ignored, never waited for
            proc, elapsed = self.run_hook(payload, args=("--reply-timeout", "125"))
            self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
            self.assertLess(elapsed, 0.6)
            time.sleep(0.2)
            self.assertEqual(app.received[0]["hook_event_name"], payload["hook_event_name"])
            self.assertNotIn("farol_reply_timeout", app.received[0])


FILE = "/work/farol/notes.txt"


def hunk(lines, old_start=1, new_start=1):
    return {"oldStart": old_start, "oldLines": sum(1 for l in lines if l[:1] != "+"), "newStart": new_start,
            "newLines": sum(1 for l in lines if l[:1] != "-"), "lines": list(lines)}


def tool_event(event, tool, tool_input, response=None):
    """A PreToolUse or PostToolUse payload, shaped like the ones Claude Code 2.1.289 sends."""
    payload = {"session_id": "s1", "transcript_path": "/home/u/.claude/projects/-work-farol/s1.jsonl", "cwd": "/work/farol",
               "permission_mode": "acceptEdits", "hook_event_name": event, "tool_name": tool, "tool_input": tool_input,
               "tool_use_id": "toolu_01"}
    if response is not None:
        payload["tool_response"] = response
        payload["duration_ms"] = 12
    return payload


def edit_done(original="alpha\nbeta\ngamma\ndelta\n", patch=None):
    patch = [hunk([" alpha", "-beta", "+beta2", "+beta3", " gamma", " delta"])] if patch is None else patch
    return tool_event("PostToolUse", "Edit",
                      {"file_path": FILE, "old_string": "beta", "new_string": "beta2\nbeta3", "replace_all": False},
                      {"filePath": FILE, "oldString": "beta", "newString": "beta2\nbeta3", "originalFile": original,
                       "structuredPatch": patch, "userModified": False, "replaceAll": False})


def write_done(kind, content, original, patch):
    return tool_event("PostToolUse", "Write", {"file_path": FILE, "content": content},
                      {"type": kind, "filePath": FILE, "content": content, "structuredPatch": patch,
                       "originalFile": original, "userModified": False})


def notebook_done(new_source, old_source=None, original="{\"cells\": []}", updated="{\"cells\": [1]}"):
    response = {"new_source": new_source, "cell_type": "code", "language": "python",
                "edit_mode": "insert" if old_source is None else "replace", "cell_id": "c1", "error": "",
                "notebook_path": "/work/farol/nb.ipynb", "original_file": original, "updated_file": updated}
    if old_source is not None:
        response["old_source"] = old_source
    return tool_event("PostToolUse", "NotebookEdit", {"notebook_path": "/work/farol/nb.ipynb", "cell_id": "c1",
                                                       "new_source": new_source}, response)


class TestSlim(unittest.TestCase):
    """What a tool event keeps on its way to the island: an edit's patch and its counts, never the whole file."""

    def setUp(self):
        self.hook = load_module()

    def slim(self, payload):
        before = json.dumps(payload, sort_keys=True)
        out = self.hook.slim(payload)
        self.assertEqual(json.dumps(payload, sort_keys=True), before, "slim() changed what it was given")
        return out

    def test_an_edit_keeps_its_patch_and_loses_the_whole_file(self):
        payload = edit_done()
        out = self.slim(payload)
        self.assertEqual(out["farol_edit"], {"added": 2, "removed": 1, "cut": False})
        self.assertEqual(out["tool_response"]["structuredPatch"], payload["tool_response"]["structuredPatch"])
        self.assertEqual(out["tool_response"], {"filePath": FILE, "structuredPatch": payload["tool_response"]["structuredPatch"],
                                                "userModified": False, "replaceAll": False})
        self.assertEqual(out["tool_input"], {"file_path": FILE, "replace_all": False})
        for key in ("session_id", "cwd", "transcript_path", "tool_use_id", "tool_name", "hook_event_name", "duration_ms"):
            self.assertEqual(out[key], payload[key], key)

    def test_multi_edit_is_slimmed_like_an_edit(self):
        payload = edit_done()
        payload["tool_name"] = "MultiEdit"
        out = self.slim(payload)
        self.assertEqual(out["farol_edit"], {"added": 2, "removed": 1, "cut": False})
        self.assertNotIn("originalFile", out["tool_response"])

    def test_every_hunk_is_counted(self):
        patch = [hunk(["-foo", "+qux", " bar", "-foo", "+qux"]), hunk([" baz", "-foo", "+qux", "+more"], 40, 40)]
        self.assertEqual(self.slim(edit_done(patch=patch))["farol_edit"], {"added": 4, "removed": 3, "cut": False})

    def test_counts_are_taken_before_the_cap(self):
        lines = ["-old %d" % i for i in range(250)] + ["+new %d" % i for i in range(450)]
        out = self.slim(edit_done(patch=[hunk(lines)]))
        self.assertEqual(out["farol_edit"], {"added": 450, "removed": 250, "cut": True})
        kept = out["tool_response"]["structuredPatch"]
        self.assertEqual(sum(len(h["lines"]) for h in kept), 300)
        self.assertEqual(kept[0]["lines"], lines[:300])
        self.assertEqual((kept[0]["oldStart"], kept[0]["oldLines"], kept[0]["newLines"]), (1, 250, 450))   # the head says what it was

    def test_the_cap_is_three_hundred_lines_over_all_the_hunks(self):
        patch = [hunk(["+a%d" % i for i in range(200)]), hunk(["+b%d" % i for i in range(200)], 500, 700),
                 hunk(["+c%d" % i for i in range(5)], 900, 1300)]
        out = self.slim(edit_done(patch=patch))
        kept = out["tool_response"]["structuredPatch"]
        self.assertEqual([len(h["lines"]) for h in kept], [200, 100])           # a hunk with nothing left is not sent
        self.assertEqual(kept[1]["lines"][-1], "+b99")
        self.assertEqual(out["farol_edit"], {"added": 405, "removed": 0, "cut": True})

    def test_exactly_three_hundred_lines_are_not_cut(self):
        out = self.slim(edit_done(patch=[hunk(["+x"] * 300)]))
        self.assertEqual(out["farol_edit"], {"added": 300, "removed": 0, "cut": False})
        self.assertEqual(len(out["tool_response"]["structuredPatch"][0]["lines"]), 300)

    def test_a_long_line_is_cut_at_two_hundred_and_forty_characters(self):
        out = self.slim(edit_done(patch=[hunk(["+" + "x" * 239, "-" + "y" * 240, " " + "é" * 5000])]))
        lines = out["tool_response"]["structuredPatch"][0]["lines"]
        self.assertEqual(lines, ["+" + "x" * 239, "-" + "y" * 239, " " + "é" * 239])
        self.assertEqual(out["farol_edit"], {"added": 1, "removed": 1, "cut": True})
        self.assertFalse(self.slim(edit_done(patch=[hunk(["+" + "x" * 239])]))["farol_edit"]["cut"])

    def test_a_write_that_creates_a_file_counts_its_lines_as_added(self):
        out = self.slim(write_done("create", "alpha\nbeta\n\ndelta\n", None, []))
        self.assertEqual(out["farol_edit"], {"added": 4, "removed": 0, "cut": False})
        self.assertEqual(out["tool_response"], {"type": "create", "filePath": FILE, "userModified": False, "structuredPatch": [
            {"oldStart": 0, "oldLines": 0, "newStart": 1, "newLines": 4, "lines": ["+alpha", "+beta", "+", "+delta"]}]})
        self.assertEqual(out["tool_input"], {"file_path": FILE})
        # no newline at the end, a single line, nothing at all
        self.assertEqual(self.slim(write_done("create", "a\nb", None, []))["farol_edit"]["added"], 2)
        self.assertEqual(self.slim(write_done("create", "a", None, []))["tool_response"]["structuredPatch"][0]["lines"], ["+a"])
        empty = self.slim(write_done("create", "", None, []))
        self.assertEqual((empty["farol_edit"], empty["tool_response"]["structuredPatch"]), ({"added": 0, "removed": 0, "cut": False}, []))

    def test_a_big_new_file_is_counted_whole_and_sent_cut(self):
        out = self.slim(write_done("create", "".join("line %d\n" % i for i in range(5000)), None, []))
        self.assertEqual(out["farol_edit"], {"added": 5000, "removed": 0, "cut": True})
        (only,) = out["tool_response"]["structuredPatch"]
        self.assertEqual((len(only["lines"]), only["newLines"], only["lines"][299]), (300, 5000, "+line 299"))

    def test_a_write_over_a_file_keeps_the_patch_claude_code_made(self):
        patch = [hunk([" alpha", "-beta2", "-beta3", "-gamma", "+omega", " delta"])]
        out = self.slim(write_done("update", "alpha\nomega\ndelta\n", "alpha\nbeta2\nbeta3\ngamma\ndelta\n", patch))
        self.assertEqual(out["farol_edit"], {"added": 1, "removed": 3, "cut": False})
        self.assertEqual(out["tool_response"], {"type": "update", "filePath": FILE, "userModified": False, "structuredPatch": patch})

    def test_a_write_that_changes_nothing_counts_nothing(self):
        out = self.slim(write_done("update", "alpha\n", "alpha\n", []))
        self.assertEqual(out["farol_edit"], {"added": 0, "removed": 0, "cut": False})
        self.assertEqual(out["tool_response"]["structuredPatch"], [])

    def test_a_notebook_edit_loses_both_whole_files(self):
        out = self.slim(notebook_done("print('two')", "print('one')\n"))
        self.assertEqual(out["tool_response"], {"new_source": "print('two')", "old_source": "print('one')\n", "cell_type": "code",
                                                "language": "python", "edit_mode": "replace", "cell_id": "c1", "error": "",
                                                "notebook_path": "/work/farol/nb.ipynb"})
        self.assertNotIn("farol_edit", out)                        # the island counts a cell's lines itself
        self.assertEqual(out["tool_input"]["new_source"], "print('two')")

    def test_a_long_cell_is_cut(self):
        out = self.slim(notebook_done("n" * 40000, "o" * 32768))
        self.assertEqual((len(out["tool_response"]["new_source"]), len(out["tool_response"]["old_source"])), (32768, 32768))
        self.assertEqual(out["farol_edit"], {"cut": True})
        self.assertNotIn("farol_edit", self.slim(notebook_done("n" * 32768)))

    def test_a_write_about_to_run_goes_without_its_content(self):
        out = self.slim(tool_event("PreToolUse", "Write", {"file_path": FILE, "content": "x" * 5000}))
        self.assertEqual(out["tool_input"], {"file_path": FILE})
        self.assertNotIn("farol_edit", out)
        edit = tool_event("PreToolUse", "Edit", {"file_path": FILE, "old_string": "a", "new_string": "b"})
        self.assertEqual(self.slim(edit), edit)                    # only a Write's content is dropped before the tool runs

    def test_a_permission_request_is_never_touched(self):
        payload = tool_event("PermissionRequest", "Write", {"file_path": FILE, "content": "x" * 5000})
        self.assertIs(self.hook.slim(payload), payload)
        asked = edit_done()
        asked["hook_event_name"] = "PermissionRequest"
        before = self.hook.line(asked)
        self.assertEqual(self.hook.line(self.hook.slim(asked)), before)

    def test_other_tools_and_other_events_are_left_alone(self):
        bash = tool_event("PostToolUse", "Bash", {"command": "ls"}, {"stdout": "a\nb\n", "stderr": "", "interrupted": False})
        read = tool_event("PostToolUse", "Read", {"file_path": FILE},
                          {"type": "text", "file": {"filePath": FILE, "content": "alpha\n", "numLines": 1, "startLine": 1, "totalLines": 1}})
        failed = edit_done()
        failed["hook_event_name"] = "PostToolUseFailure"
        stop = {"hook_event_name": "Stop", "session_id": "s1", "last_assistant_message": "done"}
        for payload in (bash, read, failed, stop, tool_event("PreToolUse", "Bash", {"command": "ls"}), {}):
            self.assertEqual(self.slim(payload), payload)

    def test_a_response_that_is_not_an_object_is_left_alone(self):
        for response in ("File written", ["x"], 3, True):
            payload = tool_event("PostToolUse", "Edit", {"file_path": FILE, "old_string": "a", "new_string": "b"}, response)
            self.assertEqual(self.slim(payload), payload, response)
        nothing = tool_event("PostToolUse", "Write", {"file_path": FILE, "content": "x"})
        self.assertEqual(self.slim(nothing), nothing)              # no tool_response at all

    def test_a_shape_it_does_not_know_never_breaks_it(self):
        # a patch that is no list: the whole-file fields still go, and nothing is counted
        odd = edit_done(patch="@@ -1 +1 @@")
        out = self.slim(odd)
        self.assertNotIn("farol_edit", out)
        self.assertNotIn("originalFile", out["tool_response"])
        self.assertEqual(out["tool_response"]["structuredPatch"], "@@ -1 +1 @@")
        # hunks and lines of the wrong kind are skipped
        out = self.slim(edit_done(patch=["hunk", {"lines": "no"}, {"oldStart": 1, "lines": ["+a", 7, None, "-b", ""]}]))
        self.assertEqual(out["farol_edit"], {"added": 1, "removed": 1, "cut": False})
        self.assertEqual(out["tool_response"]["structuredPatch"], [{"oldStart": 1, "lines": ["+a", "-b", ""]}])
        # a new file whose content is in the tool input only, or nowhere
        only_input = write_done("create", "a\nb\n", None, [])
        del only_input["tool_response"]["content"]
        self.assertEqual(self.slim(only_input)["farol_edit"]["added"], 2)
        nowhere = write_done("create", None, None, [])
        self.assertEqual(self.slim(nowhere)["farol_edit"], {"added": 0, "removed": 0, "cut": False})
        self.assertEqual(self.slim(tool_event("PostToolUse", "Edit", "not an object", {"structuredPatch": []}))["tool_input"], "not an object")
        self.assertEqual(self.slim(tool_event("PreToolUse", "Write", ["content"]))["tool_input"], ["content"])

    def test_an_edit_of_a_huge_file_fits_the_island(self):
        # shaped like the captured ones: an Edit of a 2 MB file, and nine bytes written over a file of 6000 lines
        big = "".join("row %06d of the huge file, padded with some text to make it longer ......\n" % i for i in range(28000))
        self.assertGreater(len(big), 2 * 1024 * 1024)
        edit = edit_done(original=big, patch=[hunk([" row 000000", "-row 000001", "+ROW ONE", " row 000002"])])
        self.assertGreater(len(self.hook.line(edit)), 2 * 1024 * 1024)
        out = self.slim(edit)
        self.assertLess(len(self.hook.line(out)), 2048)
        self.assertEqual(out["farol_edit"], {"added": 1, "removed": 1, "cut": False})

        old = big[:450000]
        lines = ["-" + l for l in old.split("\n")[:-1]] + ["+tiny now"]
        write = write_done("update", "tiny now\n", old, [hunk(lines)])
        out = self.slim(write)
        self.assertEqual(out["farol_edit"], {"added": 1, "removed": len(lines) - 1, "cut": True})
        self.assertLess(len(self.hook.line(out)), 64 * 1024)

    def test_the_worst_patch_still_fits(self):
        # 300 lines of 240 characters that each take twelve bytes of JSON
        out = self.slim(edit_done(patch=[hunk(["+" + "\U0001F600" * 400] * 400)]))
        self.assertLess(len(self.hook.packed(out)), 1024 * 1024)
        self.assertEqual(out["farol_edit"], {"added": 400, "removed": 0, "cut": True})

    def test_a_line_that_is_still_too_long_goes_without_the_tool_data(self):
        huge = tool_event("PostToolUse", "SomeMcpTool", {"query": "x" * 1000}, {"rows": "y" * 950000})
        sent = json.loads(self.hook.packed(self.slim(huge)))
        self.assertNotIn("tool_response", sent)
        self.assertNotIn("tool_input", sent)
        self.assertEqual((sent["tool_name"], sent["tool_use_id"], sent["session_id"]), ("SomeMcpTool", "toolu_01", "s1"))
        fits = tool_event("PostToolUse", "SomeMcpTool", {"query": "x"}, {"rows": "y" * 800000})
        self.assertEqual(self.hook.packed(fits), self.hook.line(fits))
        self.assertTrue(self.hook.packed(huge).endswith(b"\n"))


    def test_a_slim_that_fails_sends_the_event_as_it_came(self):
        # nothing known makes slim() fail; were it ever to, the island still hears of the event
        payload = edit_done()

        def broken(_):
            raise KeyError("a shape nobody thought of")
        self.assertEqual(self.hook.slimmed(payload)["farol_edit"], {"added": 2, "removed": 1, "cut": False})
        self.hook.slim = broken
        self.assertIs(self.hook.slimmed(payload), payload)


class TestSlimOnTheWire(HookTestCase):
    def test_a_finished_edit_arrives_slim_and_fast(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        big = "x" * (3 * 1024 * 1024)
        proc, elapsed = self.run_hook(edit_done(original=big))
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        self.assertLess(elapsed, 0.6)
        time.sleep(0.2)
        sent = app.received[0]
        self.assertEqual(sent["farol_edit"], {"added": 2, "removed": 1, "cut": False})
        self.assertNotIn("originalFile", sent["tool_response"])
        self.assertEqual(sent["tool_response"]["structuredPatch"][0]["lines"][1], "-beta")
        self.assertEqual(sent["farol_source"], "terminal")           # and what the hook adds is still there

    def test_a_permission_request_carries_everything_it_had(self):
        app = FakeApp(self.home, reply={"decision": "allow"})
        self.addCleanup(app.close)
        payload = tool_event("PermissionRequest", "Write", {"file_path": FILE, "content": "x" * 20000})
        proc, _ = self.run_hook(payload)
        self.assertIn(b'"behavior":"allow"', proc.stdout)
        self.assertEqual(app.received[0]["tool_input"], payload["tool_input"])
        self.assertNotIn("farol_edit", app.received[0])


class TestPureFunctions(unittest.TestCase):
    def test_decision_timeout_argument(self):
        m = load_module()
        self.assertEqual(m.decision_timeout(["farol-hook"]), 110.0)
        self.assertEqual(m.decision_timeout(["farol-hook", "--decision-timeout", "30"]), 30.0)
        for bad in ("abc", "-5", "0", "nan", "inf", "99999"):
            self.assertEqual(m.decision_timeout(["farol-hook", "--decision-timeout", bad]), 110.0, bad)
        self.assertEqual(m.decision_timeout(["farol-hook", "--decision-timeout"]), 110.0)


if __name__ == "__main__":
    unittest.main()
