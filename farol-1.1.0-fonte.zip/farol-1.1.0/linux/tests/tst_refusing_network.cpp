#include <QtTest>
#include <QQmlComponent>
#include <QQmlEngine>
#include <QQuickItem>
#include <QQuickView>
#include <QTcpServer>
#include <QTcpSocket>
#include <memory>
#include "NetworkClient.h"
#include "RefusingNetworkFactory.h"

using namespace farol;

// The island's QML engine must not be able to call out: rich text fetches whatever an image in it points to.
class TestRefusingNetwork : public QObject {
    Q_OBJECT
    QTcpServer server;
    int connections = 0;

    // A rich Text with an image on the local server, shown off screen for a moment.
    void showAnImage(QQuickView &view)
    {
        QQmlComponent component(view.engine());
        component.setData(QStringLiteral("import QtQuick\nText { textFormat: Text.RichText; text: 'antes <img src=\"http://127.0.0.1:%1/x.png\"> depois' }")
                              .arg(server.serverPort()).toUtf8(), QUrl());
        std::unique_ptr<QQuickItem> text(qobject_cast<QQuickItem *>(component.create()));
        QVERIFY2(text, qPrintable(component.errorString()));
        text->setParentItem(view.contentItem());
        view.resize(300, 100);
        view.show();
        QTest::qWait(1500);
    }

private slots:
    void initTestCase()
    {
        QVERIFY(server.listen(QHostAddress::LocalHost));
        connect(&server, &QTcpServer::newConnection, this, [this] {
            while (QTcpSocket *socket = server.nextPendingConnection()) {
                ++connections;
                connect(socket, &QTcpSocket::readyRead, socket, [socket] {   // any request gets a small JSON answer
                    socket->readAll();
                    socket->write("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: 2\r\nConnection: close\r\n\r\n{}");
                    socket->disconnectFromHost();
                });
                connect(socket, &QTcpSocket::disconnected, socket, &QObject::deleteLater);
            }
        });
    }
    void init() { connections = 0; }

    // What the factory is there to stop (and the proof that this test can see a request).
    void anEngineLeftAloneFetchesTheImage()
    {
        QQuickView view;
        showAnImage(view);
        QVERIFY(connections >= 1);
    }

    void anEngineWithTheFactoryCallsNobody()
    {
        RefusingNetworkFactory factory;
        QQuickView view;
        view.engine()->setNetworkAccessManagerFactory(&factory);
        showAnImage(view);
        QCOMPARE(connections, 0);
    }

    // Farol's own requests (the "Perguntar" tab) do not go through the engine.
    void theAppsOwnRequestsStillGoOut()
    {
        RefusingNetworkFactory factory;
        QQmlEngine engine;
        engine.setNetworkAccessManagerFactory(&factory);
        NetworkClient client;
        IHttpClient::Reply got;
        bool done = false;
        client.post({QUrl(QStringLiteral("http://127.0.0.1:%1/v1/messages").arg(server.serverPort())), {{"content-type", "application/json"}}, "{}"},
                    5000, [&](const IHttpClient::Reply &reply) { got = reply; done = true; });
        QTRY_VERIFY_WITH_TIMEOUT(done, 6000);
        QCOMPARE(got.status, 200);
        QCOMPARE(got.body, QByteArray("{}"));
        QCOMPARE(connections, 1);
    }
};

QTEST_MAIN(TestRefusingNetwork)
#include "tst_refusing_network.moc"
