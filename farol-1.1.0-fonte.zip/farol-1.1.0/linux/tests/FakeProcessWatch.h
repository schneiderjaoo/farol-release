#pragma once
#include "ProcessWatch.h"

#include <algorithm>
#include <functional>
#include <vector>

// Processes that live until exit() is called.
class FakeProcessWatch : public farol::IProcessWatch {
public:
    bool findsProcesses = true;   // false: every process is "not found", like one that is already gone

    int watch(qint64 pid, qint64 start, std::function<void()> gone) override
    {
        if (!findsProcesses)
            return 0;
        m_watches.push_back({++m_next, pid, start, std::move(gone)});
        return m_next;
    }
    void cancel(int id) override
    {
        m_watches.erase(std::remove_if(m_watches.begin(), m_watches.end(), [id](const Watch &w) { return w.id == id; }),
                        m_watches.end());
    }
    // The process exits: every watch on it runs once.
    void exit(qint64 pid, qint64 start)
    {
        std::vector<Watch> hit;
        for (const Watch &w : m_watches)
            if (w.pid == pid && w.start == start)
                hit.push_back(w);
        for (const Watch &w : hit)
            cancel(w.id);
        for (const Watch &w : hit)
            w.gone();
    }
    int watching() const { return int(m_watches.size()); }

private:
    struct Watch {
        int id;
        qint64 pid, start;
        std::function<void()> gone;
    };
    std::vector<Watch> m_watches;
    int m_next = 0;
};
