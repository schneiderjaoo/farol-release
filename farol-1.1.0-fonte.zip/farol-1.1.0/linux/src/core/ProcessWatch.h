#pragma once
#include <QtGlobal>
#include <functional>

namespace farol {

// Tells when a process exits, behind an interface so tests can end processes by hand.
class IProcessWatch {
public:
    virtual ~IProcessWatch() = default;
    // pid as the process sees itself (its own PID namespace) and its start time, both from farol-hook. Runs gone
    // once when that process exits. The returned id can be passed to cancel(); 0 means the process was not found.
    virtual int watch(qint64 pid, qint64 start, std::function<void()> gone) = 0;
    virtual void cancel(int id) = 0;
};

} // namespace farol
