#pragma once
#include <QString>

// Kept out of tst_settings_merger.cpp: moc cannot lex raw strings with a custom delimiter.
namespace {
// Custom raw-string delimiter: the content has `)"` inside ("Bash(python3 -)").
inline const QString kSettings = QStringLiteral(R"JSON({
  "respectGitignore": false,
  "permissions": {
    "allow": [
      "Bash(python3 -)",
      "Bash(awk 'NR==40{print \"len=\"length\\($0\\)}')"
    ]
  },
  "model": "opus[1m]",
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "echo 'fim — ok'"
          }
        ]
      }
    ]
  },
  "theme": "dark-daltonized"
}
)JSON");

inline const QString kNoHooks = QStringLiteral(R"JSON({
  "model": "opus[1m]",
  "theme": "dark"
}
)JSON");
inline const QString kEscapesFixture = QStringLiteral(R"({
  "a": 1.50e+3,
  "b": "é\/x",
  "c": [],
  "d": {},
  "e": null,
  "f": [
    1,
    [
      2
    ]
  ]
}
)");

inline const QString kBadHooksArray = QStringLiteral(R"({"hooks": []})");

inline const QString kBadStopObject = QStringLiteral(R"({"hooks": {"Stop": {}}})");

inline const QString kSharedGroupFixture = QStringLiteral(R"({
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "echo foreign"
          },
          {
            "type": "command",
            "command": "\"/home/u/.local/share/farol/farol-hook\"",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
)");

} // namespace
