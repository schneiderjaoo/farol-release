#pragma once
#include "SecretStore.h"
#include <QDBusObjectPath>
#include <QDBusVariant>
#include <QObject>
#include <QVariantList>

namespace farol {

// ISecretStore on the desktop's secret service (D-Bus org.freedesktop.secrets): KWallet on Plasma, GNOME Keyring
// where that one owns the name. Items of the default collection tagged application=farol. Nothing is opened at
// start; the service may ask the user to unlock the collection when a secret is asked for.
class SecretServiceStore : public QObject, public ISecretStore {
    Q_OBJECT
public:
    explicit SecretServiceStore(QObject *parent = nullptr);
    void read(const QString &name, std::function<void(bool ok, const QString &value)> done) override;
    void write(const QString &name, const QString &value, std::function<void(bool ok)> done) override;
    void remove(const QString &name, std::function<void(bool ok)> done) override;

private slots:
    void promptCompleted(bool dismissed, const QDBusVariant &result);

private:
    using Answer = std::function<void(bool ok, const QVariantList &values)>;
    void call(const QString &path, const QString &interface, const QString &method, const QVariantList &arguments, Answer then);
    void withSession(std::function<void(const QDBusObjectPath &session)> then);
    // Unlocks these objects, asking the user when the service wants to.
    void unlock(const QList<QDBusObjectPath> &objects, std::function<void(bool ok)> then);
    void runPrompt(const QDBusObjectPath &prompt, std::function<void(bool ok)> then);
    // The item kept under this name, unlocked: an empty path when there is none.
    void find(const QString &name, std::function<void(bool ok, const QDBusObjectPath &item)> then);

    QDBusObjectPath m_session;
    QString m_promptPath;
    std::function<void(bool)> m_promptDone;
};

} // namespace farol
