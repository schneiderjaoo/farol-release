#pragma once
#include <QString>

namespace farol {

// A folder that stands for another one, as ~/.claude/skills/<name> stands for a skill of the company's folder.
// On Linux a symbolic link. On Windows a directory junction: a symbolic link there needs developer mode or an
// administrator, and QFile::link makes a shortcut file (.lnk), which Claude Code does not follow. A junction only
// reaches a folder of this machine.
namespace links {

bool isLink(const QString &path);             // also one whose target is gone
QString target(const QString &path);          // where it points, cleaned; empty when it is not a link
bool make(const QString &target, const QString &link);
bool remove(const QString &link);             // the link itself, never what it points to

} // namespace links
} // namespace farol
