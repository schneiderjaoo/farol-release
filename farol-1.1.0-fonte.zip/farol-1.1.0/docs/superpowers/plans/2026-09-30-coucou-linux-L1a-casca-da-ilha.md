# Coucou Linux — L1a Casca da ilha — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ter o app `coucou` rodando no Fedora KDE com a ilha do Mochi se comportando como a do Mac — tamanhos, tempos, curvas, FSM (escondida → compacta → expandida → saudação), sons, bandeja — com personagem, cartões e conteúdo das views **provisórios** (o Mochi vem no L1b, as views no L1c).

**Architecture:** `coucou_core` (sem UI, testado com Qt Test) guarda tipos/geometria, a FSM da ilha, o estado (`AppState`) e o controlador (`IslandController`) que porta a fiação de `IslandWindowController.swift`. `coucou_platform` guarda a janela layer-shell, o som e a bandeja. A UI é QML (`linux/qml/`), ligada ao core por propriedades (`appState`, `controller`). Tempo (timers) entra por uma interface `IScheduler` para os testes usarem um relógio falso.

**Tech Stack:** C++20, Qt 6.11 (Core, Gui, Quick, Multimedia, Test), QML (`QtQuick`, `QtQuick.Shapes`), LayerShellQt 6.7, KF6 StatusNotifierItem, CMake + Ninja.

**Spec:** `docs/superpowers/specs/2026-09-29-coucou-linux-design.md` (ver a **§0 Emenda**: o alvo de fidelidade é o Swift entregue). Resultados do L0: `linux/docs/L0-findings.md`.

## Global Constraints

- Fidelidade: **o Swift vence o `SPEC.md`**. Os valores abaixo foram copiados de `IslandTypes.swift`, `IslandStateMachine.swift`, `IslandRootView.swift` e `IslandWindowController.swift`: notch 184×32; largura compacta = notch + 160; expandida 640; alturas 160 (upload/uploading/choose 176, mail 240, saudação 150, chat `min(300, 240 + 40·n)`); cantos de baixo 14 (escondida/compacta) e 22 (expandida), cantos de cima retos; FSM `hidden/petit/home/coucou` com `petit→hidden` 60 s, `home→petit` 15 s, saudação 0,6 s (10 s com hover); fechamento auto padrão 15 s; barra de contagem regressiva 160 pt, 2 pt, branco 35 %, nos últimos `min(10, 0,6·auto)` s.
- Abrir: 520 ms, curva `[.32, 1.22, .42, 1]`. Fechar: 340 ms, curva `[.45, 0, .2, 1]`. Trocar de view dentro da expandida usa a curva de abrir.
- Não alterar nada em `NotchBuddy/`. Todo código novo em `linux/`; sons lidos de `NotchBuddy/Resources/sounds` (28 WAVs).
- C++20, Qt ≥ 6.8, só pacotes do Fedora 44. Caminhos derivam de `$HOME` (`coucou::Paths`).
- Build/teste/execução sempre no host: `linux/scripts/host.sh` (o agente roda dentro do Flatpak do VSCodium).
- Escondida = **0 % de CPU** e invisível; a região de entrada da janela é só a faixa do topo (L0 linha 5).
- A ilha **nunca** rouba foco: teclado `None` por padrão, `OnDemand` só depois de um clique nela (L0 linha 3).
- Testes de QML rodam com `QT_QPA_PLATFORM=offscreen` e `QT_QUICK_BACKEND=software` (o helper `coucou_add_test` já define).
- Checagens marcadas com 👤 precisam do João. Commits terminam com o trailer `Co-Authored-By` que o harness da sessão especificar (os exemplos abaixo mostram um).

## Review Focus

1. **Hover que pisca** (o L0 viu `hover exit` + `hover enter` ~100 ms depois no clique que troca o teclado): a ilha não pode abrir/fechar timers por causa disso — testes do `HoverDebouncer` (Task 2) e do controlador (Task 4).
2. **Configuração salva corrompida ou fora da faixa** (volume 5, intervalo −3, `60` do formato antigo, lista de integrações com lixo): nada pode quebrar nem produzir valores absurdos — testes do `AppState` (Task 3).
3. **Detecção de notch devolvendo 0 ou negativo:** a ilha tem que cair no 184×32, nunca ficar com largura 0 — teste `invalidNotchFallsBack` (Task 1).
4. **Timers velhos:** relançar a saudação, ou fechar (`Esc`) com a FSM ainda em `home`, não pode disparar um `close` duplicado nem uma transição atrasada — testes da FSM (Task 2) e `escWhileHomeDoesNotDoubleClose` (Task 4).
5. **Remover a última tarefa com a ilha aberta** (view `overview` ↔ `empty`): a altura não pode mudar nem a ilha recolher sozinha — testes `syncViewFollowsTasks` (Task 3) e `layoutStaysAtHeight160WhenViewSwitchesToEmpty` (Task 4).

---

## File Structure

```
linux/
  CMakeLists.txt                       (modify) find LayerShellQt/KF6, app option, subdirs
  src/core/CMakeLists.txt              (modify) cumulative source list
  src/core/IslandTypes.h/.cpp          enums, ViewLayout table, islandSize(), botPosition()
  src/core/Scheduler.h/.cpp            IScheduler + QtScheduler
  src/core/IslandStateMachine.h/.cpp   port of IslandStateMachine.swift
  src/core/HoverDebouncer.h/.cpp       delays "pointer left" so flapping does not reach the FSM
  src/core/AgentTask.h/.cpp            task struct + the 8 integration pills
  src/core/TaskModel.h/.cpp            QAbstractListModel for QML
  src/core/AppState.h/.cpp             port of AppState.swift (QSettings-backed)
  src/core/IslandController.h/.cpp     port of IslandWindowController wiring + layout for QML
  src/core/SoundNames.h                the 28 sound names
  src/platform/CMakeLists.txt          coucou_platform
  src/platform/SoundEngine.h/.cpp      QSoundEffect pool
  src/platform/IslandWindow.h/.cpp     layer-shell window, input mask, keyboard mode
  src/platform/Tray.h/.cpp             KStatusNotifierItem + debug menu
  src/app/CMakeLists.txt, main.cpp     the `coucou` executable
  qml/Island.qml IslandHeader.qml HeaderTab.qml IconGlyph.qml
  qml/ViewPlaceholder.qml CountdownBar.qml CompactGrid.qml
  resources/fr.louisraille.NotchBuddy.desktop
  tests/CMakeLists.txt                 (modify) coucou_add_test helper
  tests/FakeScheduler.h                manual clock for tests
  tests/tst_island_types.cpp tst_scheduler_fsm.cpp tst_app_state.cpp
  tests/tst_island_controller.cpp tst_sound.cpp tst_sound_engine.cpp tst_island_qml.cpp
  docs/L1a-notes.md                    capture comparison + measurements
```

Comandos usados em todo o plano (rodar da raiz do repositório):
- Configurar/compilar: `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build`
- Testar: `linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`

---

### Task 1: Tipos, geometria e helper de testes

**Files:**
- Create: `linux/src/core/IslandTypes.h`, `linux/src/core/IslandTypes.cpp`, `linux/tests/tst_island_types.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/tests/CMakeLists.txt`

**Interfaces:**
- Produces (namespace `coucou`): enums `IslandMode{Hidden,Compact,Expanded}`, `IslandView{Overview,Empty,Approval,Question,Error,Finished,Confused,Upload,Uploading,Choose,Mail,Prompt,Searching,Result,Note,Settings,Greeting}`, `BotState{Idle,Working,Thinking,Searching,Approval,Question,Error,Finished,Ratelimit,Sleeping,Dizzy}`, `BotEmote{Love,Surprised,Proud,Wink,Yawn,Happy,Annoyed}`, `AgentLayoutMode{None,Grid,Pills,Column}`; `template<class E> QString enumKey(E)` (lowercase-first, ex.: `"overview"`); `template<class E> std::optional<E> enumFromKey(const QString&)`; `IslandConst::{notchWidth,notchHeight,expandedWidth,roundedCorner,expandedCorner,compactExtraWidth}`; `struct ViewLayout{qreal height, botX; std::optional<qreal> botY; qreal botDiameter; AgentLayoutMode agentMode;}`; `const ViewLayout &viewLayout(IslandView)`; `QSizeF islandSize(IslandMode, IslandView, qreal notchW, qreal notchH, int chatCount = 0)`; `qreal islandCornerRadius(IslandMode)`; `struct BotPlacement{qreal cx, cy, diameter, opacity;}`; `BotPlacement botPosition(IslandMode, IslandView, qreal islandH, double uploadProgress)`.
- CMake: função `coucou_add_test(<nome>)` em `tests/CMakeLists.txt`.

- [ ] **Step 1: Trocar o CMake dos testes por um helper e registrar o novo teste**

`linux/tests/CMakeLists.txt` (substituir o conteúdo):
```cmake
# Registers tests/<name>.cpp as an executable and a ctest entry linked against coucou_core.
function(coucou_add_test name)
    qt_add_executable(${name} ${name}.cpp)
    target_link_libraries(${name} PRIVATE coucou_core Qt6::Test)
    target_include_directories(${name} PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME ${name} COMMAND ${name})
    set_tests_properties(${name} PROPERTIES ENVIRONMENT "QT_QPA_PLATFORM=offscreen;QT_QUICK_BACKEND=software")
endfunction()

coucou_add_test(tst_paths)
coucou_add_test(tst_island_types)
```

- [ ] **Step 2: Escrever o teste que falha**

`linux/tests/tst_island_types.cpp`:
```cpp
#include <QtTest>
#include "IslandTypes.h"

using namespace coucou;

class TestIslandTypes : public QObject {
    Q_OBJECT
private slots:
    void layoutTableMatchesSwift() {
        QCOMPARE(viewLayout(IslandView::Overview).height, 160.0);
        QCOMPARE(viewLayout(IslandView::Overview).botX, 68.0);
        QCOMPARE(viewLayout(IslandView::Overview).botDiameter, 58.0);
        QVERIFY(!viewLayout(IslandView::Overview).botY.has_value());
        QCOMPARE(int(viewLayout(IslandView::Overview).agentMode), int(AgentLayoutMode::Pills));
        QCOMPARE(viewLayout(IslandView::Empty).botX, 70.0);
        QCOMPARE(viewLayout(IslandView::Confused).botDiameter, 66.0);
        QCOMPARE(viewLayout(IslandView::Upload).height, 176.0);
        QCOMPARE(*viewLayout(IslandView::Upload).botY, 104.0);
        QCOMPARE(viewLayout(IslandView::Upload).botX, 140.0);
        QCOMPARE(viewLayout(IslandView::Uploading).botDiameter, 20.0);
        QCOMPARE(*viewLayout(IslandView::Uploading).botY, 118.0);
        QCOMPARE(*viewLayout(IslandView::Choose).botY, 101.0);
        QCOMPARE(viewLayout(IslandView::Mail).height, 240.0);
        QCOMPARE(viewLayout(IslandView::Greeting).height, 150.0);
        QCOMPARE(viewLayout(IslandView::Greeting).botX, 320.0);
        QCOMPARE(viewLayout(IslandView::Greeting).botDiameter, 0.0);
    }

    void sizesPerMode() {
        QCOMPARE(islandSize(IslandMode::Hidden, IslandView::Overview, 184, 32), QSizeF(184, 32));
        QCOMPARE(islandSize(IslandMode::Compact, IslandView::Overview, 184, 32), QSizeF(344, 32));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Overview, 184, 32), QSizeF(640, 160));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Upload, 184, 32), QSizeF(640, 176));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Mail, 184, 32), QSizeF(640, 240));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Greeting, 184, 32), QSizeF(640, 150));
        // a wider physical notch widens the compact island too
        QCOMPARE(islandSize(IslandMode::Compact, IslandView::Overview, 200, 38), QSizeF(360, 38));
    }

    void promptHeightGrowsWithChatAndCaps() {
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, 0).height(), 240.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, 1).height(), 280.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, 2).height(), 300.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, 50).height(), 300.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, -3).height(), 240.0);
        // chat count does not affect any other view
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Overview, 184, 32, 9).height(), 160.0);
    }

    void invalidNotchFallsBack() {
        QCOMPARE(islandSize(IslandMode::Hidden, IslandView::Overview, 0, 0), QSizeF(184, 32));
        QCOMPARE(islandSize(IslandMode::Compact, IslandView::Overview, -10, -1), QSizeF(344, 32));
        QCOMPARE(islandSize(IslandMode::Hidden, IslandView::Overview, qQNaN(), 32), QSizeF(184, 32));
    }

    void corners() {
        QCOMPARE(islandCornerRadius(IslandMode::Hidden), 14.0);
        QCOMPARE(islandCornerRadius(IslandMode::Compact), 14.0);
        QCOMPARE(islandCornerRadius(IslandMode::Expanded), 22.0);
    }

    void botPlacements() {
        auto h = botPosition(IslandMode::Hidden, IslandView::Overview, 32, 0);
        QCOMPARE(h.cx, 46.0); QCOMPARE(h.cy, 16.0); QCOMPARE(h.diameter, 6.0); QCOMPARE(h.opacity, 0.0);
        auto c = botPosition(IslandMode::Compact, IslandView::Overview, 32, 0);
        QCOMPARE(c.cx, 40.0); QCOMPARE(c.cy, 16.0); QCOMPARE(c.diameter, 20.0); QCOMPARE(c.opacity, 1.0);
        // expanded, auto-centred on the 84 pt card: 42 + (160 - 42 - 84)/2 + 84/2 = 101
        auto o = botPosition(IslandMode::Expanded, IslandView::Overview, 160, 0);
        QCOMPARE(o.cx, 68.0); QCOMPARE(o.cy, 101.0); QCOMPARE(o.diameter, 58.0); QCOMPARE(o.opacity, 1.0);
        // fixed botY wins
        auto u = botPosition(IslandMode::Expanded, IslandView::Upload, 176, 0);
        QCOMPARE(u.cx, 140.0); QCOMPARE(u.cy, 104.0); QCOMPARE(u.diameter, 62.0);
        // uploading: the dot rides the progress bar (left 36, width 526)
        auto p = botPosition(IslandMode::Expanded, IslandView::Uploading, 176, 0.5);
        QCOMPARE(p.cx, 36 + 0.5 * 526); QCOMPARE(p.cy, 118.0); QCOMPARE(p.diameter, 20.0);
    }

    void enumKeysRoundTrip() {
        QCOMPARE(enumKey(IslandView::Overview), QStringLiteral("overview"));
        QCOMPARE(enumKey(IslandView::Greeting), QStringLiteral("greeting"));
        QCOMPARE(enumKey(BotState::Ratelimit), QStringLiteral("ratelimit"));
        QCOMPARE(enumKey(IslandMode::Expanded), QStringLiteral("expanded"));
        QVERIFY(enumFromKey<IslandView>("approval").value() == IslandView::Approval);
        QVERIFY(enumFromKey<IslandMode>("compact").value() == IslandMode::Compact);
        QVERIFY(!enumFromKey<IslandView>("nope").has_value());
        QVERIFY(!enumFromKey<IslandView>("").has_value());
        for (int v = 0; v <= int(IslandView::Greeting); ++v)
            QVERIFY(enumFromKey<IslandView>(enumKey(IslandView(v))).value() == IslandView(v));
    }
};

QTEST_APPLESS_MAIN(TestIslandTypes)
#include "tst_island_types.moc"
```

- [ ] **Step 3: Registrar as fontes e ver falhar**

`linux/src/core/CMakeLists.txt`:
```cmake
add_library(coucou_core STATIC
    Paths.cpp
    IslandTypes.h IslandTypes.cpp
)
target_include_directories(coucou_core PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(coucou_core PUBLIC Qt6::Core)
```
Run: `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build`
Expected: FAIL — `IslandTypes.h`/`.cpp` não existem.

- [ ] **Step 4: Implementar**

`linux/src/core/IslandTypes.h`:
```cpp
#pragma once
#include <QMetaEnum>
#include <QObject>
#include <QSizeF>
#include <QString>
#include <optional>

namespace coucou {
Q_NAMESPACE

enum class IslandMode { Hidden, Compact, Expanded };
Q_ENUM_NS(IslandMode)

enum class IslandView {
    Overview, Empty, Approval, Question, Error, Finished, Confused, Upload, Uploading,
    Choose, Mail, Prompt, Searching, Result, Note, Settings, Greeting
};
Q_ENUM_NS(IslandView)

enum class BotState { Idle, Working, Thinking, Searching, Approval, Question, Error, Finished, Ratelimit, Sleeping, Dizzy };
Q_ENUM_NS(BotState)

enum class BotEmote { Love, Surprised, Proud, Wink, Yawn, Happy, Annoyed };
Q_ENUM_NS(BotEmote)

enum class AgentLayoutMode { None, Grid, Pills, Column };

// "Overview" -> "overview": the form QML and QSettings use.
template <typename E>
QString enumKey(E e)
{
    QString k = QString::fromLatin1(QMetaEnum::fromType<E>().valueToKey(int(e)));
    if (!k.isEmpty())
        k[0] = k[0].toLower();
    return k;
}

template <typename E>
std::optional<E> enumFromKey(const QString &key)
{
    if (key.isEmpty())
        return std::nullopt;
    QString k = key;
    k[0] = k[0].toUpper();
    bool ok = false;
    const int v = QMetaEnum::fromType<E>().keyToValue(k.toLatin1().constData(), &ok);
    if (!ok)
        return std::nullopt;
    return E(v);
}

namespace IslandConst {
inline constexpr qreal notchWidth = 184;
inline constexpr qreal notchHeight = 32;
inline constexpr qreal expandedWidth = 640;
inline constexpr qreal roundedCorner = 14;   // hidden / compact
inline constexpr qreal expandedCorner = 22;
inline constexpr qreal compactExtraWidth = 160;
} // namespace IslandConst

struct ViewLayout {
    qreal height;
    qreal botX;
    std::optional<qreal> botY;   // nullopt = centred on the card
    qreal botDiameter;
    AgentLayoutMode agentMode;
};

const ViewLayout &viewLayout(IslandView view);

// notchW/notchH <= 0 (or NaN) fall back to the Swift defaults 184x32.
QSizeF islandSize(IslandMode mode, IslandView view, qreal notchW, qreal notchH, int chatCount = 0);
qreal islandCornerRadius(IslandMode mode);

struct BotPlacement {
    qreal cx, cy, diameter, opacity;
};
BotPlacement botPosition(IslandMode mode, IslandView view, qreal islandH, double uploadProgress);

} // namespace coucou
```

`linux/src/core/IslandTypes.cpp`:
```cpp
#include "IslandTypes.h"

#include <algorithm>
#include <iterator>

namespace coucou {

// Same order as enum IslandView. Values copied from IslandConst.viewLayouts in IslandTypes.swift.
static const ViewLayout kLayouts[] = {
    /* Overview  */ {160, 68,  std::nullopt, 58, AgentLayoutMode::Pills},
    /* Empty     */ {160, 70,  std::nullopt, 62, AgentLayoutMode::None},
    /* Approval  */ {160, 62,  std::nullopt, 56, AgentLayoutMode::Column},
    /* Question  */ {160, 62,  std::nullopt, 56, AgentLayoutMode::Column},
    /* Error     */ {160, 62,  std::nullopt, 58, AgentLayoutMode::Column},
    /* Finished  */ {160, 62,  std::nullopt, 58, AgentLayoutMode::Column},
    /* Confused  */ {160, 76,  std::nullopt, 66, AgentLayoutMode::Column},
    /* Upload    */ {176, 140, 104.0,        62, AgentLayoutMode::Column},
    /* Uploading */ {176, 46,  118.0,        20, AgentLayoutMode::None},
    /* Choose    */ {176, 60,  101.0,        52, AgentLayoutMode::Column},
    /* Mail      */ {240, 56,  std::nullopt, 46, AgentLayoutMode::Column},
    /* Prompt    */ {160, 52,  std::nullopt, 44, AgentLayoutMode::Column},
    /* Searching */ {160, 52,  std::nullopt, 44, AgentLayoutMode::Column},
    /* Result    */ {160, 52,  std::nullopt, 44, AgentLayoutMode::Column},
    /* Note      */ {160, 60,  std::nullopt, 50, AgentLayoutMode::Column},
    /* Settings  */ {160, 54,  std::nullopt, 46, AgentLayoutMode::None},
    /* Greeting  */ {150, 320, 90.0,         0,  AgentLayoutMode::None},
};
static_assert(std::size(kLayouts) == int(IslandView::Greeting) + 1, "one layout per IslandView");

const ViewLayout &viewLayout(IslandView view)
{
    return kLayouts[int(view)];
}

QSizeF islandSize(IslandMode mode, IslandView view, qreal nw, qreal nh, int chatCount)
{
    if (!(nw > 0))
        nw = IslandConst::notchWidth;
    if (!(nh > 0))
        nh = IslandConst::notchHeight;
    switch (mode) {
    case IslandMode::Hidden:
        return {nw, nh};
    case IslandMode::Compact:
        return {nw + IslandConst::compactExtraWidth, nh};
    case IslandMode::Expanded: {
        qreal h = viewLayout(view).height;
        if (view == IslandView::Prompt)
            h = std::min<qreal>(300, 240 + std::max(0, chatCount) * 40);
        return {IslandConst::expandedWidth, h};
    }
    }
    return {nw, nh};
}

qreal islandCornerRadius(IslandMode mode)
{
    return mode == IslandMode::Expanded ? IslandConst::expandedCorner : IslandConst::roundedCorner;
}

BotPlacement botPosition(IslandMode mode, IslandView view, qreal islandH, double uploadProgress)
{
    switch (mode) {
    case IslandMode::Hidden:
        return {46, 16, 6, 0};
    case IslandMode::Compact:
        return {40, 16, 20, 1};
    case IslandMode::Expanded: {
        const ViewLayout &l = viewLayout(view);
        if (view == IslandView::Uploading)
            return {36 + uploadProgress * 526, l.botY.value_or(103), l.botDiameter, 1};
        qreal cy;
        if (l.botY) {
            cy = *l.botY;
        } else {
            constexpr qreal headerBottom = 42, cardH = 84;   // VStack top 8 + header 34; fixed 84 pt card
            cy = headerBottom + (islandH - headerBottom - cardH) / 2 + cardH / 2;
        }
        return {l.botX, cy, l.botDiameter, 1};
    }
    }
    return {46, 16, 6, 0};
}

} // namespace coucou
```

- [ ] **Step 5: Rodar e ver passar**

Run:
```sh
linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: `100% tests passed, 0 tests failed out of 2` (tst_paths, tst_island_types), sem warnings.

- [ ] **Step 6: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux: island types, view layouts and geometry ported from Swift

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 2: Agendador, FSM da ilha e debounce do hover

**Files:**
- Create: `linux/src/core/Scheduler.h`, `linux/src/core/Scheduler.cpp`, `linux/src/core/IslandStateMachine.h`, `linux/src/core/IslandStateMachine.cpp`, `linux/src/core/HoverDebouncer.h`, `linux/src/core/HoverDebouncer.cpp`, `linux/tests/FakeScheduler.h`, `linux/tests/tst_scheduler_fsm.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/tests/CMakeLists.txt`

**Interfaces:**
- Consumes: nada da Task 1.
- Produces: `coucou::IScheduler { virtual int singleShot(int ms, std::function<void()>) = 0; virtual void cancel(int id) = 0; }` (ids nunca 0); `coucou::QtScheduler : IScheduler`; `coucou::IslandStateMachine(IScheduler&)` com `enum class State{Hidden,Petit,Home,Coucou}`, `State state() const`, `std::function<void(State,State)> onTransition`, atrasos públicos `homeToPetitDelayMs=15000, petitToHiddenDelayMs=60000, greetAutoCollapseDelayMs=600, greetHoverCollapseDelayMs=10000`, métodos `launch() mouseEntered() mouseLeft() click() greetComplete() reveal() cancelTimers()`; `coucou::HoverDebouncer(IScheduler&, int leaveDelayMs = 120)` com `std::function<void(bool)> onChanged`, `enter()`, `leave()`, `bool inside() const`; `FakeScheduler` (testes): `advance(int ms)`, `int pending() const`.

- [ ] **Step 1: Escrever `FakeScheduler` e o teste que falha**

`linux/tests/FakeScheduler.h`:
```cpp
#pragma once
#include "Scheduler.h"

#include <QtGlobal>
#include <algorithm>
#include <functional>
#include <vector>

// Manual clock: nothing runs until advance() is called.
class FakeScheduler : public coucou::IScheduler {
public:
    int singleShot(int ms, std::function<void()> fn) override
    {
        const int id = ++m_next;
        m_tasks.push_back({id, m_now + ms, std::move(fn)});
        return id;
    }
    void cancel(int id) override
    {
        m_tasks.erase(std::remove_if(m_tasks.begin(), m_tasks.end(), [id](const Task &t) { return t.id == id; }),
                      m_tasks.end());
    }
    void advance(int ms)
    {
        const qint64 target = m_now + ms;
        for (;;) {
            auto it = std::min_element(m_tasks.begin(), m_tasks.end(), [](const Task &a, const Task &b) {
                return a.due != b.due ? a.due < b.due : a.id < b.id;
            });
            if (it == m_tasks.end() || it->due > target)
                break;
            m_now = it->due;
            auto fn = std::move(it->fn);
            m_tasks.erase(it);
            fn();
        }
        m_now = target;
    }
    int pending() const { return int(m_tasks.size()); }
    qint64 now() const { return m_now; }

private:
    struct Task {
        int id;
        qint64 due;
        std::function<void()> fn;
    };
    std::vector<Task> m_tasks;
    qint64 m_now = 0;
    int m_next = 0;
};
```

`linux/tests/tst_scheduler_fsm.cpp`:
```cpp
#include <QtTest>
#include "FakeScheduler.h"
#include <memory>
#include "HoverDebouncer.h"
#include "IslandStateMachine.h"

using coucou::HoverDebouncer;
using coucou::IslandStateMachine;
using S = IslandStateMachine::State;

static QString str(S s)
{
    switch (s) {
    case S::Hidden: return "hidden";
    case S::Petit: return "petit";
    case S::Home: return "home";
    case S::Coucou: return "coucou";
    }
    return "?";
}

class TestFsm : public QObject {
    Q_OBJECT
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandStateMachine> fsm;
    QStringList log;

private slots:
    void init()
    {
        sched = std::make_unique<FakeScheduler>();
        fsm = std::make_unique<IslandStateMachine>(*sched);   // always starts in Hidden
        log.clear();
        fsm->onTransition = [this](S a, S b) { log << str(a) + ">" + str(b); };
    }

    void launchGoesToCoucou()
    {
        fsm->launch();
        QCOMPARE(log, QStringList{"hidden>coucou"});
        QCOMPARE(sched->pending(), 0);
    }

    void hoverFromHiddenPeeksThenHidesAfter60s()
    {
        fsm->mouseEntered();
        QCOMPARE(log, QStringList{"hidden>petit"});
        fsm->mouseLeft();
        sched->advance(59999);
        QVERIFY(fsm->state() == S::Petit);
        sched->advance(1);
        QVERIFY(fsm->state() == S::Hidden);
        QCOMPARE(log, (QStringList{"hidden>petit", "petit>hidden"}));
    }

    void enteringCompactCancelsHideTimer()
    {
        fsm->mouseEntered();
        fsm->mouseLeft();
        sched->advance(30000);
        fsm->mouseEntered();
        sched->advance(120000);
        QVERIFY(fsm->state() == S::Petit);
        QCOMPARE(sched->pending(), 0);
    }

    void clickOnlyWorksFromPetit()
    {
        fsm->click();                       // hidden: ignored
        QVERIFY(fsm->state() == S::Hidden);
        fsm->mouseEntered();                // -> petit
        fsm->click();
        QVERIFY(fsm->state() == S::Home);
        fsm->click();                       // home: ignored
        QCOMPARE(log, (QStringList{"hidden>petit", "petit>home"}));
    }

    void homeCollapsesTo_petitAfter15s_andHoverCancels()
    {
        fsm->mouseEntered();
        fsm->click();
        fsm->mouseLeft();
        sched->advance(14999);
        QVERIFY(fsm->state() == S::Home);
        fsm->mouseEntered();                // cancels the pending collapse
        sched->advance(60000);
        QVERIFY(fsm->state() == S::Home);
        fsm->mouseLeft();
        sched->advance(15000);
        QVERIFY(fsm->state() == S::Petit);
    }

    void greetingCollapsesAfter600msWhenNoHover()
    {
        fsm->launch();
        fsm->greetComplete();
        sched->advance(599);
        QVERIFY(fsm->state() == S::Coucou);
        sched->advance(1);
        QVERIFY(fsm->state() == S::Petit);
    }

    void greetingHoverExtendsTo10sAndGreetCompleteDoesNotOverride()
    {
        fsm->launch();
        fsm->mouseEntered();                // hover while greeting -> 10 s
        fsm->greetComplete();               // must NOT shorten it to 600 ms
        sched->advance(9999);
        QVERIFY(fsm->state() == S::Coucou);
        sched->advance(1);
        QVERIFY(fsm->state() == S::Petit);
    }

    void leavingDuringGreetingInterruptsAtOnce()
    {
        fsm->launch();
        fsm->mouseEntered();
        fsm->mouseLeft();
        QVERIFY(fsm->state() == S::Petit);
        const int transitions = log.size();
        sched->advance(120000);             // the greeting timers were cancelled
        QVERIFY(fsm->state() == S::Petit);
        QCOMPARE(log.size(), transitions);
    }

    void revealFromHiddenShowsCompactAndSchedulesHide()
    {
        fsm->reveal();
        QVERIFY(fsm->state() == S::Petit);
        sched->advance(60000);
        QVERIFY(fsm->state() == S::Hidden);
        fsm->mouseEntered();                // -> petit again
        const int n = log.size();
        fsm->reveal();                      // not hidden: ignored
        QCOMPARE(log.size(), n);
    }

    void relaunchLeavesNoStaleTimers()
    {
        fsm->mouseEntered();
        fsm->mouseLeft();                   // hide timer pending
        QCOMPARE(sched->pending(), 1);
        fsm->launch();
        QCOMPARE(sched->pending(), 0);
        sched->advance(120000);
        QVERIFY(fsm->state() == S::Coucou);
    }
};

class TestHover : public QObject {
    Q_OBJECT
private slots:
    void enterReportsOnce()
    {
        FakeScheduler s;
        HoverDebouncer d(s);
        QList<bool> seen;
        d.onChanged = [&](bool in) { seen << in; };
        d.enter();
        d.enter();
        QCOMPARE(seen, QList<bool>{true});
        QVERIFY(d.inside());
    }
    void leaveIsDelayed()
    {
        FakeScheduler s;
        HoverDebouncer d(s, 120);
        QList<bool> seen;
        d.onChanged = [&](bool in) { seen << in; };
        d.enter();
        d.leave();
        s.advance(119);
        QCOMPARE(seen, QList<bool>{true});
        s.advance(1);
        QCOMPARE(seen, (QList<bool>{true, false}));
        QVERIFY(!d.inside());
    }
    void flappingLeaveThenEnterIsInvisible()
    {
        // The L0 probe saw "hover exit" then "hover enter" ~100 ms later when the keyboard mode flipped.
        FakeScheduler s;
        HoverDebouncer d(s, 120);
        QList<bool> seen;
        d.onChanged = [&](bool in) { seen << in; };
        d.enter();
        d.leave();
        s.advance(97);
        d.enter();
        s.advance(500);
        QCOMPARE(seen, QList<bool>{true});
        QVERIFY(d.inside());
        QCOMPARE(s.pending(), 0);
    }
    void leaveWhileOutsideDoesNothing()
    {
        FakeScheduler s;
        HoverDebouncer d(s);
        QList<bool> seen;
        d.onChanged = [&](bool in) { seen << in; };
        d.leave();
        s.advance(1000);
        QVERIFY(seen.isEmpty());
    }
};

int main(int argc, char **argv)
{
    QCoreApplication app(argc, argv);
    int rc = 0;
    { TestFsm t; rc |= QTest::qExec(&t, argc, argv); }
    { TestHover t; rc |= QTest::qExec(&t, argc, argv); }
    return rc;
}
#include "tst_scheduler_fsm.moc"
```

`linux/tests/CMakeLists.txt` — acrescentar ao fim:
```cmake
coucou_add_test(tst_scheduler_fsm)
```

- [ ] **Step 2: Registrar as fontes (ainda faltam os arquivos) e ver falhar**

`linux/src/core/CMakeLists.txt`:
```cmake
add_library(coucou_core STATIC
    Paths.cpp
    IslandTypes.h IslandTypes.cpp
    Scheduler.h Scheduler.cpp
    IslandStateMachine.h IslandStateMachine.cpp
    HoverDebouncer.h HoverDebouncer.cpp
)
target_include_directories(coucou_core PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(coucou_core PUBLIC Qt6::Core)
```
Run: `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build`
Expected: FAIL — arquivos das fontes não existem.

- [ ] **Step 3: Implementar**

`linux/src/core/Scheduler.h`:
```cpp
#pragma once
#include <functional>
#include <QHash>

class QTimer;

namespace coucou {

// One-shot timers behind an interface so tests can drive time by hand.
class IScheduler {
public:
    virtual ~IScheduler() = default;
    // Runs fn once after ms milliseconds. The returned id (never 0) can be passed to cancel().
    virtual int singleShot(int ms, std::function<void()> fn) = 0;
    virtual void cancel(int id) = 0;
};

class QtScheduler : public IScheduler {
public:
    QtScheduler() = default;
    ~QtScheduler() override;
    int singleShot(int ms, std::function<void()> fn) override;
    void cancel(int id) override;

private:
    QHash<int, QTimer *> m_timers;
    int m_next = 0;
};

} // namespace coucou
```

`linux/src/core/Scheduler.cpp`:
```cpp
#include "Scheduler.h"

#include <QTimer>

namespace coucou {

QtScheduler::~QtScheduler()
{
    qDeleteAll(m_timers);
}

int QtScheduler::singleShot(int ms, std::function<void()> fn)
{
    const int id = ++m_next;
    auto *timer = new QTimer;
    timer->setSingleShot(true);
    m_timers.insert(id, timer);
    QObject::connect(timer, &QTimer::timeout, timer, [this, id, timer, fn = std::move(fn)]() {
        m_timers.remove(id);
        timer->deleteLater();
        fn();
    });
    timer->start(ms);
    return id;
}

void QtScheduler::cancel(int id)
{
    if (QTimer *t = m_timers.take(id)) {
        t->stop();
        t->deleteLater();
    }
}

} // namespace coucou
```

`linux/src/core/IslandStateMachine.h`:
```cpp
#pragma once
#include "Scheduler.h"

#include <functional>

namespace coucou {

// Port of IslandStateMachine.swift. Pure logic: it only talks through onTransition.
class IslandStateMachine {
public:
    enum class State {
        Hidden,   // island invisible (notch size)
        Petit,    // compact island
        Home,     // expanded, overview
        Coucou    // expanded, greeting animation
    };

    explicit IslandStateMachine(IScheduler &scheduler);

    State state() const { return m_state; }
    std::function<void(State, State)> onTransition;   // (from, to)

    int homeToPetitDelayMs = 15000;
    int petitToHiddenDelayMs = 60000;
    int greetAutoCollapseDelayMs = 600;
    int greetHoverCollapseDelayMs = 10000;

    void launch();
    void mouseEntered();
    void mouseLeft();
    void click();
    void greetComplete();
    void reveal();
    void cancelTimers();

private:
    void schedulePetitHide();
    void scheduleHomeCollapse();
    void scheduleGreetCollapse(int delayMs);
    void cancel(int &id);
    void transition(State to);

    IScheduler &m_sched;
    State m_state = State::Hidden;
    int m_petitHide = 0;
    int m_homeCollapse = 0;
    int m_greetCollapse = 0;   // stays non-zero after it fires, exactly like greetCollapseWork in Swift
};

} // namespace coucou
```

`linux/src/core/IslandStateMachine.cpp`:
```cpp
#include "IslandStateMachine.h"

namespace coucou {

IslandStateMachine::IslandStateMachine(IScheduler &scheduler) : m_sched(scheduler) {}

void IslandStateMachine::launch()
{
    cancelTimers();
    transition(State::Coucou);
}

void IslandStateMachine::mouseEntered()
{
    switch (m_state) {
    case State::Hidden:
        cancelTimers();
        transition(State::Petit);
        break;
    case State::Petit:
        cancel(m_petitHide);
        break;
    case State::Home:
        cancel(m_homeCollapse);
        break;
    case State::Coucou:
        // hovering during the greeting: replace the short auto-collapse with the long hover delay
        scheduleGreetCollapse(greetHoverCollapseDelayMs);
        break;
    }
}

void IslandStateMachine::mouseLeft()
{
    switch (m_state) {
    case State::Hidden:
        break;
    case State::Petit:
        schedulePetitHide();
        break;
    case State::Home:
        scheduleHomeCollapse();
        break;
    case State::Coucou:
        cancel(m_greetCollapse);
        transition(State::Petit);
        break;
    }
}

void IslandStateMachine::click()
{
    if (m_state != State::Petit)
        return;
    cancelTimers();
    transition(State::Home);
}

void IslandStateMachine::greetComplete()
{
    if (m_state != State::Coucou)
        return;
    // a longer hover timer already running must not be overridden
    if (m_greetCollapse == 0)
        scheduleGreetCollapse(greetAutoCollapseDelayMs);
}

void IslandStateMachine::reveal()
{
    if (m_state != State::Hidden)
        return;
    cancelTimers();
    transition(State::Petit);
    schedulePetitHide();
}

void IslandStateMachine::cancelTimers()
{
    cancel(m_petitHide);
    cancel(m_homeCollapse);
    cancel(m_greetCollapse);
}

void IslandStateMachine::schedulePetitHide()
{
    cancel(m_petitHide);
    m_petitHide = m_sched.singleShot(petitToHiddenDelayMs, [this] {
        if (m_state == State::Petit)
            transition(State::Hidden);
    });
}

void IslandStateMachine::scheduleHomeCollapse()
{
    cancel(m_homeCollapse);
    m_homeCollapse = m_sched.singleShot(homeToPetitDelayMs, [this] {
        if (m_state == State::Home)
            transition(State::Petit);
    });
}

void IslandStateMachine::scheduleGreetCollapse(int delayMs)
{
    cancel(m_greetCollapse);
    m_greetCollapse = m_sched.singleShot(delayMs, [this] {
        if (m_state == State::Coucou)
            transition(State::Petit);
    });
}

void IslandStateMachine::cancel(int &id)
{
    if (id != 0)
        m_sched.cancel(id);
    id = 0;
}

void IslandStateMachine::transition(State to)
{
    if (to == m_state)
        return;
    const State from = m_state;
    m_state = to;
    if (onTransition)
        onTransition(from, to);
}

} // namespace coucou
```

`linux/src/core/HoverDebouncer.h`:
```cpp
#pragma once
#include "Scheduler.h"

#include <functional>

namespace coucou {

// "Pointer left" is only reported after leaveDelayMs without an "enter" in between, so the
// enter/exit flapping the L0 probe saw (keyboard-mode flips) never reaches the FSM.
class HoverDebouncer {
public:
    explicit HoverDebouncer(IScheduler &scheduler, int leaveDelayMs = 120);

    std::function<void(bool)> onChanged;   // true = entered, false = left
    bool inside() const { return m_inside; }
    void enter();
    void leave();

private:
    IScheduler &m_sched;
    int m_leaveDelayMs;
    bool m_inside = false;
    int m_pendingLeave = 0;
};

} // namespace coucou
```

`linux/src/core/HoverDebouncer.cpp`:
```cpp
#include "HoverDebouncer.h"

namespace coucou {

HoverDebouncer::HoverDebouncer(IScheduler &scheduler, int leaveDelayMs)
    : m_sched(scheduler), m_leaveDelayMs(leaveDelayMs)
{
}

void HoverDebouncer::enter()
{
    if (m_pendingLeave != 0) {
        m_sched.cancel(m_pendingLeave);
        m_pendingLeave = 0;
    }
    if (!m_inside) {
        m_inside = true;
        if (onChanged)
            onChanged(true);
    }
}

void HoverDebouncer::leave()
{
    if (!m_inside || m_pendingLeave != 0)
        return;
    m_pendingLeave = m_sched.singleShot(m_leaveDelayMs, [this] {
        m_pendingLeave = 0;
        m_inside = false;
        if (onChanged)
            onChanged(false);
    });
}

} // namespace coucou
```

- [ ] **Step 4: Rodar e ver passar**

Run:
```sh
linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: `100% tests passed, 0 tests failed out of 3`.

- [ ] **Step 5: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux: scheduler interface, island state machine and hover debouncer

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 3: Tarefas, modelo e `AppState` (com persistência)

**Files:**
- Create: `linux/src/core/AgentTask.h`, `linux/src/core/AgentTask.cpp`, `linux/src/core/TaskModel.h`, `linux/src/core/TaskModel.cpp`, `linux/src/core/AppState.h`, `linux/src/core/AppState.cpp`, `linux/tests/tst_app_state.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/tests/CMakeLists.txt`

**Interfaces:**
- Consumes (Task 1): `IslandMode`, `IslandView`, `BotState`, `enumKey`, `enumFromKey`, `IslandConst`.
- Produces: `struct AgentTask{QString id,name,color; BotState state; int stepIndex; QStringList steps; AgentSource source; bool isIntegration; QString pillBadge; QString sessionCwd;}`, `enum class AgentSource{ClaudeCode,N8n}`, `QList<AgentTask> integrationAgents()`, `QStringList toggleableIntegrationIds()`; `TaskModel : QAbstractListModel` (roles `IdRole=Qt::UserRole+1, NameRole, ColorRole, StateRole, PillBadgeRole, IsIntegrationRole`; `all()`, `indexOf(id)`, `find(id)`, `append(t)`, `removeById(id)`, `update(id, fn)`); `AppState(QSettings*, QObject* = nullptr)` com `mode()/setMode(IslandMode)`, `view()/setView(IslandView)`, `focusId()`, `setFocus(id)`, `addTask/removeTask/updateTask(id, BotState)`, `effectiveState()`, `setStateOverride(std::optional<BotState>)`, `soundEnabled()/setSoundEnabled`, `soundVolume()/setSoundVolume` (0–0,2), `autoCloseInterval()/setAutoCloseInterval` (s), `isPinned()/setPinned`, `chatCount()/setChatCount`, `uploadProgress()/setUploadProgress`, `lastActivityMs()/setLastActivityMs`, `notchWidth()/notchHeight()/setNotchSize(w,h)`, `isPresent()/setPresent`, `activeIntegrations()`, `toggleIntegration(id)`, `syncMode()`, `syncView()`, `compactOthers()`, `tasksModel()`; sinais `modeChanged viewChanged focusChanged soundEnabledChanged soundVolumeChanged autoCloseIntervalChanged pinnedChanged chatCountChanged uploadProgressChanged lastActivityChanged notchChanged effectiveStateChanged compactOthersChanged`; propriedades QML `modeName viewName(WRITE) focusId soundEnabled(WRITE) soundVolume autoCloseInterval isPinned chatCount uploadProgress lastActivityMs effectiveStateName compactOthers tasks`.

- [ ] **Step 1: Escrever o teste que falha**

`linux/tests/tst_app_state.cpp`:
```cpp
#include <QtTest>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "AppState.h"

using namespace coucou;

class TestAppState : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    QString iniPath() const { return dir.path() + "/coucou.ini"; }
    std::unique_ptr<QSettings> settings() const { return std::make_unique<QSettings>(iniPath(), QSettings::IniFormat); }

private slots:
    void init() { QFile::remove(iniPath()); }

    void startsCompactWithClaudePlusDefaultIntegrations()
    {
        auto s = settings();
        AppState st(s.get());
        QVERIFY(st.mode() == IslandMode::Compact);   // tasks non-empty + present -> syncMode() at init
        QVERIFY(st.view() == IslandView::Overview);
        QCOMPARE(st.focusId(), QStringLiteral("integration_claude"));
        QCOMPARE(st.tasksModel()->rowCount(), 5);    // claude + resend, n8n, vercel, github
        QCOMPARE(st.notchWidth(), 184.0);
        QCOMPARE(st.notchHeight(), 32.0);
        QCOMPARE(st.autoCloseInterval(), 15.0);
        QCOMPARE(st.soundVolume(), 0.12);
        QVERIFY(st.soundEnabled());
        QVERIFY(!st.isPinned());
    }

    void integrationPillsHaveSwiftNamesAndColors()
    {
        const auto pills = integrationAgents();
        QCOMPARE(pills.size(), 8);
        QCOMPARE(pills[0].id, QStringLiteral("integration_claude"));
        QCOMPARE(pills[0].name, QStringLiteral("VS Code"));
        QCOMPARE(pills[0].color, QStringLiteral("#F5F6F8"));
        QVERIFY(pills[0].source == AgentSource::ClaudeCode);
        QCOMPARE(pills[7].id, QStringLiteral("integration_stripe"));
        QCOMPARE(pills[7].color, QStringLiteral("#0570DE"));
        QCOMPARE(toggleableIntegrationIds().size(), 7);
        QVERIFY(!toggleableIntegrationIds().contains("integration_claude"));
    }

    void toggleIntegrationRespectsMaxFourAndClaudeIsFixed()
    {
        auto s = settings();
        AppState st(s.get());
        st.toggleIntegration("integration_claude");            // cannot be toggled
        QCOMPARE(st.tasksModel()->rowCount(), 5);
        st.toggleIntegration("integration_notion");            // 4 already active -> refused
        QCOMPARE(st.tasksModel()->rowCount(), 5);
        st.setFocus("integration_github");
        st.toggleIntegration("integration_github");            // turn one off
        QCOMPARE(st.tasksModel()->rowCount(), 4);
        QCOMPARE(st.focusId(), QStringLiteral("integration_claude"));   // focus falls back to Claude
        st.toggleIntegration("integration_notion");            // now there is room
        QCOMPARE(st.tasksModel()->rowCount(), 5);
        QVERIFY(st.activeIntegrations().contains("integration_notion"));
        st.toggleIntegration("integration_bogus");             // unknown id ignored
        QCOMPARE(st.tasksModel()->rowCount(), 5);
    }

    void settingsPersistAcrossInstances()
    {
        {
            auto s = settings();
            AppState st(s.get());
            st.setSoundEnabled(false);
            st.setSoundVolume(0.05);
            st.setAutoCloseInterval(30);
            st.toggleIntegration("integration_github");
            st.toggleIntegration("integration_stripe");
        }
        auto s = settings();
        AppState st(s.get());
        QVERIFY(!st.soundEnabled());
        QCOMPARE(st.soundVolume(), 0.05);
        QCOMPARE(st.autoCloseInterval(), 30.0);
        QVERIFY(!st.activeIntegrations().contains("integration_github"));
        QVERIFY(st.activeIntegrations().contains("integration_stripe"));
    }

    void corruptOrOutOfRangeSettingsAreSanitised()
    {
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("soundVolume", 5.0);
            raw.setValue("autoCloseInterval", -3.0);
            raw.setValue("activeIntegrations", "garbage");
            raw.sync();
        }
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.soundVolume(), 0.2);                       // clamped
            QCOMPARE(st.autoCloseInterval(), 15.0);                // invalid -> default
            QCOMPARE(st.tasksModel()->rowCount(), 5);              // no valid id -> defaults
        }
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("soundVolume", -1.0);
            raw.setValue("autoCloseInterval", 60.0);               // old Swift default migrates to 15
            raw.setValue("activeIntegrations", "integration_notion;integration_bogus;integration_notion");
            raw.sync();
        }
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.soundVolume(), 0.0);
            QCOMPARE(st.autoCloseInterval(), 15.0);
            QCOMPARE(st.activeIntegrations(), QStringList{"integration_notion"});   // unknown dropped, duplicate dropped
            QCOMPARE(st.tasksModel()->rowCount(), 2);              // claude + notion
        }
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("activeIntegrations", QString());         // user turned every pill off
            raw.sync();
        }
        {
            auto s = settings();
            AppState st(s.get());
            QVERIFY(st.activeIntegrations().isEmpty());
            QCOMPARE(st.tasksModel()->rowCount(), 1);              // only Claude
        }
    }

    void syncModeFollowsTasks()
    {
        auto s = settings();
        AppState st(s.get());
        for (const auto &t : integrationAgents())
            st.removeTask(t.id);
        QCOMPARE(st.tasksModel()->rowCount(), 0);
        QVERIFY(st.mode() == IslandMode::Hidden);                  // compact + no tasks -> hidden
        AgentTask t = integrationAgents().first();
        st.addTask(t);
        QVERIFY(st.mode() == IslandMode::Compact);                 // hidden + task + present -> compact
        QCOMPARE(st.focusId(), t.id);
    }

    void syncViewFollowsTasks()
    {
        auto s = settings();
        AppState st(s.get());
        st.setMode(IslandMode::Expanded);
        st.setView(IslandView::Overview);
        for (const auto &t : integrationAgents())
            st.removeTask(t.id);
        QVERIFY(st.view() == IslandView::Empty);                   // overview + no tasks -> empty
        QVERIFY(st.mode() == IslandMode::Expanded);                // and the island stays open
        st.addTask(integrationAgents().first());
        QVERIFY(st.view() == IslandView::Overview);
    }

    void effectiveStatePrecedence()
    {
        auto s = settings();
        AppState st(s.get());
        QVERIFY(st.effectiveState() == BotState::Idle);
        st.updateTask("integration_claude", BotState::Working);
        QVERIFY(st.effectiveState() == BotState::Working);
        st.setStateOverride(BotState::Dizzy);
        QVERIFY(st.effectiveState() == BotState::Dizzy);
        QCOMPARE(st.effectiveStateName(), QStringLiteral("dizzy"));
        st.setStateOverride(std::nullopt);
        QVERIFY(st.effectiveState() == BotState::Working);
    }

    void compactOthersExcludesFocusAndCapsAtFour()
    {
        auto s = settings();
        AppState st(s.get());
        QCOMPARE(st.compactOthers().size(), 4);
        QCOMPARE(st.compactOthers().first().toMap().value("id").toString(), QStringLiteral("integration_resend"));
        st.setFocus("integration_resend");
        const auto others = st.compactOthers();
        QCOMPARE(others.size(), 4);
        QCOMPARE(others.first().toMap().value("id").toString(), QStringLiteral("integration_claude"));
    }

    void modeAndViewSetters()
    {
        auto s = settings();
        AppState st(s.get());
        QSignalSpy modeSpy(&st, &AppState::modeChanged);
        QSignalSpy viewSpy(&st, &AppState::viewChanged);
        st.setMode(IslandMode::Compact);                            // already compact: no signal
        QCOMPARE(modeSpy.count(), 0);
        st.setMode(IslandMode::Expanded);
        QCOMPARE(modeSpy.count(), 1);
        QCOMPARE(st.modeName(), QStringLiteral("expanded"));
        st.setViewName("approval");
        QCOMPARE(viewSpy.count(), 1);
        QVERIFY(st.view() == IslandView::Approval);
        st.setViewName("nonsense");                                 // ignored
        QVERIFY(st.view() == IslandView::Approval);
        QCOMPARE(viewSpy.count(), 1);
    }

    void effectiveStateFollowsFocus()
    {
        auto s = settings();
        AppState st(s.get());
        st.updateTask("integration_github", BotState::Error);
        QVERIFY(st.effectiveState() == BotState::Idle);            // focus is still Claude
        st.setFocus("integration_github");
        QVERIFY(st.effectiveState() == BotState::Error);
    }
};

QTEST_APPLESS_MAIN(TestAppState)
#include "tst_app_state.moc"
```
Acrescentar em `linux/tests/CMakeLists.txt`: `coucou_add_test(tst_app_state)`.

- [ ] **Step 2: Registrar as fontes e ver falhar**

`linux/src/core/CMakeLists.txt`:
```cmake
add_library(coucou_core STATIC
    Paths.cpp
    IslandTypes.h IslandTypes.cpp
    Scheduler.h Scheduler.cpp
    IslandStateMachine.h IslandStateMachine.cpp
    HoverDebouncer.h HoverDebouncer.cpp
    AgentTask.h AgentTask.cpp
    TaskModel.h TaskModel.cpp
    AppState.h AppState.cpp
)
target_include_directories(coucou_core PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(coucou_core PUBLIC Qt6::Core)
```
Run: `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build`
Expected: FAIL — arquivos novos não existem.

- [ ] **Step 3: Implementar `AgentTask` e `TaskModel`**

`linux/src/core/AgentTask.h`:
```cpp
#pragma once
#include "IslandTypes.h"

#include <QList>
#include <QString>
#include <QStringList>

namespace coucou {

enum class AgentSource { ClaudeCode, N8n };

struct AgentTask {
    QString id;
    QString name;
    QString color;   // "#RRGGBB"
    BotState state = BotState::Idle;
    int stepIndex = 0;
    QStringList steps;
    AgentSource source = AgentSource::ClaudeCode;
    bool isIntegration = false;
    QString pillBadge;   // "", "approval", "finished" or "error"
    QString sessionCwd;
};

// The 8 permanent integration pills, Claude first (AgentTask.integrationAgents in AppState.swift).
QList<AgentTask> integrationAgents();
// Everything except Claude.
QStringList toggleableIntegrationIds();

} // namespace coucou
```

`linux/src/core/AgentTask.cpp`:
```cpp
#include "AgentTask.h"

namespace coucou {

static AgentTask pill(const char *id, const char *name, const char *color, AgentSource src)
{
    AgentTask t;
    t.id = QString::fromLatin1(id);
    t.name = QString::fromUtf8(name);
    t.color = QString::fromLatin1(color);
    t.source = src;
    t.isIntegration = true;
    return t;
}

QList<AgentTask> integrationAgents()
{
    return {
        pill("integration_claude", "VS Code", "#F5F6F8", AgentSource::ClaudeCode),
        pill("integration_resend", "Resend", "#22C55E", AgentSource::N8n),
        pill("integration_n8n", "n8n", "#F29B38", AgentSource::N8n),
        pill("integration_vercel", "Vercel", "#7C5CFF", AgentSource::N8n),
        pill("integration_github", "GitHub", "#F4505E", AgentSource::N8n),
        pill("integration_notion", "Notion", "#8C8C8C", AgentSource::N8n),
        pill("integration_calcom", "Cal.com", "#C9956A", AgentSource::N8n),
        pill("integration_stripe", "Stripe", "#0570DE", AgentSource::N8n),
    };
}

QStringList toggleableIntegrationIds()
{
    return {"integration_resend", "integration_n8n", "integration_vercel", "integration_github",
            "integration_notion", "integration_calcom", "integration_stripe"};
}

} // namespace coucou
```

`linux/src/core/TaskModel.h`:
```cpp
#pragma once
#include "AgentTask.h"

#include <QAbstractListModel>
#include <functional>

namespace coucou {

class TaskModel : public QAbstractListModel {
    Q_OBJECT
public:
    enum Role { IdRole = Qt::UserRole + 1, NameRole, ColorRole, StateRole, PillBadgeRole, IsIntegrationRole };

    explicit TaskModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    const QList<AgentTask> &all() const { return m_tasks; }
    int indexOf(const QString &id) const;
    const AgentTask *find(const QString &id) const;
    void append(const AgentTask &task);
    bool removeById(const QString &id);
    bool update(const QString &id, const std::function<void(AgentTask &)> &fn);

private:
    QList<AgentTask> m_tasks;
};

} // namespace coucou
```

`linux/src/core/TaskModel.cpp`:
```cpp
#include "TaskModel.h"

namespace coucou {

TaskModel::TaskModel(QObject *parent) : QAbstractListModel(parent) {}

int TaskModel::rowCount(const QModelIndex &parent) const
{
    return parent.isValid() ? 0 : int(m_tasks.size());
}

QVariant TaskModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() < 0 || index.row() >= m_tasks.size())
        return {};
    const AgentTask &t = m_tasks.at(index.row());
    switch (role) {
    case IdRole: return t.id;
    case NameRole: return t.name;
    case ColorRole: return t.color;
    case StateRole: return enumKey(t.state);
    case PillBadgeRole: return t.pillBadge;
    case IsIntegrationRole: return t.isIntegration;
    }
    return {};
}

QHash<int, QByteArray> TaskModel::roleNames() const
{
    return {{IdRole, "taskId"}, {NameRole, "name"}, {ColorRole, "color"},
            {StateRole, "state"}, {PillBadgeRole, "pillBadge"}, {IsIntegrationRole, "isIntegration"}};
}

int TaskModel::indexOf(const QString &id) const
{
    for (int i = 0; i < m_tasks.size(); ++i)
        if (m_tasks.at(i).id == id)
            return i;
    return -1;
}

const AgentTask *TaskModel::find(const QString &id) const
{
    const int i = indexOf(id);
    return i < 0 ? nullptr : &m_tasks.at(i);
}

void TaskModel::append(const AgentTask &task)
{
    beginInsertRows({}, int(m_tasks.size()), int(m_tasks.size()));
    m_tasks.append(task);
    endInsertRows();
}

bool TaskModel::removeById(const QString &id)
{
    const int i = indexOf(id);
    if (i < 0)
        return false;
    beginRemoveRows({}, i, i);
    m_tasks.removeAt(i);
    endRemoveRows();
    return true;
}

bool TaskModel::update(const QString &id, const std::function<void(AgentTask &)> &fn)
{
    const int i = indexOf(id);
    if (i < 0)
        return false;
    fn(m_tasks[i]);
    emit dataChanged(index(i), index(i));
    return true;
}

} // namespace coucou
```

- [ ] **Step 4: Implementar `AppState`**

`linux/src/core/AppState.h`:
```cpp
#pragma once
#include "AgentTask.h"
#include "IslandTypes.h"
#include "TaskModel.h"

#include <QAbstractItemModel>
#include <QObject>
#include <QVariantList>
#include <optional>

class QSettings;

namespace coucou {

// Port of AppState.swift (the parts the island shell needs). Persisted through QSettings.
class AppState : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString modeName READ modeName NOTIFY modeChanged)
    Q_PROPERTY(QString viewName READ viewName WRITE setViewName NOTIFY viewChanged)
    Q_PROPERTY(QString focusId READ focusId NOTIFY focusChanged)
    Q_PROPERTY(bool soundEnabled READ soundEnabled WRITE setSoundEnabled NOTIFY soundEnabledChanged)
    Q_PROPERTY(double soundVolume READ soundVolume WRITE setSoundVolume NOTIFY soundVolumeChanged)
    Q_PROPERTY(double autoCloseInterval READ autoCloseInterval WRITE setAutoCloseInterval NOTIFY autoCloseIntervalChanged)
    Q_PROPERTY(bool isPinned READ isPinned WRITE setPinned NOTIFY pinnedChanged)
    Q_PROPERTY(int chatCount READ chatCount WRITE setChatCount NOTIFY chatCountChanged)
    Q_PROPERTY(double uploadProgress READ uploadProgress WRITE setUploadProgress NOTIFY uploadProgressChanged)
    Q_PROPERTY(qint64 lastActivityMs READ lastActivityMs WRITE setLastActivityMs NOTIFY lastActivityChanged)
    Q_PROPERTY(QString effectiveStateName READ effectiveStateName NOTIFY effectiveStateChanged)
    Q_PROPERTY(QVariantList compactOthers READ compactOthers NOTIFY compactOthersChanged)
    Q_PROPERTY(QAbstractItemModel *tasks READ tasksModel CONSTANT)

public:
    explicit AppState(QSettings *settings, QObject *parent = nullptr);

    IslandMode mode() const { return m_mode; }
    QString modeName() const { return enumKey(m_mode); }
    void setMode(IslandMode m);

    IslandView view() const { return m_view; }
    QString viewName() const { return enumKey(m_view); }
    void setView(IslandView v);
    void setViewName(const QString &name);

    QString focusId() const { return m_focusId; }
    void setFocus(const QString &id);

    QAbstractItemModel *tasksModel() const { return m_tasks; }
    TaskModel *taskModel() const { return m_tasks; }
    void addTask(const AgentTask &task);
    void removeTask(const QString &id);
    void updateTask(const QString &id, BotState state);
    BotState effectiveState() const;
    QString effectiveStateName() const { return enumKey(effectiveState()); }
    void setStateOverride(std::optional<BotState> s);

    bool soundEnabled() const { return m_soundEnabled; }
    void setSoundEnabled(bool on);
    double soundVolume() const { return m_soundVolume; }
    void setSoundVolume(double v);           // clamped to 0..0.2
    double autoCloseInterval() const { return m_autoClose; }
    void setAutoCloseInterval(double seconds);
    bool isPinned() const { return m_pinned; }
    void setPinned(bool on);
    int chatCount() const { return m_chatCount; }
    void setChatCount(int n);
    double uploadProgress() const { return m_uploadProgress; }
    void setUploadProgress(double p);
    qint64 lastActivityMs() const { return m_lastActivityMs; }
    void setLastActivityMs(qint64 ms);

    qreal notchWidth() const { return m_notchW; }
    qreal notchHeight() const { return m_notchH; }
    void setNotchSize(qreal w, qreal h);
    bool isPresent() const { return m_present; }
    void setPresent(bool on);

    QStringList activeIntegrations() const { return m_activeIntegrations; }
    Q_INVOKABLE void toggleIntegration(const QString &id);
    void loadIntegrationTasks();
    void syncMode();
    void syncView();
    QVariantList compactOthers() const;

signals:
    void modeChanged();
    void viewChanged();
    void focusChanged();
    void soundEnabledChanged();
    void soundVolumeChanged();
    void autoCloseIntervalChanged();
    void pinnedChanged();
    void chatCountChanged();
    void uploadProgressChanged();
    void lastActivityChanged();
    void notchChanged();
    void effectiveStateChanged();
    void compactOthersChanged();

private:
    void setFocusInternal(const QString &id);
    void load();
    void persist();

    QSettings *m_settings;
    TaskModel *m_tasks;
    IslandMode m_mode = IslandMode::Hidden;
    IslandView m_view = IslandView::Overview;
    QString m_focusId;
    std::optional<BotState> m_stateOverride;
    bool m_soundEnabled = true;
    double m_soundVolume = 0.12;
    double m_autoClose = 15;
    bool m_pinned = false;
    int m_chatCount = 0;
    double m_uploadProgress = 0;
    qint64 m_lastActivityMs = 0;
    qreal m_notchW = IslandConst::notchWidth;
    qreal m_notchH = IslandConst::notchHeight;
    bool m_present = true;
    QStringList m_activeIntegrations;
};

} // namespace coucou
```

`linux/src/core/AppState.cpp`:
```cpp
#include "AppState.h"

#include <QSettings>
#include <algorithm>

namespace coucou {

namespace {
constexpr double kMaxVolume = 0.2;
constexpr double kDefaultAutoClose = 15;
const QString kClaudeId = QStringLiteral("integration_claude");
const QStringList kDefaultIntegrations = {"integration_resend", "integration_n8n", "integration_vercel", "integration_github"};
} // namespace

AppState::AppState(QSettings *settings, QObject *parent)
    : QObject(parent), m_settings(settings), m_tasks(new TaskModel(this)), m_activeIntegrations(kDefaultIntegrations)
{
    if (m_settings)
        load();
    loadIntegrationTasks();   // also runs syncMode(): hidden + tasks + present -> compact, like Swift's init
}

void AppState::load()
{
    m_soundEnabled = m_settings->value("soundEnabled", true).toBool();
    m_soundVolume = std::clamp(m_settings->value("soundVolume", 0.12).toDouble(), 0.0, kMaxVolume);

    double ac = m_settings->value("autoCloseInterval", kDefaultAutoClose).toDouble();
    if (ac == 60 || !(ac > 0))          // 60 s was the old default; invalid values fall back too
        ac = kDefaultAutoClose;
    m_autoClose = ac;

    if (m_settings->contains("activeIntegrations")) {
        const QString raw = m_settings->value("activeIntegrations").toString();
        if (raw.isEmpty()) {
            m_activeIntegrations.clear();                        // user turned every pill off
        } else {
            QStringList ids;
            for (const QString &id : raw.split(';', Qt::SkipEmptyParts))
                if (toggleableIntegrationIds().contains(id) && !ids.contains(id))
                    ids << id;
            if (!ids.isEmpty())                                  // nothing valid -> keep the defaults
                m_activeIntegrations = ids;
        }
    }
}

void AppState::persist()
{
    if (!m_settings)
        return;
    m_settings->setValue("soundEnabled", m_soundEnabled);
    m_settings->setValue("soundVolume", m_soundVolume);
    m_settings->setValue("autoCloseInterval", m_autoClose);
    m_settings->setValue("activeIntegrations", m_activeIntegrations.join(';'));
    m_settings->sync();
}

void AppState::setMode(IslandMode m)
{
    if (m == m_mode)
        return;
    m_mode = m;
    emit modeChanged();
}

void AppState::setView(IslandView v)
{
    if (v == m_view)
        return;
    m_view = v;
    emit viewChanged();
}

void AppState::setViewName(const QString &name)
{
    if (auto v = enumFromKey<IslandView>(name))
        setView(*v);
}

void AppState::setFocusInternal(const QString &id)
{
    if (id == m_focusId)
        return;
    m_focusId = id;
    emit focusChanged();
    emit effectiveStateChanged();
    emit compactOthersChanged();
}

void AppState::setFocus(const QString &id)
{
    if (!m_tasks->find(id))
        return;
    m_tasks->update(id, [](AgentTask &t) { t.pillBadge.clear(); });   // bringing a task to focus clears its badge
    setFocusInternal(id);
}

void AppState::addTask(const AgentTask &task)
{
    if (m_tasks->find(task.id))
        return;
    m_tasks->append(task);
    if (m_focusId.isEmpty())
        setFocusInternal(task.id);
    emit compactOthersChanged();
    syncMode();
    syncView();
}

void AppState::removeTask(const QString &id)
{
    if (!m_tasks->removeById(id))
        return;
    if (m_focusId == id)
        setFocusInternal(m_tasks->all().isEmpty() ? QString() : m_tasks->all().first().id);
    emit compactOthersChanged();
    syncMode();
    syncView();
}

void AppState::updateTask(const QString &id, BotState state)
{
    if (m_tasks->update(id, [state](AgentTask &t) { t.state = state; })) {
        emit effectiveStateChanged();
        emit compactOthersChanged();
    }
}

BotState AppState::effectiveState() const
{
    if (m_stateOverride)
        return *m_stateOverride;
    if (const AgentTask *t = m_tasks->find(m_focusId))
        return t->state;
    return m_tasks->all().isEmpty() ? BotState::Idle : m_tasks->all().first().state;
}

void AppState::setStateOverride(std::optional<BotState> s)
{
    m_stateOverride = s;
    emit effectiveStateChanged();
}

void AppState::setSoundEnabled(bool on)
{
    if (on == m_soundEnabled)
        return;
    m_soundEnabled = on;
    persist();
    emit soundEnabledChanged();
}

void AppState::setSoundVolume(double v)
{
    v = std::clamp(v, 0.0, kMaxVolume);
    if (v == m_soundVolume)
        return;
    m_soundVolume = v;
    persist();
    emit soundVolumeChanged();
}

void AppState::setAutoCloseInterval(double seconds)
{
    if (!(seconds > 0) || seconds == m_autoClose)
        return;
    m_autoClose = seconds;
    persist();
    emit autoCloseIntervalChanged();
}

void AppState::setPinned(bool on)
{
    if (on == m_pinned)
        return;
    m_pinned = on;
    emit pinnedChanged();
}

void AppState::setChatCount(int n)
{
    n = std::max(0, n);
    if (n == m_chatCount)
        return;
    m_chatCount = n;
    emit chatCountChanged();
}

void AppState::setUploadProgress(double p)
{
    p = std::clamp(p, 0.0, 1.0);
    if (p == m_uploadProgress)
        return;
    m_uploadProgress = p;
    emit uploadProgressChanged();
}

void AppState::setLastActivityMs(qint64 ms)
{
    m_lastActivityMs = ms;
    emit lastActivityChanged();
}

void AppState::setNotchSize(qreal w, qreal h)
{
    if (!(w > 0))
        w = IslandConst::notchWidth;
    if (!(h > 0))
        h = IslandConst::notchHeight;
    if (w == m_notchW && h == m_notchH)
        return;
    m_notchW = w;
    m_notchH = h;
    emit notchChanged();
}

void AppState::setPresent(bool on)
{
    m_present = on;
    syncMode();
}

void AppState::toggleIntegration(const QString &id)
{
    if (id == kClaudeId || !toggleableIntegrationIds().contains(id))
        return;
    if (m_activeIntegrations.contains(id)) {
        m_activeIntegrations.removeAll(id);
        m_tasks->removeById(id);
        if (m_focusId == id)
            setFocusInternal(kClaudeId);
    } else {
        if (m_activeIntegrations.size() >= 4)      // max 4 active pills, like Swift
            return;
        m_activeIntegrations << id;
        if (!m_tasks->find(id))
            for (const AgentTask &t : integrationAgents())
                if (t.id == id)
                    m_tasks->append(t);
    }
    persist();
    emit compactOthersChanged();
    syncMode();
}

void AppState::loadIntegrationTasks()
{
    for (const AgentTask &t : integrationAgents()) {
        const bool shouldLoad = t.id == kClaudeId || m_activeIntegrations.contains(t.id);
        const bool loaded = m_tasks->find(t.id) != nullptr;
        if (shouldLoad && !loaded)
            m_tasks->append(t);
        if (!shouldLoad && loaded)
            m_tasks->removeById(t.id);
    }
    if (m_focusId.isEmpty())
        setFocusInternal(kClaudeId);
    emit compactOthersChanged();
    syncMode();
}

void AppState::syncMode()
{
    const bool empty = m_tasks->all().isEmpty();
    if (empty && m_mode == IslandMode::Compact)
        setMode(IslandMode::Hidden);
    else if (!empty && m_mode == IslandMode::Hidden && m_present)
        setMode(IslandMode::Compact);
}

void AppState::syncView()
{
    if (m_mode != IslandMode::Expanded)
        return;
    const bool empty = m_tasks->all().isEmpty();
    if (m_view == IslandView::Empty && !empty)
        setView(IslandView::Overview);
    else if (m_view == IslandView::Overview && empty)
        setView(IslandView::Empty);
}

QVariantList AppState::compactOthers() const
{
    QVariantList out;
    for (const AgentTask &t : m_tasks->all()) {
        if (t.id == m_focusId)
            continue;
        out.append(QVariantMap{{"id", t.id}, {"color", t.color}, {"state", enumKey(t.state)}});
        if (out.size() == 4)
            break;
    }
    return out;
}

} // namespace coucou
```

- [ ] **Step 5: Rodar e ver passar**

Run:
```sh
linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: `100% tests passed, 0 tests failed out of 4`.

- [ ] **Step 6: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux: AppState, task model and integration pills ported from Swift

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 4: `IslandController` (fiação da ilha + layout para o QML)

**Files:**
- Create: `linux/src/core/IslandController.h`, `linux/src/core/IslandController.cpp`, `linux/tests/tst_island_controller.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/tests/CMakeLists.txt`

**Interfaces:**
- Consumes: `AppState` (Task 3), `IslandStateMachine`/`HoverDebouncer`/`IScheduler` (Task 2), `islandSize`/`islandCornerRadius`/`botPosition`/`IslandView`/`enumFromKey` (Task 1), `FakeScheduler` (testes).
- Produces: `coucou::IslandController(AppState*, IScheduler*, NowFn now, QObject* = nullptr)` com `using NowFn = std::function<qint64()>`; propriedades QML `islandWidth islandHeight cornerRadius shrinking botX botY botDiameter botOpacity` (todas `NOTIFY layoutChanged`); slots/invokáveis `setPointerInside(bool)`, `islandClicked()`, `escapePressed()`, `greetComplete()`, `requestKeyboard(bool)`, `showView(QString)`, `collapse()`, `launch()`, `reveal()`, `resetActivity()`, `expandTo(QString)`; C++: `expand(IslandView)`, `setMode(IslandMode)`, `pointerEntered()`, `pointerLeft()`, `defaultView()`, `fsm()`, `wasInIsland()`; sinais `layoutChanged() playSound(QString) greetingInterrupt() greetingHover() keyboardOnDemandChanged(bool)`.

Regras portadas de `IslandWindowController.swift` (`wireFSM`, `setMode`, `expand`, `collapse`, `pollFrame`):
- `Hidden`→ `setMode(Hidden)`. `Petit`: se veio de `Coucou` emite `greetingInterrupt`, se veio de `Hidden` toca `peek`; `setMode(Compact)`; se veio de `Coucou`, `view = defaultView()`; se `!wasInIsland`, chama `fsm.mouseLeft()`. `Home`: `expand(defaultView())`; se `!wasInIsland`, `fsm.mouseLeft()`. `Coucou`: `expand(Greeting)`.
- `setMode`: nada se igual; toca `open` ao entrar em `Expanded`; ao sair de `Expanded` toca `close` e solta o `pinned`.
- `expand(v)`: `view = v`; se não está expandida, `setMode(Expanded)`; `lastActivity = now`.
- `collapse()`: `pinned = false`; se a FSM está em `Home`, `fsm.mouseLeft()`; `setMode(Compact)`; emite `keyboardOnDemandChanged(false)`.
- Ponteiro: só reporta a entrada se `!wasInIsland` e a saída se `wasInIsland`; `wasInIsland` só é atualizado **depois** de chamar a FSM (o callback vê o valor antigo, como no Swift).

- [ ] **Step 1: Escrever o teste que falha**

`linux/tests/tst_island_controller.cpp`:
```cpp
#include <QtTest>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "AppState.h"
#include "FakeScheduler.h"
#include "IslandController.h"

using namespace coucou;
using S = IslandStateMachine::State;

class TestController : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandController> ctl;
    std::unique_ptr<QSignalSpy> sounds;
    qint64 nowMs = 1000;

    QStringList soundList() const
    {
        QStringList out;
        for (const auto &args : *sounds)
            out << args.at(0).toString();
        return out;
    }
    int count(const QString &name) const { return soundList().count(name); }

private slots:
    void init()
    {
        QFile::remove(dir.path() + "/c.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/c.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        sched = std::make_unique<FakeScheduler>();
        nowMs = 1000;
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [this] { return nowMs; });
        sounds = std::make_unique<QSignalSpy>(ctl.get(), &IslandController::playSound);
    }

    void initialLayoutIsCompact()
    {
        QCOMPARE(ctl->islandWidth(), 344.0);
        QCOMPARE(ctl->islandHeight(), 32.0);
        QCOMPARE(ctl->cornerRadius(), 14.0);
        QVERIFY(!ctl->shrinking());
        QCOMPARE(ctl->botX(), 40.0);
        QCOMPARE(ctl->botY(), 16.0);
        QCOMPARE(ctl->botDiameter(), 20.0);
        QCOMPARE(ctl->botOpacity(), 1.0);
    }

    void launchOpensGreetingThenCollapsesToCompactAndHides()
    {
        QSignalSpy interrupt(ctl.get(), &IslandController::greetingInterrupt);
        ctl->launch();
        QVERIFY(ctl->fsm().state() == S::Coucou);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Greeting);
        QCOMPARE(ctl->islandHeight(), 150.0);
        QCOMPARE(soundList(), QStringList{"open"});

        ctl->greetComplete();
        sched->advance(600);
        QVERIFY(ctl->fsm().state() == S::Petit);
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(state->view() == IslandView::Overview);      // defaultView()
        QCOMPARE(interrupt.count(), 1);
        QCOMPARE(soundList(), (QStringList{"open", "close"}));

        // the pointer was never inside, so the 60 s hide timer started at once
        sched->advance(60000);
        QVERIFY(ctl->fsm().state() == S::Hidden);
        QVERIFY(state->mode() == IslandMode::Hidden);
        QCOMPARE(ctl->botOpacity(), 0.0);
    }

    void hoverFromHiddenPeeksWithSound()
    {
        state->setMode(IslandMode::Hidden);
        sounds->clear();
        ctl->pointerEntered();
        QVERIFY(ctl->fsm().state() == S::Petit);
        QVERIFY(state->mode() == IslandMode::Compact);
        QCOMPARE(soundList(), QStringList{"peek"});
    }

    void clickOnCompactOpensOverview()
    {
        ctl->pointerEntered();                 // hidden(fsm) -> petit
        sounds->clear();
        ctl->islandClicked();
        QVERIFY(ctl->fsm().state() == S::Home);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Overview);
        QCOMPARE(ctl->islandWidth(), 640.0);
        QCOMPARE(ctl->islandHeight(), 160.0);
        QCOMPARE(ctl->cornerRadius(), 22.0);
        QCOMPARE(soundList(), QStringList{"open"});
        QCOMPARE(state->lastActivityMs(), qint64(1000));
    }

    void hoverAloneNeverOpensTheCompactIsland()
    {
        ctl->pointerEntered();
        sched->advance(5000);
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(ctl->fsm().state() == S::Petit);
    }

    void homeCollapsesAfter15sOncePointerLeaves()
    {
        ctl->pointerEntered();
        ctl->islandClicked();
        sounds->clear();
        ctl->pointerLeft();
        sched->advance(14999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(ctl->fsm().state() == S::Petit);
        QVERIFY(state->mode() == IslandMode::Compact);
        QCOMPARE(soundList(), QStringList{"close"});
    }

    void escapeClosesUnlessPinned()
    {
        ctl->pointerEntered();
        ctl->islandClicked();
        QSignalSpy kb(ctl.get(), &IslandController::keyboardOnDemandChanged);
        state->setPinned(true);
        ctl->escapePressed();
        QVERIFY(state->mode() == IslandMode::Expanded);
        QCOMPARE(kb.count(), 0);
        state->setPinned(false);
        ctl->escapePressed();
        QVERIFY(state->mode() == IslandMode::Compact);
        QCOMPARE(kb.count(), 1);
        QCOMPARE(kb.first().at(0).toBool(), false);
    }

    void escWhileHomeDoesNotDoubleClose()
    {
        ctl->pointerEntered();
        ctl->islandClicked();
        ctl->pointerLeft();
        sounds->clear();
        ctl->escapePressed();                  // collapse() while the FSM is still in Home
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(ctl->fsm().state() == S::Home);
        QCOMPARE(count("close"), 1);
        sched->advance(15000);                 // the FSM catches up: home -> petit, mode already compact
        QVERIFY(ctl->fsm().state() == S::Petit);
        QCOMPARE(count("close"), 1);           // no second "close"
    }

    void shrinkingFlagOnlyForModeShrink()
    {
        ctl->expandTo("overview");
        QVERIFY(!ctl->shrinking());
        ctl->expandTo("upload");               // view change inside expanded uses the open curve
        QVERIFY(!ctl->shrinking());
        QCOMPARE(ctl->islandHeight(), 176.0);
        ctl->collapse();
        QVERIFY(ctl->shrinking());
        QCOMPARE(ctl->islandWidth(), 344.0);
        QCOMPARE(ctl->islandHeight(), 32.0);
        QCOMPARE(ctl->cornerRadius(), 14.0);
        ctl->expandTo("overview");
        QVERIFY(!ctl->shrinking());
    }

    void promptHeightFollowsChat()
    {
        ctl->expandTo("prompt");
        QCOMPARE(ctl->islandHeight(), 240.0);
        state->setChatCount(1);
        QCOMPARE(ctl->islandHeight(), 280.0);
        state->setChatCount(5);
        QCOMPARE(ctl->islandHeight(), 300.0);
    }

    void layoutStaysAtHeight160WhenViewSwitchesToEmpty()
    {
        ctl->expandTo("overview");
        for (const auto &t : integrationAgents())
            state->removeTask(t.id);
        QVERIFY(state->view() == IslandView::Empty);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QCOMPARE(ctl->islandHeight(), 160.0);
        QCOMPARE(ctl->islandWidth(), 640.0);
    }

    void notchChangeResizesTheIsland()
    {
        state->setNotchSize(200, 38);
        QCOMPARE(ctl->islandWidth(), 360.0);
        QCOMPARE(ctl->islandHeight(), 38.0);
        state->setNotchSize(0, -1);            // detection failed: fall back to 184x32
        QCOMPARE(ctl->islandWidth(), 344.0);
        QCOMPARE(ctl->islandHeight(), 32.0);
    }

    void hookExpandWorksEvenWhenFsmIsHidden()
    {
        ctl->expandTo("approval");             // alerts open the island regardless of the FSM (Swift .hookExpand)
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Approval);
        QVERIFY(ctl->fsm().state() == S::Hidden);
    }

    void revealShowsCompactFromHidden()
    {
        state->setMode(IslandMode::Hidden);
        ctl->reveal();
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(ctl->fsm().state() == S::Petit);
        sched->advance(60000);
        QVERIFY(state->mode() == IslandMode::Hidden);
    }

    void showViewSetsViewAndResetsActivity()
    {
        ctl->expandTo("overview");
        nowMs = 5000;
        ctl->showView("settings");
        QVERIFY(state->view() == IslandView::Settings);
        QCOMPARE(state->lastActivityMs(), qint64(5000));
        ctl->showView("bogus");
        QVERIFY(state->view() == IslandView::Settings);
    }

    void flappingHoverDoesNotResetTheHideTimer()
    {
        // pointerLeft/Enter come through setPointerInside(): a quick exit+enter must be invisible
        ctl->setPointerInside(true);           // hidden(fsm) -> petit
        ctl->setPointerInside(false);
        sched->advance(97);
        ctl->setPointerInside(true);           // came back before the 120 ms debounce
        sched->advance(200);
        QVERIFY(ctl->wasInIsland());
        QVERIFY(ctl->fsm().state() == S::Petit);
    }
};

QTEST_MAIN(TestController)
#include "tst_island_controller.moc"
```
Acrescentar em `linux/tests/CMakeLists.txt`: `coucou_add_test(tst_island_controller)`.

- [ ] **Step 2: Registrar a fonte e ver falhar**

`linux/src/core/CMakeLists.txt` — acrescentar `IslandController.h IslandController.cpp` à lista (depois de `AppState.h AppState.cpp`).
Run: `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build`
Expected: FAIL — `IslandController.h` não existe.

- [ ] **Step 3: Implementar**

`linux/src/core/IslandController.h`:
```cpp
#pragma once
#include "AppState.h"
#include "HoverDebouncer.h"
#include "IslandStateMachine.h"
#include "Scheduler.h"

#include <QObject>
#include <functional>

namespace coucou {

// Port of the wiring in IslandWindowController.swift (wireFSM, setMode, expand, collapse, pointer handling)
// plus the layout numbers the QML island binds to.
class IslandController : public QObject {
    Q_OBJECT
    Q_PROPERTY(qreal islandWidth READ islandWidth NOTIFY layoutChanged)
    Q_PROPERTY(qreal islandHeight READ islandHeight NOTIFY layoutChanged)
    Q_PROPERTY(qreal cornerRadius READ cornerRadius NOTIFY layoutChanged)
    Q_PROPERTY(bool shrinking READ shrinking NOTIFY layoutChanged)
    Q_PROPERTY(qreal botX READ botX NOTIFY layoutChanged)
    Q_PROPERTY(qreal botY READ botY NOTIFY layoutChanged)
    Q_PROPERTY(qreal botDiameter READ botDiameter NOTIFY layoutChanged)
    Q_PROPERTY(qreal botOpacity READ botOpacity NOTIFY layoutChanged)

public:
    using NowFn = std::function<qint64()>;
    IslandController(AppState *state, IScheduler *scheduler, NowFn now, QObject *parent = nullptr);

    IslandStateMachine &fsm() { return m_fsm; }
    bool wasInIsland() const { return m_wasInIsland; }
    IslandView defaultView() const;

    qreal islandWidth() const { return m_w; }
    qreal islandHeight() const { return m_h; }
    qreal cornerRadius() const { return m_corner; }
    bool shrinking() const { return m_shrinking; }
    qreal botX() const { return m_bot.cx; }
    qreal botY() const { return m_bot.cy; }
    qreal botDiameter() const { return m_bot.diameter; }
    qreal botOpacity() const { return m_bot.opacity; }

    void expand(IslandView view);
    void setMode(IslandMode mode);
    void pointerEntered();
    void pointerLeft();

public slots:
    void setPointerInside(bool inside);   // raw hover from the window; debounced before it reaches the FSM
    void islandClicked();
    void escapePressed();
    void greetComplete();
    void requestKeyboard(bool onDemand);
    void showView(const QString &viewName);
    void expandTo(const QString &viewName);
    void collapse();
    void launch();
    void reveal();
    void resetActivity();

signals:
    void layoutChanged();
    void playSound(const QString &name);
    void greetingInterrupt();
    void greetingHover();
    void keyboardOnDemandChanged(bool onDemand);

private:
    void onFsmTransition(IslandStateMachine::State from, IslandStateMachine::State to);
    void updateLayout(bool shrinking);
    static int modeLevel(IslandMode m);

    AppState *m_state;
    NowFn m_now;
    IslandStateMachine m_fsm;
    HoverDebouncer m_hover;
    bool m_wasInIsland = false;
    bool m_shrinking = false;
    int m_lastLevel = 0;
    qreal m_w = 0, m_h = 0, m_corner = 0;
    BotPlacement m_bot{0, 0, 0, 0};
};

} // namespace coucou
```

`linux/src/core/IslandController.cpp`:
```cpp
#include "IslandController.h"

namespace coucou {

using S = IslandStateMachine::State;

IslandController::IslandController(AppState *state, IScheduler *scheduler, NowFn now, QObject *parent)
    : QObject(parent), m_state(state), m_now(std::move(now)), m_fsm(*scheduler), m_hover(*scheduler)
{
    m_fsm.onTransition = [this](S from, S to) { onFsmTransition(from, to); };
    m_hover.onChanged = [this](bool inside) { inside ? pointerEntered() : pointerLeft(); };

    m_lastLevel = modeLevel(m_state->mode());
    connect(m_state, &AppState::modeChanged, this, [this] {
        const int level = modeLevel(m_state->mode());
        const bool shrinking = level < m_lastLevel;
        m_lastLevel = level;
        updateLayout(shrinking);
    });
    for (auto signal : {&AppState::viewChanged, &AppState::chatCountChanged, &AppState::uploadProgressChanged,
                        &AppState::notchChanged})
        connect(m_state, signal, this, [this] { updateLayout(false); });
    updateLayout(false);
}

int IslandController::modeLevel(IslandMode m)
{
    switch (m) {
    case IslandMode::Hidden: return 0;
    case IslandMode::Compact: return 1;
    case IslandMode::Expanded: return 2;
    }
    return 0;
}

void IslandController::updateLayout(bool shrinking)
{
    const QSizeF sz = islandSize(m_state->mode(), m_state->view(), m_state->notchWidth(), m_state->notchHeight(),
                                 m_state->chatCount());
    m_w = sz.width();
    m_h = sz.height();
    m_corner = islandCornerRadius(m_state->mode());
    m_bot = botPosition(m_state->mode(), m_state->view(), m_h, m_state->uploadProgress());
    m_shrinking = shrinking;
    emit layoutChanged();
}

IslandView IslandController::defaultView() const
{
    return m_state->taskModel()->all().isEmpty() ? IslandView::Empty : IslandView::Overview;
}

void IslandController::onFsmTransition(S from, S to)
{
    switch (to) {
    case S::Hidden:
        setMode(IslandMode::Hidden);
        break;
    case S::Petit:
        if (from == S::Coucou)
            emit greetingInterrupt();          // collapse of the greeting canvas starts before the mode change
        else if (from == S::Hidden)
            emit playSound(QStringLiteral("peek"));
        // mode first, then the view: changing the view while compact must not trigger an open animation
        setMode(IslandMode::Compact);
        if (from == S::Coucou)
            m_state->setView(defaultView());
        if (!m_wasInIsland)
            m_fsm.mouseLeft();                 // starts the 60 s hide timer when the pointer is not over the island
        break;
    case S::Home:
        expand(defaultView());
        if (!m_wasInIsland)
            m_fsm.mouseLeft();                 // starts the 15 s collapse timer
        break;
    case S::Coucou:
        expand(IslandView::Greeting);
        break;
    }
}

void IslandController::setMode(IslandMode mode)
{
    const IslandMode prev = m_state->mode();
    if (mode == prev)
        return;
    m_state->setMode(mode);
    if (mode == IslandMode::Expanded)
        emit playSound(QStringLiteral("open"));
    if (prev == IslandMode::Expanded) {
        emit playSound(QStringLiteral("close"));
        m_state->setPinned(false);
    }
}

void IslandController::expand(IslandView view)
{
    m_state->setView(view);
    if (m_state->mode() != IslandMode::Expanded)
        setMode(IslandMode::Expanded);
    m_state->setLastActivityMs(m_now());
    if (view == IslandView::Prompt || view == IslandView::Mail)
        emit keyboardOnDemandChanged(true);    // views with a text field need the keyboard
}

void IslandController::collapse()
{
    m_state->setPinned(false);
    if (m_fsm.state() == S::Home)
        m_fsm.mouseLeft();
    setMode(IslandMode::Compact);
    emit keyboardOnDemandChanged(false);
}

void IslandController::pointerEntered()
{
    if (m_wasInIsland)
        return;
    if (m_fsm.state() == S::Coucou)
        emit greetingHover();                  // keep the greeting open while the pointer is on it
    m_fsm.mouseEntered();
    m_wasInIsland = true;                      // after the FSM call, like pollFrame() in Swift
}

void IslandController::pointerLeft()
{
    if (!m_wasInIsland)
        return;
    m_fsm.mouseLeft();
    m_wasInIsland = false;
}

void IslandController::setPointerInside(bool inside)
{
    inside ? m_hover.enter() : m_hover.leave();
}

void IslandController::islandClicked()
{
    if (m_state->mode() != IslandMode::Expanded)
        m_fsm.click();
}

void IslandController::escapePressed()
{
    if (m_state->mode() == IslandMode::Expanded && !m_state->isPinned())
        collapse();
}

void IslandController::greetComplete() { m_fsm.greetComplete(); }
void IslandController::launch() { m_fsm.launch(); }
void IslandController::reveal() { m_fsm.reveal(); }
void IslandController::requestKeyboard(bool onDemand) { emit keyboardOnDemandChanged(onDemand); }
void IslandController::resetActivity() { m_state->setLastActivityMs(m_now()); }

void IslandController::showView(const QString &viewName)
{
    if (auto v = enumFromKey<IslandView>(viewName)) {
        m_state->setView(*v);
        resetActivity();
    }
}

void IslandController::expandTo(const QString &viewName)
{
    if (auto v = enumFromKey<IslandView>(viewName))
        expand(*v);
}

} // namespace coucou
```

- [ ] **Step 4: Rodar e ver passar**

Run:
```sh
linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: `100% tests passed, 0 tests failed out of 5`.

- [ ] **Step 5: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux: IslandController ports the window-controller wiring and layout

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 5: Sons — lista dos 28 e `SoundEngine`

**Files:**
- Create: `linux/src/core/SoundNames.h`, `linux/src/platform/CMakeLists.txt`, `linux/src/platform/SoundEngine.h`, `linux/src/platform/SoundEngine.cpp`, `linux/tests/tst_sound.cpp`, `linux/tests/tst_sound_engine.cpp`
- Modify: `linux/CMakeLists.txt`, `linux/tests/CMakeLists.txt`

**Interfaces:**
- Consumes: WAVs em `NotchBuddy/Resources/sounds/`.
- Produces: `coucou::soundNames()` (`const QStringList &`, 28 nomes); `coucou::SoundEngine(const QString &soundsDir, QObject* = nullptr)` com `isLoaded(name)`, `enabled()`, `volume()`, slots `setEnabled(bool)`, `setVolume(double)` (0–0,2), `play(QString)`; alvo CMake `coucou_platform`.

- [ ] **Step 1: Escrever os testes que falham**

`linux/tests/tst_sound.cpp` (core, sem Qt Multimedia):
```cpp
#include <QtTest>
#include <QDir>
#include <QSet>
#include "SoundNames.h"

class TestSoundNames : public QObject {
    Q_OBJECT
private slots:
    void thereAreTwentyEightUniqueNames()
    {
        const auto &names = coucou::soundNames();
        QCOMPARE(names.size(), 28);
        QCOMPARE(QSet<QString>(names.begin(), names.end()).size(), 28);
    }
    void everyNameHasAWavAndNoWavIsUnlisted()
    {
        const QDir dir(QStringLiteral(COUCOU_SOUNDS_DIR));
        QVERIFY2(dir.exists(), qPrintable(dir.path()));
        for (const QString &n : coucou::soundNames())
            QVERIFY2(dir.exists(n + ".wav"), qPrintable(n));
        const QStringList wavs = dir.entryList({"*.wav"}, QDir::Files);
        QCOMPARE(wavs.size(), coucou::soundNames().size());
    }
};

QTEST_APPLESS_MAIN(TestSoundNames)
#include "tst_sound.moc"
```

`linux/tests/tst_sound_engine.cpp`:
```cpp
#include <QtTest>
#include "SoundEngine.h"
#include "SoundNames.h"

using coucou::SoundEngine;

class TestSoundEngine : public QObject {
    Q_OBJECT
private slots:
    void loadsEveryWav()
    {
        SoundEngine engine(QStringLiteral(COUCOU_SOUNDS_DIR));
        for (const QString &n : coucou::soundNames())
            QTRY_VERIFY_WITH_TIMEOUT(engine.isLoaded(n), 5000);
    }
    void volumeIsClampedToTwoTenths()
    {
        SoundEngine engine(QStringLiteral(COUCOU_SOUNDS_DIR));
        QCOMPARE(engine.volume(), 0.12);
        engine.setVolume(5);
        QCOMPARE(engine.volume(), 0.2);
        engine.setVolume(-1);
        QCOMPARE(engine.volume(), 0.0);
    }
    void unknownNameAndDisabledAreHarmless()
    {
        SoundEngine engine(QStringLiteral(COUCOU_SOUNDS_DIR));
        engine.play("does-not-exist");
        engine.setEnabled(false);
        QVERIFY(!engine.enabled());
        engine.play("peek");
    }
};

QTEST_MAIN(TestSoundEngine)
#include "tst_sound_engine.moc"
```

`linux/tests/CMakeLists.txt` — acrescentar ao fim:
```cmake
coucou_add_test(tst_sound)
target_compile_definitions(tst_sound PRIVATE COUCOU_SOUNDS_DIR="${CMAKE_SOURCE_DIR}/../NotchBuddy/Resources/sounds")

if(TARGET coucou_platform)
    qt_add_executable(tst_sound_engine tst_sound_engine.cpp)
    target_link_libraries(tst_sound_engine PRIVATE coucou_platform coucou_core Qt6::Test)
    target_compile_definitions(tst_sound_engine PRIVATE
        COUCOU_SOUNDS_DIR="${CMAKE_SOURCE_DIR}/../NotchBuddy/Resources/sounds")
    add_test(NAME tst_sound_engine COMMAND tst_sound_engine)
    set_tests_properties(tst_sound_engine PROPERTIES ENVIRONMENT "QT_QPA_PLATFORM=offscreen;QT_QUICK_BACKEND=software")
endif()
```

- [ ] **Step 2: Ver falhar**

Run: `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build`
Expected: FAIL — `SoundNames.h` não existe.

- [ ] **Step 3: Implementar**

`linux/src/core/SoundNames.h`:
```cpp
#pragma once
#include <QStringList>

namespace coucou {

// Same 28 names SoundEngine.swift preloads.
inline const QStringList &soundNames()
{
    static const QStringList names = {
        "peek", "open", "close", "hover", "blip", "slap", "annoyed", "dizzy", "greet",
        "work", "finish", "error", "approval", "question", "approve", "gulp", "tick",
        "send", "love", "pop", "proud", "wink", "yawn", "attach", "think", "search",
        "rate", "sleep"};
    return names;
}

} // namespace coucou
```

`linux/src/platform/SoundEngine.h`:
```cpp
#pragma once
#include <QHash>
#include <QList>
#include <QObject>

class QSoundEffect;

namespace coucou {

// Pool of 3 preloaded QSoundEffect per WAV so the same sound can overlap (L0 finding 6).
class SoundEngine : public QObject {
    Q_OBJECT
public:
    explicit SoundEngine(const QString &soundsDir, QObject *parent = nullptr);

    bool isLoaded(const QString &name) const;
    bool enabled() const { return m_enabled; }
    double volume() const { return m_volume; }

public slots:
    void setEnabled(bool on) { m_enabled = on; }
    void setVolume(double v);   // clamped to 0..0.2
    void play(const QString &name);

private:
    QHash<QString, QList<QSoundEffect *>> m_pool;
    bool m_enabled = true;
    double m_volume = 0.12;
};

} // namespace coucou
```

`linux/src/platform/SoundEngine.cpp`:
```cpp
#include "SoundEngine.h"

#include "SoundNames.h"

#include <QSoundEffect>
#include <QUrl>
#include <algorithm>

namespace coucou {

SoundEngine::SoundEngine(const QString &soundsDir, QObject *parent) : QObject(parent)
{
    for (const QString &name : soundNames()) {
        QList<QSoundEffect *> voices;
        for (int i = 0; i < 3; ++i) {
            auto *fx = new QSoundEffect(this);
            fx->setSource(QUrl::fromLocalFile(soundsDir + "/" + name + ".wav"));
            fx->setVolume(float(m_volume));
            voices << fx;
        }
        m_pool.insert(name, voices);
    }
}

bool SoundEngine::isLoaded(const QString &name) const
{
    const auto it = m_pool.constFind(name);
    if (it == m_pool.constEnd())
        return false;
    return std::all_of(it->begin(), it->end(), [](QSoundEffect *fx) { return fx->status() == QSoundEffect::Ready; });
}

void SoundEngine::setVolume(double v)
{
    m_volume = std::clamp(v, 0.0, 0.2);
    for (const auto &voices : std::as_const(m_pool))
        for (QSoundEffect *fx : voices)
            fx->setVolume(float(m_volume));
}

void SoundEngine::play(const QString &name)
{
    if (!m_enabled)
        return;
    const auto it = m_pool.constFind(name);
    if (it == m_pool.constEnd())
        return;
    QSoundEffect *voice = it->first();
    for (QSoundEffect *fx : *it) {
        if (!fx->isPlaying()) {
            voice = fx;
            break;
        }
    }
    voice->setVolume(float(m_volume));
    voice->play();
}

} // namespace coucou
```

`linux/src/platform/CMakeLists.txt`:
```cmake
add_library(coucou_platform STATIC
    SoundEngine.h SoundEngine.cpp
)
target_include_directories(coucou_platform PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(coucou_platform PUBLIC coucou_core Qt6::Gui Qt6::Multimedia)
```

`linux/CMakeLists.txt` — depois de `add_subdirectory(src/core)`, acrescentar:
```cmake
add_subdirectory(src/platform)
```

- [ ] **Step 4: Rodar e ver passar**

Run:
```sh
linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: `100% tests passed, 0 tests failed out of 7`. Se `loadsEveryWav` falhar por falta de dispositivo de áudio no ambiente do teste, registre um *Ruling* e troque o `QTRY_VERIFY_WITH_TIMEOUT(isLoaded)` por checagem de `status() != Error` — o L0 mostrou `status=Ready` no host.

- [ ] **Step 5: Commit**

```bash
git add linux/CMakeLists.txt linux/src linux/tests
git commit -m "linux: sound name list and QSoundEffect pool engine

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 6: QML da casca (forma, cabeçalho, views provisórias) com testes offscreen

**Files:**
- Create: `linux/qml/Island.qml`, `linux/qml/IslandHeader.qml`, `linux/qml/HeaderTab.qml`, `linux/qml/IconGlyph.qml`, `linux/qml/ViewPlaceholder.qml`, `linux/qml/CountdownBar.qml`, `linux/qml/CompactGrid.qml`, `linux/tests/tst_island_qml.cpp`
- Modify: `linux/tests/CMakeLists.txt`

**Interfaces:**
- Consumes: `appState` (`modeName`, `viewName`, `isPinned`, `autoCloseInterval`, `lastActivityMs`, `soundEnabled`, `compactOthers`, `tasks`) e `controller` (`islandWidth/Height`, `cornerRadius`, `shrinking`, `bot*`, `setPointerInside`, `islandClicked`, `escapePressed`, `requestKeyboard`, `greetComplete`, `showView`) como propriedades de contexto do QML.
- Produces: raiz `Item` 720×320 com `objectName` nos filhos usados pelos testes/janela: `island` (o retângulo preto), `countdownBar`, `view-<nome>` (um `ViewPlaceholder` por view), `header`; propriedade `readonly property rect islandRect` (o retângulo da ilha em coordenadas da janela, que a camada de plataforma converte em região de entrada).

- [ ] **Step 1: Escrever o teste que falha**

`linux/tests/tst_island_qml.cpp`:
```cpp
#include <QtTest>
#include <QQmlContext>
#include <QQuickItem>
#include <QQuickView>
#include <QSettings>
#include <QTemporaryDir>
#include <memory>
#include "AppState.h"
#include "FakeScheduler.h"
#include "IslandController.h"

using namespace coucou;

class TestIslandQml : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandController> ctl;
    std::unique_ptr<QQuickView> view;
    QQuickItem *root = nullptr;

    QQuickItem *child(const char *name) const { return root->findChild<QQuickItem *>(name); }

private slots:
    void init()
    {
        QFile::remove(dir.path() + "/q.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/q.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        sched = std::make_unique<FakeScheduler>();
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [] { return QDateTime::currentMSecsSinceEpoch(); });
        view = std::make_unique<QQuickView>();
        view->rootContext()->setContextProperty("appState", state.get());
        view->rootContext()->setContextProperty("controller", ctl.get());
        view->setSource(QUrl::fromLocalFile(QStringLiteral(COUCOU_QML_DIR "/Island.qml")));
        QVERIFY2(view->status() == QQuickView::Ready, "Island.qml failed to load");
        root = view->rootObject();
        QVERIFY(root);
        view->show();
        QVERIFY(child("island"));
    }
    void cleanup()
    {
        view.reset();
        ctl.reset();
        state.reset();
    }

    void startsAsTheCompactPillCenteredAtTheTop()
    {
        QQuickItem *island = child("island");
        QCOMPARE(island->width(), 344.0);
        QCOMPARE(island->height(), 32.0);
        QCOMPARE(island->x(), (720.0 - 344.0) / 2);
        QCOMPARE(island->y(), 0.0);
        QCOMPARE(root->property("islandRect").toRectF(), QRectF(188, 0, 344, 32));
    }

    void expandsToOverviewSizeWithOpenCurve()
    {
        ctl->expandTo("overview");
        QQuickItem *island = child("island");
        QTRY_COMPARE_WITH_TIMEOUT(island->width(), 640.0, 3000);
        QTRY_COMPARE_WITH_TIMEOUT(island->height(), 160.0, 3000);
        QCOMPARE(island->x(), 40.0);
        QCOMPARE(root->property("islandRect").toRectF(), QRectF(40, 0, 640, 160));
    }

    void collapseShrinksBackToCompact()
    {
        ctl->expandTo("overview");
        QQuickItem *island = child("island");
        QTRY_COMPARE_WITH_TIMEOUT(island->width(), 640.0, 3000);
        ctl->collapse();
        QTRY_COMPARE_WITH_TIMEOUT(island->width(), 344.0, 3000);
        QTRY_COMPARE_WITH_TIMEOUT(island->height(), 32.0, 3000);
    }

    void onlyTheActiveViewIsVisible()
    {
        ctl->expandTo("approval");
        QTRY_COMPARE_WITH_TIMEOUT(child("view-approval")->opacity(), 1.0, 3000);
        QCOMPARE(child("view-overview")->opacity(), 0.0);
        QVERIFY(!child("view-overview")->isVisible());
        ctl->showView("overview");
        QTRY_COMPARE_WITH_TIMEOUT(child("view-overview")->opacity(), 1.0, 3000);
        QTRY_COMPARE_WITH_TIMEOUT(child("view-approval")->opacity(), 0.0, 3000);
    }

    void contentIsHiddenWhileCompact()
    {
        QQuickItem *header = child("header");
        QVERIFY(header);
        QVERIFY(!header->isVisible() || header->opacity() == 0.0 || !header->parentItem()->isVisible());
        ctl->expandTo("overview");
        QTRY_VERIFY_WITH_TIMEOUT(header->isVisible(), 2000);
    }

    void hiddenModeMakesTheIslandInvisible()
    {
        state->setMode(IslandMode::Hidden);
        QQuickItem *island = child("island");
        QTRY_COMPARE_WITH_TIMEOUT(island->opacity(), 0.0, 2000);
        state->setMode(IslandMode::Compact);
        QTRY_COMPARE_WITH_TIMEOUT(island->opacity(), 1.0, 2000);
    }

    void countdownBarStaysZeroWhenPinnedOrFresh()
    {
        ctl->expandTo("overview");
        QQuickItem *bar = child("countdownBar");
        QVERIFY(bar);
        state->setPinned(true);
        state->setLastActivityMs(QDateTime::currentMSecsSinceEpoch() - 14000);   // 1 s left of 15 s
        QTest::qWait(350);
        QCOMPARE(bar->property("barWidth").toDouble(), 0.0);                     // pinned: never shows
        state->setPinned(false);
        state->setLastActivityMs(QDateTime::currentMSecsSinceEpoch());            // fresh activity: > 9 s left
        QTest::qWait(350);
        QCOMPARE(bar->property("barWidth").toDouble(), 0.0);
        state->setLastActivityMs(QDateTime::currentMSecsSinceEpoch() - 12000);    // 3 s left of a 9 s window
        QTRY_VERIFY_WITH_TIMEOUT(bar->property("barWidth").toDouble() > 40.0, 1500);
        QVERIFY(bar->property("barWidth").toDouble() <= 160.0);
    }

    void compactGridShowsTheOtherPills()
    {
        QQuickItem *grid = child("compactGrid");
        QVERIFY(grid);
        QCOMPARE(grid->property("count").toInt(), 4);
    }
};

QTEST_MAIN(TestIslandQml)
#include "tst_island_qml.moc"
```
Acrescentar em `linux/tests/CMakeLists.txt`:
```cmake
coucou_add_test(tst_island_qml)
target_link_libraries(tst_island_qml PRIVATE Qt6::Quick)
target_compile_definitions(tst_island_qml PRIVATE COUCOU_QML_DIR="${CMAKE_SOURCE_DIR}/qml")
```

- [ ] **Step 2: Ver falhar**

Run: `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build -R tst_island_qml --output-on-failure`
Expected: FAIL — `Island.qml failed to load` (o arquivo não existe).

- [ ] **Step 3: Escrever os componentes QML**

`linux/qml/IconGlyph.qml`:
```qml
import QtQuick
import QtQuick.Shapes

// Small monochrome icons drawn in code (SF Symbols do not exist on Linux). 24x24 design grid.
Item {
    id: glyph
    property string name: ""
    property real size: 14
    property color color: "#8E939C"
    width: size
    height: size

    readonly property var fills: ({
        "house": "M12 3 L2.5 11.5 H5.5 V20.5 H10 V14.5 H14 V20.5 H18.5 V11.5 H21.5 Z",
        "bubble": "M6 4 H18 Q21 4 21 7 V14 Q21 17 18 17 H11 L6.5 21 V17 H6 Q3 17 3 14 V7 Q3 4 6 4 Z",
        "plus": "M10.8 4 H13.2 V10.8 H20 V13.2 H13.2 V20 H10.8 V13.2 H4 V10.8 H10.8 Z",
        "gear": "M19.34 10.03 L21.88 10.44 L21.88 13.56 L19.34 13.97 L18.58 15.80 L20.09 17.88 L17.88 20.09 L15.80 18.58 L13.97 19.34 L13.56 21.88 L10.44 21.88 L10.03 19.34 L8.20 18.58 L6.12 20.09 L3.91 17.88 L5.42 15.80 L4.66 13.97 L2.12 13.56 L2.12 10.44 L4.66 10.03 L5.42 8.20 L3.91 6.12 L6.12 3.91 L8.20 5.42 L10.03 4.66 L10.44 2.12 L13.56 2.12 L13.97 4.66 L15.80 5.42 L17.88 3.91 L20.09 6.12 L18.58 8.20 Z M15.2 12.0 A3.2 3.2 0 1 0 8.8 12.0 A3.2 3.2 0 1 0 15.2 12.0 Z",
        "speaker": "M3 9.5 H7 L12 5 V19 L7 14.5 H3 Z",
        "speaker-off": "M3 9.5 H7 L12 5 V19 L7 14.5 H3 Z"
    })
    readonly property var strokes: ({
        "speaker": "M15.5 9 Q18 12 15.5 15 M18 6.5 Q23 12 18 17.5",
        "speaker-off": "M15.5 9.5 L21 14.5 M21 9.5 L15.5 14.5"
    })

    Shape {
        width: 24
        height: 24
        scale: glyph.size / 24
        transformOrigin: Item.TopLeft
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            fillColor: glyph.color
            strokeColor: "transparent"
            fillRule: ShapePath.OddEvenFill
            PathSvg { path: glyph.fills[glyph.name] || "" }
        }
        ShapePath {
            fillColor: "transparent"
            strokeColor: glyph.strokes[glyph.name] ? glyph.color : "transparent"
            strokeWidth: 1.8
            capStyle: ShapePath.RoundCap
            PathSvg { path: glyph.strokes[glyph.name] || "" }
        }
    }
}
```

`linux/qml/HeaderTab.qml`:
```qml
import QtQuick

// One capsule of the header (30x22). Colors copied from TabButton in IslandRootView.swift.
Item {
    id: tab
    property string icon: ""
    property bool on: false
    signal clicked()

    width: 30
    height: 22

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: tab.on ? "#1D1F23" : (hover.hovered ? Qt.rgba(1, 1, 1, 0.07) : "transparent")
    }
    IconGlyph {
        anchors.centerIn: parent
        name: tab.icon
        size: 13
        color: tab.on ? "#F5F6F8" : (hover.hovered ? "#B0B5BE" : "#8E939C")
    }
    HoverHandler { id: hover }
    TapHandler { onTapped: tab.clicked() }
}
```

`linux/qml/IslandHeader.qml`:
```qml
import QtQuick

// Tabs on the left, settings + sound on the right (IslandHeader in IslandRootView.swift).
Item {
    id: header
    height: 34

    Row {
        x: 14
        anchors.verticalCenter: parent.verticalCenter
        spacing: 5
        HeaderTab {
            icon: "house"
            on: appState.viewName === "overview" || appState.viewName === "empty"
            onClicked: controller.showView("overview")
        }
        HeaderTab {
            icon: "bubble"
            on: appState.viewName === "prompt"
            onClicked: controller.showView("prompt")
        }
        HeaderTab {
            icon: "plus"
            on: appState.viewName === "upload"
            onClicked: controller.showView("upload")
        }
    }

    Row {
        anchors.right: parent.right
        anchors.rightMargin: 16
        anchors.verticalCenter: parent.verticalCenter
        spacing: 14

        Item {
            width: 14; height: 14
            IconGlyph {
                anchors.fill: parent
                name: "gear"
                size: 14
                color: appState.viewName === "settings" ? "#F5F6F8" : "#8E939C"
            }
            TapHandler { onTapped: controller.showView("settings") }
        }
        Item {
            width: 14; height: 14
            IconGlyph {
                anchors.fill: parent
                name: appState.soundEnabled ? "speaker" : "speaker-off"
                size: 14
                color: "#8E939C"
            }
            TapHandler { onTapped: appState.soundEnabled = !appState.soundEnabled }
        }
    }
}
```

`linux/qml/ViewPlaceholder.qml`:
```qml
import QtQuick

// Provisional card for a view (real content arrives in L1c). It already animates like the Swift views:
// enter = 300 ms after a 160 ms delay, exit = 160 ms; scale 0.97 <-> 1.
Item {
    id: card
    property string viewName: ""
    property bool active: false

    opacity: active ? 1 : 0
    scale: active ? 1 : 0.97
    visible: opacity > 0.001
    enabled: active

    Behavior on opacity {
        SequentialAnimation {
            PauseAnimation { duration: card.active ? 160 : 0 }
            NumberAnimation { duration: card.active ? 300 : 160; easing.type: card.active ? Easing.OutCubic : Easing.InCubic }
        }
    }
    Behavior on scale {
        SequentialAnimation {
            PauseAnimation { duration: card.active ? 160 : 0 }
            NumberAnimation { duration: card.active ? 300 : 160; easing.type: card.active ? Easing.OutCubic : Easing.InCubic }
        }
    }

    Rectangle {
        anchors.fill: parent
        radius: 20
        color: "#141518"
        border.color: Qt.rgba(1, 1, 1, 0.035)
        border.width: 1
        Text {
            anchors.centerIn: parent
            text: card.viewName
            color: "#5F646D"
            font.family: "Inter"
            font.pixelSize: 13
        }
    }
}
```

`linux/qml/CountdownBar.qml`:
```qml
import QtQuick

// The 2 pt line at the bottom centre that shows the last seconds before auto-close (CountdownBar in Swift).
Item {
    id: bar
    anchors.fill: parent
    property real barWidth: 0

    Rectangle {
        width: bar.barWidth
        height: 2
        radius: 2
        color: Qt.rgba(1, 1, 1, 0.35)
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
    }

    // Only ticks while the island is open, so a hidden island costs nothing.
    Timer {
        interval: 100
        repeat: true
        running: appState.modeName === "expanded"
        onTriggered: {
            if (appState.isPinned) { bar.barWidth = 0; return }
            const autoClose = appState.autoCloseInterval
            const window = Math.min(10.0, autoClose * 0.6)
            const remaining = autoClose - (Date.now() - appState.lastActivityMs) / 1000
            bar.barWidth = remaining < window ? Math.max(0, remaining / window) * 160 : 0
        }
    }
    onVisibleChanged: if (!visible) barWidth = 0
}
```

`linux/qml/CompactGrid.qml`:
```qml
import QtQuick

// 2x2 mini dots to the right of the notch in compact mode (CompactMiniGrid). The real mini-Mochis come in L1b.
Item {
    id: grid
    objectName: "compactGrid"
    width: 28
    height: 28
    readonly property int count: repeater.count

    Grid {
        anchors.centerIn: parent
        columns: 2
        spacing: 4
        Repeater {
            id: repeater
            model: appState.compactOthers
            Rectangle {
                required property var modelData
                width: 12
                height: 12
                radius: 6
                color: modelData.color
                opacity: modelData.state === "idle" ? 0.55 : 1
            }
        }
    }
}
```

`linux/qml/Island.qml`:
```qml
import QtQuick

// Window content: 720x320, transparent; the island hangs from the top centre (IslandContainer in Swift).
Item {
    id: root
    width: 720
    height: 320
    focus: true

    readonly property bool expanded: appState.modeName === "expanded"
    readonly property bool compact: appState.modeName === "compact"
    readonly property bool hiddenMode: appState.modeName === "hidden"
    // Island rectangle in window coordinates; the platform layer turns it into the input region.
    readonly property rect islandRect: Qt.rect(island.x, island.y, island.width, island.height)
    readonly property var viewNames: ["overview", "empty", "approval", "question", "error", "finished", "confused",
                                      "upload", "uploading", "choose", "mail", "prompt", "searching", "result",
                                      "note", "settings", "greeting"]

    // 520 ms with a small overshoot to open, 340 ms without overshoot to close (SPEC §4 / IslandContainer).
    component MoveAnim: NumberAnimation {
        duration: controller.shrinking ? 340 : 520
        easing.type: Easing.BezierSpline
        easing.bezierCurve: controller.shrinking ? [0.45, 0.0, 0.2, 1.0, 1.0, 1.0] : [0.32, 1.22, 0.42, 1.0, 1.0, 1.0]
    }

    Keys.onEscapePressed: controller.escapePressed()

    HoverHandler { onHoveredChanged: controller.setPointerInside(hovered) }

    Rectangle {
        id: island
        objectName: "island"
        x: (root.width - width) / 2
        y: 0
        width: controller.islandWidth
        height: controller.islandHeight
        color: "#000000"
        topLeftRadius: 0
        topRightRadius: 0
        bottomLeftRadius: controller.cornerRadius
        bottomRightRadius: controller.cornerRadius
        opacity: root.hiddenMode ? 0 : 1

        Behavior on width { MoveAnim {} }
        Behavior on height { MoveAnim {} }
        Behavior on bottomLeftRadius { MoveAnim {} }
        Behavior on bottomRightRadius { MoveAnim {} }
        Behavior on opacity { NumberAnimation { duration: 200 } }

        TapHandler {
            onTapped: {
                root.forceActiveFocus()
                if (root.expanded)
                    controller.requestKeyboard(true)   // clicking the open island lets it receive keys (Esc)
                controller.islandClicked()
            }
        }

        // Header + views, only while open.
        Item {
            id: content
            anchors.fill: parent
            opacity: root.expanded ? 1 : 0
            visible: opacity > 0.001
            Behavior on opacity { NumberAnimation { duration: root.expanded ? 200 : 120 } }

            IslandHeader {
                id: header
                objectName: "header"
                x: 0
                y: 8
                width: parent.width
                opacity: appState.viewName === "confused" ? 0 : 1
                Behavior on opacity { NumberAnimation { duration: 200 } }
            }

            Item {
                id: views
                x: 10
                y: 42
                width: parent.width - 20
                height: Math.max(0, parent.height - 42 - 10)
                Repeater {
                    model: root.viewNames
                    ViewPlaceholder {
                        required property string modelData
                        objectName: "view-" + modelData
                        anchors.fill: parent
                        viewName: modelData
                        active: appState.viewName === modelData
                    }
                }
            }
        }

        CountdownBar { objectName: "countdownBar" }

        // Compact: mini dots to the right of the notch.
        CompactGrid {
            x: island.width - 40 - width / 2
            y: (island.height - height) / 2
            opacity: root.compact ? 1 : 0
            visible: opacity > 0.001
            Behavior on opacity { NumberAnimation { duration: 250 } }
        }
    }

    // Provisional Mochi (L1b replaces it): a cream circle riding the bot placement of the current view.
    Rectangle {
        id: bot
        objectName: "bot"
        readonly property real d: controller.botDiameter
        width: d
        height: d
        radius: d / 2
        x: island.x + controller.botX - d / 2
        y: controller.botY - d / 2
        color: "#EFE6DD"
        opacity: controller.botOpacity * (root.hiddenMode ? 0 : 1)
        visible: opacity > 0.001 && d > 0
        Behavior on x { MoveAnim {} }
        Behavior on y { MoveAnim {} }
        Behavior on width { MoveAnim {} }
        Behavior on height { MoveAnim {} }
        Behavior on opacity { NumberAnimation { duration: 200 } }
    }

    // Provisional greeting: the real animation calls controller.greetComplete() when it ends (~4.6 s).
    Timer {
        interval: 4600
        running: root.expanded && appState.viewName === "greeting"
        onTriggered: controller.greetComplete()
    }
}
```

- [ ] **Step 4: Rodar e ver passar**

Run:
```sh
linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: `100% tests passed, 0 tests failed out of 8`. Se o QML acusar erro de sintaxe/propriedade, corrija seguindo a mensagem do `QQuickView::errors()` (o `QVERIFY2` do `init()` mostra que falhou; rode `QT_QPA_PLATFORM=offscreen linux/build/tests/tst_island_qml` para ver o erro do QML) e registre *Rulings* para desvios.

- [ ] **Step 5: Commit**

```bash
git add linux/qml linux/tests
git commit -m "linux: QML island shell, header, provisional views and offscreen tests

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 7: Janela layer-shell, bandeja e o executável `coucou`

**Files:**
- Create: `linux/src/platform/IslandWindow.h`, `linux/src/platform/IslandWindow.cpp`, `linux/src/platform/Tray.h`, `linux/src/platform/Tray.cpp`, `linux/src/app/CMakeLists.txt`, `linux/src/app/main.cpp`, `linux/resources/fr.louisraille.NotchBuddy.desktop`
- Modify: `linux/CMakeLists.txt`, `linux/src/platform/CMakeLists.txt`

**Interfaces:**
- Consumes: `AppState`, `IslandController`, `QtScheduler`, `SoundEngine`, `Paths`, os QML do Task 6 (via recursos `qrc:/qml/`), ícone `NotchBuddy/Assets.xcassets/AppIcon.appiconset/icon_32x32@2x.png`.
- Produces: `coucou::IslandWindow(AppState*, IslandController*, QQmlEngine*, QObject* = nullptr)` com `show()`; `coucou::Tray(AppState*, IslandController*, QObject* = nullptr)`; executável `coucou` em `linux/build/src/app/coucou`.

Comportamento (do L0): janela layer-shell overlay, âncora topo, 720×320, zona exclusiva −1, teclado `None`, tela primária; região de entrada = retângulo da ilha ± 6 px (recortado à janela) ou, com a ilha escondida, uma faixa de 3 px na largura do notch (± 6 px); o teclado passa a `OnDemand` só quando o controlador pedir.

- [ ] **Step 1: CMake do app e da plataforma**

`linux/CMakeLists.txt` (substituir o bloco de `find_package` e `add_subdirectory`):
```cmake
cmake_minimum_required(VERSION 3.25)
project(Coucou VERSION 0.1 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

find_package(Qt6 6.8 REQUIRED COMPONENTS Core Gui Quick QuickControls2 Multimedia DBus Network Test)
find_package(LayerShellQt REQUIRED)
find_package(KF6StatusNotifierItem REQUIRED)
qt_standard_project_setup(REQUIRES 6.8)

option(COUCOU_BUILD_SPIKES "Build the L0 Wayland probes" ON)

enable_testing()
add_subdirectory(src/core)
add_subdirectory(src/platform)
add_subdirectory(src/app)
add_subdirectory(tests)
if(COUCOU_BUILD_SPIKES)
    add_subdirectory(spikes)
endif()
```

`linux/src/platform/CMakeLists.txt`:
```cmake
add_library(coucou_platform STATIC
    SoundEngine.h SoundEngine.cpp
    IslandWindow.h IslandWindow.cpp
    Tray.h Tray.cpp
)
target_include_directories(coucou_platform PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(coucou_platform PUBLIC
    coucou_core Qt6::Gui Qt6::Quick Qt6::Multimedia LayerShellQt::Interface KF6::StatusNotifierItem)
```

`linux/src/app/CMakeLists.txt`:
```cmake
qt_add_executable(coucou main.cpp)

# QML and the tray icon are compiled into the executable.
set_source_files_properties("${CMAKE_SOURCE_DIR}/../NotchBuddy/Assets.xcassets/AppIcon.appiconset/icon_32x32@2x.png"
    PROPERTIES QT_RESOURCE_ALIAS coucou.png)
qt_add_resources(coucou "coucou_qml"
    PREFIX "/qml"
    BASE "${CMAKE_SOURCE_DIR}/qml"
    FILES
        ${CMAKE_SOURCE_DIR}/qml/Island.qml
        ${CMAKE_SOURCE_DIR}/qml/IslandHeader.qml
        ${CMAKE_SOURCE_DIR}/qml/HeaderTab.qml
        ${CMAKE_SOURCE_DIR}/qml/IconGlyph.qml
        ${CMAKE_SOURCE_DIR}/qml/ViewPlaceholder.qml
        ${CMAKE_SOURCE_DIR}/qml/CountdownBar.qml
        ${CMAKE_SOURCE_DIR}/qml/CompactGrid.qml)
qt_add_resources(coucou "coucou_icons"
    PREFIX "/icons"
    FILES "${CMAKE_SOURCE_DIR}/../NotchBuddy/Assets.xcassets/AppIcon.appiconset/icon_32x32@2x.png")

target_compile_definitions(coucou PRIVATE
    COUCOU_SOUNDS_DIR="${CMAKE_SOURCE_DIR}/../NotchBuddy/Resources/sounds")
target_link_libraries(coucou PRIVATE coucou_platform coucou_core Qt6::Quick)
```
> Nota: se `QT_RESOURCE_ALIAS` não pegar por causa do caminho relativo (`..`), copie o PNG com `configure_file(... COPYONLY)` para `${CMAKE_CURRENT_BINARY_DIR}/coucou.png` e use esse arquivo em `FILES`; registre a troca como *Ruling*.

`linux/resources/fr.louisraille.NotchBuddy.desktop`:
```ini
[Desktop Entry]
Type=Application
Name=Coucou
Comment=Mochi lives in the notch and watches your Claude Code sessions
Exec=coucou
Icon=fr.louisraille.NotchBuddy
Terminal=false
Categories=Utility;Development;
X-KDE-StartupNotify=false
```

- [ ] **Step 2: `IslandWindow`**

`linux/src/platform/IslandWindow.h`:
```cpp
#pragma once
#include <QObject>
#include <QQuickView>

class QQmlEngine;

namespace coucou {

class AppState;
class IslandController;

// The 720x320 transparent layer-shell surface hung from the top centre of the primary screen.
// It owns the two Wayland knobs measured in L0: the input region (clicks outside the island fall
// through) and the keyboard mode (None by default, OnDemand only when the controller asks).
class IslandWindow : public QObject {
    Q_OBJECT
public:
    IslandWindow(AppState *state, IslandController *controller, QQmlEngine *engine, QObject *parent = nullptr);
    void show();
    bool ok() const { return m_ok; }

private slots:
    void updateMask();
    void applyKeyboard(bool onDemand);

private:
    AppState *m_state;
    IslandController *m_controller;
    QQuickView m_view;
    QQuickItem *m_root = nullptr;
    bool m_ok = false;
};

} // namespace coucou
```

`linux/src/platform/IslandWindow.cpp`:
```cpp
#include "IslandWindow.h"

#include "AppState.h"
#include "IslandController.h"

#include <LayerShellQt/Window>
#include <QGuiApplication>
#include <QQmlEngine>
#include <QQuickItem>
#include <QRegion>
#include <QSurfaceFormat>

namespace coucou {

IslandWindow::IslandWindow(AppState *state, IslandController *controller, QQmlEngine *engine, QObject *parent)
    : QObject(parent), m_state(state), m_controller(controller), m_view(engine, nullptr)
{
    QSurfaceFormat fmt = m_view.format();
    fmt.setAlphaBufferSize(8);
    m_view.setFormat(fmt);
    m_view.setColor(Qt::transparent);
    m_view.setSource(QUrl(QStringLiteral("qrc:/qml/Island.qml")));
    m_root = m_view.rootObject();
    if (!m_root || m_view.status() != QQuickView::Ready)
        return;

    // Layer-shell role: must be configured before the first show() (L0 lesson).
    auto *layer = LayerShellQt::Window::get(&m_view);
    layer->setLayer(LayerShellQt::Window::LayerOverlay);
    layer->setAnchors(LayerShellQt::Window::AnchorTop);
    layer->setExclusiveZone(-1);
    layer->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityNone);
    layer->setScope(QStringLiteral("coucou"));
    m_view.setScreen(QGuiApplication::primaryScreen());

    connect(m_root, SIGNAL(islandRectChanged()), this, SLOT(updateMask()));
    connect(m_state, &AppState::modeChanged, this, &IslandWindow::updateMask);
    connect(m_state, &AppState::notchChanged, this, &IslandWindow::updateMask);
    connect(m_controller, &IslandController::keyboardOnDemandChanged, this, &IslandWindow::applyKeyboard);
    updateMask();
    m_ok = true;
}

void IslandWindow::show()
{
    if (m_ok)
        m_view.show();
}

void IslandWindow::updateMask()
{
    if (!m_root)
        return;
    QRect rect;
    if (m_state->mode() == IslandMode::Hidden) {
        // Invisible island: only a 3 px strip at the top centre reacts (L0 finding 5).
        const qreal nw = m_state->notchWidth();
        rect = QRectF((m_view.width() - nw) / 2, 0, nw, 3).toAlignedRect();
    } else {
        rect = m_root->property("islandRect").toRectF().toAlignedRect();
    }
    // 6 px of slack around the island, like the macOS hit test, clipped to the window.
    rect = rect.adjusted(-6, -6, 6, 6).intersected(QRect(QPoint(0, 0), m_view.size()));
    m_view.setMask(QRegion(rect));
}

void IslandWindow::applyKeyboard(bool onDemand)
{
    auto *layer = LayerShellQt::Window::get(&m_view);
    layer->setKeyboardInteractivity(onDemand ? LayerShellQt::Window::KeyboardInteractivityOnDemand
                                             : LayerShellQt::Window::KeyboardInteractivityNone);
}

} // namespace coucou
```

- [ ] **Step 3: `Tray`**

`linux/src/platform/Tray.h`:
```cpp
#pragma once
#include <QObject>

class KStatusNotifierItem;
class QMenu;

namespace coucou {

class AppState;
class IslandController;

// System tray icon with the same menu as the Mac menu bar item plus a Debug submenu.
class Tray : public QObject {
    Q_OBJECT
public:
    Tray(AppState *state, IslandController *controller, QObject *parent = nullptr);
    ~Tray() override;

private:
    KStatusNotifierItem *m_item = nullptr;
    QMenu *m_menu = nullptr;
};

} // namespace coucou
```

`linux/src/platform/Tray.cpp`:
```cpp
#include "Tray.h"

#include "AppState.h"
#include "IslandController.h"

#include <KStatusNotifierItem>
#include <QAction>
#include <QGuiApplication>
#include <QIcon>
#include <QMenu>

namespace coucou {

Tray::Tray(AppState *state, IslandController *controller, QObject *parent) : QObject(parent)
{
    m_item = new KStatusNotifierItem(QStringLiteral("fr.louisraille.NotchBuddy"), this);
    m_item->setCategory(KStatusNotifierItem::ApplicationStatus);
    m_item->setStatus(KStatusNotifierItem::Active);
    m_item->setTitle(QStringLiteral("Coucou"));
    m_item->setIconByPixmap(QIcon(QStringLiteral(":/icons/coucou.png")));
    m_item->setStandardActionsEnabled(false);

    m_menu = new QMenu;
    m_menu->addAction(QStringLiteral("Open Coucou"), this, [controller] { controller->expand(controller->defaultView()); });
    m_menu->addSeparator();
    auto *settings = m_menu->addAction(QStringLiteral("Settings…"));
    settings->setEnabled(false);   // the settings window arrives in L6
    m_menu->addSeparator();

    QMenu *debug = m_menu->addMenu(QStringLiteral("Debug"));
    QMenu *modes = debug->addMenu(QStringLiteral("Mode"));
    for (IslandMode m : {IslandMode::Hidden, IslandMode::Compact, IslandMode::Expanded})
        modes->addAction(enumKey(m), this, [controller, m] { controller->setMode(m); });
    QMenu *views = debug->addMenu(QStringLiteral("View"));
    for (int v = 0; v <= int(IslandView::Greeting); ++v) {
        const IslandView view = IslandView(v);
        views->addAction(enumKey(view), this, [controller, view] { controller->expand(view); });
    }
    debug->addAction(QStringLiteral("Launch greeting"), this, [controller] { controller->launch(); });
    debug->addAction(QStringLiteral("Toggle sound"), this, [state] { state->setSoundEnabled(!state->soundEnabled()); });

    m_menu->addSeparator();
    m_menu->addAction(QStringLiteral("Quit"), qApp, &QCoreApplication::quit);
    m_item->setContextMenu(m_menu);
}

Tray::~Tray()
{
    delete m_menu;
}

} // namespace coucou
```

- [ ] **Step 4: `main.cpp`**

`linux/src/app/main.cpp`:
```cpp
#include "AppState.h"
#include "IslandController.h"
#include "IslandWindow.h"
#include "Paths.h"
#include "Scheduler.h"
#include "SoundEngine.h"
#include "Tray.h"

#include <QDateTime>
#include <QDir>
#include <QFileInfo>
#include <QGuiApplication>
#include <QQmlContext>
#include <QQmlEngine>
#include <QSettings>

using namespace coucou;

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("coucou"));
    app.setDesktopFileName(QStringLiteral("fr.louisraille.NotchBuddy"));
    app.setQuitOnLastWindowClosed(false);

    QDir().mkpath(QFileInfo(Paths::configFile()).absolutePath());
    QSettings settings(Paths::configFile(), QSettings::IniFormat);

    AppState state(&settings);
    QtScheduler scheduler;
    IslandController controller(&state, &scheduler, [] { return QDateTime::currentMSecsSinceEpoch(); });

    SoundEngine sound(qEnvironmentVariable("COUCOU_SOUNDS_DIR", QStringLiteral(COUCOU_SOUNDS_DIR)));
    sound.setEnabled(state.soundEnabled());
    sound.setVolume(state.soundVolume());
    QObject::connect(&state, &AppState::soundEnabledChanged, &sound, [&] { sound.setEnabled(state.soundEnabled()); });
    QObject::connect(&state, &AppState::soundVolumeChanged, &sound, [&] { sound.setVolume(state.soundVolume()); });
    QObject::connect(&controller, &IslandController::playSound, &sound, &SoundEngine::play);

    QQmlEngine engine;
    engine.rootContext()->setContextProperty(QStringLiteral("appState"), &state);
    engine.rootContext()->setContextProperty(QStringLiteral("controller"), &controller);

    IslandWindow window(&state, &controller, &engine);
    if (!window.ok()) {
        qCritical("Could not load qrc:/qml/Island.qml");
        return 1;
    }
    Tray tray(&state, &controller);

    window.show();
    controller.launch();   // greeting -> compact, like the Mac app on launch
    return app.exec();
}
```

- [ ] **Step 5: Compilar e conferir que os testes seguem verdes**

Run:
```sh
linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: build sem warnings; `100% tests passed, 0 tests failed out of 8`; existe `linux/build/src/app/coucou`.

- [ ] **Step 6: Checagem 👤 — rodar o app**

No Konsole do João: `cd ~/src/farol && linux/build/src/app/coucou`. Pedir, uma a uma, e registrar SIM/NÃO + observação:
1. Ao abrir, aparece a ilha grande (640×150) com um cartão "greeting", toca o som `open`, e depois de ~5 s ela encolhe sozinha para a pílula compacta (344×32) com um círculo creme à esquerda e bolinhas coloridas à direita?
2. Passar o mouse na pílula compacta **não** abre; **clicar** abre a visão geral (640×160) com os três ícones à esquerda e engrenagem + alto-falante à direita, e o cartão "overview"? A abertura tem um leve "passar do ponto"?
3. Com a ilha aberta e o mouse fora dela, ela recolhe sozinha depois de ~15 s? Uma barra branca fina aparece embaixo, no centro, nos últimos ~9 s?
4. Clicar na ilha aberta e apertar `Esc` fecha? Com a ilha aberta e sem clicar nela, digitar em outra janela continua indo para ela?
5. Clicar logo abaixo da ilha (compacta e aberta) atinge a janela de baixo?
6. Ícone na bandeja aparece? O menu tem Open, Settings (cinza), Debug ▸ (Mode, View, Launch greeting, Toggle sound) e Quit? Trocar de View pelo Debug muda o cartão e a altura (ex.: `mail` = 240, `upload` = 176)?
7. Deixar a pílula compacta parada por 60 s: ela some? Encostar o mouse no topo, no centro: ela reaparece com o som `peek`?

Se algo falhar, corrigir (com teste automatizado quando for lógica; *Ruling* quando for só visual) antes do commit.

- [ ] **Step 7: Commit**

```bash
git add linux/CMakeLists.txt linux/src linux/resources
git commit -m "linux: coucou app — layer-shell island window, tray and sound wiring

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 8: Comparar com as capturas, medir CPU/memória e registrar

**Files:**
- Create: `linux/docs/L1a-notes.md`

**Interfaces:**
- Consumes: `linux/build/src/app/coucou`, `linux/scripts/measure.sh`, `design/captures/02_compact.png`, `design/captures/03_overview.png`, `design/captures/01_peek.png`.
- Produces: `linux/docs/L1a-notes.md` (entrada do plano do L1b).

- [ ] **Step 1: Capturas (agente)**

Com o app rodando (`linux/build/src/app/coucou` em segundo plano, como no L0), esperar o estado compacto e capturar; abrir `overview` pelo menu de bandeja (👤 o João clica) ou pelo clique na pílula e capturar de novo:
```sh
linux/scripts/host.sh spectacle -b -n -f -o "$PWD/linux/build/l1a-compact.png"
linux/scripts/host.sh spectacle -b -n -f -o "$PWD/linux/build/l1a-overview.png"
```
Recortar o topo com Pillow (`linux/scripts/host.sh python3 -c "from PIL import Image; ..."`, recorte `(660, 0, 1260, 200)`) e ler as imagens (`Read`) lado a lado com `design/captures/02_compact.png` e `03_overview.png`. Anotar, em `L1a-notes.md`, as diferenças de **forma, tamanho, posição, cantos e proporções** (o Mochi e o conteúdo real ainda não existem; não conte isso como diferença).

- [ ] **Step 2: CPU e memória (agente + 👤)**

```sh
PID=$(linux/scripts/host.sh pgrep -x coucou)
# 1) ilha escondida: usar o menu Debug > Mode > hidden, esperar 5 s
linux/scripts/host.sh linux/scripts/measure.sh "$PID" 20
# 2) compacta parada
linux/scripts/host.sh linux/scripts/measure.sh "$PID" 20
# 3) expandida parada (menu Debug > View > overview)
linux/scripts/host.sh linux/scripts/measure.sh "$PID" 20
```
Metas (SPEC §12): escondida ≈ 0 %; compacta < 3 %; memória PSS < 100 MB. Se a escondida não ficar perto de 0 %, investigue (timer do `CountdownBar` só roda expandida; `Behavior`s não devem rodar parados) e corrija antes de seguir.

- [ ] **Step 3: Escrever `linux/docs/L1a-notes.md`**

Estrutura fixa (preencher com o que foi observado, sem "a verificar"):
```markdown
# L1a — notas (casca da ilha)

## Checagens manuais (Task 7, Step 6)
| # | Comportamento | Resultado | Observação |
|---|---|---|---|
| 1 | Saudação abre e recolhe sozinha | | |
| 2 | Clique abre; hover não abre; overshoot | | |
| 3 | Recolhe em ~15 s; barra de contagem | | |
| 4 | Esc; teclado não é roubado | | |
| 5 | Cliques atravessam abaixo da ilha | | |
| 6 | Bandeja e menu Debug | | |
| 7 | 60 s → some; topo → peek com som | | |

## Comparação com design/captures
(diferenças de forma/tamanho/posição/cantos; o que ficou igual)

## Medições
| Estado | CPU % | PSS MB |
|---|---|---|
| escondida | | |
| compacta parada | | |
| expandida parada | | |

## Pendências para L1b/L1c
(provisórios a trocar: círculo creme, cartões, ícones; recorte arredondado do conteúdo; ...)
```

- [ ] **Step 4: Suíte completa e commit**

Run:
```sh
linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
git add linux/docs/L1a-notes.md
git commit -m "linux: L1a notes — capture comparison and measurements

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```
Expected: `100% tests passed, 0 tests failed out of 8`.

---

## Depois do L1a

O plano do **L1b (Mochi)** é escrito a partir do `L1a-notes.md`: port de `BotEngine.swift` (1503 linhas) para C++ com `QPainter`, `MochiItem`, mini-Mochis, halo e a animação de saudação (`GreetingCanvasView.swift`).
