#include "Shortcuts.h"

#include <QSettings>

namespace farol {

namespace {
const char *const kKeys[2] = {"shortcuts/toggle", "shortcuts/jump"};
const char *const kActions[2] = {"toggle", "jump"};
constexpr int kModifiers = int(Qt::ShiftModifier | Qt::ControlModifier | Qt::AltModifier | Qt::MetaModifier);

bool isModifierKey(int key)
{
    switch (key) {
    case Qt::Key_Shift: case Qt::Key_Control: case Qt::Key_Meta: case Qt::Key_Alt: case Qt::Key_AltGr:
    case Qt::Key_Super_L: case Qt::Key_Super_R: case Qt::Key_Hyper_L: case Qt::Key_Hyper_R:
    case Qt::Key_CapsLock: case Qt::Key_NumLock: case Qt::Key_ScrollLock: case Qt::Key_unknown: case 0:
        return true;
    }
    return false;
}
} // namespace

Shortcuts::Shortcuts(QSettings *settings, Bind bind, QObject *parent)
    : QObject(parent), m_settings(settings), m_bind(std::move(bind))
{
    for (int i = 0; i < 2 && m_settings; ++i)
        m_combo[i] = qMax(0, m_settings->value(kKeys[i], 0).toInt());
}

int Shortcuts::indexOf(const QString &action)
{
    for (int i = 0; i < 2; ++i)
        if (action == QLatin1String(kActions[i]))
            return i;
    return -1;
}

int Shortcuts::combo(const QString &action) const
{
    const int i = indexOf(action);
    return i < 0 ? 0 : m_combo[i];
}

void Shortcuts::restore()
{
    for (int i = 0; i < 2; ++i) {
        if (m_combo[i] == 0)
            continue;
        m_label[i] = m_bind ? m_bind(QLatin1String(kActions[i]), m_combo[i]) : QString();
        if (m_label[i].isEmpty())
            m_combo[i] = 0;        // taken by another program since it was saved: shown as none, kept in the file
    }
    emit changed();
}

void Shortcuts::fail(const QString &why)
{
    m_error = why;
    emit changed();
}

bool Shortcuts::assign(const QString &action, int key, int modifiers)
{
    const int i = indexOf(action);
    if (i < 0 || isModifierKey(key))
        return false;
    modifiers &= kModifiers;
    const bool functionKey = key >= Qt::Key_F1 && key <= Qt::Key_F35;
    if (key == Qt::Key_Escape || (!functionKey && !(modifiers & ~int(Qt::ShiftModifier)))) {
        fail(QStringLiteral("Use Ctrl, Alt ou Meta com outra tecla"));
        return false;
    }
    const int combo = key | modifiers;
    if (combo == m_combo[1 - i]) {
        fail(QStringLiteral("Já é o outro atalho do Farol"));
        return false;
    }
    const QString label = m_bind ? m_bind(action, combo) : QString();
    if (label.isEmpty()) {
        fail(QStringLiteral("Essas teclas já têm dono no sistema"));
        return false;
    }
    m_combo[i] = combo;
    m_label[i] = label;
    m_error.clear();
    if (m_settings) {
        m_settings->setValue(kKeys[i], combo);
        m_settings->sync();
    }
    emit changed();
    return true;
}

void Shortcuts::clear(const QString &action)
{
    const int i = indexOf(action);
    if (i < 0)
        return;
    if (m_bind)
        m_bind(action, 0);
    m_combo[i] = 0;
    m_label[i].clear();
    m_error.clear();
    if (m_settings) {
        m_settings->setValue(kKeys[i], 0);
        m_settings->sync();
    }
    emit changed();
}

void Shortcuts::clearError()
{
    if (m_error.isEmpty())
        return;
    m_error.clear();
    emit changed();
}

} // namespace farol
