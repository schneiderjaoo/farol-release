import QtQuick

// Settings, a view of the island (never a window of its own): the pages on the left (a row on top in the portrait
// island), the options of the chosen page beside them, each with a line saying what it does. What does not fit
// scrolls. Every change applies at once and is saved.
Item {
    id: settings
    readonly property bool narrow: width < 420   // the portrait island: pages on top, each option stacked
    property string page: "island"        // island | sessions | ai | keys | about; back to the first each time the view opens
    property string capturing: ""         // the shortcut waiting for a key press: "toggle", "jump" or none

    function startCapture(action) {
        shortcuts.clearError()
        capturing = action
        controller.requestKeyboard(true)      // the island only gets keys when asked
        keyCatcher.forceActiveFocus()
    }
    function stopCapture() { capturing = "" }
    function hooksText(state) {
        return state === "installed" ? "Hooks do Claude Code: instalados."
             : state === "outdated" ? "Hooks do Claude Code: precisam de atualização. Na bandeja: Claude Code hooks → Install…"
             : "Hooks do Claude Code: não instalados. Na bandeja: Claude Code hooks → Install…"
    }
    onPageChanged: stopCapture()
    Connections {   // leaving Settings: the first page again on the next visit, and no key press is waited for
        target: appState
        function onViewChanged() { if (appState.viewName !== "settings") { settings.stopCapture(); settings.page = "island" } }
    }

    Card { anchors.fill: parent }

    // Catches the key press for a shortcut being defined.
    Item {
        id: keyCatcher
        objectName: "shortcutCatcher"
        readonly property bool keepsKeyboard: settings.capturing !== ""   // Island.qml leaves the focus here meanwhile
        function press(key, modifiers) {
            if (settings.capturing === "")
                return false
            if (key === Qt.Key_Escape) {
                settings.stopCapture()
                return true
            }
            if (shortcuts.assign(settings.capturing, key, modifiers))
                settings.stopCapture()
            return true
        }
        Keys.onPressed: (event) => { event.accepted = press(event.key, event.modifiers) }
    }

    // One option: its name and what it does on the left, its controls on the right (they wrap when there are many);
    // in the narrow layout the controls go under the text.
    component Option: Item {
        id: opt
        property string label: ""
        property string help: ""
        property string helpName: ""      // objectName of the explanation, for the tests
        default property alias controls: flow.data
        width: parent ? parent.width : 0
        height: settings.narrow ? texts.height + 6 + flow.height : Math.max(texts.height, flow.height)
        Column {
            id: texts
            width: settings.narrow ? opt.width : Math.min(220, opt.width * 0.46)
            spacing: 2
            Text {
                width: parent.width
                elide: Text.ElideRight
                textFormat: Text.PlainText
                text: opt.label
                color: theme.text
                font.family: theme.bodyFont
                font.pixelSize: 13
                font.weight: Font.Medium
            }
            Text {
                objectName: opt.helpName
                width: parent.width
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                text: opt.help
                color: theme.dim
                font.family: theme.bodyFont
                font.pixelSize: 11
            }
        }
        Flow {
            id: flow
            x: settings.narrow ? 0 : texts.width + 16
            y: settings.narrow ? texts.height + 6 : 0
            width: opt.width - x
            spacing: 8
        }
    }

    component SideItem: Rectangle {
        id: side
        property string label: ""
        property bool primary: false
        signal clicked()
        width: settings.narrow ? sideLabel.implicitWidth + 20 : (parent ? parent.width : 0)
        height: 28
        radius: 8
        color: primary ? theme.pillFill : (sideHover.hovered ? theme.hoverFill : "transparent")
        Text {
            id: sideLabel
            x: 10
            anchors.verticalCenter: parent.verticalCenter
            textFormat: Text.PlainText
            text: side.label
            color: side.primary ? theme.text : theme.muted
            font.family: theme.bodyFont
            font.pixelSize: 13
            font.weight: side.primary ? Font.Medium : Font.Normal
        }
        HoverHandler { id: sideHover }
        TapHandler { onTapped: side.clicked() }
    }

    Flow {
        id: sidebar
        x: 10
        y: 10
        width: settings.narrow ? parent.width - 20 : 96
        spacing: 3
        Repeater {
            model: [{key: "island", label: "Ilha"}, {key: "sessions", label: "Sessões"}, {key: "ai", label: "IA"}, {key: "keys", label: "Atalhos"}, {key: "about", label: "Sobre"}]
            SideItem {
                required property var modelData
                objectName: "settingsTab" + modelData.key.charAt(0).toUpperCase() + modelData.key.slice(1)
                label: modelData.label
                primary: settings.page === modelData.key
                onClicked: settings.page = modelData.key
            }
        }
    }
    Rectangle { visible: !settings.narrow; x: 114; y: 10; width: 1; height: parent.height - 20; color: theme.line }

    Flickable {
        id: pane
        objectName: "settingsPane"
        x: settings.narrow ? 12 : 128
        y: settings.narrow ? sidebar.y + sidebar.height + 10 : 12
        width: parent.width - x - 12
        height: parent.height - y - 12
        contentHeight: pages.height
        clip: true
        boundsBehavior: Flickable.StopAtBounds

        Column {
            id: pages
            width: pane.width

            Column {
                objectName: "settingsPageIsland"
                width: parent.width
                spacing: 14
                visible: settings.page === "island"
                Option {
                    label: "Tema"
                    helpName: "helpTheme"
                    help: 'Cores da ilha. "Sistema" acompanha o tema claro ou escuro do sistema.'
                    Repeater {
                        model: [{key: "system", label: "Sistema"}, {key: "dark", label: "Escuro"}, {key: "light", label: "Claro"}]
                        PillButton {
                            required property var modelData
                            objectName: "theme" + modelData.key.charAt(0).toUpperCase() + modelData.key.slice(1)
                            text: modelData.label
                            primary: appState.themeMode === modelData.key
                            onClicked: appState.themeMode = modelData.key
                        }
                    }
                }
                Option {
                    label: "Posição"
                    helpName: "helpEdge"
                    help: "Borda da tela onde a ilha fica. Nas laterais ela vira uma coluna."
                    Repeater {
                        model: [{key: "top", label: "Topo"}, {key: "bottom", label: "Baixo"}, {key: "left", label: "Esquerda"}, {key: "right", label: "Direita"}]
                        PillButton {
                            required property var modelData
                            objectName: "edge" + modelData.key.charAt(0).toUpperCase() + modelData.key.slice(1)
                            text: modelData.label
                            primary: appState.edge === modelData.key
                            onClicked: appState.edge = modelData.key
                        }
                    }
                }
                Option {
                    label: "Recolher após"
                    helpName: "helpAutoClose"
                    help: "Tempo que a ilha aberta espera, depois que o mouse sai dela, para voltar ao modo pequeno. Um pedido de permissão ou uma pergunta ficam até a resposta."
                    Repeater {
                        model: [5, 10, 15]
                        PillButton {
                            required property int modelData
                            objectName: "autoClose" + modelData
                            text: modelData + " s"
                            primary: appState.autoCloseInterval === modelData
                            onClicked: appState.autoCloseInterval = modelData
                        }
                    }
                }
                Option {
                    label: "Esconder sem uso"
                    helpName: "helpAutoHide"
                    help: "A ilha pequena some da tela depois de um tempo sem uso e volta no próximo evento de uma sessão."
                    ToggleSwitch {
                        objectName: "autoHideSwitch"
                        checked: appState.autoHide
                        onToggled: appState.autoHide = checked
                    }
                }
                Option {
                    label: "Reduzir movimento"
                    helpName: "helpReduceMotion"
                    help: "Para as animações da ilha: o Lumi e os barcos ficam parados."
                    ToggleSwitch {
                        objectName: "reduceMotionSwitch"
                        checked: appState.reduceMotion
                        onToggled: appState.reduceMotion = checked
                    }
                }
                Option {
                    label: "Sons"
                    helpName: "helpSound"
                    help: "Liga ou desliga todos os sons do Farol: avisos, lembretes e término."
                    ToggleSwitch {
                        objectName: "soundSwitch"
                        checked: appState.soundEnabled
                        onToggled: appState.soundEnabled = checked
                    }
                }
            }

            Column {
                objectName: "settingsPageSessions"
                width: parent.width
                spacing: 14
                visible: settings.page === "sessions"
                Option {
                    label: "Ocultar inativas"
                    helpName: "helpSessionIdle"
                    help: "Tempo que uma sessão parada ou concluída continua na lista da ilha. Ela volta no próximo evento; uma sessão fechada sai na hora."
                    Repeater {
                        model: [{secs: 30, label: "30 s"}, {secs: 120, label: "2 min"}, {secs: 600, label: "10 min"}, {secs: 0, label: "Nunca"}]
                        PillButton {
                            required property var modelData
                            objectName: "sessionIdle" + modelData.secs
                            text: modelData.label
                            primary: appState.sessionIdleSeconds === modelData.secs
                            onClicked: appState.sessionIdleSeconds = modelData.secs
                        }
                    }
                }
                Option {
                    label: "Lembrar espera"
                    helpName: "helpWaitReminder"
                    help: "Uma sessão que espera a sua resposta toca o som e abre a ilha de novo a cada intervalo, no máximo 5 vezes."
                    Repeater {
                        model: [{secs: 120, label: "2 min"}, {secs: 300, label: "5 min"}, {secs: 0, label: "Nunca"}]
                        PillButton {
                            required property var modelData
                            objectName: "waitReminder" + modelData.secs
                            text: modelData.label
                            primary: appState.waitReminderSeconds === modelData.secs
                            onClicked: appState.waitReminderSeconds = modelData.secs
                        }
                    }
                }
                Option {
                    label: "Notificar ausente"
                    helpName: "helpNotifyAway"
                    help: "Com a tela bloqueada ou o computador 2 minutos sem uso, os avisos da ilha também viram notificação do sistema."
                    ToggleSwitch {
                        objectName: "notifyAwaySwitch"
                        checked: appState.notifyAway
                        onToggled: appState.notifyAway = checked
                    }
                }
                Option {
                    id: workspaceOption
                    label: "Workspace"
                    helpName: "helpWorkspace"
                    help: 'Pasta onde ficam os seus repositórios. A aba "Nova sessão" lista os que estão nela.'
                    Text {
                        objectName: "workspacePath"
                        width: settings.narrow ? workspaceOption.width : workspaceOption.width - Math.min(220, workspaceOption.width * 0.46) - 16
                        height: 20
                        verticalAlignment: Text.AlignVCenter
                        elide: Text.ElideLeft   // the end of a path says the most
                        textFormat: Text.PlainText
                        text: appState.workspaceDir === "" ? "Nenhuma pasta" : appState.workspaceDirLabel
                        color: appState.workspaceDir === "" ? theme.muted : theme.text
                        font.family: theme.bodyFont
                        font.pixelSize: 13
                    }
                    PillButton {
                        objectName: "workspaceChoose"
                        text: "Escolher…"
                        onClicked: appState.chooseWorkspaceDir()
                    }
                    PillButton {
                        objectName: "workspaceClear"
                        visible: appState.workspaceDir !== ""
                        text: "Limpar"
                        onClicked: appState.workspaceDir = ""
                    }
                }
            }

            // The AI service the "Perguntar" tab talks to. The key goes to the desktop's secret service and is never shown
            // again; farol.conf only remembers that there is one.
            Column {
                objectName: "settingsPageAi"
                width: parent.width
                spacing: 14
                visible: settings.page === "ai"
                component Field: Rectangle {
                    id: box
                    property alias input: fieldInput
                    property string placeholder: ""
                    width: 190
                    height: 28
                    radius: 10
                    color: theme.codeBg
                    border.width: 1
                    border.color: fieldInput.activeFocus ? theme.primary : theme.line
                    TextInput {
                        id: fieldInput
                        anchors.fill: parent
                        anchors.leftMargin: 10
                        anchors.rightMargin: 10
                        verticalAlignment: TextInput.AlignVCenter
                        clip: true
                        color: theme.text
                        selectionColor: theme.primary
                        selectedTextColor: theme.primaryText
                        font.family: theme.bodyFont
                        font.pixelSize: 13
                        onActiveFocusChanged: if (activeFocus) controller.requestKeyboard(true)   // the island only gets keys when asked
                        Text {
                            anchors.fill: parent
                            verticalAlignment: Text.AlignVCenter
                            visible: fieldInput.text === "" && !fieldInput.activeFocus
                            textFormat: Text.PlainText
                            text: box.placeholder
                            color: theme.dim
                            font: fieldInput.font
                            elide: Text.ElideRight
                        }
                    }
                }
                Option {
                    label: "Serviço"
                    helpName: "helpAiProvider"
                    help: 'Quem responde na aba "Perguntar". Os arquivos e a pergunta são enviados a esse serviço, e a mais nenhum.'
                    Repeater {
                        model: ["claude", "anthropic", "openai", "gemini"]
                        PillButton {
                            required property string modelData
                            objectName: "aiProvider_" + modelData
                            text: ask.labelOf(modelData)
                            primary: ask.provider === modelData
                            onClicked: ask.provider = modelData
                        }
                    }
                }
                Option {
                    visible: !ask.needsKey
                    label: "Conta"
                    helpName: "helpAiAccount"
                    help: "Responde o Claude Code instalado nesta máquina, com a conta em que ele está aberto. Não precisa de chave, e as perguntas contam no limite de uso dessa conta."
                    Text {
                        objectName: "aiAccountState"
                        height: 28
                        verticalAlignment: Text.AlignVCenter
                        textFormat: Text.PlainText
                        text: ask.claudeFound ? "Claude Code encontrado" : "Claude Code não encontrado"
                        color: ask.claudeFound ? theme.text : theme.alertText
                        font.family: theme.bodyFont
                        font.pixelSize: 13
                    }
                }
                Option {
                    visible: ask.needsKey
                    label: "Chave de API"
                    helpName: "helpAiKey"
                    help: "A chave de " + ask.providerLabel + ". Fica guardada no cofre de senhas do sistema (KWallet ou GNOME Keyring), nunca num arquivo do Farol, e não é mostrada de novo."
                    Text {
                        objectName: "aiKeyState"
                        height: 28
                        verticalAlignment: Text.AlignVCenter
                        textFormat: Text.PlainText
                        text: ask.hasKey ? "Guardada" : "Nenhuma"
                        color: ask.hasKey ? theme.text : theme.muted
                        font.family: theme.bodyFont
                        font.pixelSize: 13
                    }
                    Field {
                        id: keyField
                        objectName: "aiKeyBox"
                        placeholder: ask.hasKey ? "Colar outra chave…" : "Colar a chave…"
                        input.objectName: "aiKeyField"
                        input.echoMode: TextInput.Password
                        input.onAccepted: keySave.clicked()
                    }
                    PillButton {
                        id: keySave
                        objectName: "aiKeySave"
                        text: "Guardar"
                        primary: keyField.input.text !== ""
                        onClicked: {
                            ask.saveKey(ask.provider, keyField.input.text)
                            keyField.input.text = ""
                        }
                    }
                    PillButton {
                        objectName: "aiKeyRemove"
                        visible: ask.hasKey
                        text: "Apagar"
                        onClicked: ask.removeKey(ask.provider)
                    }
                }
                Text {
                    objectName: "aiKeyError"
                    width: parent.width
                    visible: text !== ""
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: ask.keyError
                    color: theme.alertText
                    font.family: theme.bodyFont
                    font.pixelSize: 12
                }
                Option {
                    label: "Modelo"
                    helpName: "helpAiModel"
                    help: "O modelo de " + ask.providerLabel + " que responde: do mais rápido e barato ao mais capaz."
                    Repeater {
                        model: ask.models
                        PillButton {
                            required property var modelData
                            objectName: "aiModel_" + modelData.id
                            text: modelData.label
                            primary: ask.model === modelData.id
                            onClicked: ask.setModel(ask.provider, modelData.id)
                        }
                    }
                }
            }

            // System-wide keyboard shortcuts. "Definir…" waits for the next key press (with Ctrl, Alt or Meta, or a
            // function key); Esc gives up. The desktop registers them, so they work with any window in front.
            Column {
                objectName: "settingsPageKeys"
                width: parent.width
                spacing: 14
                visible: settings.page === "keys"
                Repeater {
                    model: [{action: "toggle", label: "Abrir a ilha", help: "Atalho que abre ou fecha a ilha, com qualquer janela na frente."},
                            {action: "jump", label: "Ir à que espera", help: "Atalho que leva à sessão que espera a sua resposta. Sem nenhuma à espera, vai à sessão em foco."}]
                    Option {
                        id: keyRow
                        required property var modelData
                        readonly property string current: modelData.action === "toggle" ? shortcuts.toggleKey : shortcuts.jumpKey
                        readonly property bool listening: settings.capturing === modelData.action
                        label: modelData.label
                        helpName: "helpShortcut_" + modelData.action
                        help: modelData.help
                        Text {
                            objectName: "shortcutKey_" + keyRow.modelData.action
                            width: 130
                            height: 28
                            verticalAlignment: Text.AlignVCenter
                            elide: Text.ElideRight
                            textFormat: Text.PlainText
                            text: keyRow.listening ? "Pressione as teclas…" : (keyRow.current !== "" ? keyRow.current : "Nenhum")
                            color: keyRow.listening ? theme.lamp : (keyRow.current !== "" ? theme.text : theme.muted)
                            font.family: theme.bodyFont
                            font.pixelSize: 13
                        }
                        PillButton {
                            objectName: "shortcutSet_" + keyRow.modelData.action
                            text: keyRow.listening ? "Cancelar" : "Definir…"
                            primary: keyRow.listening
                            onClicked: keyRow.listening ? settings.stopCapture() : settings.startCapture(keyRow.modelData.action)
                        }
                        PillButton {
                            objectName: "shortcutClear_" + keyRow.modelData.action
                            visible: keyRow.current !== "" && !keyRow.listening
                            text: "Limpar"
                            onClicked: shortcuts.clear(keyRow.modelData.action)
                        }
                    }
                }
                Text {
                    objectName: "shortcutError"
                    width: parent.width
                    visible: text !== ""
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: shortcuts.error
                    color: theme.alertText
                    font.family: theme.bodyFont
                    font.pixelSize: 12
                }
            }

            Column {
                objectName: "settingsPageAbout"
                width: parent.width
                spacing: 8
                visible: settings.page === "about"
                Text {
                    textFormat: Text.PlainText
                    text: "Farol"
                    color: theme.text
                    font.family: theme.titleFont
                    font.pixelSize: 22
                    font.weight: Font.Bold
                }
                Text {
                    objectName: "aboutVersion"
                    textFormat: Text.PlainText
                    text: "Versão " + Qt.application.version
                    color: theme.muted
                    font.family: theme.bodyFont
                    font.pixelSize: 13
                }
                Text {
                    objectName: "aboutHooks"
                    width: parent.width
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    // looked at when the page opens, never in the background
                    text: settings.page === "about" ? settings.hooksText(hooks.state()) : ""
                    color: theme.text
                    font.family: theme.bodyFont
                    font.pixelSize: 13
                }
            }
        }
    }
}
