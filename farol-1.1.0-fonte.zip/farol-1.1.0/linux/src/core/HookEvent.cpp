#include "HookEvent.h"

#include <QDir>
#include <QFileInfo>
#include <QJsonArray>
#include <QJsonDocument>
#include <QMap>
#include <QRegularExpression>
#include <QStringTokenizer>
#include <cmath>

namespace farol {

namespace {
QString str(const QJsonObject &o, const char *key)
{
    const QJsonValue v = o.value(QLatin1String(key));
    return v.isString() ? v.toString() : QString();
}

// A count of lines: a whole number that is not negative; -1 for anything else.
int count(const QJsonValue &v)
{
    const double n = v.toDouble(-1);
    return v.isDouble() && n >= 0 && n <= 100'000'000 && n == std::floor(n) ? int(n) : -1;
}
} // namespace

std::optional<HookEvent> HookEvent::parse(const QByteArray &line)
{
    QJsonParseError err;
    const QJsonDocument doc = QJsonDocument::fromJson(line, &err);
    if (err.error != QJsonParseError::NoError || !doc.isObject())
        return std::nullopt;
    const QJsonObject o = doc.object();
    HookEvent e;
    e.name = str(o, "hook_event_name");
    if (e.name.isEmpty())
        return std::nullopt;
    e.sessionId = str(o, "session_id");
    if (e.sessionId.isEmpty())
        e.sessionId = QStringLiteral("unknown");
    e.cwd = str(o, "cwd");
    e.transcriptPath = str(o, "transcript_path");
    e.source = str(o, "farol_source");
    e.flatpakId = str(o, "flatpak_id");
    e.editor = str(o, "farol_editor");
    for (const QJsonValue &v : o.value("farol_ancestors").toArray()) {
        const QJsonArray pair = v.toArray();
        const qint64 pid = qint64(pair.at(0).toDouble()), start = qint64(pair.at(1).toDouble());
        if (pid > 1 && start > 0 && e.ancestors.size() < 16)
            e.ancestors.append({pid, start});
    }
    e.konsoleService = str(o, "konsole_dbus_service");
    e.konsoleSession = str(o, "konsole_dbus_session");
    e.konsoleWindow = str(o, "konsole_dbus_window");
    e.toolName = str(o, "tool_name");
    if (o.value("tool_input").isObject())
        e.toolInput = o.value("tool_input").toObject();
    e.toolUseId = str(o, "tool_use_id");
    if (o.value("tool_response").isObject())
        e.toolResponse = o.value("tool_response").toObject();
    const QJsonObject edit = o.value("farol_edit").toObject();
    const int added = count(edit.value("added")), removed = count(edit.value("removed"));
    if (added >= 0 && removed >= 0) {          // the two together, or neither
        e.editAdded = added;
        e.editRemoved = removed;
    }
    e.editCut = edit.value("cut").toBool();
    e.prompt = str(o, "prompt");
    if (e.prompt.isEmpty())
        e.prompt = str(o, "message");          // the Swift app read "message"; keep accepting it
    e.message = str(o, "message");
    e.notificationType = str(o, "notification_type");
    e.lastAssistantMessage = str(o, "last_assistant_message");
    e.errorType = str(o, "error_type");
    e.errorMessage = str(o, "error_message");
    e.claudePid = qint64(o.value("claude_pid").toDouble());
    e.claudeStart = qint64(o.value("claude_start").toDouble());
    if (e.claudePid <= 0 || e.claudeStart <= 0)
        e.claudePid = e.claudeStart = 0;       // only a pid with its start time names a process
    return e;
}

QString HookEvent::project() const
{
    QString folder = QFileInfo(QDir::cleanPath(cwd)).fileName();   // cleanPath drops a trailing slash
    if (folder.isEmpty())
        return QStringLiteral("Session");
    return projectAlias(folder);
}

QString projectAlias(const QString &folder)
{
    static const QMap<QString, QString> aliases = {
        {"notch-buddy", "Notch Buddy"}, {"notchbuddy", "Notch Buddy"}, {"notch_buddy", "Notch Buddy"}};
    return aliases.value(folder.toLower(), folder);
}

QString clip(const QString &s, int max)
{
    return s.simplified().left(max);
}

namespace {
// plainMessage() looks at no more than this of a line: a card shows a few hundred characters, the hook sends up to 1 MiB.
constexpr qsizetype kLineBudget = 4096;
// printable() leaves no control character in a line, so these two can mark where a piece of text was put aside.
constexpr QChar kHeldStart(0x01), kHeldEnd(0x02);

// A line without what draws nothing or turns the text around: control and format characters (escape sequences,
// bidi overrides, zero-width spaces, tags) and halves of a surrogate pair. Whatever is white space (a tab, a
// carriage return, a line separator) is a blank; the emoji joiner stays.
QString printable(QStringView line)
{
    QString out;
    for (qsizetype i = 0; i < line.size() && out.size() < kLineBudget; ++i) {
        char32_t c = line.at(i).unicode();
        if (QChar::isHighSurrogate(c) && i + 1 < line.size() && line.at(i + 1).isLowSurrogate())
            c = QChar::surrogateToUcs4(c, line.at(++i).unicode());
        else if (QChar::isSurrogate(c))
            continue;
        const QChar::Category category = QChar::category(c);
        if (QChar::isSpace(c))
            out += u' ';
        else if ((category != QChar::Other_Control && category != QChar::Other_Format) || c == 0x200D)
            out += QStringView(QChar::fromUcs4(c));
    }
    return out;
}

// The text of a line without the marks of code, links, images and emphasis.
QString inlineText(const QString &line)
{
    // What a code span holds, and a character behind a backslash, is text as it stands (`__init__.py`): it is put
    // aside while the marks around it go.
    QStringList held;
    QString s;
    const auto hold = [&](const QString &text) {
        s += kHeldStart + QString::number(held.size()) + kHeldEnd;
        held << text;
    };
    const auto ticksAt = [&](qsizetype at) {
        qsizetype n = 0;
        while (at + n < line.size() && line.at(at + n) == u'`')
            ++n;
        return n;
    };
    for (qsizetype i = 0; i < line.size(); ++i) {
        const QChar c = line.at(i);
        const QChar next = i + 1 < line.size() ? line.at(i + 1) : QChar();
        if (c == u'\\' && next.unicode() < 0x80 && (next.isPunct() || next.isSymbol())) {
            hold(line.mid(++i, 1));
        } else if (c == u'`') {
            const qsizetype ticks = ticksAt(i);
            qsizetype close = i + ticks;                 // a span ends at the next run of as many backticks
            while (close < line.size() && ticksAt(close) != ticks)
                close += qMax(qsizetype(1), ticksAt(close));
            if (close < line.size())
                hold(line.mid(i + ticks, close - i - ticks));
            i = (close < line.size() ? close : i) + ticks - 1;   // backticks that close nothing are dropped
        } else {
            s += c;
        }
    }

    static const QRegularExpression image(QStringLiteral(R"(!\[([^\]]*)\]\((?:[^()]|\([^()]*\))*\))"));
    static const QRegularExpression link(QStringLiteral(R"(\[([^\]]*)\]\((?:[^()]|\([^()]*\))*\))"));
    static const QRegularExpression strong(QStringLiteral(R"(\*\*|__|~~)"));
    // a single * only when it pairs around text ("2 * 3 * 4" keeps its own); a single _ is left alone: snake_case
    static const QRegularExpression emphasis(QStringLiteral(R"(\*(?!\s)([^*]+)(?<!\s)\*)"));
    static const QRegularExpression slot(QStringLiteral("\\x01(\\d+)\\x02"));
    s.replace(image, QStringLiteral("\\1"));             // first, so that an image inside a link leaves its text there
    s.replace(link, QStringLiteral("\\1"));
    s.remove(strong);
    s.replace(emphasis, QStringLiteral("\\1"));

    QString out;
    qsizetype at = 0;
    for (auto it = slot.globalMatch(s); it.hasNext();) {
        const QRegularExpressionMatch m = it.next();
        out += QStringView(s).mid(at, m.capturedStart() - at);
        out += held.value(m.captured(1).toInt());
        at = m.capturedEnd();
    }
    out += QStringView(s).mid(at);
    return out;
}
} // namespace

QString plainMessage(const QString &markdown, int maxLines, int maxChars)
{
    static const QRegularExpression quote(QStringLiteral(R"(^(?:>\s*)+)"));
    static const QRegularExpression fence(QStringLiteral(R"(^(`{3,}|~{3,})(.*)$)"));
    static const QRegularExpression rule(QStringLiteral(R"(^(?:(?:-\s*){3,}|(?:\*\s*){3,}|(?:_\s*){3,})$)"));
    // what a line may start with: a heading, then a bullet (kept, as group 1) or a number, then a task box
    static const QRegularExpression markers(
        QStringLiteral(R"(^(?:#{1,6}(?:\s+|$))?(?:([-*+])(?:\s+|$)|\d{1,9}[.)](?:\s+|$))?(?:\[[ xX]\](?:\s+|$))?)"));
    if (maxLines <= 0 || maxChars <= 0)
        return {};

    QStringList lines;
    bool more = false;                 // the message goes on after what is kept
    QString open;                      // the fence of the code block the walk is in
    for (const QStringView raw : QStringView(markdown).tokenize(u'\n')) {
        QString line = printable(raw);
        const bool cut = line.size() >= kLineBudget;
        line = line.trimmed();
        line.remove(quote);
        if (!open.isEmpty()) {
            if (line.startsWith(open) && line.count(open.at(0)) == line.size())
                open.clear();
            continue;
        }
        const QRegularExpressionMatch fenced = fence.match(line);
        if (fenced.hasMatch() && !(line.at(0) == u'`' && fenced.captured(2).contains(u'`'))) {
            open = fenced.captured(1);
            continue;
        }
        if (line.isEmpty() || line.startsWith(u'|') || rule.match(line).hasMatch())
            continue;
        const QRegularExpressionMatch marked = markers.match(line);
        const QString text = inlineText(line.mid(marked.capturedEnd())).simplified();
        if (text.isEmpty())
            continue;
        if (lines.size() == maxLines) {
            more = true;
            break;
        }
        lines << (marked.capturedLength(1) > 0 ? QStringLiteral("• ") + text : text);
        more = more || cut;
    }

    QString out = lines.join(u'\n');
    if (!more && out.size() <= maxChars)
        return out;
    out.truncate(maxChars - 1);
    if (!out.isEmpty() && out.back().isHighSurrogate())
        out.chop(1);
    while (!out.isEmpty() && out.back().isSpace())
        out.chop(1);
    return out + QChar(0x2026);
}

QString stepLabel(const QString &tool, const QJsonObject &input)
{
    static const QMap<QString, QString> labels = {
        {"Bash", "Runs"}, {"Read", "Reads"}, {"Write", "Writes"}, {"Edit", "Edits"}, {"MultiEdit", "Edits"},
        {"Glob", "Finds"}, {"Grep", "Searches"}, {"WebSearch", "Web search"}, {"WebFetch", "Fetches"},
        {"TodoWrite", "Tasks"}, {"Task", "Agent"}, {"LS", "Lists"}, {"NotebookEdit", "Notebook"},
        {"AskUserQuestion", "Asks"}};
    const QString name = tool.isEmpty() ? QStringLiteral("Tool") : tool;
    const QString label = labels.value(name, name);
    auto field = [&](const char *k) { return input.value(QLatin1String(k)).toString(); };
    if (const QString c = field("command"); !c.isEmpty())
        return label + QStringLiteral(" · ") + clip(c, 40);
    if (const QString p = field("path"); !p.isEmpty())
        return label + QStringLiteral(" · ") + QFileInfo(p).fileName();
    if (const QString f = field("file_path"); !f.isEmpty())
        return label + QStringLiteral(" · ") + QFileInfo(f).fileName();
    if (const QString n = field("notebook_path"); !n.isEmpty())
        return label + QStringLiteral(" · ") + QFileInfo(n).fileName();
    if (const QString q = field("query"); !q.isEmpty())
        return label + QStringLiteral(" · ") + clip(q, 40);
    if (const QString pat = field("pattern"); !pat.isEmpty())
        return label + QStringLiteral(" · ") + clip(pat, 40);
    return label;
}

} // namespace farol
