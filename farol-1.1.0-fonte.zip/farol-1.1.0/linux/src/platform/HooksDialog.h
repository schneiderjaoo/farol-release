#pragma once
#include <QString>

class QWidget;

namespace farol {

// Modal preview of a change to ~/.claude/settings.json. Returns true only when the user clicks `confirmLabel`;
// Cancel is the default button, so Enter and Esc never confirm.
bool confirmHooksChange(QWidget *parent, const QString &title, const QString &summary, const QString &diff,
                        const QString &confirmLabel);

} // namespace farol
