#include "NetworkClient.h"

#include <QNetworkReply>
#include <QNetworkRequest>
#include <QTimer>

namespace farol {

NetworkClient::NetworkClient(QObject *parent) : QObject(parent)
{
    m_manager.setRedirectPolicy(QNetworkRequest::ManualRedirectPolicy);
}

void NetworkClient::post(const HttpRequest &request, int timeoutMs, std::function<void(const Reply &)> done)
{
    cancel();
    QNetworkRequest r(request.url);
    for (const auto &h : request.headers)
        r.setRawHeader(h.first, h.second);
    m_cancelled = false;
    m_timedOut = false;
    QNetworkReply *reply = m_manager.post(r, request.body);
    m_reply = reply;
    auto *limit = new QTimer(reply);
    limit->setSingleShot(true);
    connect(limit, &QTimer::timeout, reply, [this, reply] {
        if (reply == m_reply)
            m_timedOut = true;
        reply->abort();
    });
    limit->start(timeoutMs);
    connect(reply, &QNetworkReply::finished, this, [this, reply, done = std::move(done)] {
        reply->deleteLater();
        Reply out;
        if (reply != m_reply) {   // replaced by a newer request
            out.cancelled = true;
            done(out);
            return;
        }
        out.cancelled = m_cancelled;
        out.timedOut = m_timedOut;
        out.status = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        out.body = reply->readAll();
        if (out.status == 0)
            out.error = reply->errorString();
        m_reply = nullptr;
        done(out);
    });
}

void NetworkClient::cancel()
{
    if (!m_reply)
        return;
    m_cancelled = true;
    m_reply->abort();
}

} // namespace farol
