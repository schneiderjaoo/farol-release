#pragma once
#include "IslandTypes.h"

#if FAROL_KDE
#include <LayerShellQt/Window>
#endif
#include <QObject>
#include <QQuickView>

class QQmlEngine;

namespace farol {

class AppState;
class IslandController;

// The 720x320 transparent surface hung from the top centre of the primary screen. It owns the two knobs measured
// in L0: the input region (clicks outside the island fall through) and the keyboard mode (None by default,
// OnDemand only when the controller asks).
//  * KDE Plasma on Wayland: a layer-shell surface, which the compositor puts against the edge.
//  * X11 (Cinnamon): a window without a frame, above the others and on every workspace, which Farol puts against
//    the edge itself. It takes no keyboard focus until the controller asks, and gives it back afterwards.
class IslandWindow : public QObject {
    Q_OBJECT
public:
    IslandWindow(AppState *state, IslandController *controller, QQmlEngine *engine, QObject *parent = nullptr);
    void show();
    bool ok() const { return m_ok; }
#if FAROL_KDE
    // One anchor only, so the compositor centres the surface along the other axis.
    static LayerShellQt::Window::Anchors anchorFor(IslandEdge edge);
#endif
    // Where a window of that size goes on a screen when Farol places it: against the edge, centred along it.
    static QPoint positionFor(IslandEdge edge, const QRect &screen, const QSize &window);

private slots:
    void updateMask();
    void applyEdge();
    void applyKeyboard(bool onDemand);
    void place();
    void lookForCompositor();

private:
    IslandEdge edge() const;

    AppState *m_state;
    IslandController *m_controller;
    QQuickView m_view;
    QQuickItem *m_root = nullptr;
    bool m_ok = false;
    bool m_layer = false;       // a layer-shell surface: the compositor places it
    bool m_seeThrough = true;   // X11: a compositor is running
    quint64 m_before = 0;       // X11: the window that had the keyboard when the island was given it
};

} // namespace farol
