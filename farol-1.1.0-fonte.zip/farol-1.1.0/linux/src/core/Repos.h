#pragma once
#include <QList>
#include <QObject>
#include <QString>
#include <QVariantList>

namespace farol {

class AppState;

// A git repository found under the workspace folder.
struct Repo {
    QString name;    // the folder's name
    QString path;    // absolute
    QString label;   // path from the workspace folder ("clients/acme"); the name for a repository right under it
};

// The folders under `root` that hold a ".git" (a folder, or the file of a worktree/submodule), sorted by label.
// The search goes `maxDepth` levels down, does not look inside a repository, skips hidden folders, node_modules and
// links, and gives up after `budget` folders so a huge tree cannot hang the island.
QList<Repo> findRepos(const QString &root, int maxDepth = 3, int budget = 3000);

// "Nova sessão" (the island's + tab): the repositories of the workspace folder chosen in Settings. Scanned when the
// folder changes and on refresh() (the view asks each time it opens), never in the background.
class Repos : public QObject {
    Q_OBJECT
    Q_PROPERTY(QVariantList list READ list NOTIFY changed)   // {name, path, label}, narrowed by `filter`
    Q_PROPERTY(int total READ total NOTIFY changed)
    Q_PROPERTY(QString filter READ filter WRITE setFilter NOTIFY changed)

public:
    explicit Repos(AppState *state, QObject *parent = nullptr);

    QVariantList list() const;
    int total() const { return int(m_repos.size()); }
    QString filter() const { return m_filter; }
    void setFilter(const QString &text);

public slots:
    void refresh();
    // Asks the app to open a new Claude Code session in `path`; only for a repository of the last scan.
    void open(const QString &path);

signals:
    void changed();
    void openRequested(const QString &path);

private:
    AppState *m_state;
    QList<Repo> m_repos;
    QString m_filter;
};

} // namespace farol
