#pragma once
#include "AiRequest.h"
#include "CommandRunner.h"
#include "HttpClient.h"
#include "SecretStore.h"
#include <QObject>
#include <QUrl>
#include <QVariantList>
#include <functional>

class QSettings;

namespace farol {

// The "Perguntar" tab: files the user dropped in, a question about them, and the answer of the service chosen in
// Settings -> IA: the Claude Code installed here (no key: it answers with the account it is logged in with), or a
// web service whose API key the user saved. Nothing leaves the machine before "Perguntar" (or Enter); a key lives
// in the desktop's secret service and farol.conf only remembers which services have one.
class Ask : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString provider READ provider WRITE setProvider NOTIFY providerChanged)
    Q_PROPERTY(QString providerLabel READ providerLabel NOTIFY providerChanged)
    Q_PROPERTY(QString model READ model NOTIFY providerChanged)
    Q_PROPERTY(QString modelLabel READ modelLabel NOTIFY providerChanged)
    Q_PROPERTY(QVariantList models READ models NOTIFY providerChanged)   // of the chosen service: {id, label}
    Q_PROPERTY(QStringList keys READ keys NOTIFY keysChanged)
    Q_PROPERTY(bool hasKey READ hasKey NOTIFY keysChanged)
    Q_PROPERTY(bool needsKey READ needsKey NOTIFY providerChanged)
    Q_PROPERTY(bool ready READ ready NOTIFY keysChanged)             // a question can be asked: no key wanted, or one saved
    Q_PROPERTY(bool claudeFound READ claudeFound NOTIFY providerChanged)
    Q_PROPERTY(QString keyError READ keyError NOTIFY keyErrorChanged)
    Q_PROPERTY(QVariantList files READ files NOTIFY filesChanged)
    Q_PROPERTY(QVariantList turns READ turns NOTIFY turnsChanged)
    Q_PROPERTY(bool busy READ busy NOTIFY busyChanged)
    Q_PROPERTY(QString error READ error NOTIFY errorChanged)
    Q_PROPERTY(QString notice READ notice NOTIFY noticeChanged)
public:
    static constexpr int kMaxFiles = 10;
    static constexpr qint64 kMaxTextBytes = 2 * 1024 * 1024;
    static constexpr qint64 kMaxTotalBytes = 20 * 1024 * 1024;
    static constexpr int kTimeoutMs = 180000;

    // locate: where the `claude` program is (empty: not installed); path: the PATH it is run with.
    Ask(QSettings *settings, ISecretStore *secrets, IHttpClient *http, ICommandRunner *runner = nullptr,
        std::function<QString()> locate = {}, const QString &path = {}, QObject *parent = nullptr);

    QString provider() const { return m_provider; }
    void setProvider(const QString &provider);
    QString providerLabel() const { return aiProviderLabel(m_provider); }
    QString model() const { return modelOf(m_provider); }
    QString modelLabel() const;
    QVariantList models() const;
    QStringList keys() const { return m_keys; }
    bool hasKey() const { return m_keys.contains(m_provider); }
    bool needsKey() const { return aiNeedsKey(m_provider); }
    bool ready() const { return !needsKey() || hasKey(); }
    bool claudeFound() const { return m_locate && !m_locate().isEmpty(); }
    QString keyError() const { return m_keyError; }
    QVariantList files() const;
    QVariantList turns() const;
    bool busy() const { return m_busy; }
    QString error() const { return m_error; }
    QString notice() const { return m_notice; }

    Q_INVOKABLE QString labelOf(const QString &provider) const { return aiProviderLabel(provider); }
    Q_INVOKABLE QString modelOf(const QString &provider) const;
    // Only one of the service's listed models is taken.
    Q_INVOKABLE void setModel(const QString &provider, const QString &model);
    Q_INVOKABLE void saveKey(const QString &provider, const QString &key);
    Q_INVOKABLE void removeKey(const QString &provider);

    Q_INVOKABLE void addUrls(const QList<QUrl> &urls);
    Q_INVOKABLE void addFile(const QString &path);
    Q_INVOKABLE void removeFile(int index);
    Q_INVOKABLE void chooseFiles() { emit filesRequested(); }
    Q_INVOKABLE void ask(const QString &question);
    Q_INVOKABLE void cancel();
    Q_INVOKABLE void clear();
    // "Copiar" on the answer at `index` of turns: asks the app to put its Markdown, as it came, on the clipboard.
    // That is the text the view was made from, with what it does not draw: the addresses and titles of links and
    // images, and link definitions nothing uses. Whoever pastes it somewhere gets those too.
    Q_INVOKABLE void copy(int index);

signals:
    void providerChanged();
    void keysChanged();
    void keyErrorChanged();
    void filesChanged();
    void turnsChanged();
    void busyChanged();
    void errorChanged();
    void noticeChanged();
    void filesRequested();
    void answered();
    void copyRequested(const QString &text);
    void failed(const QString &question);   // the question did not go through: the view gives it back to the field

private:
    void setBusy(bool busy);
    void setError(const QString &error);
    void setNotice(const QString &notice);
    void setKeyError(const QString &error);
    void giveUp(const QString &error);
    void askClaude(int round);
    void stop();
    void answerWith(const QString &provider, const AiAnswer &answer);
    qint64 totalBytes() const;

    QSettings *m_settings;
    ISecretStore *m_secrets;
    IHttpClient *m_http;
    ICommandRunner *m_runner;
    std::function<QString()> m_locate;
    QString m_path;
    QString m_provider;
    QString m_asked;     // the service the question under way went to
    QStringList m_keys;
    QString m_keyError;
    QList<AskFile> m_files;
    QList<AskTurn> m_turns;
    bool m_busy = false;
    int m_round = 0;     // answers of a question that was cancelled or cleared are dropped
    QString m_error;
    QString m_notice;
};

} // namespace farol
