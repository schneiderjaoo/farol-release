#include "ApprovalQueue.h"

#include <QCryptographicHash>

namespace farol {

namespace {
const QString kAlwaysKey = QStringLiteral("approvals/always");

bool endsALine(char32_t c)
{
    return c == U'\n' || c == U'\r' || c == 0x0B || c == 0x0C || c == 0x85 || c == 0x2028 || c == 0x2029;
}
}

ApprovalQueue::ApprovalQueue(IScheduler &scheduler, QSettings *settings, QObject *parent)
    : QObject(parent), m_sched(scheduler), m_settings(settings)
{
    if (m_settings)
        m_always = m_settings->value(kAlwaysKey).toStringList();
}

QString ApprovalQueue::alwaysKey(const ApprovalRequest &r)
{
    // Bash is approved per exact command; every other tool per tool and project.
    QString pattern;
    if (r.tool == QLatin1String("Bash")) {
        pattern = r.command;
        // A command shorter than kExactChars is kept as it is. A longer one is kept as its beginning (for whoever
        // reads farol.conf) and the digest of all of it, which makes it longer than any of the first kind: the two
        // never meet. 1.0 kept the first kExactChars of a long command and nothing else, and so allowed every
        // command that began like it; what it saved that way matches nothing here.
        if (pattern.size() >= kExactChars) {
            const QByteArrayView all(reinterpret_cast<const char *>(r.command.constData()), r.command.size() * qsizetype(sizeof(QChar)));
            pattern = r.command.left(kExactChars) + QLatin1String(" sha256:") +
                      QString::fromLatin1(QCryptographicHash::hash(all, QCryptographicHash::Sha256).toHex());
        }
    }
    return QString::fromUtf8(QJsonDocument(QJsonArray{r.cwd, r.tool, pattern}).toJson(QJsonDocument::Compact));
}

int ApprovalQueue::commandLines() const
{
    if (m_entries.isEmpty())
        return 0;
    int lines = 0;
    bool something = false;   // on the line being read
    for (const QChar c : m_entries.first().request.command) {
        if (endsALine(c.unicode())) {
            lines += something;
            something = false;
        } else if (!c.isSpace()) {
            something = true;
        }
    }
    return lines + something;
}

QString ApprovalQueue::cardText(const QString &command, bool *leftOut)
{
    QString out;
    bool blank = false, lineEnded = false;   // a run of blanks is open, and a line ended in it
    bool left = false;                       // something that would be drawn did not get in
    int marks = 0;                           // marks that take no room, since the last character that takes some
    for (qsizetype i = 0; i < command.size(); ++i) {
        char32_t c = command.at(i).unicode();
        qsizetype units = 1;
        if (command.at(i).isHighSurrogate() && i + 1 < command.size() && command.at(i + 1).isLowSurrogate()) {
            c = QChar::surrogateToUcs4(command.at(i), command.at(i + 1));
            units = 2;
        }
        const bool mark = QChar::category(c) == QChar::Mark_NonSpacing || QChar::category(c) == QChar::Mark_Enclosing;
        if (QChar::isSpace(c) || !QChar::isPrint(c)) {
            blank = true;
            lineEnded = lineEnded || endsALine(c);
            marks = 0;
        } else if (mark && marks >= kCardMarks) {
            left = true;   // a pile of them is drawn over the lines around it, and hundreds fit where one letter does
        } else {
            if (out.size() >= kCardChars) {
                left = true;
                break;
            }
            marks = mark ? marks + 1 : 0;
            if (blank && !out.isEmpty())
                out += lineEnded ? QStringLiteral(" \u21B5 ") : QStringLiteral(" ");
            blank = lineEnded = false;
            out += QStringView(command).mid(i, units);
        }
        i += units - 1;
    }
    if (out.size() > kCardChars) {
        out.truncate(kCardChars);
        if (out.back().isHighSurrogate())   // not half a character
            out.chop(1);
        left = true;
    }
    if (leftOut)
        *leftOut = left;
    return out;
}

bool ApprovalQueue::commandCut() const
{
    bool left = false;
    if (!m_entries.isEmpty())
        cardText(m_entries.first().request.command, &left);
    return left;
}

qint64 ApprovalQueue::enqueue(ApprovalRequest request, Reply reply)
{
    request.id = ++m_nextId;
    if (m_always.contains(alwaysKey(request))) {
        reply(Decision::Allow);
        return request.id;
    }
    Entry e;
    e.request = request;
    e.reply = std::move(reply);
    const qint64 id = request.id;
    e.timer = m_sched.singleShot(m_timeoutMs, [this, id] { resolve(id, Decision::Release, true); });
    m_entries.append(std::move(e));
    emit changed();
    if (m_entries.size() == 1)
        emit shown(m_entries.first().request);
    return id;
}

void ApprovalQueue::cancel(qint64 id)
{
    resolve(id, Decision::Release, false);
}

void ApprovalQueue::allow()
{
    if (!m_entries.isEmpty())
        resolve(m_entries.first().request.id, Decision::Allow, true);
}

void ApprovalQueue::deny()
{
    if (!m_entries.isEmpty())
        resolve(m_entries.first().request.id, Decision::Deny, true);
}

void ApprovalQueue::release()
{
    if (!m_entries.isEmpty())
        resolve(m_entries.first().request.id, Decision::Release, true);
}

void ApprovalQueue::always()
{
    if (m_entries.isEmpty())
        return;
    const QString key = alwaysKey(m_entries.first().request);
    if (!m_always.contains(key)) {
        m_always << key;
        if (m_settings) {
            m_settings->setValue(kAlwaysKey, m_always);
            m_settings->sync();
        }
    }
    // The front one and every identical one still waiting behind it. Back to front, so no intermediate
    // request is "shown" (pinning the island) just to be resolved a moment later.
    QList<qint64> ids;
    for (const Entry &e : std::as_const(m_entries))
        if (alwaysKey(e.request) == key)
            ids << e.request.id;
    for (qsizetype k = ids.size() - 1; k >= 0; --k)
        resolve(ids.at(k), Decision::Allow, true);
}

void ApprovalQueue::resolve(qint64 id, Decision decision, bool sendReply)
{
    int i = -1;
    for (int k = 0; k < m_entries.size(); ++k)
        if (m_entries.at(k).request.id == id)
            i = k;
    if (i < 0)
        return;
    Entry e = m_entries.takeAt(i);
    m_sched.cancel(e.timer);
    const bool wasFront = i == 0;
    emit changed();
    if (sendReply && e.reply)
        e.reply(decision);
    emit resolved(e.request, decision);
    if (decision == Decision::Release && sendReply)
        emit leftToEditor(e.request);
    if (wasFront && !m_entries.isEmpty())
        emit shown(m_entries.first().request);
}

} // namespace farol
