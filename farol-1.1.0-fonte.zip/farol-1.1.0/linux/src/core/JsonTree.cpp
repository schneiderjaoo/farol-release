#include "JsonTree.h"

#include <QJsonArray>
#include <QJsonDocument>

namespace farol {

namespace {

constexpr int kMaxDepth = 64;

struct Parser {
    const QString &s;
    int i = 0;
    QString err;

    bool fail(const QString &m)
    {
        if (err.isEmpty())
            err = QStringLiteral("%1 at offset %2").arg(m).arg(i);
        return false;
    }
    void ws()
    {
        while (i < s.size() && (s.at(i) == ' ' || s.at(i) == '\t' || s.at(i) == '\n' || s.at(i) == '\r'))
            ++i;
    }
    bool stringToken(QString &raw)
    {
        if (i >= s.size() || s.at(i) != '"')
            return fail(QStringLiteral("expected a string"));
        const int start = i++;
        while (i < s.size()) {
            const QChar c = s.at(i);
            if (c == '\\')
                i += 2;
            else if (c == '"') {
                ++i;
                raw = s.mid(start, i - start);
                return true;
            } else
                ++i;
        }
        return fail(QStringLiteral("unterminated string"));
    }
    bool value(JsonTree &out, int depth)
    {
        if (depth > kMaxDepth)
            return fail(QStringLiteral("nesting too deep"));
        ws();
        if (i >= s.size())
            return fail(QStringLiteral("unexpected end"));
        const QChar c = s.at(i);
        if (c == '{')
            return object(out, depth);
        if (c == '[')
            return array(out, depth);
        out = JsonTree();
        if (c == '"')
            return stringToken(out.raw);
        const int start = i;
        while (i < s.size() && !QStringLiteral(",]} \t\r\n").contains(s.at(i)))
            ++i;
        if (i == start)
            return fail(QStringLiteral("unexpected character"));
        out.raw = s.mid(start, i - start);
        return true;
    }
    bool object(JsonTree &out, int depth)
    {
        out = JsonTree::object();
        ++i;   // {
        ws();
        if (i < s.size() && s.at(i) == '}') {
            ++i;
            return true;
        }
        for (;;) {
            ws();
            QString rawKey;
            if (!stringToken(rawKey))
                return false;
            ws();
            if (i >= s.size() || s.at(i) != ':')
                return fail(QStringLiteral("expected ':'"));
            ++i;
            JsonTree v;
            if (!value(v, depth + 1))
                return false;
            out.keys.push_back(JsonTree::decodeString(rawKey));
            out.rawKeys.push_back(rawKey);
            out.values.push_back(std::move(v));
            ws();
            if (i < s.size() && s.at(i) == ',') {
                ++i;
                continue;
            }
            if (i < s.size() && s.at(i) == '}') {
                ++i;
                return true;
            }
            return fail(QStringLiteral("expected ',' or '}'"));
        }
    }
    bool array(JsonTree &out, int depth)
    {
        out = JsonTree::array();
        ++i;   // [
        ws();
        if (i < s.size() && s.at(i) == ']') {
            ++i;
            return true;
        }
        for (;;) {
            JsonTree v;
            if (!value(v, depth + 1))
                return false;
            out.items.push_back(std::move(v));
            ws();
            if (i < s.size() && s.at(i) == ',') {
                ++i;
                continue;
            }
            if (i < s.size() && s.at(i) == ']') {
                ++i;
                return true;
            }
            return fail(QStringLiteral("expected ',' or ']'"));
        }
    }
};

void write(const JsonTree &t, int level, int indent, QString &out)
{
    const QString pad(level * indent, ' ');
    const QString inner((level + 1) * indent, ' ');
    switch (t.kind) {
    case JsonTree::Kind::Raw:
        out += t.raw;
        break;
    case JsonTree::Kind::Object:
        if (t.values.empty()) {
            out += QStringLiteral("{}");
            break;
        }
        out += QStringLiteral("{\n");
        for (size_t k = 0; k < t.values.size(); ++k) {
            out += inner + t.rawKeys[k] + QStringLiteral(": ");
            write(t.values[k], level + 1, indent, out);
            out += (k + 1 < t.values.size()) ? QStringLiteral(",\n") : QStringLiteral("\n");
        }
        out += pad + QLatin1Char('}');
        break;
    case JsonTree::Kind::Array:
        if (t.items.empty()) {
            out += QStringLiteral("[]");
            break;
        }
        out += QStringLiteral("[\n");
        for (size_t k = 0; k < t.items.size(); ++k) {
            out += inner;
            write(t.items[k], level + 1, indent, out);
            out += (k + 1 < t.items.size()) ? QStringLiteral(",\n") : QStringLiteral("\n");
        }
        out += pad + QLatin1Char(']');
        break;
    }
}

} // namespace

JsonTree JsonTree::object()
{
    JsonTree t;
    t.kind = Kind::Object;
    return t;
}

JsonTree JsonTree::array()
{
    JsonTree t;
    t.kind = Kind::Array;
    return t;
}

JsonTree JsonTree::string(const QString &text)
{
    JsonTree t;
    t.raw = quote(text);
    return t;
}

JsonTree JsonTree::number(int n)
{
    JsonTree t;
    t.raw = QString::number(n);
    return t;
}

QString JsonTree::quote(const QString &text)
{
    QString out = QStringLiteral("\"");
    for (const QChar c : text) {
        switch (c.unicode()) {
        case '"': out += QStringLiteral("\\\""); break;
        case '\\': out += QStringLiteral("\\\\"); break;
        case '\n': out += QStringLiteral("\\n"); break;
        case '\r': out += QStringLiteral("\\r"); break;
        case '\t': out += QStringLiteral("\\t"); break;
        default:
            if (c.unicode() < 0x20)
                out += QStringLiteral("\\u%1").arg(uint(c.unicode()), 4, 16, QLatin1Char('0'));
            else
                out += c;
        }
    }
    return out + QLatin1Char('"');
}

QString JsonTree::decodeString(const QString &rawToken)
{
    const QJsonDocument doc = QJsonDocument::fromJson(("[" + rawToken + "]").toUtf8());
    return doc.array().isEmpty() ? QString() : doc.array().first().toString();
}

QString JsonTree::stringValue() const { return isString() ? decodeString(raw) : QString(); }

std::optional<JsonTree> JsonTree::parse(const QString &text, QString *error)
{
    auto fail = [&](const QString &m) -> std::optional<JsonTree> {
        if (error)
            *error = m;
        return std::nullopt;
    };
    QJsonParseError pe;
    QJsonDocument::fromJson(text.toUtf8(), &pe);
    if (pe.error != QJsonParseError::NoError)
        return fail(QStringLiteral("invalid JSON: %1 (offset %2)").arg(pe.errorString()).arg(pe.offset));
    Parser p{text};
    JsonTree t;
    if (!p.value(t, 0))
        return fail(p.err);
    p.ws();
    if (p.i != text.size())
        return fail(QStringLiteral("unexpected content after the document"));
    return t;
}

QString JsonTree::serialize(int indent) const
{
    QString out;
    write(*this, 0, indent, out);
    return out;
}

JsonTree *JsonTree::find(const QString &key)
{
    for (size_t k = 0; k < keys.size(); ++k)
        if (keys[k] == key)
            return &values[k];
    return nullptr;
}

const JsonTree *JsonTree::find(const QString &key) const
{
    return const_cast<JsonTree *>(this)->find(key);
}

JsonTree &JsonTree::set(const QString &key, JsonTree value)
{
    if (JsonTree *existing = find(key)) {
        *existing = std::move(value);
        return *existing;
    }
    keys.push_back(key);
    rawKeys.push_back(quote(key));
    values.push_back(std::move(value));
    return values.back();
}

bool JsonTree::remove(const QString &key)
{
    for (size_t k = 0; k < keys.size(); ++k) {
        if (keys[k] == key) {
            keys.erase(keys.begin() + k);
            rawKeys.erase(rawKeys.begin() + k);
            values.erase(values.begin() + k);
            return true;
        }
    }
    return false;
}

QStringList JsonTree::keyList() const
{
    QStringList out;
    for (const QString &k : keys)
        out << k;
    return out;
}

} // namespace farol
