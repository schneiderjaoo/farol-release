#include <QtTest>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include "AiRequest.h"

using namespace farol;

class TestAiRequest : public QObject {
    Q_OBJECT
    static QList<AskFile> files()
    {
        return {{"notas.txt", AskFile::Text, {}, "linha um"},
                {"tela.png", AskFile::Image, "image/png", QByteArray("\x89PNG", 4)},
                {"contrato.pdf", AskFile::Pdf, "application/pdf", "%PDF-1.7"}};
    }
    static QList<AskTurn> turns() { return {{true, "O que diz?"}, {false, "Diz X."}, {true, "E o PDF?"}}; }
    static QByteArray header(const HttpRequest &r, const char *name)
    {
        for (const auto &h : r.headers)
            if (h.first == name)
                return h.second;
        return {};
    }
    static QJsonObject body(const HttpRequest &r) { return QJsonDocument::fromJson(r.body).object(); }

private slots:
    void providersAndDefaults()
    {
        QCOMPARE(aiProviders(), QStringList({"claude", "anthropic", "openai", "gemini"}));   // the one without a key first
        QCOMPARE(aiProviderLabel("openai"), QString("ChatGPT"));
        QCOMPARE(aiProviderLabel("claude"), QString("Claude Code"));
        QVERIFY(!aiNeedsKey("claude"));
        for (const char *p : {"anthropic", "openai", "gemini"})
            QVERIFY2(aiNeedsKey(p), p);
        QCOMPARE(aiModels("claude").at(0).id, QString("sonnet"));   // Claude Code's own names for the newest of each
        QCOMPARE(aiModels("claude").at(2).id, QString("opus"));
        for (const QString &p : aiProviders()) {
            QCOMPARE(aiModels(p).size(), 3);
            QCOMPARE(aiDefaultModel(p), aiModels(p).last().id);
        }
        QCOMPARE(aiModels("anthropic").at(0).id, QString("claude-sonnet-5-5"));
        QCOMPARE(aiModels("anthropic").at(1).id, QString("claude-fable-5-1"));
        QCOMPARE(aiModels("anthropic").at(2).id, QString("claude-opus-5-5"));
    }
    // Claude Code answers with the account it is logged in with: one message on its standard input, no tools, none
    // of the user's hooks (a question must not show up in the island as a session), nothing kept on disk.
    void claudeCodeQuestion()
    {
        const QStringList a = claudeArguments("fable");
        QVERIFY(a.contains("-p"));
        QCOMPARE(a.at(a.indexOf("--tools") + 1), QString());              // no tool at all
        for (const char *flag : {"--safe-mode", "--strict-mcp-config", "--no-session-persistence", "--verbose"})
            QVERIFY2(a.contains(flag), flag);
        QCOMPARE(a.at(a.indexOf("--model") + 1), QString("fable"));
        QCOMPARE(a.at(a.indexOf("--input-format") + 1), QString("stream-json"));
        QCOMPARE(a.at(a.indexOf("--output-format") + 1), QString("stream-json"));
        QVERIFY(!a.at(a.indexOf("--system-prompt") + 1).isEmpty());
        for (const QString &arg : a)
            QVERIFY2(!arg.contains("skip-permissions") && !arg.contains("bypass"), qPrintable(arg));

        const QByteArray input = claudeInput(files(), turns());
        QVERIFY(input.endsWith('\n'));
        QCOMPARE(input.count('\n'), 1);                                    // one message, one line
        const QJsonObject o = QJsonDocument::fromJson(input).object();
        QCOMPARE(o["type"].toString(), QString("user"));
        QCOMPARE(o["message"].toObject()["role"].toString(), QString("user"));
        const QJsonArray content = o["message"].toObject()["content"].toArray();
        QCOMPARE(content.size(), 5);
        QVERIFY(content[0].toObject()["text"].toString().contains("notas.txt"));
        QVERIFY(content[0].toObject()["text"].toString().contains("linha um"));
        QCOMPARE(content[1].toObject()["type"].toString(), QString("image"));
        QCOMPARE(content[1].toObject()["source"].toObject()["media_type"].toString(), QString("image/png"));
        QCOMPARE(content[1].toObject()["source"].toObject()["data"].toString(), QString::fromLatin1(QByteArray("\x89PNG", 4).toBase64()));
        QCOMPARE(content[2].toObject()["type"].toString(), QString("document"));
        const QString before = content[3].toObject()["text"].toString();   // the conversation so far, told
        QVERIFY(before.contains("O que diz?") && before.contains("Diz X."));
        QVERIFY(!before.contains("E o PDF?"));
        QCOMPARE(content[4].toObject()["text"].toString(), QString("E o PDF?"));

        const QJsonArray first = QJsonDocument::fromJson(claudeInput({}, {{true, "oi"}})).object()["message"].toObject()["content"].toArray();
        QCOMPARE(first.size(), 1);                                         // a first question has nothing before it
        QCOMPARE(first[0].toObject()["text"].toString(), QString("oi"));
    }
    void claudeCodeAnswers()
    {
        const QString ok = R"({"type":"system","subtype":"init","tools":[]})" "\n"
                           R"({"type":"assistant","message":{"content":[{"type":"text","text":"parcial"}]}})" "\n"
                           R"({"type":"result","subtype":"success","is_error":false,"result":"Diz **X**."})" "\n";
        AiAnswer a = parseClaudeOutput(0, ok, {});
        QVERIFY(a.ok);
        QCOMPARE(a.text, QString("Diz **X**."));
        a = parseClaudeOutput(1, R"({"type":"result","subtype":"success","is_error":true,"result":"Not logged in · Please run /login"})" "\n", {});
        QVERIFY(!a.ok);
        QVERIFY(a.text.contains("entre na sua conta"));                    // what to do, in the user's language
        a = parseClaudeOutput(1, R"({"type":"result","is_error":true,"result":"Usage limit reached"})", {});
        QVERIFY(!a.ok);
        QCOMPARE(a.text, QString("Usage limit reached"));
        a = parseClaudeOutput(2, {}, "error: unknown option '--tools'\nmore\n");
        QVERIFY(!a.ok);
        QVERIFY(a.text.contains("unknown option"));
        a = parseClaudeOutput(0, "not json\n", {});
        QVERIFY(!a.ok);
        QVERIFY(!a.text.isEmpty());
        a = parseClaudeOutput(0, R"({"type":"result","is_error":false,"result":"  "})", {});
        QVERIFY(!a.ok);
    }
    void anthropicRequest()
    {
        const HttpRequest r = buildAiRequest("anthropic", "claude-opus-5-5", "sk-ant-1", files(), turns());
        QCOMPARE(r.url, QUrl("https://api.anthropic.com/v1/messages"));
        QCOMPARE(header(r, "x-api-key"), QByteArray("sk-ant-1"));
        QCOMPARE(header(r, "anthropic-version"), QByteArray("2023-06-01"));
        const QJsonObject b = body(r);
        QCOMPARE(b["model"].toString(), QString("claude-opus-5-5"));
        QVERIFY(b["max_tokens"].toInt() > 0);
        const QJsonArray messages = b["messages"].toArray();
        QCOMPARE(messages.size(), 3);
        // the files ride the first question, in the order they were added, and only there
        const QJsonArray first = messages[0].toObject()["content"].toArray();
        QCOMPARE(first.size(), 4);
        QVERIFY(first[0].toObject()["text"].toString().contains("notas.txt"));
        QVERIFY(first[0].toObject()["text"].toString().contains("linha um"));
        QCOMPARE(first[1].toObject()["type"].toString(), QString("image"));
        QCOMPARE(first[1].toObject()["source"].toObject()["media_type"].toString(), QString("image/png"));
        QCOMPARE(QByteArray::fromBase64(first[1].toObject()["source"].toObject()["data"].toString().toLatin1()), QByteArray("\x89PNG", 4));
        QCOMPARE(first[2].toObject()["type"].toString(), QString("document"));
        QCOMPARE(first[3].toObject()["text"].toString(), QString("O que diz?"));
        QCOMPARE(messages[1].toObject()["role"].toString(), QString("assistant"));
        QCOMPARE(messages[2].toObject()["content"].toArray().size(), 1);
    }
    void openAiRequest()
    {
        const HttpRequest r = buildAiRequest("openai", "gpt-5", "sk-2", files(), turns());
        QCOMPARE(r.url, QUrl("https://api.openai.com/v1/chat/completions"));
        QCOMPARE(header(r, "Authorization"), QByteArray("Bearer sk-2"));
        const QJsonArray messages = body(r)["messages"].toArray();
        QCOMPARE(messages.size(), 3);
        const QJsonArray first = messages[0].toObject()["content"].toArray();
        QCOMPARE(first.size(), 4);
        QVERIFY(first[1].toObject()["image_url"].toObject()["url"].toString().startsWith("data:image/png;base64,"));
        QCOMPARE(first[2].toObject()["file"].toObject()["filename"].toString(), QString("contrato.pdf"));
        QVERIFY(first[2].toObject()["file"].toObject()["file_data"].toString().startsWith("data:application/pdf;base64,"));
        QCOMPARE(messages[1].toObject()["content"].toString(), QString("Diz X."));
    }
    void geminiRequest()
    {
        const HttpRequest r = buildAiRequest("gemini", "gemini-flash-latest", "AIza-3", files(), turns());
        QCOMPARE(r.url, QUrl("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent"));
        QCOMPARE(header(r, "x-goog-api-key"), QByteArray("AIza-3"));
        QVERIFY2(!r.url.toString().contains("AIza"), "the key never goes in the address");
        const QJsonArray contents = body(r)["contents"].toArray();
        QCOMPARE(contents.size(), 3);
        QCOMPARE(contents[1].toObject()["role"].toString(), QString("model"));
        const QJsonArray parts = contents[0].toObject()["parts"].toArray();
        QCOMPARE(parts.size(), 4);
        QCOMPARE(parts[2].toObject()["inline_data"].toObject()["mime_type"].toString(), QString("application/pdf"));
    }
    void answers()
    {
        AiAnswer a = parseAiReply("anthropic", 200, R"({"content":[{"type":"thinking","thinking":"hm"},{"type":"text","text":"Oi "},{"type":"text","text":"você"}]})");
        QVERIFY(a.ok);
        QCOMPARE(a.text, QString("Oi você"));
        a = parseAiReply("openai", 200, R"({"choices":[{"message":{"role":"assistant","content":"Olá"}}]})");
        QVERIFY(a.ok);
        QCOMPARE(a.text, QString("Olá"));
        a = parseAiReply("gemini", 200, R"({"candidates":[{"content":{"parts":[{"text":"A"},{"text":"B"}]}}]})");
        QVERIFY(a.ok);
        QCOMPARE(a.text, QString("AB"));
    }
    void problems()
    {
        for (const QString &p : aiProviders()) {
            AiAnswer a = parseAiReply(p, 401, R"({"error":{"message":"invalid key","type":"authentication_error"}})");
            QVERIFY(!a.ok);
            QCOMPARE(a.text, QString("invalid key"));
            a = parseAiReply(p, 503, "<html>down</html>");
            QVERIFY(!a.ok);
            QVERIFY(a.text.contains("503"));
            a = parseAiReply(p, 200, "{}");            // an answer with nothing in it is not shown as an answer
            QVERIFY(!a.ok);
            a = parseAiReply(p, 200, "not json");
            QVERIFY(!a.ok);
        }
    }
};

QTEST_GUILESS_MAIN(TestAiRequest)
#include "tst_ai_request.moc"
