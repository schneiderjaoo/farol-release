#include "IslandWindow.h"

#include "AppState.h"
#include "IslandController.h"

#include "X11.h"

#include <QGuiApplication>
#include <QQmlEngine>
#include <QQuickItem>
#include <QRegion>
#include <QScreen>
#include <QSurfaceFormat>

namespace farol {

IslandWindow::IslandWindow(AppState *state, IslandController *controller, QQmlEngine *engine, QObject *parent)
    : QObject(parent), m_state(state), m_controller(controller), m_view(engine, nullptr)
{
    QSurfaceFormat fmt = m_view.format();
    fmt.setAlphaBufferSize(8);
    m_view.setFormat(fmt);
    m_view.setColor(Qt::transparent);
    m_view.setSource(QUrl(QStringLiteral("qrc:/qml/Island.qml")));
    m_root = m_view.rootObject();
    if (!m_root || m_view.status() != QQuickView::Ready)
        return;

#if FAROL_KDE
    m_layer = QGuiApplication::platformName().startsWith(QLatin1String("wayland"));
    if (m_layer) {
        // Layer-shell role: must be configured before the first show() (L0 lesson).
        auto *layer = LayerShellQt::Window::get(&m_view);
        layer->setLayer(LayerShellQt::Window::LayerOverlay);
        layer->setAnchors(anchorFor(edge()));
        layer->setExclusiveZone(-1);
        layer->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityNone);
        layer->setScope(QStringLiteral("farol"));
    }
#endif
    if (!m_layer) {
        if (QGuiApplication::platformName().startsWith(QLatin1String("wayland")))
            qWarning("This Wayland desktop has no layer-shell Farol can use: the island is an ordinary window.");
        m_view.setFlags(Qt::Tool | Qt::FramelessWindowHint | Qt::WindowStaysOnTopHint | Qt::WindowDoesNotAcceptFocus);
        connect(qGuiApp, &QGuiApplication::primaryScreenChanged, this, &IslandWindow::place);
        for (QScreen *screen : QGuiApplication::screens())
            connect(screen, &QScreen::geometryChanged, this, &IslandWindow::place);
        connect(qGuiApp, &QGuiApplication::screenAdded, this, [this](QScreen *screen) {
            connect(screen, &QScreen::geometryChanged, this, &IslandWindow::place);
        });
        connect(&m_view, &QWindow::widthChanged, this, &IslandWindow::place);
        connect(&m_view, &QWindow::heightChanged, this, &IslandWindow::place);
    }
    m_view.setScreen(QGuiApplication::primaryScreen());
    place();

    connect(m_root, SIGNAL(islandRectChanged()), this, SLOT(updateMask()));
    connect(m_state, &AppState::edgeChanged, this, &IslandWindow::applyEdge);
    // The surface is 720x320 at the top/bottom and 320x720 on the sides: the input region follows its size.
    connect(&m_view, &QWindow::widthChanged, this, &IslandWindow::updateMask);
    connect(&m_view, &QWindow::heightChanged, this, &IslandWindow::updateMask);
    connect(m_state, &AppState::modeChanged, this, &IslandWindow::lookForCompositor);   // it may have come or gone since
    connect(m_state, &AppState::modeChanged, this, &IslandWindow::updateMask);
    connect(m_state, &AppState::notchChanged, this, &IslandWindow::updateMask);
    connect(m_controller, &IslandController::keyboardOnDemandChanged, this, &IslandWindow::applyKeyboard);
    updateMask();
    m_ok = true;
}

IslandEdge IslandWindow::edge() const
{
    return enumFromKey<IslandEdge>(m_state->edge()).value_or(IslandEdge::Top);
}

#if FAROL_KDE
LayerShellQt::Window::Anchors IslandWindow::anchorFor(IslandEdge edge)
{
    switch (edge) {
    case IslandEdge::Bottom: return LayerShellQt::Window::AnchorBottom;
    case IslandEdge::Left: return LayerShellQt::Window::AnchorLeft;
    case IslandEdge::Right: return LayerShellQt::Window::AnchorRight;
    case IslandEdge::Top: break;
    }
    return LayerShellQt::Window::AnchorTop;
}
#endif

QPoint IslandWindow::positionFor(IslandEdge edge, const QRect &screen, const QSize &window)
{
    const int alongX = screen.x() + (screen.width() - window.width()) / 2;
    const int alongY = screen.y() + (screen.height() - window.height()) / 2;
    switch (edge) {
    case IslandEdge::Bottom: return {alongX, screen.y() + screen.height() - window.height()};
    case IslandEdge::Left: return {screen.x(), alongY};
    case IslandEdge::Right: return {screen.x() + screen.width() - window.width(), alongY};
    case IslandEdge::Top: break;
    }
    return {alongX, screen.y()};
}

void IslandWindow::place()
{
    if (m_layer)
        return;
    if (const QScreen *screen = QGuiApplication::primaryScreen())
        m_view.setPosition(positionFor(edge(), screen->geometry(), m_view.size()));
}

void IslandWindow::applyEdge()
{
#if FAROL_KDE
    if (m_layer)
        LayerShellQt::Window::get(&m_view)->setAnchors(anchorFor(edge()));
#endif
    place();
    updateMask();
}

void IslandWindow::show()
{
    if (!m_ok)
        return;
    if (!m_layer && x11::available()) {
        m_view.create();                           // the window exists, not shown yet: now is when its workspace is said
        x11::showOnEveryWorkspace(m_view.winId());
        m_seeThrough = x11::composited();
        updateMask();
    }
    m_view.show();
}

void IslandWindow::updateMask()
{
    if (!m_root)
        return;
    QRect rect;
    if (m_state->mode() == IslandMode::Hidden) {
        // Invisible island: only a 3 px strip along the docked edge reacts (L0 finding 5).
        rect = hiddenStrip(edge(), QSizeF(m_view.size()), m_state->notchWidth()).toAlignedRect();
    } else {
        rect = m_root->property("islandRect").toRectF().toAlignedRect();
    }
    // 6 px of slack around the island, like the macOS hit test, clipped to the window.
    rect = rect.adjusted(-6, -6, 6, 6).intersected(QRect(QPoint(0, 0), m_view.size()));
    if (m_layer || !x11::available() || !m_seeThrough) {
        // Without a compositor (X11) the window is cut to the island: what is around it would be black.
        m_view.setMask(QRegion(rect));
        return;
    }
    // On X11 a mask also cuts what is drawn (the beam, a shadow): only the input region is set, in the server's
    // own pixels.
    if (m_view.handle()) {
        const qreal scale = m_view.devicePixelRatio();
        x11::setInputRegion(m_view.winId(), QRectF(rect.x() * scale, rect.y() * scale, rect.width() * scale, rect.height() * scale).toAlignedRect());
    }
}

void IslandWindow::lookForCompositor()
{
    if (m_layer || !x11::available())
        return;
    const bool seeThrough = x11::composited();
    if (seeThrough == m_seeThrough)
        return;
    m_seeThrough = seeThrough;
    if (seeThrough)
        m_view.setMask(QRegion());
    updateMask();
}

void IslandWindow::applyKeyboard(bool onDemand)
{
#if FAROL_KDE
    if (m_layer) {
        auto *layer = LayerShellQt::Window::get(&m_view);
        layer->setKeyboardInteractivity(onDemand ? LayerShellQt::Window::KeyboardInteractivityOnDemand
                                                 : LayerShellQt::Window::KeyboardInteractivityNone);
        return;
    }
#endif
    // On demand: a click on the island gives it the keyboard, as any window. Otherwise it never takes it, and the
    // window that had it gets it back when the island was the one typing.
    if (onDemand == !m_view.flags().testFlag(Qt::WindowDoesNotAcceptFocus))
        return;
    if (onDemand) {
        m_before = x11::activeWindow();
        m_view.setFlag(Qt::WindowDoesNotAcceptFocus, false);
        return;
    }
    const bool typing = m_view.isActive();
    m_view.setFlag(Qt::WindowDoesNotAcceptFocus, true);
    if (typing && m_before && m_before != quint64(m_view.winId()))
        x11::activate(m_before);
    m_before = 0;
}

} // namespace farol
