#pragma once
#include "HookEvent.h"

#include <QChar>
#include <QList>
#include <QString>
#include <optional>

namespace farol {

struct DiffRow {
    QChar kind;     // ' ' a line that stayed, '+' one added, '-' one removed, '@' the head of a hunk ("@@ -1,4 +1,5 @@")
    QString text;   // without its marker, as diffText() leaves it
};

// What a file tool did to a file, read from its PostToolUse.
struct EditDiff {
    QString file;                  // as the tool named it
    bool created = false;          // the file was not there before
    int added = 0, removed = 0;    // lines, over the whole edit: also when the rows were cut
    bool cut = false;              // the edit was more than the rows show
    QList<DiffRow> rows;
};

inline constexpr int kDiffMaxLines = 300;   // lines of an edit that are kept (the heads of its hunks come on top)
inline constexpr int kDiffMaxChars = 240;   // of one line, its marker included

// Edit, Write, MultiEdit and NotebookEdit: the tools whose PostToolUse says what changed in a file.
bool isFileTool(const QString &tool);

// A line of a file as a row shows it: a tab is four spaces, the end of a Windows line is dropped, and whatever
// would draw nothing, break the row or turn the text around (control characters, line separators, the bidi
// controls, half a surrogate pair) is U+FFFD, so that it is seen to be there.
QString diffText(const QString &line);

// The diff of the edit a PostToolUse reports. Edit, Write and MultiEdit carry it as a structuredPatch (a Write that
// creates a file as its content, which farol-hook turns into one hunk of additions); a NotebookEdit carries the
// cell before and after, which unifiedDiff() compares. The counts are farol-hook's (made before it cut the patch)
// or, from an older hook that sends everything, the patch's own; kDiffMaxLines and kDiffMaxChars are applied here
// again. A diff without rows is an edit that changed nothing, or one whose patch did not come. nullopt for any
// other event or tool and for a tool_response of a shape this does not know: the step then stays a plain step.
std::optional<EditDiff> editDiffOf(const HookEvent &e);

} // namespace farol
