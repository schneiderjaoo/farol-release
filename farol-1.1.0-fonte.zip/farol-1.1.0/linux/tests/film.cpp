// Development aid, not a test: plays scripted demos of the island off screen, on a made-up desktop with a pointer
// and captions (tests/film/Stage.qml), and saves the frames of each one and a few stills.
//   QT_SCALE_FACTOR=2 QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software build/tests/farol_film <output folder>
// Then, per film:  ffmpeg -framerate 10 -i <folder>/<film>/%05d.png ... (see linux/design/marketing/README.md)
#include <QDir>
#include <QFile>
#include <QFontDatabase>
#include <QGuiApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QQmlContext>
#include <QQuickItem>
#include <QQuickView>
#include <QSettings>
#include <QTemporaryDir>
#include <QTest>
#include <QTimer>
#include "Answers.h"
#include "AppState.h"
#include "ApprovalQueue.h"
#include "Ask.h"
#include "ClaudeSessions.h"
#include "EditDiffs.h"
#include "FakeAsk.h"
#include "FakeCommandRunner.h"
#include "HooksStatus.h"
#include "IslandController.h"
#include "LumiLook.h"
#include "Plugins.h"
#include "QuestionDesk.h"
#include "Repos.h"
#include "Scheduler.h"
#include "Shortcuts.h"
#include "Skills.h"
#include "Theme.h"

using namespace farol;

static const char kPlugins[] = R"JSON({
  "installed": [
    {"id": "superpowers@claude-plugins-official", "scope": "user", "enabled": true},
    {"id": "code-simplifier@claude-plugins-official", "scope": "user", "enabled": true},
    {"id": "agent-sdk-dev@claude-plugins-official", "scope": "user", "enabled": false}
  ],
  "available": [
    {"pluginId": "pr-review-toolkit@claude-plugins-official", "name": "pr-review-toolkit", "description": "Review agents for tests, types and error handling."},
    {"pluginId": "context7@context7-marketplace", "name": "context7", "description": "Up-to-date library docs."},
    {"pluginId": "frontend-design@claude-plugins-official", "name": "frontend-design", "description": "Distinctive, production-grade interfaces."}
  ]
})JSON";

static HookEvent ev(const QString &name, const QString &sid, const QString &cwd, const QJsonObject &extra = {})
{
    QJsonObject o = extra;
    o["hook_event_name"] = name;
    o["session_id"] = sid;
    o["cwd"] = cwd;
    return *HookEvent::parse(QJsonDocument(o).toJson(QJsonDocument::Compact));
}

static QQuickItem *findItem(QQuickItem *item, const std::function<bool(QQuickItem *)> &is)
{
    if (is(item))
        return item;
    for (QQuickItem *c : item->childItems())
        if (QQuickItem *f = findItem(c, is))
            return f;
    return nullptr;
}

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    app.setApplicationVersion(QStringLiteral("1.0.1"));
    const QString out = argc > 1 ? QString::fromLocal8Bit(argv[1]) : QStringLiteral("film");
    QDir().mkpath(out);
    for (const char *font : {"/BricolageGrotesque.ttf", "/InstrumentSans.ttf"})
        QFontDatabase::addApplicationFont(QStringLiteral(FAROL_FONTS_DIR) + QLatin1String(font));

    QTemporaryDir dir;
    QSettings settings(dir.path() + "/s.ini", QSettings::IniFormat);
    AppState state(&settings);
    state.setSessionIdleSeconds(0);                 // nobody turns dormant in the middle of a film
    state.setWaitReminderSeconds(0);
    QtScheduler sched;
    IslandController ctl(&state, &sched, [] { return QDateTime::currentMSecsSinceEpoch(); });
    Theme theme(&state);
    theme.setSystemDark(true);
    LumiLooks looks;
    ApprovalQueue queue(sched, &settings);
    QuestionDesk questions(sched);
    EditDiffs diffs(&state, &ctl);
    ClaudeSessions sessions(&state, &ctl, &sched, &queue, &questions, nullptr, &diffs);
    Shortcuts shortcuts(&settings, [](const QString &, int) { return QStringLiteral("Meta+F"); });
    HooksStatus hooks([] { return QStringLiteral("installed"); });
    FakeCommandRunner commands, claude;
    Skills skills(&state, &commands, &settings, dir.path() + "/claude-skills", [] { return QDateTime::currentMSecsSinceEpoch(); });
    Plugins plugins(&claude, [] { return QStringLiteral("/usr/bin/claude"); }, QStringLiteral("/usr/bin"));
    FakeSecretStore wallet;
    FakeHttpClient http;
    settings.setValue("ai/provider", "anthropic");
    Ask ask(&settings, &wallet, &http);
    Answers answers(&theme);
    Repos repos(&state);

    QQuickView view;
    QQmlContext *c = view.rootContext();
    c->setContextProperty("theme", &theme);
    c->setContextProperty("lumiLooks", &looks);
    c->setContextProperty("appState", &state);
    c->setContextProperty("controller", &ctl);
    c->setContextProperty("questions", &questions);
    c->setContextProperty("approvals", &queue);
    c->setContextProperty("sessions", &sessions);
    c->setContextProperty("diffs", &diffs);
    c->setContextProperty("shortcuts", &shortcuts);
    c->setContextProperty("hooks", &hooks);
    c->setContextProperty("skills", &skills);
    c->setContextProperty("plugins", &plugins);
    c->setContextProperty("ask", &ask);
    c->setContextProperty("answers", &answers);
    c->setContextProperty("repos", &repos);
    c->setContextProperty("islandUrl", QUrl::fromLocalFile(QStringLiteral(FAROL_QML_DIR "/Island.qml")));
    view.setSource(QUrl::fromLocalFile(QStringLiteral(FAROL_FILM_DIR "/Stage.qml")));
    if (view.status() != QQuickView::Ready)
        return 1;
    QQuickItem *stage = view.rootObject();
    view.show();
    ctl.setMode(IslandMode::Compact);
    QTest::qWait(300);

    // ---- recording ----
    QString reel;
    int frame = 0;
    QTimer camera;
    camera.setInterval(100);                         // 10 frames a second
    QObject::connect(&camera, &QTimer::timeout, &view, [&] {
        stage->setProperty("tick", !stage->property("tick").toBool());   // no stale pixels where the island was
        if (!reel.isEmpty())
            view.grabWindow().save(QStringLiteral("%1/%2/%3.png").arg(out, reel).arg(frame++, 5, 10, QLatin1Char('0')));
    });
    const auto record = [&](const QString &name) {
        QDir().mkpath(out + "/" + name);
        reel = name;
        frame = 0;
        camera.start();
    };
    const auto cut = [&] { camera.stop(); reel.clear(); };
    const auto still = [&](const QString &name) {
        stage->setProperty("tick", !stage->property("tick").toBool());
        view.grabWindow().save(out + "/" + name + ".png");
    };

    // ---- the actor ----
    const auto wait = [](int ms) { QTest::qWait(ms); };
    const auto say = [&](const QString &text) { stage->setProperty("caption", text); };
    const auto named = [&](const char *name) {
        return findItem(stage, [name](QQuickItem *i) { return i->objectName() == QLatin1String(name); });
    };
    const auto labelled = [&](const QString &text) {
        return findItem(stage, [&text](QQuickItem *i) { return i->isVisible() && i->property("primary").isValid() && i->property("text").toString() == text; });
    };
    const auto pointTo = [&](const QPointF &p) {
        stage->setProperty("pointerX", p.x());
        stage->setProperty("pointerY", p.y());
        wait(700);
        QTest::mouseMove(&view, p.toPoint());
        wait(150);
    };
    const auto centre = [](QQuickItem *item) { return item->mapToScene(QPointF(item->width() / 2, item->height() / 2)); };
    const auto click = [&](QQuickItem *item) {
        if (!item) {
            qWarning("nothing to click");
            return;
        }
        const QPointF p = centre(item);
        pointTo(p);
        stage->setProperty("pressed", true);
        wait(180);
        QTest::mouseClick(&view, Qt::LeftButton, Qt::NoModifier, p.toPoint());
        wait(160);
        stage->setProperty("pressed", false);
    };
    const auto title = [&](const QString &sid, const QString &text) {
        const QString path = dir.path() + '/' + sid + ".jsonl";
        QFile f(path);
        if (f.open(QIODevice::WriteOnly))
            f.write(QJsonDocument(QJsonObject{{"type", "ai-title"}, {"aiTitle", text}, {"sessionId", sid}}).toJson(QJsonDocument::Compact) + '\n');
        return path;
    };
    const auto tool = [&](const QString &sid, const QString &cwd, const QString &name, const QJsonObject &input, const QString &transcript = {}) {
        QJsonObject extra{{"tool_name", name}, {"tool_input", input}};
        if (!transcript.isEmpty())
            extra["transcript_path"] = transcript;
        sessions.handleEvent(ev("PreToolUse", sid, cwd, extra));
    };
    const auto bash = [&](const QString &sid, const QString &cwd, const QString &command) { tool(sid, cwd, "Bash", {{"command", command}}); };
    const auto endAll = [&] {
        for (const char *sid : {"a", "b", "c", "d"})
            sessions.handleEvent(ev("SessionEnd", sid, "/work/x"));
        ctl.setMode(IslandMode::Compact);
        stage->setProperty("pointerX", 620);
        stage->setProperty("pointerY", 380);
        QTest::mouseMove(&view, QPoint(620, 380));
        say({});
        wait(900);
    };
    const QPointF rest(640, 360);

    // ================= 1. the sessions =================
    bash("a", "/work/loja-api", "npm test");
    bash("b", "/work/site", "npm run build");
    bash("c", "/work/relatorios", "pytest -q");
    state.setFocus(ClaudeSessions::taskId("a"));
    state.modifyTask(ClaudeSessions::taskId("a"), [](AgentTask &t) { t.contextTokens = 96000; t.contextWindow = 200000; });
    ctl.setMode(IslandMode::Compact);
    wait(600);
    record("1-sessoes");
    say("Cada sessão do Claude Code vira um barco na ilha. Enquanto ela trabalha, o barco navega.");
    wait(2500);
    still("foto-1-ilha-pequena");
    tool("a", "/work/loja-api", "Edit", {{"file_path", "/work/loja-api/src/pedidos.ts"}});
    wait(2500);
    say("Quando uma sessão termina, o Lumi avisa.");
    sessions.handleEvent(ev("Stop", "b", "/work/site", {{"last_assistant_message", "Pronto: o build passou e o site está no ar."}}));
    wait(3200);
    click(labelled("OK"));
    wait(1200);
    say("Abra a ilha para ver todas as sessões.");
    pointTo(QPointF(480, 16));
    ctl.expandTo("overview");
    wait(2600);
    still("foto-2-sessoes");
    say("Um clique põe a sessão em foco: os últimos passos e o uso do contexto.");
    if (QQuickItem *row = named("pillName2"))
        click(row->parentItem());
    wait(2600);
    say("E outro leva você de volta à janela dela.");
    click(named("jumpButton"));
    pointTo(rest);
    wait(2200);
    cut();
    endAll();

    // ================= 2. permissions and questions =================
    bash("a", "/work/loja-api", "npm test");
    bash("b", "/work/site", "npm run dev");
    ctl.setMode(IslandMode::Compact);
    wait(600);
    record("2-permissoes");
    say("O Claude Code pediu permissão? A ilha abre com o comando.");
    wait(1800);
    sessions.handlePermission(ev("PermissionRequest", "a", "/work/loja-api", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "npm run migrate && npm test"}}}}), [](Decision) {});
    wait(3200);
    still("foto-3-permissao");
    say("Permita ou negue dali mesmo, sem trocar de janela.");
    click(labelled("Permitir"));
    wait(900);
    bash("a", "/work/loja-api", "npm run migrate && npm test");
    ctl.setMode(IslandMode::Compact);
    pointTo(rest);
    wait(1500);
    say("As perguntas do Claude também chegam na ilha.");
    QJsonArray options;
    for (const char *o : {"PostgreSQL", "SQLite", "Oracle"})
        options << QJsonObject{{"label", o}, {"description", QString()}};
    sessions.handleQuestion(ev("PermissionRequest", "b", "/work/site", {{"tool_name", "AskUserQuestion"},
                                {"tool_input", QJsonObject{{"questions", QJsonArray{QJsonObject{{"question", "Qual banco usar nos testes?"}, {"header", "Banco"},
                                                                                              {"multiSelect", false}, {"options", options}}}}}}}),
                            [](const QJsonObject &) {});
    wait(3200);
    still("foto-4-pergunta");
    click(named("questionOption0"));
    if (QQuickItem *confirm = named("questionConfirm"); confirm && confirm->isVisible())
        click(confirm);
    wait(900);
    bash("b", "/work/site", "npm test");
    ctl.setMode(IslandMode::Compact);
    pointTo(rest);
    say("Prefere decidir no editor? A ilha pequena continua avisando quem espera por você.");
    sessions.handlePermission(ev("PermissionRequest", "b", "/work/site", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "git push origin main"}}}}), [](Decision) {});
    wait(2600);
    click(labelled("Decidir no editor"));
    ctl.setMode(IslandMode::Compact);
    pointTo(rest);
    wait(4200);
    cut();
    endAll();

    // ================= 3. asking about a file =================
    ask.saveKey("anthropic", "k");
    bash("a", "/work/loja-api", "npm test");
    ctl.setMode(IslandMode::Compact);
    QFile report(dir.path() + "/vendas-setembro.csv");
    if (report.open(QIODevice::WriteOnly))
        report.write("produto;quantidade;total\ncamiseta;120;5400\ncalca;80;7200\n");
    report.close();
    wait(600);
    record("3-perguntar");
    say("Tem um arquivo e uma dúvida? Solte o arquivo na ilha.");
    stage->setProperty("dragging", "vendas-setembro.csv");
    wait(1500);
    pointTo(QPointF(470, 18));
    stage->setProperty("dragging", "");
    ask.addFile(report.fileName());
    ctl.expandTo("ask");
    wait(2200);
    say("Pergunte. Quem responde é o serviço que você escolher: Anthropic, ChatGPT ou Gemini, com a sua chave.");
    QQuickItem *field = named("askField");
    const QString question = QStringLiteral("Qual produto vendeu mais em setembro?");
    if (field) {
        pointTo(centre(field));
        for (int i = 1; i <= question.size(); ++i) {
            field->setProperty("text", question.left(i));
            wait(55);
        }
    }
    wait(700);
    click(named("askSend"));
    wait(2200);
    http.answer(200, R"({"content":[{"type":"text","text":"A **calça** foi o produto que mais faturou: R$ 7.200 com 80 peças.\n\nA camiseta vendeu mais unidades (120), mas somou R$ 5.400."}]})");
    say("A resposta chega ali mesmo, e a conversa continua.");
    pointTo(rest);
    wait(1000);
    still("foto-5-perguntar");
    wait(3600);
    cut();
    ask.clear();
    endAll();

    // ================= 4. the company's skills and the plugins =================
    for (const char *name : {"superloja-frontend", "superloja-openapi", "superloja-loja-api-sql", "superloja-testes"}) {
        QDir().mkpath(dir.path() + "/skills/" + name);
        QFile f(dir.path() + "/skills/" + name + "/SKILL.md");
        if (f.open(QIODevice::WriteOnly))
            f.write("# skill\n");
    }
    QDir().mkpath(dir.path() + "/skills/.git");
    state.setWorkspaceDir(dir.path());
    bash("a", "/work/loja-api", "npm test");
    ctl.setMode(IslandMode::Compact);
    wait(600);
    record("4-skills");
    say("As skills da empresa num lugar só: aponte a pasta do repositório uma vez.");
    pointTo(QPointF(480, 16));
    ctl.expandTo("overview");
    wait(900);
    click(named("railTabSkills"));
    wait(900);
    state.setSkillsDir(dir.path() + "/skills");
    wait(400);
    while (commands.pending() > 0)
        commands.answer(0);
    while (claude.pending() > 0)
        claude.answer(0, {}, kPlugins);
    say("O Farol liga cada skill ao Claude Code e atualiza a pasta pelo git. Se algo impedir, ele avisa.");
    wait(3600);
    still("foto-6-skills");
    say("Na mesma aba ficam os plugins: ligar, desligar, remover e instalar pelo catálogo.");
    click(named("pluginsAdd"));
    wait(400);
    while (claude.pending() > 0)
        claude.answer(0, {}, kPlugins);
    wait(3200);
    pointTo(rest);
    wait(1200);
    cut();
    return 0;
}
