#pragma once
#include <QHash>
#include <QList>
#include <QString>
#include <QStringList>

namespace farol {

// The company's skills folder (a git clone with one folder per skill) and the links that make Claude Code use it:
// ~/.claude/skills/<name> -> <folder>/<skill>. Only links that point into the chosen folder (or into the one chosen
// before) are ever created, changed or removed; anything else in ~/.claude/skills is left alone.
struct SkillEntry {
    QString name;   // the `name:` of its SKILL.md, else the folder's name: the name of the link
    QString path;   // the skill's folder
};

// Every direct subfolder with a SKILL.md, by name. Hidden folders are skipped.
QList<SkillEntry> scanSkills(const QString &skillsDir);

struct LinkPlan {
    QHash<QString, QString> create;   // link name -> skill folder: no link yet
    QHash<QString, QString> relink;   // ours, pointing at the wrong folder
    QStringList remove;               // ours, for a skill that is gone
    QStringList conflicts;            // the name is taken by something that is not ours: left alone
    int linked = 0;                   // skills in use once the plan is applied
    bool changes() const { return !create.isEmpty() || !relink.isEmpty() || !remove.isEmpty(); }
};

// skillsDir may be empty (no folder chosen: our links go). previousDir: the folder chosen before, whose links are
// ours too.
LinkPlan planLinks(const QString &skillsDir, const QString &claudeSkillsDir, const QString &previousDir = {});
bool applyLinks(const LinkPlan &plan, const QString &claudeSkillsDir, QString *error = nullptr);

} // namespace farol
