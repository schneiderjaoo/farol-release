#pragma once
#include <QString>
#include <functional>

namespace farol {

// Where secrets (API keys) are kept: the desktop's secret service, never a file of Farol's. The platform layer talks to
// org.freedesktop.secrets (KWallet on Plasma); tests give a fake. Every call answers once, later, without blocking.
class ISecretStore {
public:
    virtual ~ISecretStore() = default;
    virtual void read(const QString &name, std::function<void(bool ok, const QString &value)> done) = 0;
    virtual void write(const QString &name, const QString &value, std::function<void(bool ok)> done) = 0;
    virtual void remove(const QString &name, std::function<void(bool ok)> done) = 0;
};

} // namespace farol
