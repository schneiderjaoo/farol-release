#pragma once
#include "HttpClient.h"
#include "SecretStore.h"

#include <QHash>
#include <QList>

namespace farol {

// A wallet in memory. `failing` makes every call report a failure.
class FakeSecretStore : public ISecretStore {
public:
    QHash<QString, QString> values;
    bool failing = false;
    int reads = 0;
    void read(const QString &name, std::function<void(bool, const QString &)> done) override
    {
        ++reads;
        done(!failing, failing ? QString() : values.value(name));
    }
    void write(const QString &name, const QString &value, std::function<void(bool)> done) override
    {
        if (!failing)
            values.insert(name, value);
        done(!failing);
    }
    void remove(const QString &name, std::function<void(bool)> done) override
    {
        if (!failing)
            values.remove(name);
        done(!failing);
    }
};

// Records every request and answers when the test says so.
class FakeHttpClient : public IHttpClient {
public:
    struct Call {
        HttpRequest request;
        int timeoutMs;
        std::function<void(const Reply &)> done;
    };
    QList<Call> calls;
    int cancels = 0;
    void post(const HttpRequest &request, int timeoutMs, std::function<void(const Reply &)> done) override
    {
        calls.append({request, timeoutMs, std::move(done)});
    }
    void cancel() override { ++cancels; }
    void answer(int status, const QByteArray &body)
    {
        Reply r;
        r.status = status;
        r.body = body;
        finish(r);
    }
    void finish(const Reply &r) { calls.last().done(r); }
    QByteArray header(const char *name) const
    {
        for (const auto &h : calls.last().request.headers)
            if (h.first == name)
                return h.second;
        return {};
    }
};

} // namespace farol
