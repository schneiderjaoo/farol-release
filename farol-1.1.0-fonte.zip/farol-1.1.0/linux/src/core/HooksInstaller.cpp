#include "HooksInstaller.h"

#include "ClaudeSettingsMerger.h"
#include "TextDiff.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QSaveFile>

namespace farol {

HooksInstaller::HooksInstaller(QString settingsPath, QString hookPath, int decisionTimeoutSec, Clock clock, QString interpreter)
    : m_settingsPath(std::move(settingsPath)), m_hookPath(std::move(hookPath)), m_interpreter(std::move(interpreter)),
      m_decisionTimeoutSec(decisionTimeoutSec), m_clock(std::move(clock))
{
}

QString HooksInstaller::targetPath() const
{
    const QFileInfo fi(m_settingsPath);
    if (fi.isSymLink()) {
        const QString target = fi.canonicalFilePath();
        if (!target.isEmpty())
            return target;
    }
    return m_settingsPath;
}

bool HooksInstaller::readCurrent(QString *text, QString *error) const
{
    QFile f(targetPath());
    if (!f.exists()) {
        text->clear();
        return true;
    }
    if (!f.open(QIODevice::ReadOnly)) {
        *error = QStringLiteral("Cannot read %1: %2").arg(f.fileName(), f.errorString());
        return false;
    }
    *text = QString::fromUtf8(f.readAll());
    return true;
}

HooksPlan HooksInstaller::plan(bool install) const
{
    HooksPlan p;
    if (!readCurrent(&p.before, &p.error))
        return p;
    p.settingsExisted = QFileInfo::exists(targetPath());
    const MergeResult r = install ? ClaudeSettingsMerger::install(p.before, m_hookPath, m_decisionTimeoutSec, m_interpreter)
                                  : ClaudeSettingsMerger::uninstall(p.before);
    if (!r.ok) {
        p.error = r.error;
        return p;
    }
    p.ok = true;
    p.after = r.text;
    p.changes = r.changed;
    p.diff = unifiedDiff(p.before, p.after, QStringLiteral("settings.json (current)"), QStringLiteral("settings.json (after)"));
    return p;
}

bool HooksInstaller::installed() const
{
    QString text, error;
    return readCurrent(&text, &error) && ClaudeSettingsMerger::isInstalled(text);
}

bool HooksInstaller::upToDate() const
{
    if (!installed())
        return false;
    const HooksPlan p = planInstall();
    return p.ok && !p.changes;
}

QString HooksInstaller::backupPathFor() const
{
    const QFileInfo fi(m_settingsPath);
    const QString base = fi.absolutePath() + QLatin1Char('/') + fi.fileName() + QStringLiteral(".bak-") +
                         m_clock().toString(QStringLiteral("yyyyMMdd-HHmm"));
    QString path = base;
    for (int n = 2; QFileInfo::exists(path); ++n)
        path = base + QStringLiteral("-%1").arg(n);
    return path;
}

bool HooksInstaller::apply(const HooksPlan &plan, QString *error, QString *backupPath) const
{
    auto fail = [&](const QString &m) {
        if (error)
            *error = m;
        return false;
    };
    if (!plan.ok || !plan.changes)
        return fail(QStringLiteral("Nothing to write."));

    QString now, err;
    if (!readCurrent(&now, &err))
        return fail(err);
    if (now != plan.before)
        return fail(QStringLiteral("settings.json changed after the preview was made. Nothing was written; open the "
                                   "dialog again to see the new diff."));

    const QString target = targetPath();
    QFile::Permissions perms;
    if (QFileInfo::exists(target)) {
        perms = QFile::permissions(target);
        const QString backup = backupPathFor();
        if (!QFile::copy(target, backup))
            return fail(QStringLiteral("Could not create the backup %1; nothing was written.").arg(backup));
        if (backupPath)
            *backupPath = backup;
    } else if (!QDir().mkpath(QFileInfo(target).absolutePath())) {
        return fail(QStringLiteral("Could not create %1").arg(QFileInfo(target).absolutePath()));
    }

    QSaveFile out(target);
    if (!out.open(QIODevice::WriteOnly))
        return fail(QStringLiteral("Cannot write %1: %2").arg(target, out.errorString()));
    out.write(plan.after.toUtf8());
    if (!out.commit())
        return fail(QStringLiteral("Cannot write %1: %2").arg(target, out.errorString()));
    if (perms)
        QFile::setPermissions(target, perms);
    return true;
}

} // namespace farol
