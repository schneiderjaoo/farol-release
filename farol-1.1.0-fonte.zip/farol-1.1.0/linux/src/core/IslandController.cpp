#include "IslandController.h"

namespace farol {

using S = IslandStateMachine::State;

IslandController::IslandController(AppState *state, IScheduler *scheduler, NowFn now, QObject *parent)
    : QObject(parent), m_state(state), m_now(std::move(now)), m_fsm(*scheduler), m_hover(*scheduler)
{
    m_fsm.onTransition = [this](S from, S to) { onFsmTransition(from, to); };
    m_hover.onChanged = [this](bool inside) { inside ? pointerEntered() : pointerLeft(); };

    // Deliberate fix over the Swift app, where the auto-close setting only drew the countdown line and the
    // island still collapsed after a fixed 15 s: here the setting is the real collapse delay.
    auto applyAutoClose = [this] { m_fsm.homeToPetitDelayMs = qRound(m_state->autoCloseInterval() * 1000); };
    applyAutoClose();
    connect(m_state, &AppState::autoCloseIntervalChanged, this, applyAutoClose);

    // Settings -> "Esconder sem uso". Turned on with the pointer elsewhere, the minute starts now.
    m_fsm.setHideWhenIdle(m_state->autoHide());
    connect(m_state, &AppState::autoHideChanged, this, [this] {
        m_fsm.setHideWhenIdle(m_state->autoHide());
        if (!m_state->autoHide())
            m_fsm.reveal();                    // a hidden island comes back, to stay
        else if (!m_wasInIsland && m_fsm.state() == S::Petit)
            m_fsm.mouseLeft();
    });

    m_lastLevel = modeLevel(m_state->mode());
    connect(m_state, &AppState::modeChanged, this, [this] {
        const int level = modeLevel(m_state->mode());
        const bool shrinking = level < m_lastLevel;
        m_lastLevel = level;
        updateLayout(shrinking);
    });
    for (auto signal : {&AppState::viewChanged, &AppState::chatCountChanged, &AppState::uploadProgressChanged,
                        &AppState::notchChanged, &AppState::edgeChanged})
        connect(m_state, signal, this, [this] { updateLayout(false); });
    updateLayout(false);
}

int IslandController::modeLevel(IslandMode m)
{
    switch (m) {
    case IslandMode::Hidden: return 0;
    case IslandMode::Compact: return 1;
    case IslandMode::Expanded: return 2;
    }
    return 0;
}

void IslandController::updateLayout(bool shrinking)
{
    const QSizeF sz = islandSize(m_state->mode(), m_state->view(), m_state->notchWidth(), m_state->notchHeight(),
                                 m_state->chatCount(), m_state->vertical());
    m_w = sz.width();
    m_h = sz.height();
    m_corner = islandCornerRadius(m_state->mode());
    m_bot = botPosition(m_state->mode(), m_state->view(), m_h, m_state->uploadProgress(), m_state->vertical());
    if (shrinking != m_shrinking) {
        m_shrinking = shrinking;
        emit shrinkingChanged();               // first: Behavior reads the curve when the size changes
    }
    emit layoutChanged();
}

IslandView IslandController::defaultView() const
{
    return m_state->taskModel()->all().isEmpty() ? IslandView::Empty : IslandView::Overview;
}

void IslandController::onFsmTransition(S from, S to)
{
    switch (to) {
    case S::Hidden:
        setMode(IslandMode::Hidden);
        break;
    case S::Petit:
        if (from == S::Home && m_state->isPinned()) {
            // A pinned alert (permission request) must stay until answered: undo the timer-driven collapse.
            // Silent, no timers: the answer re-arms the idle timer through expand().
            m_fsm.openExternally();
            return;
        }
        if (from == S::Coucou)
            emit greetingInterrupt();          // collapse of the greeting canvas starts before the mode change
        else if (from == S::Hidden)
            emit playSound(QStringLiteral("peek"));
        // mode first, then the view: changing the view while compact must not trigger an open animation
        setMode(IslandMode::Compact);
        if (from == S::Coucou)
            m_state->setView(defaultView());
        if (!m_wasInIsland)
            m_fsm.mouseLeft();                 // starts the 60 s hide timer when the pointer is not over the island
        break;
    case S::Home:
        applyExpand(defaultView());
        if (!m_wasInIsland)
            m_fsm.mouseLeft();                 // starts the 15 s collapse timer
        break;
    case S::Coucou:
        applyExpand(IslandView::Greeting);
        break;
    }
}

void IslandController::setMode(IslandMode mode)
{
    const IslandMode prev = m_state->mode();
    if (mode == prev)
        return;
    m_state->setMode(mode);
    if (mode == IslandMode::Expanded)
        emit playSound(QStringLiteral("open"));
    if (prev == IslandMode::Expanded) {
        emit playSound(QStringLiteral("close"));
        m_state->setPinned(false);
        emit keyboardOnDemandChanged(false);   // whatever closed it (Esc, FSM timer, greeting): hand the keyboard back
    }
}

void IslandController::expand(IslandView view)
{
    // Opened from outside the FSM (tray/debug menu, hook alerts): keep the FSM in step, and give it the same
    // 15 s idle collapse a click-open has when the pointer is elsewhere — except for pinned alerts, which stay
    // until answered. Opening again while already in Home restarts that idle timer.
    const IslandStateMachine::State before = m_fsm.state();
    const bool moved = m_fsm.openExternally();     // Hidden/Petit/Coucou -> Home, silently
    if (moved && before == S::Coucou)
        emit greetingInterrupt();                  // the greeting canvas stops
    applyExpand(view);
    if ((moved || before == S::Home) && !m_wasInIsland && !m_state->isPinned())
        m_fsm.mouseLeft();
}

void IslandController::applyExpand(IslandView view)
{
    m_state->setView(view);
    if (m_state->mode() != IslandMode::Expanded)
        setMode(IslandMode::Expanded);
    m_state->setLastActivityMs(m_now());
    if (view == IslandView::Prompt || view == IslandView::Mail || view == IslandView::Ask)
        emit keyboardOnDemandChanged(true);        // views with a text field need the keyboard
}

void IslandController::collapse()
{
    m_state->setPinned(false);
    const IslandStateMachine::State before = m_fsm.state();
    if (m_fsm.closeExternally()) {                 // Home/Coucou -> Petit, so the pill is clickable again
        if (before == S::Coucou)
            emit greetingInterrupt();
        if (!m_wasInIsland)
            m_fsm.mouseLeft();                     // start the 60 s hide countdown
    }
    setMode(IslandMode::Compact);
}

void IslandController::pointerEntered()
{
    if (m_wasInIsland)
        return;
    if (m_fsm.state() == S::Coucou)
        emit greetingHover();                  // keep the greeting open while the pointer is on it
    m_fsm.mouseEntered();
    m_wasInIsland = true;                      // after the FSM call, like pollFrame() in Swift
}

void IslandController::pointerLeft()
{
    if (!m_wasInIsland)
        return;
    m_fsm.mouseLeft();
    m_wasInIsland = false;
}

void IslandController::setPointerInside(bool inside)
{
    inside ? m_hover.enter() : m_hover.leave();
}

void IslandController::islandClicked()
{
    if (m_state->mode() != IslandMode::Expanded)
        m_fsm.click();
}

void IslandController::escapePressed()
{
    if (m_state->mode() == IslandMode::Expanded && !m_state->isPinned())
        collapse();
}

void IslandController::greetComplete() { m_fsm.greetComplete(); }
void IslandController::launch() { m_fsm.launch(); }
void IslandController::reveal() { m_fsm.reveal(); }
void IslandController::requestKeyboard(bool onDemand) { emit keyboardOnDemandChanged(onDemand); }
void IslandController::resetActivity() { m_state->setLastActivityMs(m_now()); }

void IslandController::showView(const QString &viewName)
{
    if (auto v = enumFromKey<IslandView>(viewName)) {
        m_state->setView(*v);
        resetActivity();
    }
}

void IslandController::expandTo(const QString &viewName)
{
    if (auto v = enumFromKey<IslandView>(viewName))
        expand(*v);
}

} // namespace farol
