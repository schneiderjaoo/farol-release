#pragma once
#include "JumpTarget.h"

#include <QList>
#include <QString>
#include <QStringList>

namespace farol {

// What to run to take the user back to a Claude Code session. Pure: SessionJumper executes it.
struct JumpCommand {
    // RaiseWindow: nothing to run, the session's window (found through its processes) only has to come forward.
    enum class Kind { None, Process, KonsoleDBus, RaiseWindow };
    Kind kind = Kind::None;
    QStringList windowClasses;   // Process: what the editor's windows are called by KWin (compared without case)
    QString program;
    QStringList args;            // Process
    QString service, objectPath; // KonsoleDBus: org.kde.konsole.Window.setCurrentSession(sessionId)
    int sessionId = 0;
};

JumpCommand jumpCommandFor(const JumpTarget &target);

// Asks the editor for a new Claude Code tab in the window that has the focus: the extension's own URI handler
// ("/open" runs its "Open in Primary Editor" command). An unknown or malformed flatpak id falls back to VSCodium.
// `editor` is the editor's program when it is not a Flatpak ("code", "cursor", ...).
JumpCommand newClaudeTabCommand(const QString &flatpakId = {}, const QString &editor = {});

// Folder names that can appear in the title of the editor window holding a session: the session's folder, then up
// to two folders above it. Empty for a relative path or "/".
QStringList windowFolderCandidates(const QString &cwd);

// The same for a new session: only the repository's own folder (a window of a folder above it would start Claude there).
QStringList sessionWindowFolders(const QString &repo);

// KWin script that raises a window and reports the outcome to Farol's own D-Bus object (SessionJumper::WindowResult).
// The candidates are the windows of one of `windowClasses` or of one of the processes `pids`; the first whose title
// names one of `folders` (in priority order) wins. With `anyWindow` (a terminal: its title may say anything) a
// candidate of the closest process is taken when no title matches. The strings are JSON-escaped.
QString kwinActivateScript(const QStringList &folders, const QStringList &windowClasses, const QList<qint64> &pids = {},
                           bool anyWindow = false);

// A window of the desktop, as Farol reads it itself where there is no KWin to ask (X11).
struct DesktopWindow {
    quint64 id = 0;
    QString windowClass;   // compared without case
    QString title;
    qint64 pid = 0;
    bool operator==(const DesktopWindow &) const = default;
};

// The choice kwinActivateScript makes, for a list of windows read here: the index of the window to raise, -1 when
// there is none. Same candidates, same order of preference.
int windowToRaise(const QList<DesktopWindow> &windows, const QStringList &folders, const QStringList &windowClasses,
                  const QList<qint64> &pids = {}, bool anyWindow = false);

} // namespace farol
