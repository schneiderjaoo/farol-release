#pragma once
#include "CommandRunner.h"

#include <QList>

namespace farol {

// Records every command and answers when the test says so.
class FakeCommandRunner : public ICommandRunner {
public:
    struct Call {
        QString program;
        QStringList arguments, env;
        int timeoutMs;
        std::function<void(const Result &)> done;
        QByteArray input;
    };
    QList<Call> calls;
    int cancels = 0;

    void run(const QString &program, const QStringList &arguments, const QStringList &env, int timeoutMs,
             std::function<void(const Result &)> done, const QByteArray &input = {}) override
    {
        calls.append({program, arguments, env, timeoutMs, std::move(done), input});
    }
    void cancel() override { ++cancels; }
    // Answers the oldest command not answered yet.
    void answer(int exitCode, const QString &err = {}, const QString &out = {})
    {
        Result r;
        r.started = true;
        r.exitCode = exitCode;
        r.err = err;
        r.out = out;
        finish(r);
    }
    void finish(const Result &r)
    {
        const auto done = calls.at(answered).done;
        ++answered;
        done(r);
    }
    int pending() const { return int(calls.size()) - answered; }
    int answered = 0;
};

} // namespace farol
