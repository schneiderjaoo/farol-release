#pragma once
#include <QByteArray>
#include <QList>
#include <QPair>
#include <QUrl>
#include <functional>

namespace farol {

struct HttpRequest {
    QUrl url;
    QList<QPair<QByteArray, QByteArray>> headers;
    QByteArray body;
};

// Posts one request without blocking and reports once how it went. The platform layer does it with
// QNetworkAccessManager; tests give a fake.
class IHttpClient {
public:
    struct Reply {
        int status = 0;          // 0: no answer from the server (see `error`)
        bool timedOut = false;
        bool cancelled = false;
        QByteArray body;
        QString error;           // the transport's own words when there was no answer
    };
    virtual ~IHttpClient() = default;
    virtual void post(const HttpRequest &request, int timeoutMs, std::function<void(const Reply &)> done) = 0;
    // Gives up the request under way; its `done` is called with `cancelled`.
    virtual void cancel() = 0;
};

} // namespace farol
