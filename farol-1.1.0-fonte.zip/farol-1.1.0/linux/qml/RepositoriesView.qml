import QtQuick

// "Nova sessão" (the + tab; the view keeps the Swift name "upload"): the git repositories found under the workspace
// folder chosen in Settings. A click on one (or Enter in the filter, for the first match) opens it in the editor
// with a new Claude Code session. Nothing is opened without that click or Enter.
Item {
    id: view
    readonly property bool vertical: appState.vertical
    readonly property real sideX: vertical ? 12 : 16         // Lumi lives on the rail, outside the card
    readonly property bool hasWorkspace: appState.workspaceDir !== ""
    readonly property var list: repos.list
    readonly property bool filtering: repos.filter !== ""

    function open(path) {
        repos.open(path)
        controller.collapse()
    }

    // The view is loaded each time its tab opens: look at the folder again and start with the whole list.
    Component.onCompleted: {
        repos.filter = ""
        repos.refresh()
    }

    Card { anchors.fill: parent }

    Text {
        id: title
        x: view.sideX
        y: 12
        height: view.vertical ? 18 : 30
        verticalAlignment: Text.AlignVCenter
        textFormat: Text.PlainText
        text: "Nova sessão"
        color: theme.text
        font.family: theme.titleFont
        font.pixelSize: 15
        font.weight: Font.DemiBold
    }

    // Filter: beside the title, or under it in the portrait island.
    Rectangle {
        id: filterBox
        visible: repos.total > 0
        x: view.vertical ? view.sideX : title.x + title.width + 14
        y: view.vertical ? 36 : 12
        width: parent.width - x - (view.vertical ? 12 : 16)
        height: 30
        radius: 12
        color: theme.codeBg
        border.width: 1
        border.color: field.activeFocus ? theme.primary : theme.line
        TextInput {
            id: field
            objectName: "repoFilter"
            anchors.fill: parent
            anchors.leftMargin: 12
            anchors.rightMargin: 12
            verticalAlignment: TextInput.AlignVCenter
            clip: true
            color: theme.text
            selectionColor: theme.primary
            selectedTextColor: theme.primaryText
            font.family: theme.bodyFont
            font.pixelSize: 13
            maximumLength: 80
            onTextChanged: repos.filter = text
            Keys.onReturnPressed: if (view.filtering && view.list.length > 0) view.open(view.list[0].path)
            Keys.onEnterPressed: if (view.filtering && view.list.length > 0) view.open(view.list[0].path)
            Keys.onEscapePressed: text !== "" ? text = "" : controller.collapse()
            Text {
                anchors.fill: parent
                verticalAlignment: Text.AlignVCenter
                visible: field.text === "" && !field.activeFocus
                textFormat: Text.PlainText
                text: view.vertical ? "Filtrar…" : "Filtrar " + repos.total + " repositórios…"
                color: theme.dim
                font: field.font
                elide: Text.ElideRight
            }
        }
    }

    // Under the title and the filter: the repositories, or why there are none.
    Item {
        id: body
        x: view.sideX
        y: view.vertical ? 74 : 50
        width: parent.width - x - (view.vertical ? 12 : 16)
        height: parent.height - y - 10

        Flickable {
            anchors.fill: parent
            visible: view.list.length > 0
            contentHeight: pills.height
            clip: true
            boundsBehavior: Flickable.StopAtBounds
            Flow {
                id: pills
                width: parent.width
                spacing: 8
                Repeater {
                    model: view.list
                    PillButton {
                        required property var modelData
                        required property int index
                        objectName: "repo" + index
                        maxWidth: pills.width
                        text: modelData.label
                        primary: view.filtering && index === 0   // the one Enter opens
                        onClicked: view.open(modelData.path)
                    }
                }
            }
        }

        Column {
            visible: view.list.length === 0
            width: parent.width
            spacing: 8
            Text {
                objectName: "repoEmpty"
                width: parent.width
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                text: !view.hasWorkspace ? "Escolha a pasta da sua workspace nas Configurações para ver os repositórios."
                      : repos.total === 0 ? "Nenhum repositório (.git) em " + appState.workspaceDirLabel + "."
                      : "Nenhum repositório com “" + repos.filter + "”."
                color: theme.muted
                font.family: theme.bodyFont
                font.pixelSize: 13
            }
            PillButton {
                objectName: "repoSettings"
                visible: !view.hasWorkspace
                text: "Abrir Configurações"
                primary: true
                onClicked: controller.showView("settings")
            }
        }
    }
}
