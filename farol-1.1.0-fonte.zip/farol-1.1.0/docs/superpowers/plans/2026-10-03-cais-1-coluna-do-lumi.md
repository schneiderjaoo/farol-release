# Cais 1 — coluna do Lumi com as abas — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** A faixa de abas do topo da ilha aberta dá lugar a uma coluna à esquerda, com o Lumi em cima e as abas embaixo dele, em todas as views.

**Architecture:** `IslandRail.qml` substitui `IslandHeader.qml`: uma grade de `RailTab` (2×2 em paisagem, uma linha de 4 no retrato). `Island.qml` põe a coluna e as views lado a lado (coluna em cima no retrato). `botPosition` passa a colocar o Lumi no topo da coluna. As views perdem a margem esquerda que reservava o lugar do Lumi. As alturas da ilha em paisagem não mudam: os 34 px da faixa viram espaço de conteúdo.

**Tech Stack:** C++20, Qt 6 QML, QtTest. Build e testes no host por `linux/scripts/host.sh`.

**Spec:** `docs/superpowers/specs/2026-10-03-redesenho-cais-design.md` (§2.1). Este plano cobre só o passo 1 da §6; os passos 2 a 6 têm planos próprios.

## Global Constraints

- Build, teste e execução sempre no host: `linux/scripts/host.sh sh -c 'cd ~/workspace/farol && cmake -S linux -B linux/build -G Ninja >/dev/null && cmake --build linux/build > linux/build/build.log 2>&1 && ctest --test-dir linux/build --output-on-failure'`.
- Nunca um hex num `.qml`: cores e fontes só de `theme.*`.
- Texto de interface em pt-BR; código e comentários em inglês.
- Nenhum commit, push ou PR: o autor commita quando quiser.
- Não tirar capturas da tela do autor.
- `pkill -x farol` sozinho na própria chamada; nunca `pkill -f`.
- Nada é aprovado, respondido ou aberto sem clique ou Enter.
- Desvio da spec, decidido aqui: a §2.1 diz que cada view perde 34 px de altura. As alturas em paisagem ficam como estão, porque a coluna precisa de 150 px (Lumi + abas) e a menor view tem 160. O conteúdo ganha os 34 px.
- A quarta casa da grade é o botão de som (alto-falante) até a aba Skills existir (passo 5); a essa altura o som já estará na janela de Ajustes (passo 2).

## Geometria (valores usados em todas as tarefas)

| | Paisagem (640 de largura) | Retrato (280 de largura) |
|---|---|---|
| Coluna (`rail`) | x 10, y 10, 88 × (H − 20) | x 10, y 10, (W − 20) × 66 |
| Lumi (`botPosition`) | centro (54, 48), diâmetro 52 | centro (44, 44), diâmetro 52 |
| Grade de abas | 2 colunas, na ilha em (17, 90) | 4 colunas, na ilha em (116, 31) |
| Aba (`RailTab`) | 34 × 26, raio 9, espaço 6 | igual |
| Views | x 106, y 10, (W − 116) × (H − 20) | x 10, y 86, (W − 20) × (H − 96) |

## Review Focus

- Retrato com menos altura para o conteúdo (as views começam em y 86 em vez de 42): textos longos não podem sair da ilha. Coberto na Tarefa 3 pelo teste de retrato existente, com as alturas ajustadas.
- Coluna invisível (saudação, "confused") não pode receber clique: uma aba transparente que troca de view seria um clique fantasma. Teste na Tarefa 2.
- Clicar numa aba com um pedido de permissão na tela: deve se comportar como a faixa antiga (troca a view; o pedido continua na fila). Teste na Tarefa 2.
- O Lumi não pode cobrir as abas em nenhuma view nem borda. Teste na Tarefa 2.
- Nenhum texto de view pode ficar embaixo da coluna em paisagem. Teste na Tarefa 3.

---

### Task 1: Lugar do Lumi na coluna

**Files:**
- Modify: `linux/src/core/IslandTypes.cpp` (`botPosition`)
- Test: `linux/tests/tst_island_types.cpp`, `linux/tests/tst_island_controller.cpp`

**Interfaces:**
- Produces: `botPosition(Expanded, view, h, p, portrait=false)` → `{54, 48, 52, 1}`; com `portrait=true` → `{44, 44, 52, 1}`. `Uploading` e `Greeting` mantêm o lugar próprio.

- [ ] **Step 1: Ajustar os testes para os valores novos**

Em `tst_island_types.cpp`, no teste que percorre as views em retrato, trocar a verificação por:

```cpp
QVERIFY2(p.cx == 44 && p.cy == 44 && p.diameter == 52, qPrintable(enumKey(IslandView(v))));
```

e a verificação de paisagem por:

```cpp
// Farol: one spot for every open view, on top of the rail, so the mascot does not move when the tab changes
auto o = botPosition(IslandMode::Expanded, IslandView::Overview, 160, 0);
QCOMPARE(o.cx, 54.0); QCOMPARE(o.cy, 48.0); QCOMPARE(o.diameter, 52.0); QCOMPARE(o.opacity, 1.0);
```

Em `tst_island_controller.cpp`, `sideEdgesUseThePortraitLayout`: `QCOMPARE(ctl->botX(), 44.0);` depois do `expand` em retrato e `QCOMPARE(ctl->botX(), 54.0);` depois de voltar à paisagem.

- [ ] **Step 2: Rodar e ver falhar**

Run: `linux/scripts/host.sh sh -c 'cd ~/workspace/farol && cmake --build linux/build > linux/build/build.log 2>&1 && ctest --test-dir linux/build -R "tst_island_types|tst_island_controller" --output-on-failure'`
Expected: FAIL, "Actual (o.cx): 62" e "Actual (ctl->botX()): 48".

- [ ] **Step 3: Implementar**

Em `botPosition`, no ramo de retrato, `return {48, 92, 56, 1};` vira:

```cpp
            return {44, 44, 52, 1};   // top-left, on the rail; the tabs sit beside it
```

e no ramo de paisagem, o comentário e o `return {62, 101, 56, 1};` viram:

```cpp
        // On top of the rail (88 wide from x = 10); the tabs come under it.
        return {54, 48, 52, 1};
```

- [ ] **Step 4: Rodar e ver passar**

Mesmo comando do Step 2. Expected: `100% tests passed`.

---

### Task 2: A coluna e as abas

**Files:**
- Create: `linux/qml/RailTab.qml`, `linux/qml/IslandRail.qml`
- Delete: `linux/qml/IslandHeader.qml`, `linux/qml/HeaderTab.qml`
- Modify: `linux/qml/Island.qml` (bloco `content`), `linux/src/app/CMakeLists.txt` (lista `farol_qml`)
- Test: `linux/tests/tst_island_qml.cpp`

**Interfaces:**
- Consumes: `botPosition` da Tarefa 1.
- Produces: itens `rail`, `railTabs`, `railTabSessions`, `railTabNew`, `railTabSettings`, `railTabSound` (cada aba com `signal clicked()` e `property bool on`); as views em x 106 / y 10 (paisagem) e x 10 / y 86 (retrato).

- [ ] **Step 1: Escrever os testes**

Em `tst_island_qml.cpp`, `contentIsHiddenWhileCompact` passa a usar `child("rail")` no lugar de `child("header")` (mesmas três verificações). Em `lumiIsCentredAndInsideTheIslandInEveryView`, a linha vertical vira `QVERIFY2(r.top() >= 4 && r.bottom() <= island->height() - 4, ...)`. Acrescentar:

```cpp
    // The rail: the tabs under Lumi (beside it on a side edge), never under it, and each one opens its view.
    void theRailHoldsTheTabsAndLumiDoesNotCoverThem()
    {
        for (const char *edge : {"top", "left"}) {
            state->setEdge(edge);
            ctl->expandTo("overview");
            QTest::qWait(900);
            QQuickItem *island = child("island");
            QQuickItem *lumi = nullptr;
            for (QQuickItem *c : child("bot")->childItems())
                lumi = c;
            QVERIFY(lumi);
            const QRectF l = lumi->mapRectToItem(island, QRectF(0, 0, lumi->width(), lumi->height()));
            for (const char *name : {"railTabSessions", "railTabNew", "railTabSettings", "railTabSound"}) {
                QQuickItem *tab = child(name);
                QVERIFY2(tab && tab->isVisible(), name);
                const QRectF r = tab->mapRectToItem(island, QRectF(0, 0, tab->width(), tab->height()));
                QVERIFY2(!r.intersects(l), name);
                QVERIFY2(r.left() >= 4 && r.top() >= 4 && r.right() <= island->width() - 4 && r.bottom() <= island->height() - 4, name);
            }
            QCOMPARE(child("railTabSessions")->property("on").toBool(), true);
            QVERIFY(QMetaObject::invokeMethod(child("railTabNew"), "clicked"));
            QCOMPARE(state->viewName(), QStringLiteral("upload"));
            QCOMPARE(child("railTabNew")->property("on").toBool(), true);
            QCOMPARE(child("railTabSessions")->property("on").toBool(), false);
            QVERIFY(QMetaObject::invokeMethod(child("railTabSettings"), "clicked"));
            QCOMPARE(state->viewName(), QStringLiteral("settings"));
            QVERIFY(QMetaObject::invokeMethod(child("railTabSessions"), "clicked"));
            QCOMPARE(state->viewName(), QStringLiteral("overview"));
            const bool sound = state->soundEnabled();
            QVERIFY(QMetaObject::invokeMethod(child("railTabSound"), "clicked"));
            QCOMPARE(state->soundEnabled(), !sound);
            QVERIFY(QMetaObject::invokeMethod(child("railTabSound"), "clicked"));
        }
    }

    // No rail in the greeting: an invisible tab must not take a click.
    void theRailIsGoneInTheGreeting()
    {
        ctl->expandTo("greeting");
        QTRY_VERIFY_WITH_TIMEOUT(!child("rail")->isVisible(), 2000);
        ctl->expandTo("overview");
        QTRY_VERIFY_WITH_TIMEOUT(child("rail")->isVisible() && child("rail")->opacity() > 0.99, 2000);
    }

    // A tab clicked while a permission request is on screen changes the view; the request stays in the queue.
    void aTabLeavesAPermissionRequestWaiting()
    {
        sessions->handlePermission(ev("PermissionRequest", "s1", "/work/farol", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "ls"}}}}), [](Decision) {});
        QTRY_COMPARE_WITH_TIMEOUT(state->viewName(), QStringLiteral("approval"), 2000);
        QVERIFY(QMetaObject::invokeMethod(child("railTabNew"), "clicked"));
        QCOMPARE(state->viewName(), QStringLiteral("upload"));
        QVERIFY(queue->property("active").toBool());
        queue->deny();
    }
```

- [ ] **Step 2: Rodar e ver falhar**

Run: `linux/scripts/host.sh sh -c 'cd ~/workspace/farol && cmake --build linux/build > linux/build/build.log 2>&1 && linux/build/tests/tst_island_qml theRailHoldsTheTabsAndLumiDoesNotCoverThem theRailIsGoneInTheGreeting aTabLeavesAPermissionRequestWaiting contentIsHiddenWhileCompact'`
Expected: FAIL nos quatro (`child("rail")` e `child("railTabSessions")` são nulos).

- [ ] **Step 3: Criar `linux/qml/RailTab.qml`**

```qml
import QtQuick

// One tab of the rail (34x26): filled when its view is the one on screen.
Item {
    id: tab
    property string icon: ""
    property bool on: false
    signal clicked()

    width: 34
    height: 26

    Rectangle {
        anchors.fill: parent
        radius: 9
        color: tab.on ? theme.card : (hover.hovered ? theme.pillHoverFill : theme.pillFill)
    }
    IconGlyph {
        anchors.centerIn: parent
        name: tab.icon
        size: 14
        color: tab.on ? theme.text : (hover.hovered ? theme.textHover : theme.muted)
    }
    HoverHandler { id: hover }
    TapHandler { onTapped: tab.clicked() }
}
```

- [ ] **Step 4: Criar `linux/qml/IslandRail.qml`**

```qml
import QtQuick

// The column on the left of every open view: Lumi on top (Island.qml puts it there, see botPosition) and the tabs
// under it, two by two. In the portrait island the rail is a strip on top and the tabs are a row beside Lumi.
// The fourth cell is the sound switch until the Skills tab takes it.
Item {
    id: rail
    readonly property bool vertical: appState.vertical

    Grid {
        objectName: "railTabs"
        x: rail.vertical ? 106 : 7
        y: rail.vertical ? 21 : 80
        columns: rail.vertical ? 4 : 2
        spacing: 6
        RailTab {
            objectName: "railTabSessions"
            icon: "sessions"
            on: appState.viewName === "overview" || appState.viewName === "empty"
            onClicked: controller.showView("overview")
        }
        RailTab {
            objectName: "railTabNew"
            icon: "new-session"
            on: appState.viewName === "upload"
            onClicked: controller.showView("upload")
        }
        RailTab {
            objectName: "railTabSettings"
            icon: "settings"
            on: appState.viewName === "settings"
            onClicked: controller.showView("settings")
        }
        RailTab {
            objectName: "railTabSound"
            icon: appState.soundEnabled ? "speaker" : "speaker-off"
            onClicked: appState.soundEnabled = !appState.soundEnabled
        }
    }
}
```

- [ ] **Step 5: Montar em `linux/qml/Island.qml`**

Dentro do `Item { id: content ... }`, o bloco `IslandHeader { ... }` e as cinco primeiras linhas do `Item { id: views ... }` viram:

```qml
                IslandRail {
                    id: rail
                    objectName: "rail"
                    x: 10
                    y: 10
                    width: root.sideways ? parent.width - 20 : 88
                    height: root.sideways ? 66 : Math.max(0, parent.height - 20)
                    // no tabs where Lumi is not on the rail
                    opacity: appState.viewName === "confused" || appState.viewName === "greeting" ? 0 : 1
                    visible: opacity > 0.001
                    Behavior on opacity { NumberAnimation { duration: 200 } }
                }

                Item {
                    id: views
                    x: root.sideways ? 10 : 106
                    y: root.sideways ? 86 : 10
                    width: parent.width - (root.sideways ? 20 : 116)
                    height: Math.max(0, parent.height - (root.sideways ? 96 : 20))
```

O comentário acima do bloco passa a ser `// Rail + views, only while open.`

- [ ] **Step 6: Lista de recursos**

Em `linux/src/app/CMakeLists.txt`, na lista `farol_qml`, trocar as linhas de `IslandHeader.qml` e `HeaderTab.qml` por:

```cmake
        ${CMAKE_SOURCE_DIR}/qml/IslandRail.qml
        ${CMAKE_SOURCE_DIR}/qml/RailTab.qml
```

e apagar os dois arquivos antigos: `git rm linux/qml/IslandHeader.qml linux/qml/HeaderTab.qml` (só tira do índice e do disco; não commita).

- [ ] **Step 7: Rodar e ver passar**

Mesmo comando do Step 2, com `cmake -S linux -B linux/build -G Ninja >/dev/null &&` na frente (a lista de recursos mudou). Expected: os quatro passam.

---

### Task 3: As views sem o lugar do Lumi

**Files:**
- Modify: `linux/qml/ApprovalView.qml:10`, `ErrorView.qml:9`, `FinishedView.qml:9`, `QuestionView.qml:29`, `SettingsView.qml:67`, `OverviewView.qml:20`, `RepositoriesView.qml:9`
- Modify: `linux/src/core/IslandTypes.cpp` (`kPortraitHeights`, só se o teste de retrato pedir)
- Test: `linux/tests/tst_island_qml.cpp`, `linux/tests/tst_island_types.cpp`, `linux/tests/tst_island_controller.cpp`

**Interfaces:**
- Consumes: a área das views da Tarefa 2.

- [ ] **Step 1: Escrever o teste de paisagem**

```cpp
    // In the landscape island no text of a view lies under the rail (the views start after it).
    void noViewTextLiesUnderTheRail()
    {
        std::function<void(QQuickItem *, const QString &)> walk = [&](QQuickItem *item, const QString &view) {
            for (QQuickItem *c : item->childItems()) {
                if (!c->isVisible() || c->opacity() < 0.01)
                    continue;
                if (c->inherits("QQuickText") && !c->property("text").toString().isEmpty()) {
                    const QRectF r = c->mapRectToItem(child("island"), QRectF(0, 0, c->width(), c->height()));
                    QVERIFY2(r.left() >= 106, qPrintable(view + " '" + c->property("text").toString() + "' at " + QString::number(r.left())));
                }
                walk(c, view);
            }
        };
        sessions->handleEvent(ev("PreToolUse", "s1", "/work/farol", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "ls"}}}}));
        for (const char *v : {"overview", "upload", "settings", "error", "finished"}) {
            ctl->expandTo(v);
            QTest::qWait(900);
            walk(child(QByteArray("view-") + v), QString::fromLatin1(v));
        }
        sessions->handlePermission(ev("PermissionRequest", "s1", "/work/farol", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "ls"}}}}), [](Decision) {});
        QTest::qWait(900);
        walk(child("view-approval"), QStringLiteral("approval"));
        queue->deny();
    }
```

- [ ] **Step 2: Rodar**

Run: `linux/scripts/host.sh sh -c 'cd ~/workspace/farol && cmake --build linux/build > linux/build/build.log 2>&1 && linux/build/tests/tst_island_qml noViewTextLiesUnderTheRail portraitViewsKeepEverythingInsideTheIsland'`
Expected: o primeiro passa (as views já começam em 106, mas com uma margem interna de 116 sobrando); o de retrato pode falhar por falta de altura. Anotar cada "sticks out" e de quanto.

- [ ] **Step 3: Tirar a margem do Lumi das views**

Em `ApprovalView.qml`, `ErrorView.qml`, `FinishedView.qml`, `QuestionView.qml` e `SettingsView.qml`, a linha

```qml
        anchors.leftMargin: appState.vertical ? 76 : 116   // Lumi sits top-left of a portrait card
```

vira

```qml
        anchors.leftMargin: appState.vertical ? 12 : 16
```

Em `OverviewView.qml`:

```qml
    readonly property real textX: vertical ? 12 : 14   // Lumi lives on the rail, outside the card
```

Em `RepositoriesView.qml`:

```qml
    readonly property real sideX: vertical ? 12 : 16         // Lumi lives on the rail, outside the card
```

- [ ] **Step 4: Ajustar as alturas de retrato pelo que o teste disser**

Rodar de novo o comando do Step 2. Para cada view que o teste de retrato acusar ("<view> ... sticks out: x,y WxH of 280xN"), somar à entrada dela em `kPortraitHeights` o quanto passou, arredondado para cima em dezenas, sem ultrapassar 700 (a janela tem 720). Uma view que precisar de mais de 700 tem a lista dela posta num `Flickable`, como a de sessões. Atualizar os mesmos números onde `tst_island_types.cpp` e `tst_island_controller.cpp` os fixam (o controller fixa `360` para Overview em retrato). Repetir até passar.

- [ ] **Step 5: Rodar a suíte inteira**

Run: `linux/scripts/host.sh sh -c 'cd ~/workspace/farol && cmake --build linux/build > linux/build/build.log 2>&1 && ctest --test-dir linux/build --output-on-failure'`
Expected: `100% tests passed, 0 tests failed out of 28`.

---

### Task 4: Documentação, instalação e conferência na tela

**Files:**
- Modify: `CLAUDE.md`, `.claude/skills/farol-island-ui/SKILL.md`

- [ ] **Step 1: `CLAUDE.md`**

Acrescentar depois da linha "The compact island stays on screen.":

```markdown
- The open island has a rail, not a header: `IslandRail.qml`, 88 px on the left of every view (a strip on top in the portrait island), with Lumi on top (`botPosition`: 54,48 landscape, 44,44 portrait, diameter 52) and the tabs under it (`RailTab`: sessions, new session, settings, and the sound switch in the fourth cell until the Skills tab takes it). The views start after it (x 106, y 10; portrait x 10, y 86) and keep no room for Lumi inside their cards. No rail in the greeting.
```

Na linha "Dock edge", trocar "views read `appState.vertical` (Lumi top-left of the card, buttons wrap in `Flow`, session card above the pill list)" por "views read `appState.vertical` (buttons wrap in `Flow`, session card above the pill list)".

- [ ] **Step 2: Skill `farol-island-ui`**

Na tabela "A new or changed view", a linha de `IslandHeader.qml` vira:

```markdown
| `linux/qml/IslandRail.qml` | A tab, if the user opens it by hand (`controller.showView("<key>")`): a `RailTab` with `objectName: "railTab<Name>"`; icons are in `IconGlyph.qml` |
```

Em "Layout rules that the tests enforce", o primeiro item vira:

```markdown
- Lumi lives on the rail, outside the views: a view's content starts at its own left edge (margin 16 in landscape, 12 in portrait). The view area is the island minus the rail (106 px on the left in landscape, 86 px on top in portrait) and 10 px on the other sides.
```

- [ ] **Step 3: Instalar e reiniciar**

```bash
linux/scripts/host.sh sh -c 'cd ~/workspace/farol && cmake --install linux/build --prefix ~/.local >/dev/null && echo installed'
linux/scripts/host.sh pkill -x farol
linux/scripts/host.sh sh -c 'setsid $HOME/.local/bin/farol > $HOME/.local/state/farol/farol.out 2>&1 < /dev/null & sleep 0; exit 0' > /dev/null 2>&1
```

- [ ] **Step 4: Pedir ao autor para olhar**

Sem captura de tela: pedir ao autor que abra a ilha e passe pelas quatro casas da coluna, com a ilha no topo e numa lateral, e diga o que estiver torto.
