#include <QtTest>
#include <QDir>
#include <QFile>
#include <QTemporaryDir>
#include <memory>
#include "ClaudeLocator.h"
#include "FakeCommandRunner.h"
#include "Plugins.h"

using namespace farol;

// The shape `claude plugin list --json --available` printed with Claude Code 2.1.284.
static const char kListing[] = R"JSON({
  "installed": [
    {"id": "superpowers@claude-plugins-official", "version": "6.4.1", "scope": "user", "enabled": true,
     "installPath": "/home/x/.claude/plugins/cache/claude-plugins-official/superpowers/6.4.1", "installedAt": "2026-09-14T14:37:26.633Z"},
    {"id": "agent-sdk-dev@claude-plugins-official", "version": "d182", "scope": "user", "enabled": false},
    {"id": "team-rules@acme", "version": "1", "scope": "project", "enabled": true}
  ],
  "available": [
    {"pluginId": "pr-review-toolkit@claude-plugins-official", "name": "pr-review-toolkit",
     "description": "Review agents for tests,\n types and error handling.", "futureField": [1, 2]},
    {"pluginId": "context7@context7-marketplace", "name": "context7", "description": "Up-to-date library docs."},
    {"pluginId": "caveman@caveman", "description": "Talk like a caveman."}
  ]
})JSON";

class TestPlugins : public QObject {
    Q_OBJECT
    std::unique_ptr<FakeCommandRunner> runner;
    std::unique_ptr<Plugins> plugins;
    QString claude = "/opt/node/bin/claude";

    static QStringList field(const QVariantList &list, const char *key)
    {
        QStringList out;
        for (const QVariant &v : list)
            out << v.toMap().value(key).toString();
        return out;
    }
    static QVariantMap row(const QVariantList &list, const QString &id)
    {
        for (const QVariant &v : list)
            if (v.toMap().value("id").toString() == id)
                return v.toMap();
        return {};
    }
    void load()
    {
        plugins->refresh();
        runner->answer(0, {}, kListing);
    }

private slots:
    void init()
    {
        runner = std::make_unique<FakeCommandRunner>();
        claude = "/opt/node/bin/claude";
        plugins = std::make_unique<Plugins>(runner.get(), [this] { return claude; }, QStringLiteral("/usr/bin:/bin"));
    }

    void theListingIsReadIntoInstalledAndAvailable()
    {
        const PluginListing l = parsePluginListing(kListing);
        QVERIFY(l.ok);
        QCOMPARE(l.installed.size(), 2);                                  // the project-scope one is not the user's
        QCOMPARE(l.installed.at(0).name, QStringLiteral("agent-sdk-dev"));   // by name
        QVERIFY(!l.installed.at(0).enabled);
        QCOMPARE(l.installed.at(1).marketplace, QStringLiteral("claude-plugins-official"));
        QCOMPARE(l.available.size(), 3);
        QCOMPARE(l.available.at(0).name, QStringLiteral("caveman"));      // no "name": from the id
        QCOMPARE(l.available.at(2).description, QStringLiteral("Review agents for tests, types and error handling."));
        QVERIFY(!parsePluginListing("{\"installed\": [").ok);             // cut short
        QVERIFY(!parsePluginListing("[]").ok);
        QVERIFY(!parsePluginListing("").ok);
        QVERIFY(parsePluginListing("{\"installed\": []}").ok);            // nothing installed, no catalogue: still a listing
    }

    void theListIsAskedOfClaudeCodeWithItsOwnFolderInThePath()
    {
        plugins->refresh();
        QVERIFY(plugins->loading() && plugins->busy());
        QCOMPARE(runner->calls.size(), 1);
        QCOMPARE(runner->calls.first().program, claude);
        QCOMPARE(runner->calls.first().arguments, (QStringList{"plugin", "list", "--json", "--available"}));
        // the `node` beside it is found: its folder goes first, as this system writes a folder and separates a list
        QCOMPARE(runner->calls.first().env, QStringList{"PATH=" + QDir::toNativeSeparators(QFileInfo(claude).absolutePath()) +
                                                         QDir::listSeparator() + "/usr/bin:/bin"});
        plugins->refresh();                                               // while it runs: not twice
        QCOMPARE(runner->calls.size(), 1);
        runner->answer(0, {}, kListing);
        QVERIFY(!plugins->loading() && plugins->hasClaude());
        QCOMPARE(field(plugins->installed(), "name"), (QStringList{"agent-sdk-dev", "superpowers"}));
        QCOMPARE(plugins->catalogTotal(), 3);
        QCOMPARE(plugins->error(), QString());
    }

    void withoutClaudeCodeItSaysSoAndRunsNothing()
    {
        claude.clear();
        plugins->refresh();
        QCOMPARE(runner->calls.size(), 0);
        QVERIFY(!plugins->hasClaude());
        QVERIFY(plugins->installed().isEmpty());
        plugins->install("context7@context7-marketplace");
        QCOMPARE(runner->calls.size(), 0);
        claude = "/opt/node/bin/claude";                                   // installed meanwhile: found on the next look
        plugins->refresh();
        QCOMPARE(runner->calls.size(), 1);
        ICommandRunner::Result gone;                                       // the file is there but does not run
        runner->finish(gone);
        QVERIFY(!plugins->hasClaude());
    }

    void anAnswerThatIsNotTheListingKeepsWhatWasThere()
    {
        load();
        plugins->refresh();
        runner->answer(0, {}, "{\"installed\": [");
        QVERIFY(plugins->error().contains("Não entendi"));
        QCOMPARE(plugins->installed().size(), 2);                          // the last good list stays on screen
        plugins->refresh();
        runner->answer(1, "Error: not logged in\n");
        QVERIFY(plugins->error().contains("not logged in"));
        plugins->refresh();
        ICommandRunner::Result slow;
        slow.started = true;
        slow.timedOut = true;
        runner->finish(slow);
        QVERIFY(plugins->error().contains("demorou"));
        plugins->refresh();
        runner->answer(0, {}, kListing);
        QCOMPARE(plugins->error(), QString());
    }

    void theCatalogueIsFilteredByNameDescriptionAndMarketplace()
    {
        load();
        QCOMPARE(field(plugins->catalog(), "name"), (QStringList{"caveman", "context7", "pr-review-toolkit"}));
        plugins->setFilter("REVIEW");
        QCOMPARE(field(plugins->catalog(), "name"), QStringList{"pr-review-toolkit"});
        plugins->setFilter("library");                                     // in the description
        QCOMPARE(field(plugins->catalog(), "name"), QStringList{"context7"});
        plugins->setFilter("  official ");                                 // the marketplace
        QCOMPARE(field(plugins->catalog(), "name"), QStringList{"pr-review-toolkit"});
        plugins->setFilter("zzz");
        QVERIFY(plugins->catalog().isEmpty());
        QCOMPARE(plugins->catalogTotal(), 3);
    }

    void turningOffOnAndRemovingRunOneCommandEachThenReadTheListAgain()
    {
        load();
        plugins->setEnabled("superpowers@claude-plugins-official", false);
        QCOMPARE(runner->calls.size(), 2);
        QCOMPARE(runner->calls.last().arguments, (QStringList{"plugin", "disable", "superpowers@claude-plugins-official"}));
        QVERIFY(plugins->busy());
        QVERIFY(row(plugins->installed(), "superpowers@claude-plugins-official").value("busy").toBool());
        plugins->remove("agent-sdk-dev@claude-plugins-official");          // one at a time: ignored while the first runs
        plugins->install("context7@context7-marketplace");
        QCOMPARE(runner->calls.size(), 2);
        runner->answer(0);
        QCOMPARE(runner->calls.size(), 3);                                 // the list is read again
        QCOMPARE(runner->calls.last().arguments, (QStringList{"plugin", "list", "--json", "--available"}));
        QVERIFY(plugins->notice().contains("Desligado: superpowers"));
        runner->answer(0, {}, kListing);
        QVERIFY(!plugins->busy());

        plugins->setEnabled("agent-sdk-dev@claude-plugins-official", true);
        QCOMPARE(runner->calls.last().arguments, (QStringList{"plugin", "enable", "agent-sdk-dev@claude-plugins-official"}));
        runner->answer(0);
        runner->answer(0, {}, kListing);
        plugins->remove("agent-sdk-dev@claude-plugins-official");
        QCOMPARE(runner->calls.last().arguments, (QStringList{"plugin", "uninstall", "agent-sdk-dev@claude-plugins-official"}));
        runner->answer(0);
        QVERIFY(plugins->notice().contains("Removido: agent-sdk-dev"));
        runner->answer(0, {}, kListing);
        QCOMPARE(runner->pending(), 0);
    }

    void installingSaysWhatClaudeCodeSaidWhenItFails()
    {
        load();
        plugins->install("context7@context7-marketplace");
        QCOMPARE(runner->calls.last().arguments, (QStringList{"plugin", "install", "context7@context7-marketplace"}));
        QCOMPARE(runner->calls.last().timeoutMs, 120000);
        QVERIFY(row(plugins->catalog(), "context7@context7-marketplace").value("busy").toBool());
        runner->answer(1, "Installing...\nError: marketplace context7-marketplace is unreachable\n\n");
        runner->answer(0, {}, kListing);
        QCOMPARE(row(plugins->catalog(), "context7@context7-marketplace").value("error").toString(), QStringLiteral("Error: marketplace context7-marketplace is unreachable"));
        QCOMPARE(plugins->notice(), QString());

        plugins->install("caveman@caveman");                               // it wants a command accepted: never from here
        runner->answer(1, "This marketplace declares a command. Re-run with --accept-command <sha256> to accept it.");
        runner->answer(0, {}, kListing);
        QVERIFY(row(plugins->catalog(), "caveman@caveman").value("error").toString().contains("Instale pelo Claude Code"));
        for (const auto &call : runner->calls)
            QVERIFY(!call.arguments.join(' ').contains("accept-command"));

        plugins->install("context7@context7-marketplace");                 // trying again clears its error
        QCOMPARE(row(plugins->catalog(), "context7@context7-marketplace").value("error").toString(), QString());
        runner->answer(0);
        QVERIFY(plugins->notice().contains("Instalado: context7"));
        runner->answer(0, {}, kListing);
    }

#ifdef Q_OS_WIN
    // Windows: claude.exe (Claude Code's own installer, the editor extension) or npm's claude.cmd.
    void claudeIsFoundInTheUsualPlaces()
    {
        QTemporaryDir tmp;
        const QString home = tmp.path() + "/home";
        const auto program = [&](const QString &path) {
            QVERIFY(QDir().mkpath(QFileInfo(path).absolutePath()));
            QFile f(path);
            QVERIFY(f.open(QIODevice::WriteOnly));
        };
        QCOMPARE(findClaude(home, {}), QString());
        const QString ext = home + "/.vscode/extensions";
        program(ext + "/anthropic.claude-code-2.1.9-win32-x64/resources/native-binary/claude.exe");
        program(ext + "/anthropic.claude-code-2.1.292-win32-x64/resources/native-binary/claude.exe");
        QCOMPARE(findClaude(home, {}), ext + "/anthropic.claude-code-2.1.292-win32-x64/resources/native-binary/claude.exe");   // the newest
        program(home + "/AppData/Roaming/npm/claude.cmd");
        QCOMPARE(findClaude(home, {}), home + "/AppData/Roaming/npm/claude.cmd");
        program(home + "/.local/bin/claude");                              // no extension: Windows cannot run it
        QCOMPARE(findClaude(home, {}), home + "/AppData/Roaming/npm/claude.cmd");
        program(home + "/.local/bin/claude.exe");
        QCOMPARE(findClaude(home, {}), home + "/.local/bin/claude.exe");
        program(tmp.path() + "/bin/claude.exe");
        const QString inPath = QDir::toNativeSeparators(tmp.path() + "/bin");   // PATH has backslashes
        QCOMPARE(findClaude(home, {tmp.path() + "/empty", "", inPath}), tmp.path() + "/bin/claude.exe");
        QCOMPARE(findClaude(home, {inPath}, home + "/AppData/Roaming/npm/claude.cmd"), home + "/AppData/Roaming/npm/claude.cmd");   // the saved one
        QCOMPARE(findClaude(home, {inPath}, home + "/gone/claude.exe"), tmp.path() + "/bin/claude.exe");
        QCOMPARE(claudeEnvironment("C:/a/b/claude.exe", ""), QStringList{R"(PATH=C:\a\b)"});
        QCOMPARE(claudeEnvironment("C:/a/b/claude.exe", R"(C:\Windows)"), QStringList{R"(PATH=C:\a\b;C:\Windows)"});
    }
#else
    void claudeIsFoundInTheUsualPlaces()
    {
        QTemporaryDir tmp;
        const QString home = tmp.path() + "/home";
        const auto program = [&](const QString &path, bool executable = true) {
            QVERIFY(QDir().mkpath(QFileInfo(path).absolutePath()));
            QFile f(path);
            QVERIFY(f.open(QIODevice::WriteOnly));
            f.write("#!/bin/sh\n");
            f.close();
            QVERIFY(f.setPermissions(executable ? QFile::Permissions(0x7755) : QFile::Permissions(0x6644)));
        };
        QCOMPARE(findClaude(home, {}), QString());
        const QString ext = home + "/.var/app/com.vscodium.codium/data/codium/extensions";
        program(ext + "/anthropic.claude-code-2.1.9-linux-x64/resources/native-binary/claude");
        program(ext + "/anthropic.claude-code-2.1.285-linux-x64/resources/native-binary/claude");
        QCOMPARE(findClaude(home, {}), ext + "/anthropic.claude-code-2.1.285-linux-x64/resources/native-binary/claude");   // the newest
        program(home + "/.nvm/versions/node/v9.11.0/bin/claude");
        program(home + "/.nvm/versions/node/v22.21.0/bin/claude");
        QCOMPARE(findClaude(home, {}), home + "/.nvm/versions/node/v22.21.0/bin/claude");
        program(home + "/.local/bin/claude", false);                       // there but not runnable: skipped
        QCOMPARE(findClaude(home, {}), home + "/.nvm/versions/node/v22.21.0/bin/claude");
        program(tmp.path() + "/usr/bin/claude");
        QCOMPARE(findClaude(home, {tmp.path() + "/empty", "", tmp.path() + "/usr/bin"}), tmp.path() + "/usr/bin/claude");
        QCOMPARE(findClaude(home, {tmp.path() + "/usr/bin"}, home + "/.nvm/versions/node/v9.11.0/bin/claude"), home + "/.nvm/versions/node/v9.11.0/bin/claude");   // the saved one
        QCOMPARE(findClaude(home, {tmp.path() + "/usr/bin"}, home + "/gone/claude"), tmp.path() + "/usr/bin/claude");
        QCOMPARE(claudeEnvironment("/a/b/claude", ""), QStringList{"PATH=/a/b"});
    }
#endif
};

QTEST_GUILESS_MAIN(TestPlugins)
#include "tst_plugins.moc"
