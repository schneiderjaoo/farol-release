#pragma once
#include <QString>
#include <QStringList>

namespace farol {

// Where the `claude` program is. Farol started from the desktop's menu does not inherit the terminal's PATH (nvm,
// ~/.local/bin), so the usual places are looked at too: the saved path, PATH, ~/.local/bin, ~/.claude/local, the
// newest Node under nvm, and the binary the Claude Code extension ships (VSCodium/VS Code/Cursor, Flatpak or not).
// Empty when there is none.
QString findClaude(const QString &home, const QStringList &pathDirs, const QString &saved = {});

// The environment additions to run it with: its own folder goes first in PATH, because the nvm one is a script
// that needs the `node` beside it.
QStringList claudeEnvironment(const QString &claude, const QString &path);

} // namespace farol
