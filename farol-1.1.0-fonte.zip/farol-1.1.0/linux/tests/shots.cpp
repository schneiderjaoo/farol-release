// Development aid, not a test: renders the island's views off screen, with made-up sessions, into PNG files, so a
// change to the looks can be checked without touching the desktop.
//   QT_QPA_PLATFORM=offscreen QT_QUICK_BACKEND=software build/tests/farol_shots <output folder>
#include <QDir>
#include <QFile>
#include <QFontDatabase>
#include <QGuiApplication>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QQmlContext>
#include <QQuickItem>
#include <QQuickView>
#include <QSettings>
#include <QTemporaryDir>
#include <QTest>
#include "Answers.h"
#include "AppState.h"
#include "ApprovalQueue.h"
#include "Ask.h"
#include "ClaudeSessions.h"
#include "EditDiffs.h"
#include "FakeAsk.h"
#include "FakeCommandRunner.h"
#include "FakeScheduler.h"
#include "HooksStatus.h"
#include "IslandController.h"
#include "LumiLook.h"
#include "Plugins.h"
#include "QuestionDesk.h"
#include "Repos.h"
#include "Shortcuts.h"
#include "Skills.h"
#include "Theme.h"

using namespace farol;

static const char kPlugins[] = R"JSON({
  "installed": [
    {"id": "superpowers@claude-plugins-official", "scope": "user", "enabled": true},
    {"id": "code-simplifier@claude-plugins-official", "scope": "user", "enabled": true},
    {"id": "agent-sdk-dev@claude-plugins-official", "scope": "user", "enabled": false}
  ],
  "available": [
    {"pluginId": "pr-review-toolkit@claude-plugins-official", "name": "pr-review-toolkit", "description": "Review agents for tests, types and error handling."},
    {"pluginId": "context7@context7-marketplace", "name": "context7", "description": "Up-to-date library docs."}
  ]
})JSON";

static HookEvent ev(const QString &name, const QString &sid, const QString &cwd, const QJsonObject &extra = {})
{
    QJsonObject o = extra;
    o["hook_event_name"] = name;
    o["session_id"] = sid;
    o["cwd"] = cwd;
    return *HookEvent::parse(QJsonDocument(o).toJson(QJsonDocument::Compact));
}

static QQuickItem *findItem(QQuickItem *item, const QString &name)
{
    if (item->objectName() == name)
        return item;
    for (QQuickItem *c : item->childItems())
        if (QQuickItem *f = findItem(c, name))
            return f;
    return nullptr;
}

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    app.setApplicationVersion(QStringLiteral("1.0.1"));
    const QString out = argc > 1 ? QString::fromLocal8Bit(argv[1]) : QStringLiteral("shots");
    QDir().mkpath(out);
    for (const char *font : {"/BricolageGrotesque.ttf", "/InstrumentSans.ttf"})
        QFontDatabase::addApplicationFont(QStringLiteral(FAROL_FONTS_DIR) + QLatin1String(font));

    QTemporaryDir dir;
    QSettings settings(dir.path() + "/s.ini", QSettings::IniFormat);
    AppState state(&settings);
    FakeScheduler sched;
    IslandController ctl(&state, &sched, [] { return QDateTime::currentMSecsSinceEpoch(); });
    Theme theme(&state);
    theme.setSystemDark(true);
    LumiLooks looks;
    ApprovalQueue queue(sched, &settings);
    QuestionDesk questions(sched);
    EditDiffs diffs(&state, &ctl);
    ClaudeSessions sessions(&state, &ctl, &sched, &queue, &questions, nullptr, &diffs);
    Shortcuts shortcuts(&settings, [](const QString &, int) { return QStringLiteral("Meta+F"); });
    HooksStatus hooks([] { return QStringLiteral("installed"); });
    FakeCommandRunner commands, claude;
    Skills skills(&state, &commands, &settings, dir.path() + "/claude-skills", [] { return QDateTime::currentMSecsSinceEpoch(); });
    Plugins plugins(&claude, [] { return QStringLiteral("/usr/bin/claude"); }, QStringLiteral("/usr/bin"));
    FakeSecretStore wallet;
    FakeHttpClient http;
    settings.setValue("ai/provider", "anthropic");
    Ask ask(&settings, &wallet, &http);
    Answers answers(&theme);
    Repos repos(&state);

    QQuickView view;
    QQmlContext *c = view.rootContext();
    c->setContextProperty("theme", &theme);
    c->setContextProperty("lumiLooks", &looks);
    c->setContextProperty("appState", &state);
    c->setContextProperty("controller", &ctl);
    c->setContextProperty("questions", &questions);
    c->setContextProperty("approvals", &queue);
    c->setContextProperty("sessions", &sessions);
    c->setContextProperty("diffs", &diffs);
    c->setContextProperty("shortcuts", &shortcuts);
    c->setContextProperty("hooks", &hooks);
    c->setContextProperty("skills", &skills);
    c->setContextProperty("plugins", &plugins);
    c->setContextProperty("ask", &ask);
    c->setContextProperty("answers", &answers);
    c->setContextProperty("repos", &repos);
    view.setColor(QColor(90, 100, 112));   // stands for the desktop behind the island
    view.setSource(QUrl::fromLocalFile(QStringLiteral(FAROL_QML_DIR "/Island.qml")));
    if (view.status() != QQuickView::Ready)
        return 1;
    view.show();
    QTest::qWait(100);

    const auto shot = [&](const QString &name) {
        QTest::qWait(1200);   // the island settles at its size
        view.grabWindow().save(out + "/" + name + ".png");
    };
    const auto click = [&](const char *name) {
        if (QQuickItem *item = findItem(view.rootObject(), QString::fromLatin1(name)))
            QMetaObject::invokeMethod(item, "clicked");
        else
            qWarning("no item %s", name);
    };
    const auto title = [&](const QString &sid, const QString &text) {
        const QString path = dir.path() + '/' + sid + ".jsonl";
        QFile f(path);
        if (f.open(QIODevice::WriteOnly))
            f.write(QJsonDocument(QJsonObject{{"type", "ai-title"}, {"aiTitle", text}, {"sessionId", sid}}).toJson(QJsonDocument::Compact) + '\n');
        return QJsonObject{{"transcript_path", path}, {"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "ctest --output-on-failure"}}}};
    };

    // An edit as farol-hook reports it: the tool about to run, then done, with its patch (hunks of a first line and
    // the lines) and its counts; `counted` stands for an edit longer than the patch that was sent.
    int calls = 0;
    const auto edit = [&](const QString &sid, const QString &tool, const QString &file, const QList<QPair<int, QStringList>> &hunks,
                          const QString &type = {}, int counted = -1) {
        const QString call = QStringLiteral("toolu_%1").arg(++calls);
        int added = 0, removed = 0;
        QJsonArray patch;
        for (const auto &[start, lines] : hunks) {
            int plus = 0, minus = 0;
            for (const QString &l : lines) {
                plus += l.startsWith('+');
                minus += l.startsWith('-');
            }
            patch << QJsonObject{{"oldStart", type == "create" ? 0 : start}, {"oldLines", int(lines.size()) - plus}, {"newStart", start},
                                 {"newLines", counted >= 0 ? counted : int(lines.size()) - minus}, {"lines", QJsonArray::fromStringList(lines)}};
            added += plus;
            removed += minus;
        }
        QJsonObject response{{"filePath", file}, {"structuredPatch", patch}};
        if (!type.isEmpty())
            response["type"] = type;
        const QJsonObject input{{"file_path", file}};
        sessions.handleEvent(ev("PreToolUse", sid, "/work/farol", {{"tool_name", tool}, {"tool_use_id", call}, {"tool_input", input}}));
        sessions.handleEvent(ev("PostToolUse", sid, "/work/farol", {{"tool_name", tool}, {"tool_use_id", call}, {"tool_input", input}, {"tool_response", response},
            {"farol_edit", QJsonObject{{"added", counted >= 0 ? counted : added}, {"removed", removed}, {"cut", counted >= 0}}}}));
    };
    // a file of 412 lines that Claude wrote, of which farol-hook sends the first 300
    QStringList written{"+import QtQuick", "+", "+// The diff of one edit (view \"diff\"): opened by a click on the step of an edit in the session card.",
                        "+Item {", "+    id: view", "+    readonly property bool vertical: appState.vertical", "+\treadonly property real sideX: vertical ? 12 : 16",
                        "+", "+    Card { anchors.fill: parent }", "+"};
    while (written.size() < 300)
        written << QStringLiteral("+    // linha %1 do arquivo novo").arg(written.size() + 1);

    for (const char *edge : {"top", "left"}) {
        const QString tag = QLatin1String(edge) + QLatin1Char('-');
        state.setEdge(edge);
        sessions.handleEvent(ev("PreToolUse", "a", "/work/farol", title("a", "Lista de sessões no lugar das pílulas")));
        // three edits: one that changed a file in two places, one that wrote a file as it was, one that made a file
        edit("a", "Edit", "/work/farol/linux/qml/OverviewView.qml",
             {{9, {" Item {", "     id: overview", "     readonly property var task: appState.focusTask", "-    readonly property var tail: steps.slice(-3)",
                   "-    // the last three steps", "+    readonly property var tail: (task.stepList || []).slice(-3)   // {label, file, added, removed, diff}",
                   "+    // how many diffs the session keeps (core/EditDiffs), asked again whenever one comes or goes",
                   "+    readonly property int changes: diffs.revision >= 0 && task.id ? diffs.kept(task.id) : 0",
                   "     readonly property string message: task.finalMessage || \"\"", "     readonly property bool vertical: appState.vertical"}},
              {143, {"                 wrapMode: Text.Wrap", "-                maximumLineCount: 4", "+                maximumLineCount: changesRow.visible ? 3 : 4",
                     "                 elide: Text.ElideRight", "                 text: overview.message  // <b>texto</b>, nunca marcação"}}});
        edit("a", "Write", "/work/farol/CLAUDE.md", {}, "update");
        edit("a", "Write", "/work/farol/linux/qml/DiffView.qml", {{1, written}}, "create", 412);
        sessions.handleEvent(ev("PreToolUse", "b", "/work/farol", title("b", "Ícone novo do Lumi")));
        sessions.handleEvent(ev("PreToolUse", "c", "/work/superloja-loja-api", {{"tool_name", "Bash"}}));
        sessions.handleEvent(ev("PreToolUse", "d", "/work/site", {{"tool_name", "Bash"}}));
        sessions.handleEvent(ev("PreToolUse", "e", "/work/docs", {{"tool_name", "Bash"}}));
        state.setFocus(ClaudeSessions::taskId("a"));
        state.modifyTask(ClaudeSessions::taskId("a"), [](AgentTask &t) { t.contextTokens = 132000; t.contextWindow = 200000; });
        state.modifyTask(ClaudeSessions::taskId("b"), [](AgentTask &t) { t.state = BotState::Question; });
        state.modifyTask(ClaudeSessions::taskId("d"), [](AgentTask &t) { t.state = BotState::Idle; });
        state.modifyTask(ClaudeSessions::taskId("e"), [](AgentTask &t) { t.state = BotState::Idle; t.dormant = true; });

        ctl.setMode(IslandMode::Compact);
        shot(tag + "1-compact-waiting");
        state.modifyTask(ClaudeSessions::taskId("c"), [](AgentTask &t) { t.state = BotState::Error; });
        shot(tag + "1-compact-error");
        state.setThemeMode("light");                    // the light theme: the scene by day
        shot(tag + "1-compact-day");
        state.setThemeMode("dark");
        ctl.expandTo("overview");
        shot(tag + "2-overview");                       // the card: the steps of the three edits and "2 alterações"
        click("overviewStep0");                         // the diff of the first one
        shot(tag + "2-diff");
        state.setThemeMode("light");
        shot(tag + "2-diff-day");
        state.setThemeMode("dark");
        click("diffNext");                              // the new file: only additions, cut to 300 lines
        shot(tag + "2-diff-new");
        if (QQuickItem *rows = findItem(view.rootObject(), QStringLiteral("diffRows")))
            rows->setProperty("contentX", 60);          // flicked sideways
        shot(tag + "2-diff-new-flicked");
        click("diffBack");

        // "a" ends its turn with what a model writes (a heading, emphasis, code, a link, a list, a block, a table):
        // the alert says its first line, and the card shows its first lines as text in place of the steps
        sessions.handleEvent(ev("Stop", "a", "/work/farol", {{"last_assistant_message", QStringLiteral(
            "## Lista de sessões pronta\n\n"
            "Troquei as **pílulas** por uma lista em [`OverviewView.qml`](linux/qml/OverviewView.qml): cada sessão tem o seu "
            "barco, o nome e o que está fazendo.\n\n"
            "- `tst_island_qml` passa nas duas bordas\n"
            "- Falta só regravar os filmes do <b>marketing</b>\n"
            "- O `CLAUDE.md` já descreve a lista\n\n"
            "```sh\nctest --test-dir linux/build --output-on-failure\n```\n\n"
            "| Teste | Resultado |\n|---|---|\n| tst_island_qml | passou |\n")}}));
        shot(tag + "2-finished");
        ctl.expandTo("overview");
        shot(tag + "2-overview-finished");
        // back to work, as it was: the shots that follow are of the other tabs
        sessions.handleEvent(ev("PreToolUse", "a", "/work/farol", {{"tool_name", "Edit"}, {"tool_input", QJsonObject{{"file_path", "/work/farol/linux/qml/OverviewView.qml"}}}}));

        ctl.showView("skills");
        QDir().mkpath(dir.path() + "/skills/superloja-frontend");
        QFile(dir.path() + "/skills/superloja-frontend/SKILL.md").open(QIODevice::WriteOnly);
        QDir().mkpath(dir.path() + "/skills/.git");
        state.setSkillsDir(dir.path() + "/skills");
        QTest::qWait(900);   // the tab loads and asks for the plugins
        while (commands.pending() > 0)
            commands.answer(0);
        while (claude.pending() > 0)
            claude.answer(0, {}, kPlugins);
        shot(tag + "3-skills");
        click("pluginsAdd");
        QTest::qWait(300);
        while (claude.pending() > 0)
            claude.answer(0, {}, kPlugins);
        shot(tag + "3-skills-catalog");

        ask.clear();
        ask.saveKey("anthropic", "k");
        ctl.showView("ask");
        shot(tag + "4-ask-empty");
        QFile note(dir.path() + "/relatorio-de-custos-2026.csv");
        if (note.open(QIODevice::WriteOnly))
            note.write("a;b\n1;2\n");
        note.close();
        ask.addFile(note.fileName());
        ask.ask("Qual é o total da coluna b?");
        // an answer with what a model writes: a heading, a list, inline code, a block with a long line, a link, a table
        const QString answer = QStringLiteral(
            "## Total da coluna b\n\n"
            "O total é **2**: o arquivo `relatorio-de-custos-2026.csv` só tem uma linha de dados.\n\n"
            "1. Abra o arquivo\n"
            "2. Some a coluna:\n"
            "   ```sh\n"
            "   awk -F';' 'NR > 1 { s += $2 } END { print s }' relatorio-de-custos-2026.csv\n"
            "   ```\n"
            "3. Confira com a [documentação do awk](https://www.gnu.org/software/gawk/manual/)\n\n"
            "| Coluna | Valor |\n|---|---|\n| a | 1 |\n| b | 2 |\n");
        http.answer(200, QJsonDocument(QJsonObject{{"content", QJsonArray{QJsonObject{{"type", "text"}, {"text", answer}}}}}).toJson());
        QQuickItem *talk = findItem(view.rootObject(), QStringLiteral("askTalk"));
        const auto scrollTo = [&](bool end) {
            if (talk)
                talk->setProperty("contentY", end ? qMax(0.0, talk->property("contentHeight").toReal() - talk->height()) : 0.0);
        };
        shot(tag + "4-ask-answer");                      // as the tab shows it when the answer arrives
        scrollTo(true);
        shot(tag + "4-ask-answer-end");
        state.setThemeMode("light");
        scrollTo(false);
        shot(tag + "4-ask-answer-day");
        scrollTo(true);
        shot(tag + "4-ask-answer-day-end");
        state.setThemeMode("dark");

        ctl.showView("settings");
        shot(tag + "5-settings");
        click("settingsTabAi");
        shot(tag + "5-settings-ai");
        ask.setProvider("claude");                       // the service without a key
        shot(tag + "5-settings-ai-claude");
        ask.setProvider("anthropic");

        ctl.showView("upload");
        shot(tag + "6-new-session");
        for (const char *sid : {"a", "b", "c", "d", "e"})
            sessions.handleEvent(ev("SessionEnd", sid, "/work/x"));
        state.setSkillsDir(QString());
    }
    return 0;
}
