#include <QtTest>
#include <QJsonArray>
#include <QJsonDocument>
#include <QLocalSocket>
#include <QProcess>
#include <QSettings>
#include <QTemporaryDir>
#include <cstring>
#include <memory>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include "AppState.h"
#include "ApprovalQueue.h"
#include "ClaudeSessions.h"
#include "EditDiffs.h"
#include "FakeScheduler.h"
#include "HookServer.h"
#include "IslandController.h"
#include "QuestionDesk.h"

using namespace farol;

class TestHookServer : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandController> ctl;
    std::unique_ptr<ApprovalQueue> queue;
    std::unique_ptr<QuestionDesk> questions;
    std::unique_ptr<EditDiffs> diffs;
    std::unique_ptr<ClaudeSessions> sessions;
    std::unique_ptr<HookServer> server;
    std::vector<std::unique_ptr<QLocalSocket>> clients;

    QString sockPath() const { return dir.path() + "/run/farol.sock"; }
    QLocalSocket *client()
    {
        clients.push_back(std::make_unique<QLocalSocket>());
        clients.back()->connectToServer(sockPath());
        clients.back()->waitForConnected(1000);
        return clients.back().get();
    }
    static void send(QLocalSocket *c, const QByteArray &data)
    {
        c->write(data);
        c->flush();
    }
    static QByteArray event(const QString &name, const QString &sid, const QString &cwd, const QString &extra = {})
    {
        return QStringLiteral(R"({"hook_event_name":"%1","session_id":"%2","cwd":"%3"%4})")
                   .arg(name, sid, cwd, extra).toUtf8() + "\n";
    }
    const AgentTask *task(const QString &sid) const { return state->taskModel()->find(ClaudeSessions::taskId(sid)); }

private slots:
    void init()
    {
        server.reset();
        sessions.reset();                                       // the desk holds a reference to the old scheduler
        questions.reset();
        diffs.reset();
        QDir(dir.path() + "/run").removeRecursively();
        QFile::remove(dir.path() + "/s.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/s.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        sched = std::make_unique<FakeScheduler>();
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [] { return qint64(0); });
        queue = std::make_unique<ApprovalQueue>(*sched, settings.get());
        questions = std::make_unique<QuestionDesk>(*sched);
        diffs = std::make_unique<EditDiffs>(state.get(), ctl.get());
        sessions = std::make_unique<ClaudeSessions>(state.get(), ctl.get(), sched.get(), queue.get(), questions.get(), nullptr, diffs.get());
        server = std::make_unique<HookServer>(sessions.get(), queue.get());
        QVERIFY(server->start(sockPath()) == HookServer::StartResult::Started);
    }
    void cleanup()
    {
        clients.clear();
        server.reset();
    }

    void socketFolderIsPrivate()
    {
        const QFile::Permissions p = QFileInfo(dir.path() + "/run").permissions();
        QCOMPARE(p & (QFile::ReadGroup | QFile::WriteGroup | QFile::ExeGroup | QFile::ReadOther | QFile::WriteOther | QFile::ExeOther),
                 QFile::Permissions());
    }

    void eventLogKeepsTheRawLines()
    {
        const QString log = dir.path() + "/events.jsonl";
        server->setEventLog(log);
        QLocalSocket *c = client();
        send(c, event("SessionStart", "s1", "/work/proj"));
        QTRY_VERIFY(task("s1"));
        QFile f(log);
        QVERIFY(f.open(QIODevice::ReadOnly));
        const QByteArray text = f.readAll();
        QVERIFY(text.contains(R"("hook_event_name":"SessionStart")"));
        QVERIFY(text.endsWith('\n'));
    }

    void sessionStartCreatesThePill()
    {
        send(client(), event("SessionStart", "s1", "/home/u/proj"));
        QTRY_VERIFY_WITH_TIMEOUT(task("s1") != nullptr, 2000);
        QCOMPARE(task("s1")->name, QStringLiteral("proj"));
    }

    void lineWithoutNewlineIsStillHandledWhenTheClientCloses()
    {
        QLocalSocket *c = client();
        send(c, QByteArray(R"({"hook_event_name":"SessionStart","session_id":"s2","cwd":"/w/x"})"));
        c->disconnectFromServer();
        QTRY_VERIFY_WITH_TIMEOUT(task("s2") != nullptr, 2000);
    }

    void garbageIsIgnoredAndTheServerSurvives()
    {
        send(client(), "garbage\n");
        send(client(), "[1,2]\n");
        send(client(), "{\"x\":1}\n");
        send(client(), QByteArray("\xff\xfe\n"));
        send(client(), event("SessionStart", "ok", "/w/ok"));
        QTRY_VERIFY_WITH_TIMEOUT(task("ok") != nullptr, 2000);
        QCOMPARE(sessions->sessionCount(), 1);                  // no ghost pill from the garbage
    }

    void oversizedLineIsDroppedAndTheServerSurvives()
    {
        QLocalSocket *c = client();
        c->write(QByteArray(HookServer::kMaxLine + 4096, 'x'));
        c->waitForBytesWritten(1000);
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 3000);
        send(client(), event("SessionStart", "after", "/w/after"));
        QTRY_VERIFY_WITH_TIMEOUT(task("after") != nullptr, 2000);
    }

    void permissionAllowRoundTrip()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"ls -la"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        QCOMPARE(queue->command(), QStringLiteral("ls -la"));
        QVERIFY(!c->canReadLine());                             // nothing answered without a click
        queue->allow();
        QTRY_VERIFY_WITH_TIMEOUT(c->canReadLine(), 2000);
        QCOMPARE(c->readLine().trimmed(), QByteArray(R"({"decision":"allow"})"));
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 2000);
    }

    void permissionDenyCarriesAMessage()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"rm x"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        queue->deny();
        QTRY_VERIFY_WITH_TIMEOUT(c->canReadLine(), 2000);
        const auto reply = QJsonDocument::fromJson(c->readLine()).object();
        QCOMPARE(reply.value("decision").toString(), QStringLiteral("deny"));
        QVERIFY(!reply.value("message").toString().isEmpty());
    }

    void permissionTimeoutReleases()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"ls"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        sched->advance(ApprovalQueue::kDefaultTimeoutMs);
        QTRY_VERIFY_WITH_TIMEOUT(c->canReadLine(), 2000);
        QCOMPARE(c->readLine().trimmed(), QByteArray(R"({"decision":"release"})"));
    }

    void clientDisconnectCancelsThePendingRequest()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"ls"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        QVERIFY(state->isPinned());
        c->abort();                                             // Claude Code killed the hook
        QTRY_VERIFY_WITH_TIMEOUT(!queue->active(), 2000);
        QVERIFY(!state->isPinned());
    }

    // Quitting Farol (or a failing test) with a hook still waiting for a click used to crash: the open sockets were
    // closed after the connection table was gone.
    void destroyingTheServerWithAHeldRequestDoesNotCrash()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"ls"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        server.reset();
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 2000);   // the hook sees the close and exits
    }

    void askUserQuestionIsHeldAndAnsweredFromTheIsland()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p",
                      R"(,"tool_name":"AskUserQuestion","tool_input":{"questions":[{"question":"Pick one?","options":[{"label":"A"},{"label":"B"}]}]})"));
        QTRY_VERIFY_WITH_TIMEOUT(questions->active(), 2000);
        QVERIFY(!c->canReadLine());                             // nothing answered without a click
        QVERIFY(!queue->active());                              // it is not a permission to allow or deny
        QVERIFY(task("s1") && task("s1")->state == BotState::Question);
        questions->choose("B");
        QTRY_VERIFY_WITH_TIMEOUT(c->canReadLine(), 2000);
        const auto reply = QJsonDocument::fromJson(c->readLine()).object();
        QCOMPARE(reply.value("decision").toString(), QStringLiteral("allow"));
        const QJsonObject updated = reply.value("updatedInput").toObject();
        QCOMPARE(updated.value("answers").toObject(), (QJsonObject{{"Pick one?", "B"}}));
        QCOMPARE(updated.value("questions").toArray().size(), 1);
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 2000);
    }

    void askUserQuestionLeftToTheEditorIsReleased()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p",
                      R"(,"tool_name":"AskUserQuestion","tool_input":{"questions":[{"question":"Pick one?","options":[{"label":"A"},{"label":"B"}]}]})"));
        QTRY_VERIFY_WITH_TIMEOUT(questions->active(), 2000);
        questions->release();
        QTRY_VERIFY_WITH_TIMEOUT(c->canReadLine(), 2000);
        QCOMPARE(c->readLine().trimmed(), QByteArray(R"({"decision":"release"})"));
    }

    void theHookGoingAwayDropsTheHeldQuestion()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p",
                      R"(,"tool_name":"AskUserQuestion","tool_input":{"questions":[{"question":"Pick one?","options":[{"label":"A"},{"label":"B"}]}]})"));
        QTRY_VERIFY_WITH_TIMEOUT(questions->active(), 2000);
        c->abort();                                             // answered in the editor: Claude Code killed the hook
        QTRY_VERIFY_WITH_TIMEOUT(!questions->active(), 2000);
    }

    // Only a PermissionRequest is ever answered: a Stop or a PostToolUse is shown and the connection closed, nothing
    // is written back.
    void stopAndPostToolUseAreShownAndNeverAnswered()
    {
        QLocalSocket *c = client();
        send(c, event("PostToolUse", "s1", "/w/p", R"(,"tool_name":"Bash")"));
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 2000);
        QCOMPARE(c->readAll(), QByteArray());
        QVERIFY(task("s1") && task("s1")->state == BotState::Working);

        c = client();
        send(c, event("Stop", "s1", "/w/p", R"(,"last_assistant_message":"Pronto.")"));
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 2000);
        QCOMPARE(c->readAll(), QByteArray());
        QVERIFY(task("s1")->state == BotState::Finished);
    }

    // The PostToolUse of an Edit as farol-hook sends it (the patch and the counts, no whole file): the step of the
    // edit says how much changed, its diff is kept, and like every PostToolUse it is never answered.
    void aSlimmedEditReachesTheSessionWithItsCountsAndItsDiff()
    {
        send(client(), event("PreToolUse", "s1", "/w/p",
                             R"(,"tool_name":"Edit","tool_use_id":"toolu_01","tool_input":{"file_path":"/w/p/small.txt","old_string":"beta","new_string":"beta2\nbeta3"})"));
        QTRY_VERIFY_WITH_TIMEOUT(task("s1") && task("s1")->steps.size() == 1, 2000);
        QCOMPARE(task("s1")->steps.last().added, -1);
        QLocalSocket *c = client();
        send(c, event("PostToolUse", "s1", "/w/p",
                      R"(,"tool_name":"Edit","tool_use_id":"toolu_01","tool_input":{"file_path":"/w/p/small.txt","replace_all":false},)"
                      R"("tool_response":{"filePath":"/w/p/small.txt","structuredPatch":[{"oldStart":1,"oldLines":4,"newStart":1,"newLines":5,)"
                      R"("lines":[" alpha","-beta","+beta2","+beta3"," gamma"," delta"]}],"userModified":false,"replaceAll":false},)"
                      R"("duration_ms":10,"farol_edit":{"added":2,"removed":1,"cut":false})"));
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 2000);
        QCOMPARE(c->readAll(), QByteArray());
        QCOMPARE(task("s1")->steps.size(), 1);
        const Step step = task("s1")->steps.last();
        QCOMPARE(step.label, QStringLiteral("Edits · small.txt"));
        QCOMPARE(step.added, 2);
        QCOMPARE(step.removed, 1);
        QVERIFY(diffs->has(step.diff));
        QVERIFY(state->view() != IslandView::Diff);              // nothing opens by itself
    }

    // The whole way: Claude Code's payload for an Edit of a file of 2 MB, through the real farol-hook, into the
    // island. As Claude Code sends it the line is over what the server takes; slimmed, the edit arrives.
    void theRealHookBringsAnEditOfAHugeFileToTheIsland()
    {
        const QString home = dir.path() + "/home";
        QDir(home).removeRecursively();
        HookServer atHome(sessions.get(), queue.get());
        QVERIFY(atHome.start(home + "/.local/share/farol/farol.sock") == HookServer::StartResult::Started);

        const QJsonObject hunk{{"oldStart", 1}, {"oldLines", 3}, {"newStart", 1}, {"newLines", 3},
                               {"lines", QJsonArray{" row 000000", "-row 000001", "+ROW ONE", " row 000002"}}};
        const QString original = QStringLiteral("row of the huge file, padded with some text to make it longer\n").repeated(34000);
        const QJsonObject payload{
            {"session_id", "huge"}, {"cwd", "/w/p"}, {"hook_event_name", "PostToolUse"}, {"tool_name", "Edit"}, {"tool_use_id", "toolu_02"},
            {"tool_input", QJsonObject{{"file_path", "/w/p/huge.txt"}, {"old_string", "row 000001"}, {"new_string", "ROW ONE"}, {"replace_all", false}}},
            {"tool_response", QJsonObject{{"filePath", "/w/p/huge.txt"}, {"oldString", "row 000001"}, {"newString", "ROW ONE"},
                                          {"originalFile", original}, {"structuredPatch", QJsonArray{hunk}}, {"userModified", false}}}};
        const QByteArray raw = QJsonDocument(payload).toJson(QJsonDocument::Compact);
        QVERIFY(raw.size() > HookServer::kMaxLine);              // as it is, the server would drop it

        QProcess hook;
        QProcessEnvironment env;
        env.insert("HOME", home);
        env.insert("PATH", qEnvironmentVariable("PATH", "/usr/bin:/bin"));
        hook.setProcessEnvironment(env);
        hook.start("python3", {QStringLiteral(FAROL_HOOK_PATH)});
        QVERIFY2(hook.waitForStarted(5000), "python3 is needed to run farol-hook");
        hook.write(raw);
        hook.closeWriteChannel();
        QTRY_VERIFY_WITH_TIMEOUT(hook.state() == QProcess::NotRunning, 10000);
        QCOMPARE(hook.exitCode(), 0);
        QCOMPARE(hook.readAllStandardOutput() + hook.readAllStandardError(), QByteArray());
        QTRY_VERIFY_WITH_TIMEOUT(task("huge") && !task("huge")->steps.isEmpty(), 2000);
        const Step step = task("huge")->steps.last();
        QCOMPARE(step.label, QStringLiteral("Edits · huge.txt"));
        QCOMPARE(step.added, 1);
        QCOMPARE(step.removed, 1);
        QVERIFY(diffs->open(step.diff));
        QCOMPARE(diffs->fileName(), QStringLiteral("huge.txt"));
        QCOMPARE(diffs->rows().size(), 5);
        QCOMPARE(diffs->rows().at(2).toMap().value("text").toString(), QStringLiteral("row 000001"));
        QVERIFY(!diffs->cut());
    }

    void alwaysAllowedRequestIsAnsweredWithoutAnAlert()
    {
        QLocalSocket *first = client();
        send(first, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"make"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        queue->always();
        QTRY_VERIFY_WITH_TIMEOUT(first->canReadLine(), 2000);
        QLocalSocket *again = client();
        send(again, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"make"})"));
        QTRY_VERIFY_WITH_TIMEOUT(again->canReadLine(), 2000);
        QCOMPARE(again->readLine().trimmed(), QByteArray(R"({"decision":"allow"})"));
        QVERIFY(!queue->active());
    }

    void secondInstanceSeesTheFirstOneAndLeavesItAlone()
    {
        HookServer other(sessions.get(), queue.get());
        QVERIFY(other.start(sockPath()) == HookServer::StartResult::AlreadyRunning);
        send(client(), event("SessionStart", "still", "/w/still"));   // the first server keeps answering
        QTRY_VERIFY_WITH_TIMEOUT(task("still") != nullptr, 2000);
    }

    void staleSocketFileIsReplaced()
    {
        const QString stale = dir.path() + "/stale/farol.sock";
        QDir().mkpath(dir.path() + "/stale");
        const int fd = ::socket(AF_UNIX, SOCK_STREAM, 0);
        sockaddr_un addr{};
        addr.sun_family = AF_UNIX;
        std::strncpy(addr.sun_path, stale.toUtf8().constData(), sizeof(addr.sun_path) - 1);
        QVERIFY(::bind(fd, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) == 0);
        ::close(fd);                                            // the file stays, nobody listens (a crashed run)
        QVERIFY(QFile::exists(stale));
        HookServer other(sessions.get(), queue.get());
        QVERIFY(other.start(stale) == HookServer::StartResult::Started);
    }

    void tooLongSocketPathFails()
    {
        HookServer other(sessions.get(), queue.get());
        QVERIFY(other.start(dir.path() + "/" + QString(120, 'a') + "/farol.sock") == HookServer::StartResult::Failed);
        QVERIFY(!other.errorString().isEmpty());
    }
};

QTEST_MAIN(TestHookServer)
#include "tst_hook_server.moc"
