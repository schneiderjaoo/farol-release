#pragma once
#include <QObject>
#include <QString>
#include <functional>

class QSettings;

namespace farol {

// The two system-wide keyboard shortcuts, chosen in Settings -> Atalhos: "toggle" opens or closes the island and
// "jump" goes to the session that waits for an answer. This class validates and remembers them (farol.conf,
// shortcuts/toggle and shortcuts/jump: Qt key | modifiers, 0 = none); the desktop side is behind `Bind`.
class Shortcuts : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString toggleKey READ toggleKey NOTIFY changed)   // how the desktop names the keys ("Meta+F"), or ""
    Q_PROPERTY(QString jumpKey READ jumpKey NOTIFY changed)
    Q_PROPERTY(QString error READ error NOTIFY changed)           // why the last assign() was refused (pt-BR), or ""

public:
    // Registers `combo` (0 = none) for `action` with the desktop and returns its name for the screen; an empty
    // string means the desktop refused it (taken by another program).
    using Bind = std::function<QString(const QString &action, int combo)>;

    Shortcuts(QSettings *settings, Bind bind, QObject *parent = nullptr);

    // Registers what was saved. Called once at start, after the backend is ready.
    void restore();
    // A key press caught by the Settings view. false with no error for a lone modifier (the user is still pressing);
    // false with `error` set for keys that cannot be a global shortcut or that are taken.
    Q_INVOKABLE bool assign(const QString &action, int key, int modifiers);
    Q_INVOKABLE void clear(const QString &action);
    Q_INVOKABLE void clearError();

    QString toggleKey() const { return m_label[0]; }
    QString jumpKey() const { return m_label[1]; }
    QString error() const { return m_error; }
    int combo(const QString &action) const;

signals:
    void changed();

private:
    static int indexOf(const QString &action);
    void fail(const QString &why);

    QSettings *m_settings;
    Bind m_bind;
    int m_combo[2] = {0, 0};
    QString m_label[2];
    QString m_error;
};

} // namespace farol
