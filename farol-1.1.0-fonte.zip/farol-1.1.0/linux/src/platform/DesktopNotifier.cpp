#include "DesktopNotifier.h"

#include "X11.h"

#include <QDBusConnection>
#include <QDBusMessage>
#include <QDBusPendingCallWatcher>
#include <QDBusPendingReply>
#include <QVariantMap>
#include <memory>
#if FAROL_KDE
#include <KIdleTime>
#endif

namespace farol {

QString notificationBody(const QString &text, bool markup)
{
    if (!markup)
        return text;
    QString out = text;
    return out.replace(QLatin1Char('&'), QLatin1String("&amp;")).replace(QLatin1Char('<'), QLatin1String("&lt;")).replace(QLatin1Char('>'), QLatin1String("&gt;"));
}

DesktopNotifier::DesktopNotifier(QObject *parent) : QObject(parent)
{
#if FAROL_KDE
    if (desktopIsKde()) {
        KIdleTime *idle = KIdleTime::instance();
        idle->addIdleTimeout(kIdleMs);
        connect(idle, &KIdleTime::timeoutReached, this, [this, idle] {
            m_idle = true;
            idle->catchNextResumeEvent();
        });
        connect(idle, &KIdleTime::resumingFromIdle, this, [this] { m_idle = false; });
    }
#endif

    // Asked once, without waiting: until the server says how it reads the body, the body is escaped.
    const QDBusMessage ask = QDBusMessage::createMethodCall(QStringLiteral("org.freedesktop.Notifications"), QStringLiteral("/org/freedesktop/Notifications"),
                                                            QStringLiteral("org.freedesktop.Notifications"), QStringLiteral("GetCapabilities"));
    auto *watcher = new QDBusPendingCallWatcher(QDBusConnection::sessionBus().asyncCall(ask, 2000), this);
    connect(watcher, &QDBusPendingCallWatcher::finished, this, [this, watcher] {
        const QDBusPendingReply<QStringList> capabilities = *watcher;
        watcher->deleteLater();
        if (!capabilities.isError())
            m_bodyMarkup = capabilities.value().contains(QLatin1String("body-markup"));
    });
}

void DesktopNotifier::notifyIfAway(const QString &title, const QString &text)
{
    // Outside Plasma the X server is asked how long nobody touched the computer, at this moment only.
    if (m_idle || m_alwaysAway || x11::idleMs() >= kIdleMs) {
        send(title, text);
        return;
    }
    // Not idle, but the screen may have been locked a moment ago. Cinnamon's screen saver goes by its own name.
    const auto sent = std::make_shared<bool>(false);
    for (const char *name : {"org.freedesktop.ScreenSaver", "org.cinnamon.ScreenSaver"}) {
        const QString service = QLatin1String(name);
        const QString path = service == QLatin1String("org.freedesktop.ScreenSaver") ? QStringLiteral("/ScreenSaver")
                                                                                     : QStringLiteral("/org/cinnamon/ScreenSaver");
        const QDBusMessage ask = QDBusMessage::createMethodCall(service, path, service, QStringLiteral("GetActive"));
        auto *watcher = new QDBusPendingCallWatcher(QDBusConnection::sessionBus().asyncCall(ask, 2000), this);
        connect(watcher, &QDBusPendingCallWatcher::finished, this, [this, watcher, title, text, sent] {
            const QDBusPendingReply<bool> locked = *watcher;
            watcher->deleteLater();
            if (!locked.isError() && locked.value() && !*sent) {
                *sent = true;
                send(title, text);
            }
        });
    }
}

void DesktopNotifier::send(const QString &title, const QString &text)
{
    QDBusMessage notify = QDBusMessage::createMethodCall(QStringLiteral("org.freedesktop.Notifications"), QStringLiteral("/org/freedesktop/Notifications"),
                                                         QStringLiteral("org.freedesktop.Notifications"), QStringLiteral("Notify"));
    notify << QStringLiteral("Farol") << uint(0) << QStringLiteral("local.joao.Farol") << title << notificationBody(text, m_bodyMarkup) << QStringList()
           << QVariantMap{{QStringLiteral("desktop-entry"), QStringLiteral("local.joao.Farol")}} << int(-1);
    QDBusConnection::sessionBus().asyncCall(notify, 2000);   // fire and forget: a missing notification daemon is not an error
}

} // namespace farol
