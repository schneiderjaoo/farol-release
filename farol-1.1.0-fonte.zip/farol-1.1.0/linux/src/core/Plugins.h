#pragma once
#include "CommandRunner.h"

#include <QHash>
#include <QList>
#include <QObject>
#include <QString>
#include <QVariantList>
#include <functional>

namespace farol {

struct PluginInfo {
    QString id;            // "name@marketplace"
    QString name, marketplace, description;
    bool enabled = false;
};

// What `claude plugin list --json --available` prints: the plugins installed for the user and the ones the known
// marketplaces offer. Unknown fields are ignored; ok is false when the text is not that JSON.
struct PluginListing {
    bool ok = false;
    QList<PluginInfo> installed, available;
};
PluginListing parsePluginListing(const QByteArray &json);

// The Skills tab's plugins: the installed ones (on/off, remove) and the catalogue to install more from. Every
// change is made by Claude Code's own program (`claude plugin ...`), started by a click, one command at a time;
// Farol never writes Claude Code's settings itself. The list is read when the tab asks, never in the background.
class Plugins : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool hasClaude READ hasClaude NOTIFY changed)
    Q_PROPERTY(bool loading READ loading NOTIFY changed)
    Q_PROPERTY(bool busy READ busy NOTIFY changed)                 // a command runs: the buttons wait
    Q_PROPERTY(QString error READ error NOTIFY changed)            // the list could not be read (pt-BR)
    Q_PROPERTY(QString notice READ notice NOTIFY changed)          // what the last action did (pt-BR)
    Q_PROPERTY(QVariantList installed READ installed NOTIFY changed)   // {id, name, marketplace, enabled, busy, error}
    Q_PROPERTY(QVariantList catalog READ catalog NOTIFY changed)       // {id, name, marketplace, description, busy, error}
    Q_PROPERTY(int catalogTotal READ catalogTotal NOTIFY changed)
    Q_PROPERTY(QString filter READ filter WRITE setFilter NOTIFY changed)
public:
    static constexpr int kListTimeoutMs = 30 * 1000;
    static constexpr int kActionTimeoutMs = 120 * 1000;

    // locate: the path of `claude`, or empty; asked each time the list is read. path: the PATH to run it with.
    Plugins(ICommandRunner *runner, std::function<QString()> locate, const QString &path, QObject *parent = nullptr);

    bool hasClaude() const { return m_hasClaude; }
    bool loading() const { return m_loading; }
    bool busy() const { return !m_busyId.isEmpty() || m_loading; }
    QString error() const { return m_error; }
    QString notice() const { return m_notice; }
    QVariantList installed() const;
    QVariantList catalog() const;
    int catalogTotal() const { return int(m_listing.available.size()); }
    QString filter() const { return m_filter; }
    void setFilter(const QString &text);

    Q_INVOKABLE void refresh();
    Q_INVOKABLE void setEnabled(const QString &id, bool on);
    Q_INVOKABLE void remove(const QString &id);
    Q_INVOKABLE void install(const QString &id);

signals:
    void changed();

private:
    void act(const QString &id, const QStringList &arguments, const QString &done);
    void list();
    static QString lastLine(const ICommandRunner::Result &r);

    ICommandRunner *m_runner;
    std::function<QString()> m_locate;
    QString m_path;
    QString m_claude;
    bool m_hasClaude = true;    // until looked for
    bool m_loading = false;
    QString m_busyId;
    QString m_error, m_notice, m_filter;
    QHash<QString, QString> m_errors;   // plugin id -> why its last action failed
    PluginListing m_listing;
};

} // namespace farol
