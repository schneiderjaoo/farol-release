#pragma once
#include <QByteArray>
#include <QString>
#include <QStringList>
#include <functional>

namespace farol {

// Runs a program without blocking and reports once how it went. The platform layer does it with QProcess; tests
// give a fake.
class ICommandRunner {
public:
    struct Result {
        bool started = false;    // false: the program is not installed (or could not be run)
        bool timedOut = false;
        int exitCode = -1;
        QString out, err;
    };
    virtual ~ICommandRunner() = default;
    // env: "NAME=value" entries added to the app's own environment. input: what the program reads from its standard
    // input (nothing: it finds the end of it at once).
    virtual void run(const QString &program, const QStringList &arguments, const QStringList &env, int timeoutMs,
                     std::function<void(const Result &)> done, const QByteArray &input = {}) = 0;
    // Ends what this runner still has running; each command reports as one that did not exit by itself.
    virtual void cancel() {}
};

} // namespace farol
