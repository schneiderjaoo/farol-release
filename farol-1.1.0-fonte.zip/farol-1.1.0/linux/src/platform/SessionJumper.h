#pragma once
#include "JumpCommand.h"
#include "JumpTarget.h"

#include <QObject>
#include <QTimer>
#include <functional>

class QTemporaryFile;

namespace farol {

// Executes jumpCommandFor(target).
//  * An editor (VSCodium, VS Code, Cursor, ...; Flatpak or not): a KWin script raises the editor window whose title
//    names the session's folder; only when there is none (or KWin does not answer) the editor is asked to open it.
//  * Konsole: switches to the session's tab over D-Bus, then its window is raised.
//  * Any other terminal: the window of the closest process above Claude Code that has one is raised.
// Windows are also looked for by process: farol-hook names the processes above Claude Code, and their pids on this
// side come from ProcessWatcher::hostPid (a Flatpak has pids of its own).
// The KWin script reports back to WindowResult on Farol's own D-Bus object (/Jumper).
// Without KWin, on an X11 desktop (Cinnamon), the window is chosen the same way among the ones the window manager
// lists and raised through it (x11::windows, windowToRaise).
//
// openSession ("Nova sessão") uses the same pieces to start a new Claude Code session in a repository: raise its
// window (opening the folder first when there is none and looking for the window until it shows up), then hand the
// editor the Claude Code extension's URI, which opens a new tab in the window that has the focus.
class SessionJumper : public QObject {
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "local.joao.Farol.Jumper")
public:
    explicit SessionJumper(QObject *parent = nullptr);
    ~SessionJumper() override;
public slots:
    void jump(const farol::JumpTarget &target);
    // `editor`: flatpakId and editor of the editor to use (ClaudeSessions::lastEditor); empty means VSCodium.
    void openSession(const QString &repo, const farol::JumpTarget &editor = {});
    Q_SCRIPTABLE void WindowResult(bool found);   // D-Bus: called by the KWin script, never by the UI

private:
    using Found = std::function<void(bool found)>;
    bool activateWithKWin(const QStringList &folders, const QStringList &windowClasses, const QList<qint64> &pids, bool anyWindow,
                          Found then);
    void finishKWinScript();
    void lookForSessionWindow();
    void sessionWindowLooked(bool found);

    // "Nova sessão" in progress: the folder being opened and how many times its window was looked for.
    struct Opening {
        QString repo;
        JumpCommand openFolder;
        JumpTarget editor;
        int looks = 0;
    };
    Opening m_opening;
    QTimer m_lookAgain;
    Found m_then;                    // what to do with the KWin script's answer
    QTemporaryFile *m_script = nullptr;
    QTimer m_timeout;
    bool m_waiting = false;
    bool m_registered = false;
};

} // namespace farol
