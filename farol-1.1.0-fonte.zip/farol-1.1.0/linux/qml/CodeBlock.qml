import QtQuick

// Monospace box for the command/file a permission request is about. Clips at two lines.
Rectangle {
    id: block
    property string text: ""
    readonly property alias cut: label.truncated   // the two lines were not enough for the text
    implicitHeight: 34
    height: 34
    radius: 8
    clip: true   // marks piled on a character are drawn outside its line
    color: theme.codeBg
    border.color: theme.line
    border.width: 1

    Text {
        id: label
        anchors.fill: parent
        anchors.leftMargin: 10
        anchors.rightMargin: 10
        verticalAlignment: Text.AlignVCenter
        textFormat: Text.PlainText
        text: block.text
        color: theme.text
        font.family: theme.monoFont
        font.pixelSize: 12
        wrapMode: Text.WrapAnywhere
        maximumLineCount: 2
        elide: Text.ElideRight
    }
}
