#pragma once
#include <QObject>
#include <QPointer>

class QQuickWindow;

// Owns the two Wayland knobs the island needs: the input region (clicks outside
// the island fall through to the window below) and the layer-shell keyboard mode.
class IslandProbe : public QObject {
    Q_OBJECT
public:
    explicit IslandProbe(QObject *parent = nullptr);
    void attach(QQuickWindow *window);

    Q_INVOKABLE void setInputRect(qreal x, qreal y, qreal w, qreal h);
    Q_INVOKABLE void setKeyboardOnDemand(bool on);
    Q_INVOKABLE void log(const QString &message);

private:
    QPointer<QQuickWindow> m_window;
};
