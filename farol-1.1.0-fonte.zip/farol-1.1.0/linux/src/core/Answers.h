#pragma once
#include <QCache>
#include <QObject>
#include <QString>
#include <QUrl>

namespace farol {

class Theme;

// What the "Perguntar" tab shows of an answer (context object `answers`): its Markdown as safe HTML in the theme's
// colours (core/AnswerText), and the one thing a click on it may do, which is to open a web link.
class Answers : public QObject {
    Q_OBJECT
public:
    static constexpr int kKeptChars = 4 * 1024 * 1024;   // of Markdown and HTML together, in what is kept

    explicit Answers(Theme *theme, QObject *parent = nullptr);

    // `dark` is the theme the caller draws in: a binding that passes theme.dark asks again when the theme changes.
    // A conversation is laid out again at every change, so what was converted is kept.
    Q_INVOKABLE QString html(const QString &markdown, bool dark);
    Q_INVOKABLE bool isWebLink(const QString &link) const;
    // For the line that says where a link goes: its host, and what comes after the host (core/AnswerText).
    Q_INVOKABLE QString host(const QString &link) const;
    Q_INVOKABLE QString rest(const QString &link) const;
    // After a click: asks the app to open a web link in the browser. Anything else is not opened.
    Q_INVOKABLE void open(const QString &link);

    int conversions() const { return m_conversions; }   // how many texts were really converted

signals:
    void openRequested(const QUrl &url);

private:
    Theme *m_theme;
    QCache<QString, QString> m_kept;
    int m_conversions = 0;
};

} // namespace farol
