#include <QtTest>
#include <QDir>
#include <QFile>
#include <QTemporaryDir>
#include <memory>
#include "Links.h"
#include "SkillsFolder.h"

using namespace farol;

class TestSkillsFolder : public QObject {
    Q_OBJECT
    std::unique_ptr<QTemporaryDir> dir;

    QString company() const { return dir->path() + "/workspace/skills"; }
    QString claude() const { return dir->path() + "/home/.claude/skills"; }
    void skill(const QString &base, const QString &folder, const QString &frontMatter = {}) const
    {
        QVERIFY(QDir().mkpath(base + "/" + folder));
        QFile f(base + "/" + folder + "/SKILL.md");
        QVERIFY(f.open(QIODevice::WriteOnly));
        f.write(frontMatter.toUtf8() + "\n# body\n");
    }
    static QString target(const QString &link) { return links::target(link); }

private slots:
    void init()
    {
        dir = std::make_unique<QTemporaryDir>();
        QVERIFY(QDir().mkpath(company()));
        QVERIFY(QDir().mkpath(claude()));
    }

    void aSkillIsAFolderWithASkillFileNamedByItsFrontMatter()
    {
        skill(company(), "superloja-sql");
        skill(company(), "superloja-loja-api-sql", "---\nname: ords-rest-superloja\ndescription: x\n---");
        skill(company(), "quoted", "---\ndescription: y\nname: \"quoted-name\"\n---");
        skill(company(), "bad", "---\nname: ../../etc\n---");                    // not a file name: the folder's
        skill(company(), "late", "intro\n---\nname: not-front-matter\n---");     // no front matter at the top
        skill(company(), ".hidden");
        QVERIFY(QDir().mkpath(company() + "/docs"));                             // no SKILL.md: not a skill
        QStringList names;
        for (const SkillEntry &s : scanSkills(company()))
            names << s.name + "=" + QFileInfo(s.path).fileName();
        names.sort();
        QCOMPARE(names, (QStringList{"bad=bad", "late=late", "ords-rest-superloja=superloja-loja-api-sql", "quoted-name=quoted", "superloja-sql=superloja-sql"}));
        QVERIFY(scanSkills(QString()).isEmpty());
        QVERIFY(scanSkills(dir->path() + "/nowhere").isEmpty());
    }

    void missingLinksAreCreatedAndRightOnesLeftAlone()
    {
        skill(company(), "a");
        skill(company(), "b", "---\nname: bee\n---");
        QVERIFY(links::make(company() + "/a", claude() + "/a"));                 // already right
        LinkPlan plan = planLinks(company(), claude());
        QCOMPARE(plan.create.keys(), QStringList{"bee"});
        QVERIFY(plan.relink.isEmpty() && plan.remove.isEmpty() && plan.conflicts.isEmpty());
        QCOMPARE(plan.linked, 2);
        QVERIFY(applyLinks(plan, claude()));
        QCOMPARE(target(claude() + "/bee"), company() + "/b");
        QVERIFY(QFileInfo(claude() + "/bee/SKILL.md").isFile());                 // Claude Code reads through the link
        QVERIFY(!planLinks(company(), claude()).changes());                      // nothing left to do
    }

    void aSkillThatMovedIsRelinkedAndAGoneOneUnlinked()
    {
        skill(company(), "new-folder", "---\nname: moved\n---");
        QVERIFY(links::make(company() + "/old-folder", claude() + "/moved"));    // ours, the folder was renamed
        QVERIFY(links::make(company() + "/deleted", claude() + "/deleted"));     // ours, the skill is gone (dangling)
        LinkPlan plan = planLinks(company(), claude());
        QCOMPARE(plan.relink.keys(), QStringList{"moved"});
        QCOMPARE(plan.remove, QStringList{"deleted"});
        QCOMPARE(plan.linked, 1);
        QVERIFY(applyLinks(plan, claude()));
        QCOMPARE(target(claude() + "/moved"), company() + "/new-folder");
        QVERIFY(!links::isLink(claude() + "/deleted"));
    }

    void whatIsNotOursIsNeverTouched()
    {
        skill(company(), "taken-by-folder");
        skill(company(), "taken-by-link");
        skill(company(), "free");
        const QString other = dir->path() + "/home/.agents/skills";
        skill(other, "taken-by-link");
        skill(other, "animate");
        skill(claude(), "taken-by-folder");                                      // the user's own skill, a real folder
        skill(claude(), "batch-shell");
        QVERIFY(links::make(other + "/taken-by-link", claude() + "/taken-by-link"));
        QVERIFY(links::make(other + "/animate", claude() + "/animate"));
        QVERIFY(links::make(dir->path() + "/gone", claude() + "/dangling-of-someone-else"));
        LinkPlan plan = planLinks(company(), claude());
        QCOMPARE(plan.conflicts, (QStringList{"taken-by-folder", "taken-by-link"}));
        QCOMPARE(plan.create.keys(), QStringList{"free"});
        QVERIFY(plan.remove.isEmpty() && plan.relink.isEmpty());
        QCOMPARE(plan.linked, 1);
        QVERIFY(applyLinks(plan, claude()));
        QCOMPARE(target(claude() + "/taken-by-link"), other + "/taken-by-link");
        QVERIFY(!links::isLink(claude() + "/taken-by-folder"));
        QVERIFY(QFileInfo(claude() + "/batch-shell/SKILL.md").isFile());
        QCOMPARE(target(claude() + "/animate"), other + "/animate");
        QVERIFY(links::isLink(claude() + "/dangling-of-someone-else"));
    }

    void twoFoldersDeclaringOneNameAreAConflictNotAFlipFlop()
    {
        skill(company(), "one", "---\nname: same\n---");
        skill(company(), "two", "---\nname: same\n---");
        LinkPlan plan = planLinks(company(), claude());
        QCOMPARE(plan.conflicts, QStringList{"same"});
        QCOMPARE(plan.create.value("same"), company() + "/one");                 // the first has it
        QVERIFY(applyLinks(plan, claude()));
        QVERIFY(!planLinks(company(), claude()).changes());                      // and it stays so
    }

    void changingOrClearingTheFolderTakesItsLinksAlong()
    {
        skill(company(), "a");
        skill(company(), "b");
        QVERIFY(applyLinks(planLinks(company(), claude()), claude()));
        const QString other = dir->path() + "/elsewhere/skills";
        skill(other, "a");
        skill(other, "c");
        LinkPlan plan = planLinks(other, claude(), company());                   // another folder chosen
        QCOMPARE(plan.relink.keys(), QStringList{"a"});
        QCOMPARE(plan.create.keys(), QStringList{"c"});
        QCOMPARE(plan.remove, QStringList{"b"});
        QVERIFY(applyLinks(plan, claude()));
        QCOMPARE(target(claude() + "/a"), other + "/a");

        plan = planLinks(QString(), claude(), other);                            // no folder any more
        QCOMPARE(plan.remove, (QStringList{"a", "c"}));
        QCOMPARE(plan.linked, 0);
        QVERIFY(applyLinks(plan, claude()));
        QVERIFY(QDir(claude()).entryList(QDir::AllEntries | QDir::System | QDir::NoDotAndDotDot).isEmpty());
        QVERIFY(QFileInfo(other + "/a/SKILL.md").isFile());                      // the skills themselves are untouched
    }

    void theLinksFolderIsCreatedWhenMissing()
    {
        skill(company(), "a");
        const QString fresh = dir->path() + "/fresh/.claude/skills";
        QVERIFY(applyLinks(planLinks(company(), fresh), fresh));
        QCOMPARE(target(fresh + "/a"), company() + "/a");
    }
};

QTEST_GUILESS_MAIN(TestSkillsFolder)
#include "tst_skills_folder.moc"
