#include "SecretServiceStore.h"

#include <QDBusArgument>
#include <QDBusConnection>
#include <QDBusMessage>
#include <QDBusMetaType>
#include <QDBusPendingCallWatcher>
#include <QMap>

namespace farol {
// (oayays): the session, the parameters of its algorithm (none for "plain"), the value and its content type
struct SsSecret {
    QDBusObjectPath session;
    QByteArray parameters;
    QByteArray value;
    QString contentType;
};
using SsAttributes = QMap<QString, QString>;
} // namespace farol
Q_DECLARE_METATYPE(farol::SsSecret)

namespace farol {

static QDBusArgument &operator<<(QDBusArgument &a, const SsSecret &s)
{
    a.beginStructure();
    a << s.session << s.parameters << s.value << s.contentType;
    a.endStructure();
    return a;
}

static const QDBusArgument &operator>>(const QDBusArgument &a, SsSecret &s)
{
    a.beginStructure();
    a >> s.session >> s.parameters >> s.value >> s.contentType;
    a.endStructure();
    return a;
}

static const QString kService = QStringLiteral("org.freedesktop.secrets");
static const QString kServicePath = QStringLiteral("/org/freedesktop/secrets");
static const QString kServiceIface = QStringLiteral("org.freedesktop.Secret.Service");
static const QString kCollectionIface = QStringLiteral("org.freedesktop.Secret.Collection");
static const QString kItemIface = QStringLiteral("org.freedesktop.Secret.Item");
static const QString kPromptIface = QStringLiteral("org.freedesktop.Secret.Prompt");

static SsAttributes attributesOf(const QString &name)
{
    return {{QStringLiteral("application"), QStringLiteral("farol")}, {QStringLiteral("key"), name}};
}

static bool isSet(const QDBusObjectPath &path)
{
    return !path.path().isEmpty() && path.path() != QLatin1String("/");
}

SecretServiceStore::SecretServiceStore(QObject *parent) : QObject(parent)
{
    qDBusRegisterMetaType<SsSecret>();
    qDBusRegisterMetaType<SsAttributes>();
}

void SecretServiceStore::call(const QString &path, const QString &interface, const QString &method, const QVariantList &arguments,
                              Answer then)
{
    QDBusMessage message = QDBusMessage::createMethodCall(kService, path, interface, method);
    message.setArguments(arguments);
    auto *watcher = new QDBusPendingCallWatcher(QDBusConnection::sessionBus().asyncCall(message), this);
    connect(watcher, &QDBusPendingCallWatcher::finished, this, [then = std::move(then)](QDBusPendingCallWatcher *w) {
        w->deleteLater();
        if (w->isError())
            then(false, {});
        else
            then(true, w->reply().arguments());
    });
}

void SecretServiceStore::withSession(std::function<void(const QDBusObjectPath &)> then)
{
    if (isSet(m_session)) {
        then(m_session);
        return;
    }
    // "plain": the secret crosses the session bus as it is, like every desktop client that does not negotiate a key
    call(kServicePath, kServiceIface, QStringLiteral("OpenSession"),
         {QStringLiteral("plain"), QVariant::fromValue(QDBusVariant(QString()))}, [this, then](bool ok, const QVariantList &values) {
        if (ok && values.size() >= 2)
            m_session = values.at(1).value<QDBusObjectPath>();
        then(m_session);
    });
}

void SecretServiceStore::runPrompt(const QDBusObjectPath &prompt, std::function<void(bool)> then)
{
    if (m_promptDone) {   // one question to the user at a time
        then(false);
        return;
    }
    m_promptPath = prompt.path();
    m_promptDone = std::move(then);
    QDBusConnection::sessionBus().connect(kService, m_promptPath, kPromptIface, QStringLiteral("Completed"), this,
                                          SLOT(promptCompleted(bool,QDBusVariant)));
    call(m_promptPath, kPromptIface, QStringLiteral("Prompt"), {QString()}, [this](bool ok, const QVariantList &) {
        if (!ok)
            promptCompleted(true, {});
    });
}

void SecretServiceStore::promptCompleted(bool dismissed, const QDBusVariant &)
{
    if (!m_promptDone)
        return;
    QDBusConnection::sessionBus().disconnect(kService, m_promptPath, kPromptIface, QStringLiteral("Completed"), this,
                                             SLOT(promptCompleted(bool,QDBusVariant)));
    const auto done = std::move(m_promptDone);
    m_promptDone = nullptr;
    done(!dismissed);
}

void SecretServiceStore::unlock(const QList<QDBusObjectPath> &objects, std::function<void(bool)> then)
{
    call(kServicePath, kServiceIface, QStringLiteral("Unlock"), {QVariant::fromValue(objects)},
         [this, then = std::move(then)](bool ok, const QVariantList &values) {
        if (!ok || values.size() < 2) {
            then(false);
            return;
        }
        const QDBusObjectPath prompt = values.at(1).value<QDBusObjectPath>();
        if (isSet(prompt))
            runPrompt(prompt, then);
        else
            then(true);
    });
}

void SecretServiceStore::find(const QString &name, std::function<void(bool, const QDBusObjectPath &)> then)
{
    call(kServicePath, kServiceIface, QStringLiteral("SearchItems"), {QVariant::fromValue(attributesOf(name))},
         [this, then = std::move(then)](bool ok, const QVariantList &values) {
        if (!ok || values.size() < 2) {
            then(false, {});
            return;
        }
        const auto unlocked = qdbus_cast<QList<QDBusObjectPath>>(values.at(0));
        const auto locked = qdbus_cast<QList<QDBusObjectPath>>(values.at(1));
        if (!unlocked.isEmpty()) {
            then(true, unlocked.first());
            return;
        }
        if (locked.isEmpty()) {
            then(true, {});
            return;
        }
        const QDBusObjectPath item = locked.first();
        unlock({item}, [then, item](bool opened) { then(opened, opened ? item : QDBusObjectPath()); });
    });
}

void SecretServiceStore::read(const QString &name, std::function<void(bool, const QString &)> done)
{
    withSession([this, name, done = std::move(done)](const QDBusObjectPath &session) {
        if (!isSet(session)) {
            done(false, {});
            return;
        }
        find(name, [this, session, done](bool ok, const QDBusObjectPath &item) {
            if (!ok || !isSet(item)) {
                done(ok, {});   // none kept under that name: an empty value
                return;
            }
            call(item.path(), kItemIface, QStringLiteral("GetSecret"), {QVariant::fromValue(session)},
                 [done](bool got, const QVariantList &values) {
                if (!got || values.isEmpty()) {
                    done(false, {});
                    return;
                }
                done(true, QString::fromUtf8(qdbus_cast<SsSecret>(values.first()).value));
            });
        });
    });
}

void SecretServiceStore::write(const QString &name, const QString &value, std::function<void(bool)> done)
{
    withSession([this, name, value, done = std::move(done)](const QDBusObjectPath &session) {
        if (!isSet(session)) {
            done(false);
            return;
        }
        call(kServicePath, kServiceIface, QStringLiteral("ReadAlias"), {QStringLiteral("default")},
             [this, session, name, value, done](bool ok, const QVariantList &values) {
            const QDBusObjectPath collection = ok && !values.isEmpty() ? values.first().value<QDBusObjectPath>() : QDBusObjectPath();
            if (!isSet(collection)) {
                done(false);
                return;
            }
            unlock({collection}, [this, session, collection, name, value, done](bool opened) {
                if (!opened) {
                    done(false);
                    return;
                }
                const QVariantMap properties{
                    {QStringLiteral("org.freedesktop.Secret.Item.Label"), QStringLiteral("Farol: chave de API (%1)").arg(name)},
                    {QStringLiteral("org.freedesktop.Secret.Item.Attributes"), QVariant::fromValue(attributesOf(name))}};
                const SsSecret secret{session, {}, value.toUtf8(), QStringLiteral("text/plain; charset=utf8")};
                call(collection.path(), kCollectionIface, QStringLiteral("CreateItem"),
                     {properties, QVariant::fromValue(secret), true}, [this, done](bool created, const QVariantList &out) {
                    if (!created || out.size() < 2) {
                        done(false);
                        return;
                    }
                    const QDBusObjectPath prompt = out.at(1).value<QDBusObjectPath>();
                    if (isSet(prompt))
                        runPrompt(prompt, done);
                    else
                        done(true);
                });
            });
        });
    });
}

void SecretServiceStore::remove(const QString &name, std::function<void(bool)> done)
{
    find(name, [this, done = std::move(done)](bool ok, const QDBusObjectPath &item) {
        if (!ok || !isSet(item)) {
            done(ok);   // nothing to take away
            return;
        }
        call(item.path(), kItemIface, QStringLiteral("Delete"), {}, [this, done](bool deleted, const QVariantList &out) {
            if (!deleted) {
                done(false);
                return;
            }
            const QDBusObjectPath prompt = out.isEmpty() ? QDBusObjectPath() : out.first().value<QDBusObjectPath>();
            if (isSet(prompt))
                runPrompt(prompt, done);
            else
                done(true);
        });
    });
}

} // namespace farol
