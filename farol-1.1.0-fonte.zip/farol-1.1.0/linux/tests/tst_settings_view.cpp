#include <QtTest>
#include <QQmlContext>
#include <QQmlEngine>
#include <QQuickItem>
#include <QQuickView>
#include <QSettings>
#include <QTemporaryDir>
#include <memory>
#include "Answers.h"
#include "AppState.h"
#include "Ask.h"
#include "FakeAsk.h"
#include "FakeScheduler.h"
#include "HooksStatus.h"
#include "IslandController.h"
#include "Shortcuts.h"
#include "Theme.h"

using namespace farol;

// The Settings view (qml/SettingsView.qml) on its own, at the sizes the island gives it: 524x280 beside the rail in
// the landscape island, 260x504 under it in the portrait one.
class TestSettingsView : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<Theme> theme;
    std::unique_ptr<Shortcuts> shortcuts;
    std::unique_ptr<HooksStatus> hooks;
    std::unique_ptr<FakeSecretStore> wallet;
    std::unique_ptr<FakeHttpClient> http;
    std::unique_ptr<Ask> ask;
    std::unique_ptr<Answers> answers;
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandController> ctl;
    std::unique_ptr<QQuickView> view;
    QList<int> takenKeys;                 // key combinations "another program" has
    QString hookState;
    QQuickItem *root = nullptr;

    static QQuickItem *findItem(QQuickItem *item, const QString &name)
    {
        if (item->objectName() == name)
            return item;
        for (QQuickItem *c : item->childItems())
            if (QQuickItem *f = findItem(c, name))
                return f;
        return nullptr;
    }
    QQuickItem *child(const char *name) const { return findItem(root, QString::fromLatin1(name)); }
    QString textOf(const char *name) const
    {
        QQuickItem *item = child(name);
        return item ? item->property("text").toString() : QString();
    }
    void openPage(const char *page)   // "Island", "Sessions", "Keys" or "About"
    {
        QVERIFY(QMetaObject::invokeMethod(child(QByteArray("settingsTab") + page), "clicked"));
        QVERIFY(child(QByteArray("settingsPage") + page)->isVisible());
    }

private slots:
    void initTestCase() { QCoreApplication::setApplicationVersion(QStringLiteral("9.8")); }
    void init()
    {
        QFile::remove(dir.path() + "/w.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/w.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        theme = std::make_unique<Theme>(state.get());
        theme->setSystemDark(true);
        takenKeys.clear();
        shortcuts = std::make_unique<Shortcuts>(settings.get(), [this](const QString &, int combo) {
            return takenKeys.contains(combo) ? QString() : (combo == (int(Qt::MetaModifier) | int(Qt::Key_F)) ? QStringLiteral("Meta+F") : QStringLiteral("keys"));
        });
        hookState = QStringLiteral("installed");
        hooks = std::make_unique<HooksStatus>([this] { return hookState; });
        sched = std::make_unique<FakeScheduler>();
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [] { return QDateTime::currentMSecsSinceEpoch(); });
        ctl->expandTo("settings");
        view = std::make_unique<QQuickView>();
        view->rootContext()->setContextProperty("theme", theme.get());
        view->rootContext()->setContextProperty("appState", state.get());
        view->rootContext()->setContextProperty("controller", ctl.get());
        view->rootContext()->setContextProperty("shortcuts", shortcuts.get());
        view->rootContext()->setContextProperty("hooks", hooks.get());
        wallet = std::make_unique<FakeSecretStore>();
        http = std::make_unique<FakeHttpClient>();
        settings->setValue("ai/provider", "anthropic");   // the service these tests save a key for
        ask = std::make_unique<Ask>(settings.get(), wallet.get(), http.get());
        view->rootContext()->setContextProperty("ask", ask.get());
        answers = std::make_unique<Answers>(theme.get());
        view->rootContext()->setContextProperty("answers", answers.get());
        view->setResizeMode(QQuickView::SizeRootObjectToView);
        view->resize(524, 280);
        view->setSource(QUrl::fromLocalFile(QStringLiteral(FAROL_QML_DIR "/SettingsView.qml")));
        QVERIFY2(view->status() == QQuickView::Ready, "SettingsView.qml failed to load");
        root = view->rootObject();
        QVERIFY(root);
        view->show();
        QTest::qWait(50);
    }
    void cleanup()
    {
        view.reset();
        answers.reset();
        ask.reset();
        ctl.reset();
        sched.reset();
        hooks.reset();
        shortcuts.reset();
        theme.reset();
        state.reset();
    }

    void itOpensOnTheIslandPageAndSwitchesPages()
    {
        QCOMPARE(child("settingsTabIsland")->property("primary").toBool(), true);
        QVERIFY(child("settingsPageIsland")->isVisible());
        QVERIFY(!child("settingsPageSessions")->isVisible() && !child("settingsPageKeys")->isVisible() && !child("settingsPageAbout")->isVisible());
        openPage("Keys");
        QVERIFY(!child("settingsPageIsland")->isVisible());
        QCOMPARE(child("settingsTabKeys")->property("primary").toBool(), true);
    }

    // Leaving Settings starts it over: the first page on the next visit, and no key press waited for.
    void leavingTheViewStartsItOver()
    {
        openPage("Keys");
        QVERIFY(QMetaObject::invokeMethod(child("shortcutSet_toggle"), "clicked"));
        QCOMPARE(root->property("capturing").toString(), QStringLiteral("toggle"));
        ctl->showView("overview");
        QCOMPARE(root->property("page").toString(), QStringLiteral("island"));
        QCOMPARE(root->property("capturing").toString(), QString());
    }

    void islandPageSetsLookPlaceMotionAndSound()
    {
        QVERIFY(child("themeSystem") && child("themeDark") && child("themeLight"));
        QCOMPARE(child("themeSystem")->property("primary").toBool(), true);                // "Sistema" is the default
        QVERIFY(QMetaObject::invokeMethod(child("themeLight"), "clicked"));
        QCOMPARE(state->themeMode(), QStringLiteral("light"));
        QCOMPARE(child("themeLight")->property("primary").toBool(), true);

        QCOMPARE(child("edgeTop")->property("primary").toBool(), true);                    // default
        QVERIFY(QMetaObject::invokeMethod(child("edgeLeft"), "clicked"));
        QCOMPARE(state->edge(), QStringLiteral("left"));
        QCOMPARE(child("edgeLeft")->property("primary").toBool(), true);
        QCOMPARE(child("edgeTop")->property("primary").toBool(), false);

        QCOMPARE(child("autoClose15")->property("primary").toBool(), true);                // default
        QVERIFY(QMetaObject::invokeMethod(child("autoClose5"), "clicked"));
        QCOMPARE(state->autoCloseInterval(), 5.0);
        QCOMPARE(child("autoClose15")->property("primary").toBool(), false);

        QVERIFY(!child("autoHideSwitch")->property("checked").toBool());                   // the island stays by default
        QVERIFY(QMetaObject::invokeMethod(child("autoHideSwitch"), "toggle"));
        QVERIFY(state->autoHide());
        QVERIFY(QMetaObject::invokeMethod(child("reduceMotionSwitch"), "toggle"));
        QVERIFY(state->reduceMotion());
        QVERIFY(child("reduceMotionSwitch")->property("checked").toBool());

        QCOMPARE(child("soundSwitch")->property("checked").toBool(), state->soundEnabled());
        const bool sound = state->soundEnabled();
        QVERIFY(QMetaObject::invokeMethod(child("soundSwitch"), "toggle"));
        QCOMPARE(state->soundEnabled(), !sound);
    }

    void sessionsPageSetsIdleTimeRemindersNotificationsAndWorkspace()
    {
        openPage("Sessions");
        QCOMPARE(child("sessionIdle30")->property("primary").toBool(), true);              // default
        QVERIFY(QMetaObject::invokeMethod(child("sessionIdle600"), "clicked"));
        QCOMPARE(state->sessionIdleSeconds(), 600);
        QCOMPARE(child("sessionIdle600")->property("primary").toBool(), true);
        QCOMPARE(child("sessionIdle30")->property("primary").toBool(), false);
        QVERIFY(QMetaObject::invokeMethod(child("sessionIdle0"), "clicked"));              // "Nunca"
        QCOMPARE(state->sessionIdleSeconds(), 0);

        QCOMPARE(child("waitReminder120")->property("primary").toBool(), true);            // default
        QVERIFY(QMetaObject::invokeMethod(child("waitReminder0"), "clicked"));             // "Nunca"
        QCOMPARE(state->waitReminderSeconds(), 0);
        QVERIFY(QMetaObject::invokeMethod(child("waitReminder300"), "clicked"));
        QCOMPARE(state->waitReminderSeconds(), 300);

        QVERIFY(child("notifyAwaySwitch")->property("checked").toBool());                  // on by default
        QVERIFY(QMetaObject::invokeMethod(child("notifyAwaySwitch"), "toggle"));
        QVERIFY(!state->notifyAway());

        QCOMPARE(textOf("workspacePath"), QStringLiteral("Nenhuma pasta"));
        QVERIFY(!child("workspaceClear")->isVisible());
        QSignalSpy asked(state.get(), &AppState::workspaceDirRequested);
        QVERIFY(QMetaObject::invokeMethod(child("workspaceChoose"), "clicked"));
        QCOMPARE(asked.count(), 1);                                                        // the app answers with the folder dialog
        state->setWorkspaceDir("/srv/code/workspace");
        QCOMPARE(textOf("workspacePath"), QStringLiteral("/srv/code/workspace"));
        QVERIFY(child("workspaceClear")->isVisible());
        QVERIFY(QMetaObject::invokeMethod(child("workspaceClear"), "clicked"));
        QCOMPARE(state->workspaceDir(), QString());
    }

    // Atalhos: "Definir…" waits for a key press, which becomes the system-wide shortcut.
    void keysPageDefinesAShortcutFromAKeyPress()
    {
        openPage("Keys");
        QCOMPARE(textOf("shortcutKey_toggle"), QStringLiteral("Nenhum"));
        QVERIFY(!child("shortcutClear_toggle")->isVisible());
        QQuickItem *catcher = child("shortcutCatcher");
        const auto press = [&](int key, int modifiers) {
            QVariant handled;
            QMetaObject::invokeMethod(catcher, "press", Q_RETURN_ARG(QVariant, handled), Q_ARG(QVariant, key), Q_ARG(QVariant, modifiers));
            return handled.toBool();
        };
        QVERIFY(!press(Qt::Key_F, int(Qt::MetaModifier)));                                 // nothing is being defined: keys pass

        QSignalSpy keyboard(ctl.get(), &IslandController::keyboardOnDemandChanged);
        QVERIFY(QMetaObject::invokeMethod(child("shortcutSet_toggle"), "clicked"));
        QCOMPARE(textOf("shortcutKey_toggle"), QStringLiteral("Pressione as teclas…"));
        QCOMPARE(keyboard.count(), 1);                                                     // the island asked for the keyboard
        QVERIFY(catcher->property("focus").toBool());                                      // the key press goes to it
        QVERIFY(press(Qt::Key_Meta, int(Qt::MetaModifier)));                               // still pressing: keeps waiting
        QCOMPARE(textOf("shortcutKey_toggle"), QStringLiteral("Pressione as teclas…"));
        QVERIFY(press(Qt::Key_F, int(Qt::NoModifier)));                                    // not a shortcut: says why, keeps waiting
        QVERIFY(child("shortcutError")->isVisible());
        QVERIFY(press(Qt::Key_F, int(Qt::MetaModifier)));
        QCOMPARE(textOf("shortcutKey_toggle"), QStringLiteral("Meta+F"));
        QVERIFY(!child("shortcutError")->isVisible());
        QCOMPARE(shortcuts->combo("toggle"), int(Qt::MetaModifier) | int(Qt::Key_F));
        QVERIFY(child("shortcutClear_toggle")->isVisible());

        QVERIFY(QMetaObject::invokeMethod(child("shortcutSet_jump"), "clicked"));          // Esc gives up
        QVERIFY(press(Qt::Key_Escape, 0));
        QCOMPARE(textOf("shortcutKey_jump"), QStringLiteral("Nenhum"));

        takenKeys << (int(Qt::ControlModifier) | int(Qt::Key_J));                          // another program has it
        QVERIFY(QMetaObject::invokeMethod(child("shortcutSet_jump"), "clicked"));
        QVERIFY(press(Qt::Key_J, int(Qt::ControlModifier)));
        QVERIFY(child("shortcutError")->isVisible());
        QCOMPARE(textOf("shortcutKey_jump"), QStringLiteral("Pressione as teclas…"));      // still waiting for another

        QVERIFY(QMetaObject::invokeMethod(child("shortcutClear_toggle"), "clicked"));
        QCOMPARE(shortcuts->combo("toggle"), 0);
        openPage("Island");                                                                // leaving the page gives up
        QCOMPARE(root->property("capturing").toString(), QString());
    }

    // Every option says what it does under its name, and no option is lost in either island: nothing is cut on the
    // side, and what does not fit in height can be scrolled to.
    void everyOptionExplainsItselfAndStaysReachable()
    {
        const QList<QPair<const char *, QList<const char *>>> pages = {
            {"Island", {"helpTheme", "helpEdge", "helpAutoClose", "helpAutoHide", "helpReduceMotion", "helpSound"}},
            {"Sessions", {"helpSessionIdle", "helpWaitReminder", "helpNotifyAway", "helpWorkspace"}},
            {"Ai", {"helpAiProvider", "helpAiKey", "helpAiModel"}},
            {"Keys", {"helpShortcut_toggle", "helpShortcut_jump"}}};
        state->setWorkspaceDir("/home/someone.with.a.long.name@company.local/Development/workspace");
        for (const QSize size : {QSize(524, 280), QSize(260, 504)}) {
            view->resize(size);
            QTRY_COMPARE_WITH_TIMEOUT(root->width(), qreal(size.width()), 2000);
            QQuickItem *pane = child("settingsPane");
            for (const auto &page : pages) {
                openPage(page.first);
                QTest::qWait(100);                                                         // the rows wrap on the next frame
                QQuickItem *column = child(QByteArray("settingsPage") + page.first);
                QTRY_VERIFY2_WITH_TIMEOUT(pane->property("contentHeight").toReal() >= column->height() - 0.5, page.first, 2000);   // all of it scrolls into view
                for (const char *name : page.second) {
                    QQuickItem *help = child(name);
                    QVERIFY2(help && help->isVisible(), name);
                    QVERIFY2(help->property("text").toString().size() > 20, name);
                    const QRectF r = help->mapRectToItem(root, QRectF(0, 0, help->width(), help->height()));
                    QVERIFY2(r.left() >= 0 && r.right() <= root->width(), name);
                }
                std::function<void(QQuickItem *)> walk = [&](QQuickItem *item) {              // no control cut on the right
                    for (QQuickItem *c : item->childItems()) {
                        if (!c->isVisible())
                            continue;
                        if (c->property("primary").isValid() || c->property("checked").isValid() || c->inherits("QQuickText")) {
                            const QRectF r = c->mapRectToItem(root, QRectF(0, 0, c->width(), c->height()));
                            QVERIFY2(r.right() <= root->width() + 0.5, qPrintable(QString("%1 %2 at %3 of %4").arg(page.first, c->objectName()).arg(r.right()).arg(root->width())));
                        }
                        walk(c);
                    }
                };
                walk(column);
            }
        }
    }

    void aboutPageShowsTheVersionAndTheHooks()
    {
        openPage("About");
        QCOMPARE(textOf("aboutVersion"), QStringLiteral("Versão 9.8"));
        QVERIFY(textOf("aboutHooks").contains("instalados."));
        for (const QString &s : {QStringLiteral("outdated"), QStringLiteral("missing"), QString()}) {   // looked at when the page opens
            hookState = s;
            openPage("Island");
            openPage("About");
            QVERIFY2(textOf("aboutHooks").contains(s == "outdated" ? "precisam de atualização" : "não instalados"), qPrintable(s));
        }
    }

    // Settings -> IA with Claude Code: no key to ask for, only whether it is installed, and its models.
    void aiPageAsksNoKeyForClaudeCode()
    {
        openPage("Ai");
        QVERIFY(child("helpAiKey")->isVisible());
        QVERIFY(!child("helpAiAccount")->isVisible());
        QVERIFY(QMetaObject::invokeMethod(child("aiProvider_claude"), "clicked"));
        QCOMPARE(ask->provider(), QStringLiteral("claude"));
        QVERIFY(child("aiProvider_claude")->property("primary").toBool());
        QVERIFY(!child("helpAiKey")->isVisible());
        QVERIFY(!child("aiKeyField")->isVisible());
        QVERIFY(child("helpAiAccount")->isVisible());
        QCOMPARE(textOf("aiAccountState"), QStringLiteral("Claude Code não encontrado"));   // this test has none
        QVERIFY(child("aiModel_opus")->property("primary").toBool());
        QVERIFY(QMetaObject::invokeMethod(child("aiModel_sonnet"), "clicked"));
        QCOMPARE(ask->modelOf("claude"), QStringLiteral("sonnet"));
        for (const QSize size : {QSize(524, 280), QSize(260, 504)}) {                       // reachable at both sizes
            view->resize(size);
            QTRY_COMPARE_WITH_TIMEOUT(root->width(), qreal(size.width()), 2000);
            QTest::qWait(100);
            QQuickItem *pane = child("settingsPane");
            QTRY_VERIFY_WITH_TIMEOUT(pane->property("contentHeight").toReal() >= child("settingsPageAi")->height() - 0.5, 2000);
            QQuickItem *help = child("helpAiAccount");
            QVERIFY(help->mapToItem(root, QPointF(help->width(), 0)).x() <= root->width() + 0.5);
        }
    }
    // Settings -> IA: the service, its key (to the wallet, never shown again) and its model.
    void aiPageKeepsTheKeyInTheWallet()
    {
        openPage("Ai");
        QCOMPARE(textOf("aiKeyState"), QStringLiteral("Nenhuma"));
        QVERIFY(!child("aiKeyRemove")->isVisible());
        QCOMPARE(child("aiKeyField")->property("echoMode").toInt(), 2);          // TextInput.Password
        QVERIFY(QMetaObject::invokeMethod(child("aiKeySave"), "clicked"));       // nothing typed
        QVERIFY(child("aiKeyError")->isVisible());
        child("aiKeyField")->setProperty("text", "sk-ant-secret");
        QVERIFY(QMetaObject::invokeMethod(child("aiKeySave"), "clicked"));
        QCOMPARE(wallet->values.value("anthropic"), QStringLiteral("sk-ant-secret"));
        QCOMPARE(textOf("aiKeyState"), QStringLiteral("Guardada"));
        QCOMPARE(textOf("aiKeyField"), QString());                               // not left on screen
        QVERIFY(!child("aiKeyError")->isVisible());
        QVERIFY(child("aiKeyRemove")->isVisible());

        QVERIFY(QMetaObject::invokeMethod(child("aiProvider_gemini"), "clicked"));   // each service has its own key and model
        QCOMPARE(ask->provider(), QStringLiteral("gemini"));
        QCOMPARE(textOf("aiKeyState"), QStringLiteral("Nenhuma"));
        QVERIFY(child("aiModel_gemini-pro-latest")->property("primary").toBool());   // the default is the one picked
        QVERIFY(child("aiModel_claude-opus-5-5") == nullptr);                        // only this service's models
        QVERIFY(QMetaObject::invokeMethod(child("aiModel_gemini-flash-latest"), "clicked"));
        QCOMPARE(ask->modelOf("gemini"), QStringLiteral("gemini-flash-latest"));
        QVERIFY(child("aiModel_gemini-flash-latest")->property("primary").toBool());

        QVERIFY(QMetaObject::invokeMethod(child("aiProvider_anthropic"), "clicked"));
        for (const char *name : {"aiModel_claude-sonnet-5-5", "aiModel_claude-fable-5-1", "aiModel_claude-opus-5-5"})
            QVERIFY2(child(name) && child(name)->isVisible(), name);
        QVERIFY(child("aiModel_claude-opus-5-5")->property("primary").toBool());
        QVERIFY(QMetaObject::invokeMethod(child("aiKeyRemove"), "clicked"));
        QVERIFY(!wallet->values.contains("anthropic"));
        QCOMPARE(textOf("aiKeyState"), QStringLiteral("Nenhuma"));
    }
};

QTEST_MAIN(TestSettingsView)
#include "tst_settings_view.moc"
