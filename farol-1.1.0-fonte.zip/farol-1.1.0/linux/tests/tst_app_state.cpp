#include <QtTest>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "AppState.h"
#include "Paths.h"

using namespace farol;

class TestAppState : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    QString iniPath() const { return dir.path() + "/farol.ini"; }
    std::unique_ptr<QSettings> settings() const { return std::make_unique<QSettings>(iniPath(), QSettings::IniFormat); }
    // The four pills the Swift app activates by default, for the tests about pills and focus.
    std::unique_ptr<QSettings> withFourIntegrations() const
    {
        auto s = settings();
        s->setValue("activeIntegrations", "integration_resend;integration_n8n;integration_vercel;integration_github");
        s->sync();
        return s;
    }

private slots:
    void init() { QFile::remove(iniPath()); }

    // Deliberate divergence from the Swift app (which pre-activates Resend, n8n, Vercel and GitHub): an
    // integration pill only appears once the user adds it.
    void startsCompactWithOnlyTheClaudePill()
    {
        auto s = settings();
        AppState st(s.get());
        QVERIFY(st.mode() == IslandMode::Compact);   // tasks non-empty + present -> syncMode() at init
        QVERIFY(st.view() == IslandView::Overview);
        QCOMPARE(st.focusId(), QStringLiteral("integration_claude"));
        QCOMPARE(st.tasksModel()->rowCount(), 1);    // claude only
        QVERIFY(st.activeIntegrations().isEmpty());
        QVERIFY(st.compactOthers().isEmpty());
        QCOMPARE(st.notchWidth(), 184.0);
        QCOMPARE(st.notchHeight(), 32.0);
        QCOMPARE(st.autoCloseInterval(), 15.0);
        QCOMPARE(st.soundVolume(), 0.12);
        QVERIFY(st.soundEnabled());
        QVERIFY(!st.isPinned());
    }

    void integrationPillsHaveSwiftNamesAndColors()
    {
        const auto pills = integrationAgents();
        QCOMPARE(pills.size(), 8);
        QCOMPARE(pills[0].id, QStringLiteral("integration_claude"));
        QCOMPARE(pills[0].name, QStringLiteral("VS Code"));
        QCOMPARE(pills[0].color, QStringLiteral("#F5F6F8"));
        QVERIFY(pills[0].source == AgentSource::ClaudeCode);
        QCOMPARE(pills[7].id, QStringLiteral("integration_stripe"));
        QCOMPARE(pills[7].color, QStringLiteral("#0570DE"));
        QCOMPARE(toggleableIntegrationIds().size(), 7);
        QVERIFY(!toggleableIntegrationIds().contains("integration_claude"));
    }

    void toggleIntegrationRespectsMaxFourAndClaudeIsFixed()
    {
        auto s = withFourIntegrations();
        AppState st(s.get());
        st.toggleIntegration("integration_claude");            // cannot be toggled
        QCOMPARE(st.tasksModel()->rowCount(), 5);
        st.toggleIntegration("integration_notion");            // 4 already active -> refused
        QCOMPARE(st.tasksModel()->rowCount(), 5);
        st.setFocus("integration_github");
        st.toggleIntegration("integration_github");            // turn one off
        QCOMPARE(st.tasksModel()->rowCount(), 4);
        QCOMPARE(st.focusId(), QStringLiteral("integration_claude"));   // focus falls back to Claude
        st.toggleIntegration("integration_notion");            // now there is room
        QCOMPARE(st.tasksModel()->rowCount(), 5);
        QVERIFY(st.activeIntegrations().contains("integration_notion"));
        st.toggleIntegration("integration_bogus");             // unknown id ignored
        QCOMPARE(st.tasksModel()->rowCount(), 5);
    }

    void settingsPersistAcrossInstances()
    {
        {
            auto s = withFourIntegrations();
            AppState st(s.get());
            st.setSoundEnabled(false);
            st.setSoundVolume(0.05);
            st.setAutoCloseInterval(30);
            st.toggleIntegration("integration_github");
            st.toggleIntegration("integration_stripe");
        }
        auto s = settings();
        AppState st(s.get());
        QVERIFY(!st.soundEnabled());
        QCOMPARE(st.soundVolume(), 0.05);
        QCOMPARE(st.autoCloseInterval(), 30.0);
        QVERIFY(!st.activeIntegrations().contains("integration_github"));
        QVERIFY(st.activeIntegrations().contains("integration_stripe"));
    }

    void corruptOrOutOfRangeSettingsAreSanitised()
    {
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("soundVolume", 5.0);
            raw.setValue("autoCloseInterval", -3.0);
            raw.setValue("activeIntegrations", "garbage");
            raw.sync();
        }
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.soundVolume(), 0.2);                       // clamped
            QCOMPARE(st.autoCloseInterval(), 15.0);                // invalid -> default
            QCOMPARE(st.tasksModel()->rowCount(), 1);              // no valid id -> defaults (none)
        }
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("soundVolume", -1.0);
            raw.setValue("autoCloseInterval", 60.0);               // old Swift default migrates to 15
            raw.setValue("activeIntegrations", "integration_notion;integration_bogus;integration_notion");
            raw.sync();
        }
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.soundVolume(), 0.0);
            QCOMPARE(st.autoCloseInterval(), 15.0);
            QCOMPARE(st.activeIntegrations(), QStringList{"integration_notion"});   // unknown dropped, duplicate dropped
            QCOMPARE(st.tasksModel()->rowCount(), 2);              // claude + notion
        }
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("activeIntegrations", QString());         // user turned every pill off
            raw.sync();
        }
        {
            auto s = settings();
            AppState st(s.get());
            QVERIFY(st.activeIntegrations().isEmpty());
            QCOMPARE(st.tasksModel()->rowCount(), 1);              // only Claude
        }
    }

    void nonFiniteSettingsFallBackToDefaults()
    {
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("soundVolume", "nan");
            raw.setValue("autoCloseInterval", "inf");
            raw.sync();
        }
        auto s = settings();
        AppState st(s.get());
        QCOMPARE(st.soundVolume(), 0.12);
        QCOMPARE(st.autoCloseInterval(), 15.0);
        st.setSoundVolume(qQNaN());
        QCOMPARE(st.soundVolume(), 0.12);
        st.setAutoCloseInterval(qInf());
        QCOMPARE(st.autoCloseInterval(), 15.0);
    }

    void syncModeFollowsTasks()
    {
        auto s = settings();
        AppState st(s.get());
        for (const auto &t : integrationAgents())
            st.removeTask(t.id);
        QCOMPARE(st.tasksModel()->rowCount(), 0);
        QVERIFY(st.mode() == IslandMode::Hidden);                  // compact + no tasks -> hidden
        AgentTask t = integrationAgents().first();
        st.addTask(t);
        QVERIFY(st.mode() == IslandMode::Compact);                 // hidden + task + present -> compact
        QCOMPARE(st.focusId(), t.id);
    }

    void syncViewFollowsTasks()
    {
        auto s = settings();
        AppState st(s.get());
        st.setMode(IslandMode::Expanded);
        st.setView(IslandView::Overview);
        for (const auto &t : integrationAgents())
            st.removeTask(t.id);
        QVERIFY(st.view() == IslandView::Empty);                   // overview + no tasks -> empty
        QVERIFY(st.mode() == IslandMode::Expanded);                // and the island stays open
        st.addTask(integrationAgents().first());
        QVERIFY(st.view() == IslandView::Overview);
    }

    void effectiveStatePrecedence()
    {
        auto s = settings();
        AppState st(s.get());
        QVERIFY(st.effectiveState() == BotState::Idle);
        st.updateTask("integration_claude", BotState::Working);
        QVERIFY(st.effectiveState() == BotState::Working);
        st.setStateOverride(BotState::Dizzy);
        QVERIFY(st.effectiveState() == BotState::Dizzy);
        QCOMPARE(st.effectiveStateName(), QStringLiteral("dizzy"));
        st.setStateOverride(std::nullopt);
        QVERIFY(st.effectiveState() == BotState::Working);
    }

    void compactOthersExcludesFocusAndCapsAtFour()
    {
        auto s = withFourIntegrations();
        AppState st(s.get());
        QCOMPARE(st.compactOthers().size(), 4);
        QCOMPARE(st.compactOthers().first().toMap().value("id").toString(), QStringLiteral("integration_resend"));
        st.setFocus("integration_resend");
        const auto others = st.compactOthers();
        QCOMPARE(others.size(), 4);
        QCOMPARE(others.first().toMap().value("id").toString(), QStringLiteral("integration_claude"));
    }

    void modeAndViewSetters()
    {
        auto s = settings();
        AppState st(s.get());
        QSignalSpy modeSpy(&st, &AppState::modeChanged);
        QSignalSpy viewSpy(&st, &AppState::viewChanged);
        st.setMode(IslandMode::Compact);                            // already compact: no signal
        QCOMPARE(modeSpy.count(), 0);
        st.setMode(IslandMode::Expanded);
        QCOMPARE(modeSpy.count(), 1);
        QCOMPARE(st.modeName(), QStringLiteral("expanded"));
        st.setViewName("approval");
        QCOMPARE(viewSpy.count(), 1);
        QVERIFY(st.view() == IslandView::Approval);
        st.setViewName("nonsense");                                 // ignored
        QVERIFY(st.view() == IslandView::Approval);
        QCOMPARE(viewSpy.count(), 1);
    }

    void effectiveStateFollowsFocus()
    {
        auto s = withFourIntegrations();
        AppState st(s.get());
        st.updateTask("integration_github", BotState::Error);
        QVERIFY(st.effectiveState() == BotState::Idle);            // focus is still Claude
        st.setFocus("integration_github");
        QVERIFY(st.effectiveState() == BotState::Error);
    }

    void modifyTaskMutatesAndNotifies()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        QSignalSpy focus(&st, &AppState::focusTaskChanged);
        QSignalSpy effective(&st, &AppState::effectiveStateChanged);
        st.modifyTask("integration_claude", [](AgentTask &t) {
            t.steps << Step{"Reads · a.txt"} << Step{"Runs · ls"};
            t.stepIndex = 1;
            t.alertText = "hello";
            t.finalMessage = "All done.\n• tests pass";
            t.options = {"A", "B"};
        });
        QCOMPARE(focus.count(), 1);
        QCOMPARE(effective.count(), 1);
        const QVariantMap f = st.focusTask();
        QCOMPARE(f.value("id").toString(), QStringLiteral("integration_claude"));
        QCOMPARE(f.value("alertText").toString(), QStringLiteral("hello"));
        QCOMPARE(f.value("finalMessage").toString(), QStringLiteral("All done.\n• tests pass"));
        QCOMPARE(f.value("steps").toStringList(), (QStringList{"Reads · a.txt", "Runs · ls"}));
        QCOMPARE(f.value("stepIndex").toInt(), 1);
        QCOMPARE(f.value("options").toStringList(), (QStringList{"A", "B"}));
        QVERIFY(f.value("isIntegration").toBool());
        QCOMPARE(f.value("state").toString(), QStringLiteral("idle"));
    }

    // The card's rows: "steps" stays the list of labels, and "stepList" has beside each label what the step of an
    // edit knows (its file, its counts, the diff to open).
    void theFocusTaskListsItsStepsWithWhatAnEditChanged()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        QCOMPARE(st.focusTask().value("steps").toStringList(), QStringList());
        QVERIFY(st.focusTask().contains("stepList"));
        QCOMPARE(st.focusTask().value("stepList").toList().size(), 0);

        st.modifyTask("integration_claude", [](AgentTask &t) {
            t.steps << Step{"Runs · make"} << Step{"Edits · a.txt", "toolu_1", "/w/a.txt", 12, 3, 42}
                    << Step{"Writes · b.txt", "toolu_2", "/w/b.txt", 0, 0, 0};
            t.stepIndex = 2;
        });
        const QVariantMap f = st.focusTask();
        QCOMPARE(f.value("steps").toStringList(), (QStringList{"Runs · make", "Edits · a.txt", "Writes · b.txt"}));
        QCOMPARE(f.value("stepIndex").toInt(), 2);
        const QVariantList list = f.value("stepList").toList();
        QCOMPARE(list.size(), 3);
        const auto row = [&](int i) {
            const QVariantMap m = list.at(i).toMap();
            return QStringLiteral("%1|%2|%3|%4|%5").arg(m.value("label").toString(), m.value("file").toString())
                .arg(m.value("added").toInt()).arg(m.value("removed").toInt()).arg(m.value("diff").toLongLong());
        };
        QCOMPARE(row(0), QStringLiteral("Runs · make||-1|-1|0"));
        QCOMPARE(row(1), QStringLiteral("Edits · a.txt|/w/a.txt|12|3|42"));
        QCOMPARE(row(2), QStringLiteral("Writes · b.txt|/w/b.txt|0|0|0"));
        QCOMPARE(list.at(1).toMap().size(), 5);                     // the id of the tool call is not for the screen
        QCOMPARE(st.taskModel()->data(st.taskModel()->index(0), TaskModel::StepRole).toString(), QStringLiteral("Writes · b.txt"));
    }

    void modifyTaskOnUnknownIdIsANoOp()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        QSignalSpy focus(&st, &AppState::focusTaskChanged);
        st.modifyTask("nope", [](AgentTask &t) { t.alertText = "x"; });
        QCOMPARE(focus.count(), 0);
    }

    void focusTaskFollowsFocusAndStateUpdates()
    {
        auto seeded = withFourIntegrations();
        QSettings &settings = *seeded;
        AppState st(&settings);
        QSignalSpy focus(&st, &AppState::focusTaskChanged);
        st.setFocus("integration_n8n");
        QCOMPARE(st.focusTask().value("name").toString(), QStringLiteral("n8n"));
        QVERIFY(focus.count() >= 1);
        focus.clear();
        st.updateTask("integration_n8n", BotState::Working);
        QCOMPARE(focus.count(), 1);
        QCOMPARE(st.focusTask().value("state").toString(), QStringLiteral("working"));
    }

    void themeModeDefaultsToSystemAndPersists()
    {
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.themeMode(), QStringLiteral("system"));
            QVERIFY(!st.reduceMotion());
            QSignalSpy spy(&st, &AppState::themeModeChanged);
            st.setThemeMode("light");
            st.setThemeMode("light");                       // no change, no signal
            QCOMPARE(spy.count(), 1);
            st.setReduceMotion(true);
        }
        auto s = settings();
        AppState st(s.get());
        QCOMPARE(st.themeMode(), QStringLiteral("light"));
        QVERIFY(st.reduceMotion());
    }

    // Settings -> "Ocultar inativas": seconds a session at rest stays in the island; 0 keeps it.
    void sessionIdleSecondsDefaultsToThirtyPersistsAndRejectsOddValues()
    {
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.sessionIdleSeconds(), 30);
            QSignalSpy spy(&st, &AppState::sessionIdleSecondsChanged);
            st.setSessionIdleSeconds(120);
            st.setSessionIdleSeconds(120);                   // no change, no signal
            st.setSessionIdleSeconds(-5);                    // rejected
            st.setSessionIdleSeconds(3);                     // shorter than 10 s: rejected
            st.setSessionIdleSeconds(24 * 60 * 60 + 1);      // longer than a day: rejected
            QCOMPARE(spy.count(), 1);
            QCOMPARE(st.sessionIdleSeconds(), 120);
        }
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.sessionIdleSeconds(), 120);
            st.setSessionIdleSeconds(0);                     // never
        }
        {
            auto s = settings();
            QCOMPARE(AppState(s.get()).sessionIdleSeconds(), 0);
            s->setValue("sessionIdleSeconds", "soon");       // edited by hand into nonsense: the default
        }
        auto s = settings();
        QCOMPARE(AppState(s.get()).sessionIdleSeconds(), 30);
    }

    // Nothing says how big a model's context window is: 200k until a session shows more, then 1M, remembered.
    void contextWindowIsLearntPerModel()
    {
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.contextWindowFor("claude-x", 150000), 200000);
            QCOMPARE(st.contextWindowFor("claude-x", 200000), 200000);
            QCOMPARE(st.contextWindowFor("claude-big", 355000), 1000000);     // seen above 200k
            QCOMPARE(st.contextWindowFor("claude-big", 30000), 1000000);      // so it is a 1M model from now on
            QCOMPARE(st.contextWindowFor("claude-x", 30000), 200000);
            QCOMPARE(st.contextWindowFor("", 300000), 1000000);               // unnamed: right now, not remembered
            QCOMPARE(st.contextWindowFor("", 3000), 200000);
        }
        auto s = settings();
        AppState st(s.get());
        QCOMPARE(st.contextWindowFor("claude-big", 30000), 1000000);          // across restarts
    }

    // Settings -> "Lembrar espera": seconds between the calls of a session that waits for an answer; 0 never.
    void waitReminderDefaultsToTwoMinutesPersistsAndRejectsOddValues()
    {
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.waitReminderSeconds(), 120);
            QSignalSpy spy(&st, &AppState::waitReminderSecondsChanged);
            st.setWaitReminderSeconds(300);
            st.setWaitReminderSeconds(300);                  // no change, no signal
            st.setWaitReminderSeconds(5);                    // shorter than 30 s: rejected
            st.setWaitReminderSeconds(-1);
            st.setWaitReminderSeconds(60 * 60 + 1);          // longer than an hour: rejected
            QCOMPARE(spy.count(), 1);
        }
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.waitReminderSeconds(), 300);
            st.setWaitReminderSeconds(0);                    // never
        }
        {
            auto s = settings();
            QCOMPARE(AppState(s.get()).waitReminderSeconds(), 0);
            s->setValue("waitReminderSeconds", 7);           // edited by hand into nonsense: the default
        }
        auto s = settings();
        QCOMPARE(AppState(s.get()).waitReminderSeconds(), 120);
    }

    // Settings -> "Notificar ausente": on by default.
    void notifyAwayIsOnByDefaultAndPersists()
    {
        {
            auto s = settings();
            AppState st(s.get());
            QVERIFY(st.notifyAway());
            QSignalSpy spy(&st, &AppState::notifyAwayChanged);
            st.setNotifyAway(false);
            st.setNotifyAway(false);                         // no change, no signal
            QCOMPARE(spy.count(), 1);
        }
        auto s = settings();
        QVERIFY(!AppState(s.get()).notifyAway());
    }

    // Settings -> "Esconder sem uso": off by default, the compact island stays on screen.
    void autoHideIsOffByDefaultAndPersists()
    {
        {
            auto s = settings();
            AppState st(s.get());
            QVERIFY(!st.autoHide());
            QSignalSpy spy(&st, &AppState::autoHideChanged);
            st.setAutoHide(true);
            st.setAutoHide(true);                            // no change, no signal
            QCOMPARE(spy.count(), 1);
        }
        auto s = settings();
        QVERIFY(AppState(s.get()).autoHide());
    }

    // Settings -> Workspace: the folder where the developer keeps the repositories. Any absolute path, or none.
    void workspaceDirIsEmptyByDefaultPersistsAndRejectsRelativePaths()
    {
        const QString home = Paths::home();   // Windows has no HOME of its own
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.workspaceDir(), QString());
            QCOMPARE(st.workspaceDirLabel(), QString());
            QSignalSpy spy(&st, &AppState::workspaceDirChanged);
            st.setWorkspaceDir(home + "/dev/");              // stored clean: no trailing slash
            st.setWorkspaceDir(home + "/dev");               // no change, no signal
            st.setWorkspaceDir("dev/repos");                 // relative: rejected
            QCOMPARE(spy.count(), 1);
            QCOMPARE(st.workspaceDir(), home + "/dev");
            QCOMPARE(st.workspaceDirLabel(), QStringLiteral("~/dev"));
        }
        auto s = settings();
        AppState st(s.get());
        QCOMPARE(st.workspaceDir(), home + "/dev");
        st.setWorkspaceDir("/srv/code");                     // outside the home folder: shown as it is
        QCOMPARE(st.workspaceDirLabel(), QStringLiteral("/srv/code"));
        st.setWorkspaceDir(QString());                       // cleared
        QCOMPARE(AppState(s.get()).workspaceDir(), QString());
        s->setValue("workspaceDir", "not/absolute");
        QCOMPARE(AppState(s.get()).workspaceDir(), QString());
    }

    void choosingTheWorkspaceDirOnlyAsksForTheFolderDialog()
    {
        auto s = settings();
        AppState st(s.get());
        QSignalSpy asked(&st, &AppState::workspaceDirRequested);
        st.chooseWorkspaceDir();
        QCOMPARE(asked.count(), 1);
        QCOMPARE(st.workspaceDir(), QString());
    }

    void edgeDefaultsToTopPersistsAndRejectsUnknownValues()
    {
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.edge(), QStringLiteral("top"));
            QSignalSpy spy(&st, &AppState::edgeChanged);
            st.setEdge("left");
            st.setEdge("left");                              // no change, no signal
            st.setEdge("diagonal");                          // rejected
            QCOMPARE(spy.count(), 1);
            QCOMPARE(st.edge(), QStringLiteral("left"));
        }
        {
            auto s = settings();
            AppState st(s.get());
            QCOMPARE(st.edge(), QStringLiteral("left"));
        }
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("edge", "middle");
            raw.sync();
        }
        auto s = settings();
        AppState st(s.get());
        QCOMPARE(st.edge(), QStringLiteral("top"));          // corrupt value -> default
    }

    // Docked to a side edge the island is a portrait column; QML re-reads `vertical` on edgeChanged.
    void verticalIsTrueOnlyOnTheSideEdges()
    {
        auto s = settings();
        AppState st(s.get());
        QSignalSpy spy(&st, &AppState::edgeChanged);
        QVERIFY(!st.vertical());                             // top
        st.setEdge("left");
        QVERIFY(st.vertical());
        st.setEdge("right");
        QVERIFY(st.vertical());
        st.setEdge("bottom");
        QVERIFY(!st.vertical());
        QCOMPARE(spy.count(), 3);
    }

    void unknownThemeModeFallsBackToSystem()
    {
        {
            QSettings raw(iniPath(), QSettings::IniFormat);
            raw.setValue("themeMode", "neon");
            raw.sync();
        }
        auto s = settings();
        AppState st(s.get());
        QCOMPARE(st.themeMode(), QStringLiteral("system"));
        st.setThemeMode("neon");                            // rejected as well
        QCOMPARE(st.themeMode(), QStringLiteral("system"));
    }

    void focusTaskIsEmptyWithoutTasks()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        const auto ids = [&] { QStringList out; for (const auto &t : st.taskModel()->all()) out << t.id; return out; }();
        for (const QString &id : ids)
            st.removeTask(id);
        QVERIFY(st.focusTask().isEmpty());
    }

    void stepRoleIsTheCurrentStep()
    {
        auto seeded = withFourIntegrations();
        QSettings &settings = *seeded;
        AppState st(&settings);
        st.modifyTask("integration_claude", [](AgentTask &t) { t.steps << Step{"one"} << Step{"two"}; t.stepIndex = 1; });
        const int row = st.taskModel()->indexOf("integration_claude");
        QCOMPARE(st.taskModel()->data(st.taskModel()->index(row), TaskModel::StepRole).toString(), QStringLiteral("two"));
        const int other = st.taskModel()->indexOf("integration_n8n");
        QCOMPARE(st.taskModel()->data(st.taskModel()->index(other), TaskModel::StepRole).toString(), QString());
    }
    // The company's skills folder: empty by default, an absolute path or nothing, remembered.
    void skillsDirIsAnAbsoluteFolderRememberedAcrossRuns()
    {
        QTemporaryDir tmp;
        QSettings settings(tmp.path() + "/s.ini", QSettings::IniFormat);
        {
            AppState state(&settings);
            QCOMPARE(state.skillsDir(), QString());
            QSignalSpy changed(&state, &AppState::skillsDirChanged);
            state.setSkillsDir("relative/skills");                // not a place: refused
            QCOMPARE(state.skillsDir(), QString());
            state.setSkillsDir("/srv/code//skills/");
            QCOMPARE(state.skillsDir(), QStringLiteral("/srv/code/skills"));
            state.setSkillsDir("/srv/code/skills");               // the same: no second signal
            QCOMPARE(changed.count(), 1);
            QSignalSpy asked(&state, &AppState::skillsDirRequested);
            state.chooseSkillsDir();
            QCOMPARE(asked.count(), 1);
        }
        AppState again(&settings);
        QCOMPARE(again.skillsDir(), QStringLiteral("/srv/code/skills"));
        QCOMPARE(again.skillsDirLabel(), QStringLiteral("/srv/code/skills"));
        again.setSkillsDir(QString());
        QCOMPARE(AppState(&settings).skillsDir(), QString());
    }

};

QTEST_APPLESS_MAIN(TestAppState)
#include "tst_app_state.moc"
