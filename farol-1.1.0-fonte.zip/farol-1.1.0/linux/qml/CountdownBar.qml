import QtQuick

// The 2 pt line at the bottom centre that shows the last seconds before auto-close (CountdownBar in Swift).
Item {
    id: bar
    anchors.fill: parent
    property real barWidth: 0

    Rectangle {
        width: bar.barWidth
        height: 2
        radius: 2
        color: theme.countdown
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
    }

    // Only ticks while the island is open, so a hidden island costs nothing.
    Timer {
        interval: 100
        repeat: true
        running: appState.modeName === "expanded"
        onTriggered: {
            if (appState.isPinned) { bar.barWidth = 0; return }
            const autoClose = appState.autoCloseInterval
            const window = Math.min(10.0, autoClose * 0.6)
            const remaining = autoClose - (Date.now() - appState.lastActivityMs) / 1000
            bar.barWidth = remaining < window ? Math.max(0, remaining / window) * 160 : 0
        }
    }
    // Leaving the expanded mode stops the Timer; clear the line so it cannot stay on the compact pill.
    onVisibleChanged: if (!visible) barWidth = 0
    Connections {
        target: appState
        function onModeChanged() { if (appState.modeName !== "expanded") bar.barWidth = 0 }
    }
}
