#include "BridgeReceiver.h"
#include <cstdio>

void BridgeReceiver::cursor(int x, int y)
{
    ++cursorCalls;
    if (cursorCalls % 30 == 1) { std::printf("cursor %d,%d\n", x, y); std::fflush(stdout); }
}

void BridgeReceiver::window(const QString &caption, const QString &resourceClass, int x, int y, int w, int h)
{
    std::printf("window class=%s caption=\"%s\" geom=%d,%d %dx%d\n", qPrintable(resourceClass),
                qPrintable(caption), x, y, w, h);
    std::fflush(stdout);
}
