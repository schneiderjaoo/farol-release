#include "X11.h"

#include <QGuiApplication>

#if FAROL_X11
#include <QHash>
#include <QKeyCombination>
#include <cstdlib>
#include <memory>
#include <xcb/screensaver.h>
#include <xcb/shape.h>
#include <xcb/xcb.h>
#endif

namespace farol {

bool desktopIsKde()
{
#if FAROL_KDE
    return QGuiApplication::platformName().startsWith(QLatin1String("wayland"))
        || qEnvironmentVariable("XDG_CURRENT_DESKTOP").contains(QLatin1String("KDE"), Qt::CaseInsensitive);
#else
    return false;
#endif
}

namespace x11 {

#if FAROL_X11
namespace {

template <typename T>
using Reply = std::unique_ptr<T, decltype(&std::free)>;
template <typename T>
Reply<T> reply(T *r) { return Reply<T>(r, &std::free); }

xcb_connection_t *connection()
{
    auto *x = qGuiApp ? qGuiApp->nativeInterface<QNativeInterface::QX11Application>() : nullptr;
    return x ? x->connection() : nullptr;
}

xcb_window_t root(xcb_connection_t *c)
{
    return xcb_setup_roots_iterator(xcb_get_setup(c)).data->root;
}

xcb_atom_t atom(xcb_connection_t *c, const char *name)
{
    static QHash<QByteArray, xcb_atom_t> known;
    const auto it = known.constFind(name);
    if (it != known.constEnd())
        return *it;
    const auto r = reply(xcb_intern_atom_reply(c, xcb_intern_atom(c, 0, quint16(qstrlen(name)), name), nullptr));
    return known[name] = r ? r->atom : XCB_ATOM_NONE;
}

QByteArray property(xcb_connection_t *c, xcb_window_t window, xcb_atom_t name)
{
    if (name == XCB_ATOM_NONE)
        return {};
    // 16 384 bytes: more windows, or a longer title, than anybody has
    const auto r = reply(xcb_get_property_reply(c, xcb_get_property(c, 0, window, name, XCB_GET_PROPERTY_TYPE_ANY, 0, 4096), nullptr));
    if (!r)
        return {};
    return QByteArray(static_cast<const char *>(xcb_get_property_value(r.get())), xcb_get_property_value_length(r.get()));
}

QList<quint32> numbers(const QByteArray &data)
{
    QList<quint32> out;
    for (qsizetype i = 0; i + 4 <= data.size(); i += 4) {
        quint32 n;
        memcpy(&n, data.constData() + i, 4);
        out << n;
    }
    return out;
}

// The keysym of a Qt key, 0 for a key Farol does not take as a shortcut.
quint32 keysym(Qt::Key key)
{
    if (key >= Qt::Key_A && key <= Qt::Key_Z)
        return quint32(key) + 0x20;                      // the unshifted letter
    if (key >= Qt::Key_Space && key <= Qt::Key_AsciiTilde)
        return quint32(key);
    if (key >= Qt::Key_F1 && key <= Qt::Key_F35)
        return 0xffbe + quint32(key - Qt::Key_F1);
    switch (key) {
    case Qt::Key_Escape: return 0xff1b;
    case Qt::Key_Tab: return 0xff09;
    case Qt::Key_Backspace: return 0xff08;
    case Qt::Key_Return: return 0xff0d;
    case Qt::Key_Enter: return 0xff8d;
    case Qt::Key_Insert: return 0xff63;
    case Qt::Key_Delete: return 0xffff;
    case Qt::Key_Pause: return 0xff13;
    case Qt::Key_Print: return 0xff61;
    case Qt::Key_Home: return 0xff50;
    case Qt::Key_End: return 0xff57;
    case Qt::Key_Left: return 0xff51;
    case Qt::Key_Up: return 0xff52;
    case Qt::Key_Right: return 0xff53;
    case Qt::Key_Down: return 0xff54;
    case Qt::Key_PageUp: return 0xff55;
    case Qt::Key_PageDown: return 0xff56;
    default: return 0;
    }
}

// The key of this keyboard that writes the keysym without a modifier (or with Shift), 0 when it has none.
xcb_keycode_t keycode(xcb_connection_t *c, quint32 sym)
{
    const xcb_setup_t *setup = xcb_get_setup(c);
    const int first = setup->min_keycode, count = setup->max_keycode - setup->min_keycode + 1;
    const auto r = reply(xcb_get_keyboard_mapping_reply(c, xcb_get_keyboard_mapping(c, xcb_keycode_t(first), quint8(count)), nullptr));
    if (!r || r->keysyms_per_keycode == 0)
        return 0;
    const xcb_keysym_t *syms = xcb_get_keyboard_mapping_keysyms(r.get());
    const int per = r->keysyms_per_keycode;
    for (int column = 0; column < qMin(per, 2); ++column)
        for (int i = 0; i < count; ++i)
            if (syms[i * per + column] == sym)
                return xcb_keycode_t(first + i);
    return 0;
}

constexpr quint16 kModifiers = XCB_MOD_MASK_SHIFT | XCB_MOD_MASK_CONTROL | XCB_MOD_MASK_1 | XCB_MOD_MASK_4;
// Caps Lock and Num Lock are modifiers to the server: a grab is for one exact set, so each key is grabbed four times.
constexpr quint16 kLocks[] = {0, XCB_MOD_MASK_LOCK, XCB_MOD_MASK_2, XCB_MOD_MASK_LOCK | XCB_MOD_MASK_2};

} // namespace

bool available() { return connection() != nullptr; }

QList<DesktopWindow> windows()
{
    QList<DesktopWindow> out;
    xcb_connection_t *c = connection();
    if (!c)
        return out;
    for (quint32 id : numbers(property(c, root(c), atom(c, "_NET_CLIENT_LIST")))) {
        DesktopWindow w;
        w.id = id;
        // WM_CLASS is "instance\0class\0": the class is the name the other desktops go by
        const QList<QByteArray> names = property(c, id, XCB_ATOM_WM_CLASS).split('\0');
        w.windowClass = QString::fromUtf8(names.size() > 1 && !names[1].isEmpty() ? names[1] : names.value(0));
        QByteArray title = property(c, id, atom(c, "_NET_WM_NAME"));
        w.title = title.isEmpty() ? QString::fromLatin1(property(c, id, XCB_ATOM_WM_NAME)) : QString::fromUtf8(title);
        w.pid = numbers(property(c, id, atom(c, "_NET_WM_PID"))).value(0);
        out << w;
    }
    return out;
}

quint64 activeWindow()
{
    xcb_connection_t *c = connection();
    return c ? numbers(property(c, root(c), atom(c, "_NET_ACTIVE_WINDOW"))).value(0) : 0;
}

void activate(quint64 window)
{
    xcb_connection_t *c = connection();
    if (!c || !window)
        return;
    xcb_client_message_event_t e{};
    e.response_type = XCB_CLIENT_MESSAGE;
    e.format = 32;
    e.window = xcb_window_t(window);
    e.type = atom(c, "_NET_ACTIVE_WINDOW");
    e.data.data32[0] = 2;   // asked for by the user, as a pager would: the window manager does it without second thoughts
    e.data.data32[1] = XCB_CURRENT_TIME;
    xcb_send_event(c, 0, root(c), XCB_EVENT_MASK_SUBSTRUCTURE_NOTIFY | XCB_EVENT_MASK_SUBSTRUCTURE_REDIRECT, reinterpret_cast<const char *>(&e));
    xcb_flush(c);
}

void showOnEveryWorkspace(quint64 window)
{
    xcb_connection_t *c = connection();
    if (!c || !window)
        return;
    const quint32 all = 0xffffffff;
    xcb_change_property(c, XCB_PROP_MODE_REPLACE, xcb_window_t(window), atom(c, "_NET_WM_DESKTOP"), XCB_ATOM_CARDINAL, 32, 1, &all);
    xcb_flush(c);
}

void setInputRegion(quint64 window, const QRect &rect)
{
    xcb_connection_t *c = connection();
    if (!c || !window || !xcb_get_extension_data(c, &xcb_shape_id)->present)
        return;
    const xcb_rectangle_t r{qint16(rect.x()), qint16(rect.y()), quint16(qMax(0, rect.width())), quint16(qMax(0, rect.height()))};
    xcb_shape_rectangles(c, XCB_SHAPE_SO_SET, XCB_SHAPE_SK_INPUT, XCB_CLIP_ORDERING_UNSORTED, xcb_window_t(window), 0, 0, 1, &r);
    xcb_flush(c);
}

bool composited()
{
    xcb_connection_t *c = connection();
    if (!c)
        return false;
    const auto owner = reply(xcb_get_selection_owner_reply(c, xcb_get_selection_owner(c, atom(c, "_NET_WM_CM_S0")), nullptr));
    return owner && owner->owner != XCB_WINDOW_NONE;
}

int idleMs()
{
    xcb_connection_t *c = connection();
    if (!c || !xcb_get_extension_data(c, &xcb_screensaver_id)->present)
        return -1;
    const auto r = reply(xcb_screensaver_query_info_reply(c, xcb_screensaver_query_info(c, root(c)), nullptr));
    return r ? int(qMin<quint32>(r->ms_since_user_input, INT_MAX)) : -1;
}

Key grabKey(int combo)
{
    xcb_connection_t *c = connection();
    if (!c)
        return {};
    const QKeyCombination keys = QKeyCombination::fromCombined(combo);
    Key key;
    key.code = keycode(c, keysym(keys.key()));
    if (!key.code)
        return {};
    const Qt::KeyboardModifiers held = keys.keyboardModifiers();
    key.modifiers = quint16((held & Qt::ShiftModifier ? XCB_MOD_MASK_SHIFT : 0) | (held & Qt::ControlModifier ? XCB_MOD_MASK_CONTROL : 0)
                            | (held & Qt::AltModifier ? XCB_MOD_MASK_1 : 0) | (held & Qt::MetaModifier ? XCB_MOD_MASK_4 : 0));
    for (quint16 lock : kLocks) {
        const xcb_void_cookie_t grab = xcb_grab_key_checked(c, 1, root(c), key.modifiers | lock, key.code, XCB_GRAB_MODE_ASYNC, XCB_GRAB_MODE_ASYNC);
        if (const auto error = reply(xcb_request_check(c, grab))) {   // another program has it
            ungrabKey(key);
            return {};
        }
    }
    return key;
}

void ungrabKey(Key key)
{
    xcb_connection_t *c = connection();
    if (!c || !key.code)
        return;
    for (quint16 lock : kLocks)
        xcb_ungrab_key(c, key.code, root(c), key.modifiers | lock);
    xcb_flush(c);
}

bool keyPress(const QByteArray &eventType, void *message, Key *key)
{
    if (eventType != "xcb_generic_event_t")
        return false;
    const auto *event = static_cast<const xcb_generic_event_t *>(message);
    if ((event->response_type & ~0x80) != XCB_KEY_PRESS)
        return false;
    const auto *press = static_cast<const xcb_key_press_event_t *>(message);
    key->code = press->detail;
    key->modifiers = press->state & kModifiers;
    return true;
}

#else

bool available() { return false; }
QList<DesktopWindow> windows() { return {}; }
quint64 activeWindow() { return 0; }
void activate(quint64) {}
void showOnEveryWorkspace(quint64) {}
void setInputRegion(quint64, const QRect &) {}
bool composited() { return false; }
int idleMs() { return -1; }
Key grabKey(int) { return {}; }
void ungrabKey(Key) {}
bool keyPress(const QByteArray &, void *, Key *) { return false; }

#endif

} // namespace x11
} // namespace farol
