#include <QtTest>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include "ClaudeSettingsMerger.h"
#include "JsonTree.h"
#include "SettingsFixtures.h"

using namespace farol;

namespace {
const QString kHook = QStringLiteral("/home/u/.local/share/farol/farol-hook");

// Canonical 2-space formatting, as Claude Code writes it.

} // namespace

class TestSettingsMerger : public QObject {
    Q_OBJECT
private slots:
    void roundTripIsIdentical()
    {
        QString err;
        const auto t = JsonTree::parse(kSettings, &err);
        QVERIFY2(t, qPrintable(err));
        QCOMPARE(t->serialize() + "\n", kSettings);
    }

    void roundTripKeepsEscapesNumbersAndEmptyContainers()
    {
        const QString text = kEscapesFixture;
        const auto t = JsonTree::parse(text, nullptr);
        QVERIFY(t);
        QCOMPARE(t->serialize() + "\n", text);
    }

    void parseRejectsInvalidJson()
    {
        QString err;
        QVERIFY(!JsonTree::parse("{\"a\": ", &err));
        QVERIFY(!err.isEmpty());
        QVERIFY(!JsonTree::parse("{} trailing", &err));
        QVERIFY(!JsonTree::parse("", &err));
    }

    void installKeepsKeyOrderEverythingElseAndAddsTheTwelveEvents()
    {
        const MergeResult r = ClaudeSettingsMerger::install(kSettings, kHook, 110);
        QVERIFY2(r.ok, qPrintable(r.error));
        QVERIFY(r.changed);
        // everything before "hooks" is byte-for-byte the original
        QVERIFY(r.text.startsWith(kSettings.left(kSettings.indexOf(QStringLiteral("  \"hooks\": {")))));
        QVERIFY(r.text.endsWith(QStringLiteral("  \"theme\": \"dark-daltonized\"\n}\n")));
        const auto tree = JsonTree::parse(r.text, nullptr);
        QVERIFY(tree);
        QCOMPARE(tree->keyList(), (QStringList{"respectGitignore", "permissions", "model", "hooks", "theme"}));

        const QJsonObject hooks = QJsonDocument::fromJson(r.text.toUtf8()).object().value("hooks").toObject();
        QCOMPARE(hooks.keys().size(), 12);
        for (const QString &ev : ClaudeSettingsMerger::events())
            QVERIFY2(hooks.contains(ev), qPrintable(ev));
        // the user's own Stop hook is still first, ours is appended
        const QJsonArray stop = hooks.value("Stop").toArray();
        QCOMPARE(stop.size(), 2);
        QVERIFY(stop.at(0).toObject().value("hooks").toArray().at(0).toObject().value("command").toString().startsWith("echo"));
        // Stop is fire-and-forget like every event except PermissionRequest
        const QJsonObject ours = stop.at(1).toObject().value("hooks").toArray().at(0).toObject();
        QCOMPARE(ours.value("command").toString(), QStringLiteral("\"/home/u/.local/share/farol/farol-hook\""));
        QCOMPARE(ours.value("timeout").toInt(), 10);
        QCOMPARE(ours.value("type").toString(), QStringLiteral("command"));
        const QJsonObject start = hooks.value("SessionStart").toArray().at(0).toObject().value("hooks").toArray().at(0).toObject();
        QCOMPARE(start.value("command").toString(), QStringLiteral("\"/home/u/.local/share/farol/farol-hook\""));
        QCOMPARE(start.value("timeout").toInt(), 10);

        const QJsonObject perm = hooks.value("PermissionRequest").toArray().at(0).toObject().value("hooks").toArray().at(0).toObject();
        QCOMPARE(perm.value("command").toString(), QStringLiteral("\"/home/u/.local/share/farol/farol-hook\" --decision-timeout 110"));
        QCOMPARE(perm.value("timeout").toInt(), 120);
    }

    void installIsIdempotent()
    {
        const MergeResult once = ClaudeSettingsMerger::install(kSettings, kHook, 110);
        const MergeResult twice = ClaudeSettingsMerger::install(once.text, kHook, 110);
        QVERIFY(twice.ok);
        QCOMPARE(twice.text, once.text);
        QVERIFY(!twice.changed);
    }

    void installReplacesOurOldEntriesWithANewTimeout()
    {
        const MergeResult a = ClaudeSettingsMerger::install(kSettings, kHook, 110);
        const MergeResult b = ClaudeSettingsMerger::install(a.text, kHook, 60);
        QVERIFY(b.changed);
        const QJsonObject hooks = QJsonDocument::fromJson(b.text.toUtf8()).object().value("hooks").toObject();
        QCOMPARE(hooks.value("PermissionRequest").toArray().size(), 1);   // replaced, not duplicated
        QCOMPARE(hooks.value("Stop").toArray().size(), 2);
        QCOMPARE(hooks.value("PermissionRequest").toArray().at(0).toObject().value("hooks").toArray().at(0).toObject().value("timeout").toInt(), 70);
    }

    void uninstallRestoresTheOriginalExactly()
    {
        const MergeResult installed = ClaudeSettingsMerger::install(kSettings, kHook, 110);
        const MergeResult removed = ClaudeSettingsMerger::uninstall(installed.text);
        QVERIFY(removed.ok);
        QVERIFY(removed.changed);
        QCOMPARE(removed.text, kSettings);

        const MergeResult installed2 = ClaudeSettingsMerger::install(kNoHooks, kHook, 110);
        QCOMPARE(ClaudeSettingsMerger::uninstall(installed2.text).text, kNoHooks);   // "hooks" we created is removed again
    }

    void uninstallWithNothingInstalledChangesNothing()
    {
        const MergeResult r = ClaudeSettingsMerger::uninstall(kSettings);
        QVERIFY(r.ok);
        QVERIFY(!r.changed);
        QCOMPARE(r.text, kSettings);
    }

    void missingOrEmptyFileBecomesAFreshObject()
    {
        for (const QString &existing : {QString(), QStringLiteral("  \n")}) {
            const MergeResult r = ClaudeSettingsMerger::install(existing, kHook, 110);
            QVERIFY(r.ok);
            QVERIFY(r.changed);
            QVERIFY(QJsonDocument::fromJson(r.text.toUtf8()).object().contains("hooks"));
            QCOMPARE(ClaudeSettingsMerger::uninstall(r.text).text, QStringLiteral("{}\n"));
        }
    }

    void strangeFilesAreRefusedNotCorrupted()
    {
        for (const QString &bad : {QStringLiteral("{ not json"), QStringLiteral("[1,2]"), QStringLiteral("\"text\""),
                                   kBadHooksArray, kBadStopObject}) {
            const MergeResult r = ClaudeSettingsMerger::install(bad, kHook, 110);
            QVERIFY2(!r.ok, qPrintable(bad));
            QVERIFY(!r.error.isEmpty());
            QVERIFY(r.text.isEmpty());                                // never a half-edited text
            const MergeResult u = ClaudeSettingsMerger::uninstall(bad);
            if (u.ok)
                QCOMPARE(u.text, bad);                                // nothing of ours in there: untouched
            else
                QVERIFY(!u.error.isEmpty());
        }
    }

    void aForeignHookSharingOurGroupSurvivesUninstall()
    {
        const QString shared = kSharedGroupFixture;
        const MergeResult r = ClaudeSettingsMerger::uninstall(shared);
        QVERIFY(r.ok);
        const QJsonArray stop = QJsonDocument::fromJson(r.text.toUtf8()).object().value("hooks").toObject().value("Stop").toArray();
        QCOMPARE(stop.size(), 1);
        QCOMPARE(stop.at(0).toObject().value("hooks").toArray().size(), 1);
        QCOMPARE(stop.at(0).toObject().value("hooks").toArray().at(0).toObject().value("command").toString(), QStringLiteral("echo foreign"));
    }

    void isInstalledDetectsOnlyOurEntries()
    {
        QVERIFY(!ClaudeSettingsMerger::isInstalled(kSettings));
        QVERIFY(!ClaudeSettingsMerger::isInstalled(QString()));
        QVERIFY(!ClaudeSettingsMerger::isInstalled("{ broken"));
        QVERIFY(ClaudeSettingsMerger::isInstalled(ClaudeSettingsMerger::install(kSettings, kHook, 110).text));
    }

    void pathsWithSpacesAreQuotedAndStillRecognised()
    {
        const QString spaced = QStringLiteral("/home/a b/.local/share/farol/farol-hook");
        const MergeResult r = ClaudeSettingsMerger::install(kNoHooks, spaced, 110);
        QVERIFY(ClaudeSettingsMerger::isInstalled(r.text));
        const QJsonObject hooks = QJsonDocument::fromJson(r.text.toUtf8()).object().value("hooks").toObject();
        QCOMPARE(hooks.value("SessionStart").toArray().at(0).toObject().value("hooks").toArray().at(0).toObject().value("command").toString(),
                 QStringLiteral("\"/home/a b/.local/share/farol/farol-hook\""));
    }

    // Hooks installed while the app was still called Coucou: installing Farol replaces them, uninstall removes them.
    void legacyCoucouEntriesAreReplacedAndRemoved()
    {
        const QString legacyHook = QStringLiteral("/home/u/.local/share/coucou/nb-hook");
        const MergeResult legacy = ClaudeSettingsMerger::install(kSettings, legacyHook, 110);
        QVERIFY(legacy.ok);
        QVERIFY(!ClaudeSettingsMerger::isInstalled(legacy.text));        // old entries do not count as installed

        const MergeResult migrated = ClaudeSettingsMerger::install(legacy.text, kHook, 110);
        QVERIFY(migrated.ok);
        QVERIFY(!migrated.text.contains(QStringLiteral("coucou/nb-hook")));
        const QJsonObject hooks = QJsonDocument::fromJson(migrated.text.toUtf8()).object().value("hooks").toObject();
        QCOMPARE(hooks.value("Stop").toArray().size(), 2);               // the user's own + ours, no duplicate
        QCOMPARE(hooks.value("PermissionRequest").toArray().size(), 1);

        QCOMPARE(ClaudeSettingsMerger::uninstall(legacy.text).text, kSettings);
    }
};

QTEST_APPLESS_MAIN(TestSettingsMerger)
#include "tst_settings_merger.moc"
