import QtQuick

Item {
    Card { anchors.fill: parent; wash: theme.ok }
    Column {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: appState.vertical ? 12 : 16
        anchors.rightMargin: appState.vertical ? 12 : 16
        spacing: 5

        AgentWho {
            name: appState.focusTask.name || ""
            label: "finished"
            dot: appState.focusTask.color || theme.muted
        }
        Text {
            objectName: "finishedTitle"
            width: parent.width
            textFormat: Text.PlainText
            // the alert text goes when the session turns idle, a moment before the island closes: the message stays
            text: appState.focusTask.alertText || (appState.focusTask.finalMessage || "").split("\n")[0] || "Sessão concluída"
            color: theme.text
            font.family: theme.titleFont
            font.pixelSize: 15
            font.weight: Font.DemiBold
            wrapMode: Text.Wrap
            maximumLineCount: appState.vertical ? 3 : 2
            elide: Text.ElideRight
        }
        Flow {   // the buttons wrap onto more lines in the portrait island
            width: parent.width
            spacing: 8
            PillButton {
                text: "Abrir sessão"
                primary: true
                onClicked: { sessions.jump(appState.focusId); controller.collapse() }
            }
            PillButton { text: "OK"; onClicked: controller.collapse() }
        }
    }
}
