#include "Skills.h"

#include "AppState.h"
#include "SkillsFolder.h"

#include <QFileInfo>
#include <QSettings>

namespace farol {

Skills::Skills(AppState *state, ICommandRunner *runner, QSettings *settings, const QString &claudeSkillsDir,
               std::function<qint64()> nowMs, QObject *parent)
    : QObject(parent), m_state(state), m_runner(runner), m_settings(settings), m_claudeDir(claudeSkillsDir),
      m_now(std::move(nowMs)), m_dir(state->skillsDir())
{
    m_updatedAt = m_settings->value("skillsUpdatedAt").toLongLong();
    connect(m_state, &AppState::skillsDirChanged, this, &Skills::onDirChanged);
}

QString Skills::status() const
{
    if (m_dir.isEmpty())
        return QStringLiteral("none");
    if (!m_conflicts.isEmpty() || !m_linkError.isEmpty() || m_pull == Pull::Dirty || m_pull == Pull::Offline || m_pull == Pull::NoGit)
        return QStringLiteral("warn");
    return m_pull == Pull::NoRepository ? QStringLiteral("plain") : QStringLiteral("ok");
}

QString Skills::message() const
{
    if (m_dir.isEmpty())
        return QStringLiteral("Escolha a pasta das skills da empresa");
    if (m_busy)
        return QStringLiteral("Atualizando…");
    if (!m_linkError.isEmpty())
        return QStringLiteral("Não consegui ligar as skills");
    switch (m_pull) {
    case Pull::Dirty: return QStringLiteral("Não atualizei: há mudanças suas no clone");
    case Pull::Offline: return QStringLiteral("Não consegui falar com o GitHub");
    case Pull::NoGit: return QStringLiteral("Instale o git para atualizar");
    case Pull::NoRepository: return QStringLiteral("Pasta sem git");
    case Pull::Never: return QStringLiteral("Skills ligadas");
    case Pull::Ok: break;
    }
    return QStringLiteral("Em dia com o GitHub");
}

QString Skills::detail() const
{
    if (m_dir.isEmpty() || m_busy)
        return {};
    if (!m_linkError.isEmpty())
        return m_linkError;
    if (!m_conflicts.isEmpty())
        return QStringLiteral("Nome já usado por outra skill sua: ") + m_conflicts.join(QStringLiteral(", "));
    switch (m_pull) {
    case Pull::Dirty: return QStringLiteral("Guarde ou desfaça as mudanças na pasta e tente de novo.");
    case Pull::Offline: return QStringLiteral("Confira a rede e o seu acesso ao repositório.");
    case Pull::NoGit: return QStringLiteral("As skills continuam ligadas como estão.");
    case Pull::NoRepository: return QStringLiteral("Atualize as skills por conta própria.");
    case Pull::Never: return {};
    case Pull::Ok: break;
    }
    const qint64 minutes = qMax<qint64>(0, m_now() - m_updatedAt) / 60000;
    if (minutes < 1)
        return QStringLiteral("atualizado agora");
    if (minutes < 60)
        return QStringLiteral("atualizado há %1 min").arg(minutes);
    return QStringLiteral("atualizado há %1 h").arg(minutes / 60);
}

void Skills::onDirChanged()
{
    const QString previous = m_dir;
    m_dir = m_state->skillsDir();
    m_pull = Pull::Never;
    m_pulledAt = 0;
    relink(previous);
    if (!m_dir.isEmpty())
        pull();
}

void Skills::relink(const QString &previousDir)
{
    const LinkPlan plan = planLinks(m_dir, m_claudeDir, previousDir);
    m_linkError.clear();
    if (applyLinks(plan, m_claudeDir, &m_linkError)) {
        m_linked = plan.linked;
    } else {   // count what is really there
        const LinkPlan now = planLinks(m_dir, m_claudeDir);
        m_linked = now.linked - int(now.create.size()) - int(now.relink.size());
    }
    m_conflicts = plan.conflicts;
    emit changed();
}

void Skills::refresh()
{
    if (m_dir.isEmpty() || m_busy) {
        emit changed();
        return;
    }
    relink();
    if (m_pulledAt == 0 || m_now() - m_pulledAt >= kUpdateEveryMs)
        pull();
}

void Skills::updateNow()
{
    if (m_dir.isEmpty() || m_busy)
        return;
    relink();
    pull();
}

void Skills::pull()
{
    m_pulledAt = m_now();
    if (!QFileInfo::exists(m_dir + QStringLiteral("/.git"))) {
        m_pull = Pull::NoRepository;
        emit changed();
        return;
    }
    m_busy = true;
    emit changed();
    const QString dir = m_dir;
    // No prompt can be answered from here: a password or passphrase request fails at once instead of hanging.
    m_runner->run(QStringLiteral("git"), {QStringLiteral("-C"), dir, QStringLiteral("pull"), QStringLiteral("--ff-only")},
                  {QStringLiteral("GIT_TERMINAL_PROMPT=0"), QStringLiteral("GIT_SSH_COMMAND=ssh -o BatchMode=yes -o ConnectTimeout=10"),
                   QStringLiteral("LC_ALL=C")},
                  kPullTimeoutMs, [this, dir](const ICommandRunner::Result &r) {
                      if (dir != m_dir)   // another folder was chosen meanwhile: its own pull answers
                          return;
                      m_busy = false;
                      m_pull = classify(r);
                      if (m_pull == Pull::Ok) {
                          m_updatedAt = m_now();
                          m_settings->setValue("skillsUpdatedAt", m_updatedAt);
                      }
                      relink();   // a pull may bring new skills, or take some away
                  });
}

Skills::Pull Skills::classify(const ICommandRunner::Result &r)
{
    if (!r.started)
        return Pull::NoGit;
    if (r.timedOut)
        return Pull::Offline;
    if (r.exitCode == 0)
        return Pull::Ok;
    const QString err = r.err + r.out;
    if (err.contains(QLatin1String("not a git repository")))
        return Pull::NoRepository;
    for (const char *sign : {"Could not resolve", "unable to access", "Connection", "Permission denied", "Could not read from remote",
                             "timed out", "Network is unreachable", "Host key verification failed", "Authentication failed",
                             "terminal prompts disabled"})
        if (err.contains(QLatin1String(sign)))
            return Pull::Offline;
    return Pull::Dirty;   // local changes, commits of the user's own, anything else git refuses to fast-forward over
}

} // namespace farol
