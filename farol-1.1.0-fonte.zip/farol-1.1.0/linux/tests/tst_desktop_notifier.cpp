#include <QtTest>
#include "DesktopNotifier.h"

using namespace farol;

// The body of a notification is markup for a server that says "body-markup", and Farol sends a model's text there.
class TestDesktopNotifier : public QObject {
    Q_OBJECT
private slots:
    void theBodyIsEscapedForAServerThatReadsMarkup()
    {
        QCOMPARE(notificationBody("Rodei <b>tudo</b> & pronto: 2 > 1", true), QStringLiteral("Rodei &lt;b&gt;tudo&lt;/b&gt; &amp; pronto: 2 &gt; 1"));
        QCOMPARE(notificationBody("<img src=\"http://127.0.0.1:9/x.png\"/>", true), QStringLiteral("&lt;img src=\"http://127.0.0.1:9/x.png\"/&gt;"));
        QCOMPARE(notificationBody("&lt;", true), QStringLiteral("&amp;lt;"));   // what the model wrote is what is read
        QCOMPARE(notificationBody("Tudo pronto.", true), QStringLiteral("Tudo pronto."));
        QCOMPARE(notificationBody(QString(), true), QString());
    }

    void theBodyGoesAsItIsToAServerThatShowsPlainText()
    {
        QCOMPARE(notificationBody("Rodei <b>tudo</b> & pronto: 2 > 1", false), QStringLiteral("Rodei <b>tudo</b> & pronto: 2 > 1"));
    }
};

QTEST_APPLESS_MAIN(TestDesktopNotifier)
#include "tst_desktop_notifier.moc"
