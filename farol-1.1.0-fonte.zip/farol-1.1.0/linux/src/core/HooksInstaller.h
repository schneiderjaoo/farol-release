#pragma once
#include <QDateTime>
#include <QString>
#include <functional>

namespace farol {

struct HooksPlan {
    bool ok = false;
    QString error;
    QString before, after;   // file text now / after the change
    QString diff;
    bool changes = false;
    bool settingsExisted = false;
};

// Previews and applies the Farol hooks in ~/.claude/settings.json: backup, diff, atomic write. It never writes
// without a plan, and a plan never writes anything.
class HooksInstaller {
public:
    using Clock = std::function<QDateTime()>;
    // interpreter: see ClaudeSettingsMerger::install.
    HooksInstaller(QString settingsPath, QString hookPath, int decisionTimeoutSec = 110,
                   Clock clock = [] { return QDateTime::currentDateTime(); }, QString interpreter = {});

    HooksPlan planInstall() const { return plan(true); }
    HooksPlan planUninstall() const { return plan(false); }
    bool installed() const;
    // Installed exactly as this version would write them (an older install can have other timeouts or arguments).
    bool upToDate() const;
    // settings.json.bak-YYYYMMDD-HHMM next to the settings file, "-2", "-3"... when it already exists.
    QString backupPathFor() const;
    // Writes plan.after. Refuses (writing and copying nothing) when the file is not exactly plan.before any more.
    bool apply(const HooksPlan &plan, QString *error, QString *backupPath = nullptr) const;

private:
    HooksPlan plan(bool install) const;
    QString targetPath() const;   // follows a symlink (dotfile managers)
    bool readCurrent(QString *text, QString *error) const;

    QString m_settingsPath, m_hookPath, m_interpreter;
    int m_decisionTimeoutSec;
    Clock m_clock;
};

} // namespace farol
