#include "EditDiff.h"

#include "TextDiff.h"

#include <QJsonArray>
#include <QStringList>
#include <utility>

namespace farol {

namespace {
const QChar kReplacement(0xFFFD);

// Unicode's Bidi_Control characters: they change the order the text of a line is drawn in.
bool isBidiControl(char32_t c)
{
    return c == 0x061C || c == 0x200E || c == 0x200F || (c >= 0x202A && c <= 0x202E) || (c >= 0x2066 && c <= 0x2069);
}

QString str(const QJsonObject &o, const char *key)
{
    const QJsonValue v = o.value(QLatin1String(key));
    return v.isString() ? v.toString() : QString();
}

// The lines of a text; the end of its last line is not one more, empty, line.
QStringList linesOf(const QString &text)
{
    if (text.isEmpty())
        return {};
    QStringList lines = text.split(QLatin1Char('\n'));
    if (lines.last().isEmpty())
        lines.removeLast();
    return lines;
}

// Fills the rows of a diff line by line, up to kDiffMaxLines of them, each cut to kDiffMaxChars, and counts what
// was added and removed over all of them, kept or not.
class Rows {
public:
    explicit Rows(EditDiff &diff) : m_diff(diff) {}

    // The head of a hunk: shown only if a line of the hunk is.
    void hunk(int oldStart, int oldLines, int newStart, int newLines)
    {
        m_head = QStringLiteral("@@ -%1,%2 +%3,%4 @@").arg(oldStart).arg(oldLines).arg(newStart).arg(newLines);
    }
    // A line with its marker in front (' ', '+' or '-'); one without a known marker is a line that stayed.
    void line(const QString &raw)
    {
        const QChar marker = raw.isEmpty() ? QChar(u' ') : raw.at(0);
        const bool marked = marker == u'+' || marker == u'-' || marker == u' ';
        m_added += marker == u'+';
        m_removed += marker == u'-';
        if (m_lines == kDiffMaxLines) {
            m_diff.cut = true;
            return;
        }
        ++m_lines;
        if (!m_head.isEmpty())
            m_diff.rows.append({QChar(u'@'), std::exchange(m_head, QString())});
        // no more of a long line is looked at than could be shown (a tab takes four places, never fewer)
        QString text = diffText(raw.mid(marked ? 1 : 0, kDiffMaxChars + 1));
        if (text.size() > kDiffMaxChars - 1) {
            m_diff.cut = true;
            text.truncate(kDiffMaxChars - 1);
            if (!text.isEmpty() && text.back().isHighSurrogate())
                text.chop(1);
        }
        m_diff.rows.append({marked ? marker : QChar(u' '), text});
    }
    int added() const { return m_added; }
    int removed() const { return m_removed; }

private:
    EditDiff &m_diff;
    QString m_head;
    int m_lines = 0, m_added = 0, m_removed = 0;
};

// Edit, Write, MultiEdit: the hunks of tool_response.structuredPatch.
bool readPatch(const HookEvent &e, EditDiff &diff, Rows &rows)
{
    const QJsonObject &r = e.toolResponse;
    diff.file = diffText(!str(r, "filePath").isEmpty() ? str(r, "filePath") : str(e.toolInput, "file_path"));
    diff.created = str(r, "type") == QLatin1String("create");
    if (!r.value("structuredPatch").isArray())
        return false;
    const QJsonArray patch = r.value("structuredPatch").toArray();
    int hunks = 0;
    for (const QJsonValue &v : patch) {
        const QJsonObject h = v.toObject();
        if (!h.value("lines").isArray())
            continue;
        ++hunks;
        rows.hunk(h.value("oldStart").toInt(), h.value("oldLines").toInt(), h.value("newStart").toInt(), h.value("newLines").toInt());
        for (const QJsonValue &l : h.value("lines").toArray())
            if (l.isString())
                rows.line(l.toString());
    }
    if (hunks > 0)
        return true;
    if (!patch.isEmpty())
        return false;                              // something else than hunks
    if (!diff.created)
        return true;                               // the file was written as it was: nothing changed
    // A new file has no patch: every line of its content was added. (farol-hook sends them as a hunk already; this
    // is what an older one sends.)
    const QJsonValue content = r.value("content").isString() ? r.value("content") : e.toolInput.value("content");
    if (!content.isString())
        return false;
    const QStringList lines = linesOf(content.toString());
    rows.hunk(0, 0, 1, int(lines.size()));
    for (const QString &l : lines)
        rows.line(QLatin1Char('+') + l);
    return true;
}

// NotebookEdit: the cell before and after, compared here.
bool readCell(const HookEvent &e, EditDiff &diff, Rows &rows)
{
    const QJsonObject &r = e.toolResponse;
    diff.file = diffText(!str(r, "notebook_path").isEmpty() ? str(r, "notebook_path") : str(e.toolInput, "notebook_path"));
    if (!r.value("new_source").isString())
        return false;
    const bool hadSource = r.value("old_source").isString();
    if (!hadSource && str(r, "edit_mode") == QLatin1String("delete"))
        return false;                              // a cell that went, and nothing says what it held
    const QStringList before = linesOf(r.value("old_source").toString());
    const QStringList after = linesOf(r.value("new_source").toString());
    if (before.isEmpty() || after.isEmpty()) {     // a new cell, or one that was emptied
        rows.hunk(before.isEmpty() ? 0 : 1, int(before.size()), after.isEmpty() ? 0 : 1, int(after.size()));
        for (const QString &l : before)
            rows.line(QLatin1Char('-') + l);
        for (const QString &l : after)
            rows.line(QLatin1Char('+') + l);
        return true;
    }
    const QStringList unified = unifiedDiff(before.join(QLatin1Char('\n')), after.join(QLatin1Char('\n')), {}, {}).split(QLatin1Char('\n'));
    for (qsizetype i = 2; i + 1 < unified.size(); ++i) {   // after the two lines that name the files; the text ends with a line break
        const QString &l = unified.at(i);
        if (l.startsWith(QLatin1String("@@ "))) {
            const QStringList n = l.mid(3).replace(QLatin1Char(','), QLatin1Char(' ')).split(QLatin1Char(' '));   // -a b +c d @@
            rows.hunk(-n.value(0).toInt(), n.value(1).toInt(), n.value(2).toInt(), n.value(3).toInt());
        } else {
            rows.line(l);
        }
    }
    return true;
}
} // namespace

bool isFileTool(const QString &tool)
{
    return tool == QLatin1String("Edit") || tool == QLatin1String("Write") || tool == QLatin1String("MultiEdit") ||
           tool == QLatin1String("NotebookEdit");
}

QString diffText(const QString &line)
{
    QStringView in(line);
    if (in.endsWith(u'\r'))
        in.chop(1);
    QString out;
    out.reserve(in.size());
    for (qsizetype i = 0; i < in.size(); ++i) {
        char32_t c = in.at(i).unicode();
        if (c == u'\t') {
            out += QLatin1String("    ");
            continue;
        }
        if (QChar::isHighSurrogate(c) && i + 1 < in.size() && in.at(i + 1).isLowSurrogate())
            c = QChar::surrogateToUcs4(c, in.at(++i).unicode());
        else if (QChar::isSurrogate(c))
            c = kReplacement.unicode();
        const QChar::Category category = QChar::category(c);
        if (category == QChar::Other_Control || category == QChar::Separator_Line || category == QChar::Separator_Paragraph || isBidiControl(c))
            c = kReplacement.unicode();
        out += QStringView(QChar::fromUcs4(c));
    }
    return out;
}

std::optional<EditDiff> editDiffOf(const HookEvent &e)
{
    if (e.name != QLatin1String("PostToolUse") || !isFileTool(e.toolName))
        return std::nullopt;
    const bool counted = e.editAdded >= 0 && e.editRemoved >= 0;
    EditDiff diff;
    Rows rows(diff);
    const bool known = e.toolName == QLatin1String("NotebookEdit") ? readCell(e, diff, rows) : readPatch(e, diff, rows);
    if (!known) {
        if (!counted)
            return std::nullopt;
        diff.rows.clear();                         // the counts came, the patch did not (or not as one)
    }
    diff.added = counted ? e.editAdded : rows.added();
    diff.removed = counted ? e.editRemoved : rows.removed();
    diff.cut = diff.cut || e.editCut;
    return diff;
}

} // namespace farol
