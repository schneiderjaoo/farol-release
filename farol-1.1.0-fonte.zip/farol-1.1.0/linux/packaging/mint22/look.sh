#!/bin/sh
# Inside the farol-mint22 image: starts Farol in the session of session.sh and saves a picture of the screen, so the
# island can be looked at as Mint shows it without a Mint machine.
#   linux/packaging/mint22/run.sh linux/packaging/mint22/look.sh <farol> <picture.png> [view] [edge]
# <farol> is the program to run: linux/build-mint22/src/app/farol, or /usr/bin/farol with the package installed.
if [ -z "${FAROL_LOOKING:-}" ]; then
    FAROL_LOOKING=1 exec "$(dirname "$0")/session.sh" "$0" "$@"
fi
farol=$1 picture=$2 view=${3:-} edge=${4:-}
FAROL_DEBUG_VIEW=$view FAROL_DEBUG_EDGE=$edge "$farol" >"$HOME/farol.log" 2>&1 &
python3 -c "import time; time.sleep(10)"
import -window root "$picture"
grep -v "symbolsresolver\|pw.conf\|multimedia\|PulseAudio\|QSoundEffect\|host portal" "$HOME/farol.log"
kill $! 2>/dev/null
