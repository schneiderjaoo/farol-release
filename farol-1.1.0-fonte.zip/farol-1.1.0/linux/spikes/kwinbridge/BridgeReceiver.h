#pragma once
#include <QObject>

class BridgeReceiver : public QObject {
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "local.joao.Farol.Bridge")
public:
    using QObject::QObject;
    int cursorCalls = 0;

public slots:
    void cursor(int x, int y);
    void window(const QString &caption, const QString &resourceClass, int x, int y, int w, int h);
};
