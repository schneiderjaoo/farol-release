#!/bin/sh
# Usage: measure.sh <pid> <seconds> — prints average CPU% over the window and current PSS in MB.
pid=$1; secs=${2:-10}
tck=$(getconf CLK_TCK)
t0=$(awk '{print $14+$15}' /proc/$pid/stat)
sleep "$secs"
t1=$(awk '{print $14+$15}' /proc/$pid/stat)
cpu=$(echo "$t0 $t1 $tck $secs" | awk '{printf "%.2f", ($2-$1)/$3/$4*100}')
pss=$(awk '/^Pss:/ {printf "%.1f", $2/1024}' /proc/$pid/smaps_rollup)
echo "pid=$pid cpu=${cpu}% pss=${pss}MB"
