import QtQuick

// CardBackground in the Swift views: dark rounded card, optionally washed from below with the alert colour.
Rectangle {
    id: card
    property color wash: "transparent"
    radius: 20
    color: theme.card
    border.color: theme.line
    border.width: 1

    Rectangle {
        anchors.fill: parent
        radius: card.radius
        visible: card.wash.a > 0
        gradient: Gradient {
            GradientStop { position: 0.0; color: "transparent" }
            GradientStop { position: 1.0; color: Qt.rgba(card.wash.r, card.wash.g, card.wash.b, 0.14) }
        }
    }
}
