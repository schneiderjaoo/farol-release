#!/bin/sh
# Inside the farol-mint22 image: runs a command in a desktop session nobody sees, an X server (1600x900) with
# Cinnamon's own window manager and compositor (muffin) and a session bus.
#   linux/packaging/mint22/run.sh linux/packaging/mint22/session.sh <command> [arguments]
wait_for() { python3 -c "import time; time.sleep($1)"; }

export HOME=$(mktemp -d) DISPLAY=:99 XDG_SESSION_TYPE=x11 XDG_CURRENT_DESKTOP=X-Cinnamon FAROL_TEST_X11=1
Xvfb :99 -screen 0 1600x900x24 >/dev/null 2>&1 &
xserver=$!
wait_for 1
eval "$(dbus-launch --sh-syntax)"
muffin >"$HOME/muffin.log" 2>&1 &
wm=$!
wait_for 3
"$@"
status=$?
kill $wm $xserver "$DBUS_SESSION_BUS_PID" 2>/dev/null
exit $status
