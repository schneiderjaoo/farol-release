#pragma once
#include "Scheduler.h"

#include <functional>

namespace farol {

// "Pointer left" is only reported after leaveDelayMs without an "enter" in between, so the
// enter/exit flapping the L0 probe saw (keyboard-mode flips) never reaches the FSM.
class HoverDebouncer {
public:
    explicit HoverDebouncer(IScheduler &scheduler, int leaveDelayMs = 120);

    std::function<void(bool)> onChanged;   // true = entered, false = left
    bool inside() const { return m_inside; }
    void enter();
    void leave();

private:
    IScheduler &m_sched;
    int m_leaveDelayMs;
    bool m_inside = false;
    int m_pendingLeave = 0;
};

} // namespace farol
