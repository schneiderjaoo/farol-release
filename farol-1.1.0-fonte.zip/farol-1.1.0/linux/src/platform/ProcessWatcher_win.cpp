#include "ProcessWatcher.h"

#include <QWinEventNotifier>
#include <qt_windows.h>

// Windows: a process handle is signalled when the process exits, and the event loop waits on it. `start` is the
// creation time of the process (a FILETIME as one number, what the hook sends): a pid is given to another process
// once its owner is gone, the creation time tells them apart. There are no PID namespaces.
namespace farol {

namespace {

qint64 creationTime(HANDLE process)
{
    FILETIME created{}, exited{}, kernel{}, user{};
    if (!GetProcessTimes(process, &created, &exited, &kernel, &user))
        return -1;
    return (qint64(created.dwHighDateTime) << 32) | qint64(created.dwLowDateTime);
}

} // namespace

ProcessWatcher::ProcessWatcher(QObject *parent) : QObject(parent) {}

ProcessWatcher::~ProcessWatcher()
{
    for (const Watch &w : std::as_const(m_watches))
        release(w);
}

qint64 ProcessWatcher::hostPid(qint64 pid, qint64 start, const QString &)
{
    if (pid <= 0 || start <= 0)
        return 0;
    const HANDLE process = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, DWORD(pid));
    if (!process)
        return 0;
    const bool same = creationTime(process) == start;
    CloseHandle(process);
    return same ? pid : 0;
}

int ProcessWatcher::watch(qint64 pid, qint64 start, std::function<void()> gone)
{
    if (pid <= 0 || start <= 0)
        return 0;
    const HANDLE process = OpenProcess(SYNCHRONIZE | PROCESS_QUERY_LIMITED_INFORMATION, FALSE, DWORD(pid));
    if (!process)
        return 0;
    if (creationTime(process) != start) {   // it exited meanwhile and the pid went to another process
        CloseHandle(process);
        return 0;
    }
    const int id = ++m_next;
    auto *notifier = new QWinEventNotifier(process, this);
    m_watches.insert(id, Watch{process, notifier, std::move(gone)});
    connect(notifier, &QWinEventNotifier::activated, this, [this, id] {
        const auto it = m_watches.constFind(id);
        if (it == m_watches.constEnd())
            return;
        const Watch w = *it;
        m_watches.erase(it);
        release(w);
        if (w.gone)
            w.gone();
    });
    return id;
}

void ProcessWatcher::cancel(int id)
{
    const auto it = m_watches.constFind(id);
    if (it == m_watches.constEnd())
        return;
    release(*it);
    m_watches.erase(it);
}

void ProcessWatcher::release(const Watch &w)
{
    w.notifier->setEnabled(false);
    w.notifier->deleteLater();
    CloseHandle(w.process);
}

} // namespace farol
