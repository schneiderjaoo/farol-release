# Coucou Linux — L2 Claude Code (sessões, aprovações, hooks) Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** As sessões reais do Claude Code (VSCodium e Konsole) aparecem na ilha, uma bolinha por sessão; o usuário aprova/nega permissões, vê perguntas, fim e erro de cada sessão e pula para a sessão com um clique; os hooks entram no `~/.claude/settings.json` só depois de backup + diff + confirmação.

**Architecture:** `nb-hook` (Python, stdlib) manda cada evento por uma linha JSON ao socket Unix `~/.local/share/coucou/nb.sock`. `HookServer` (Qt Network) lê a linha, e `ClaudeSessions` (core, sem UI) traduz o evento em mudanças no `AppState` (uma `AgentTask` por sessão) e em pedidos à ilha (revelar, abrir uma view, tocar som). Permissões passam por `ApprovalQueue` (fila FIFO, timeout, lista "sempre autorizar"), e o hook espera a decisão com a conexão aberta. O instalador edita o `settings.json` com um mini-parser JSON que **preserva a ordem das chaves** (`JsonTree`), gera o diff e só grava depois do "Confirmar".

**Tech Stack:** C++20, Qt 6.11 (Core, Network, Quick, Widgets, DBus), QML, Python 3 stdlib (`unittest`), Qt Test, CMake/Ninja. Build e testes no host por `linux/scripts/host.sh`.

**Spec:** `docs/superpowers/specs/2026-09-29-coucou-linux-design.md` (§0 emenda, §3.2, §6, §10, §11) e, como alvo de fidelidade, `NotchBuddy/Sources/App/HookServer.swift` e as views `ApprovalView`…`FinishedView` de `IslandViewContent.swift`. Desvios deliberados em relação ao Swift estão na Task 14 (que também os registra na §0 da spec).

## Global Constraints

- C++20 + Qt 6 (QML) + LayerShellQt + KF6, Fedora 44 KDE Plasma (Wayland) só. **Nunca mexer em `NotchBuddy/`.**
- Build/teste/execução no host: `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`.
- Todos os caminhos derivam de `$HOME` (`coucou::Paths`), nunca de `XDG_*` (o Flatpak do VSCodium remapeia).
- Nunca bloquear o Claude Code: toda falha do `nb-hook` = sem saída, exit 0, prazo curto (0,3 s nos eventos comuns). O app fechado não atrasa nada.
- Nenhuma aprovação sem clique (ou `Y`/`N` com a ilha já focada por clique). Timeout e desconexão **não** decidem nada: o hook cai no fluxo normal (`release`).
- `~/.claude/settings.json` só é escrito com backup datado, diff mostrado e confirmação explícita. Nunca sobrescrever às cegas.
- Segredos só no KWallet; sem telemetria; 0 % de CPU com a ilha escondida (nada de timer periódico novo: só `singleShot` do `IScheduler`).
- Tempo sempre via `IScheduler` (testes com `FakeScheduler`). Testes QML: `QT_QPA_PLATFORM=offscreen;QT_QUICK_BACKEND=software`.
- Nunca `pkill -f <nome>` de uma linha de comando que contém `<nome>`; use `pkill -x` em chamada própria.
- Estilo do código: comentários em inglês, curtos, só onde o "porquê" não é óbvio; Swift/SwiftUI → Qt 1:1 nas constantes.
- Commits terminam com `Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>`.

## Review Focus

1. **Linha do hook malformada, gigante ou sem campos** (lixo, JSON que não é objeto, sem `hook_event_name`, `session_id`/`cwd` ausentes, 2 MiB sem `\n`): o servidor não cai, não cria bolinha-fantasma e fecha a conexão. Testes: Task 3 (`parse`), Task 7 (lixo e linha gigante).
2. **App morto / conexão fechada com aprovação pendente** (o Claude Code mata o hook ao responder no editor; o app reinicia): a ilha tira o alerta, desafixa e segue para o próximo da fila; o hook sem resposta não imprime nada. Testes: Task 2 (`release`/fechou sem resposta), Task 5 (`cancel`), Task 7 (cliente desconecta).
3. **Sessões que somem sem `SessionEnd`** (Claude Code morto com `kill -9`) e **duas sessões na mesma pasta**: nada de bolinha fantasma para sempre (expira em 30 min) e ids distintos por `session_id`, não por pasta. Testes: Task 6.
4. **`settings.json` estranho**: inválido, ausente, `hooks` com tipo errado, symlink de gerenciador de dotfiles, chaves em ordem própria, arquivo alterado entre o diff e a gravação. O instalador recusa ou preserva; nunca corrompe. Testes: Tasks 10 e 11.
5. **Alerta fixado vs. timers da ilha**: aprovação pendente com a FSM chamando `home→petit`; aprovação nova chegando com a ilha já aberta; fila com 2 pedidos. A ilha não recolhe com aprovação na tela. Testes: Tasks 1, 5 e 6.

---

## File Structure

| Arquivo | Responsabilidade |
|---|---|
| `linux/hook/nb-hook` | Script Python do hook (stdlib). Enriquece o evento, fala com o socket, imprime só a decisão de permissão. |
| `linux/hook/tests/test_nb_hook.py` | `unittest` do hook (app ausente, allow/deny/release, origem, HOME ausente, stdout fechado…). |
| `linux/src/core/HookEvent.{h,cpp}` | `HookEvent::parse`, `projectAlias`, `stepLabel`, `clip`. |
| `linux/src/core/ApprovalQueue.{h,cpp}` | Fila de permissões, timeout, lista "sempre autorizar" persistida, propriedades para o QML. |
| `linux/src/core/JumpTarget.h` | Struct de contexto para voltar à sessão. |
| `linux/src/core/ClaudeSessions.{h,cpp}` | Evento do hook → `AppState` (uma tarefa por sessão) + pedidos à ilha + ligação com `ApprovalQueue`. |
| `linux/src/core/HookScript.{h,cpp}` | `installHookScript(content, dest)`: grava o `nb-hook` (0755) só se mudou. |
| `linux/src/core/JsonTree.{h,cpp}` | Mini-parser/serializador JSON que preserva a ordem das chaves e os tokens originais. |
| `linux/src/core/ClaudeSettingsMerger.{h,cpp}` | `install`/`uninstall`/`isInstalled` sobre o texto do `settings.json`. |
| `linux/src/core/TextDiff.{h,cpp}` | Diff unificado por linhas. |
| `linux/src/core/HooksInstaller.{h,cpp}` | `planInstall`/`planUninstall`/`apply` (backup, checagem de alteração concorrente, symlink, escrita atômica). |
| `linux/src/core/JumpCommand.{h,cpp}` | Função pura `jumpCommandFor(JumpTarget)`. |
| `linux/src/platform/HookServer.{h,cpp}` | `QLocalServer`, `SO_PEERCRED`, protocolo de linha, detecção de instância única. |
| `linux/src/platform/HooksDialog.{h,cpp}` | `QDialog` com o diff e "Confirmar"/"Cancelar". |
| `linux/src/platform/SessionJumper.{h,cpp}` | Executa um `JumpCommand` (QProcess / D-Bus do Konsole). |
| `linux/qml/{Card,PillButton,AgentWho,CodeBlock}.qml` | Componentes compartilhados das views. |
| `linux/qml/{ApprovalView,QuestionView,FinishedView,ErrorView,OverviewView}.qml` | Views reais. |
| Modificados | `IslandController.cpp`, `AgentTask.h`, `TaskModel.{h,cpp}`, `AppState.{h,cpp}`, `Tray.{h,cpp}`, `ViewPlaceholder.qml`, `Island.qml`, `main.cpp`, os `CMakeLists.txt`, `tests/tst_*`. |

---

### Task 1: Alerta fixado não recolhe (guarda na FSM)

Fecha a pendência "L2" de `linux/docs/L1a-notes.md`: os timers da FSM chamam `setMode()` sem olhar `isPinned`.

**Files:**
- Modify: `linux/src/core/IslandController.cpp` (`onFsmTransition`, caso `S::Petit`)
- Test: `linux/tests/tst_island_controller.cpp`

**Interfaces:**
- Consumes: `AppState::isPinned()`, `IslandStateMachine::openExternally()`.
- Produces: nenhum símbolo novo; comportamento: com `isPinned()` verdadeiro, `Home→Petit` disparado por timer é desfeito (volta a `Home`, sem timers).

- [ ] **Step 1: Escrever o teste que falha**

Em `tst_island_controller.cpp`, antes de `void escapeClosesUnlessPinned()`:

```cpp
    void pinnedAlertSurvivesTheIdleTimer()
    {
        ctl->expand(IslandView::Overview);            // opened from outside, pointer elsewhere: 15 s idle timer runs
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(10000);
        state->setPinned(true);                       // a permission request arrives...
        ctl->expand(IslandView::Approval);            // ...and asks for its view; the old timer is still armed
        sched->advance(60000);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(ctl->fsm().state() == S::Home);

        state->setPinned(false);                      // answered
        ctl->expand(IslandView::Overview);
        sched->advance(14999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(state->mode() == IslandMode::Compact);
    }
```

- [ ] **Step 2: Rodar e ver falhar**

Run: `linux/scripts/host.sh cmake --build linux/build --target tst_island_controller && linux/scripts/host.sh linux/build/tests/tst_island_controller pinnedAlertSurvivesTheIdleTimer`
Expected: FAIL em `state->mode() == IslandMode::Expanded` (a ilha recolheu aos 15 s).

- [ ] **Step 3: Implementar a guarda**

Em `IslandController::onFsmTransition`, no início do `case S::Petit:`:

```cpp
    case S::Petit:
        if (from == S::Home && m_state->isPinned()) {
            // A pinned alert (permission request) must stay until answered: undo the timer-driven collapse.
            // Silent, no timers: the answer re-arms the idle timer through expand().
            m_fsm.openExternally();
            return;
        }
        if (from == S::Coucou)
```
O bloco novo entra como as primeiras instruções do `case S::Petit:`; o restante do caso (`if (from == S::Coucou) ... else if (from == S::Hidden) ...`, `setMode(IslandMode::Compact)` etc.) fica exatamente como está.

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: 9/9 passam.

- [ ] **Step 5: Commit**

```bash
git add linux/src/core/IslandController.cpp linux/tests/tst_island_controller.cpp
git commit -m "linux(L2): a pinned alert is not collapsed by the FSM idle timers

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 2: `nb-hook` (Python) com `unittest`

**Files:**
- Create: `linux/hook/nb-hook`, `linux/hook/tests/test_nb_hook.py`
- Modify: `linux/tests/CMakeLists.txt` (registrar o `unittest` no ctest)

**Interfaces:**
- Produces (protocolo hook→app): uma linha JSON (`payload` do Claude Code + `coucou_source` ∈ `vscodium|konsole|terminal`, `flatpak_id`, `konsole_dbus_service|session|window`, `term_program`, `cwd`), terminada em `\n`.
- Produces (protocolo app→hook, só `PermissionRequest`): uma linha `{"decision":"allow"|"deny"|"release","message":"…"}`.
- Produces (stdout do hook): exatamente `{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"allow"}}}` (ou `"deny"`, com `"message"` opcional) e mais nada; qualquer outro caso = stdout vazio, stderr vazio, exit 0.
- CLI: `nb-hook [--decision-timeout SECONDS]` (padrão 110; inválido → padrão).

- [ ] **Step 1: Escrever os testes (falham: o script não existe)**

`linux/hook/tests/test_nb_hook.py`:

```python
import importlib.machinery
import importlib.util
import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import unittest

HOOK = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "nb-hook"))


def load_module():
    loader = importlib.machinery.SourceFileLoader("nb_hook", HOOK)
    spec = importlib.util.spec_from_loader("nb_hook", loader)
    module = importlib.util.module_from_spec(spec)
    loader.exec_module(module)
    return module


class FakeApp:
    """Listens on $HOME/.local/share/coucou/nb.sock like the island does."""

    def __init__(self, home, reply=None, delay=0.0):
        folder = os.path.join(home, ".local/share/coucou")
        os.makedirs(folder)
        self.path = os.path.join(folder, "nb.sock")
        self.server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.server.bind(self.path)
        self.server.listen(4)
        self.received = []
        self.reply = reply      # dict -> sent as one JSON line; None -> just close (after `delay`)
        self.delay = delay
        threading.Thread(target=self._serve, daemon=True).start()

    def _serve(self):
        while True:
            try:
                conn, _ = self.server.accept()
            except OSError:
                return
            try:
                conn.settimeout(5)
                buf = b""
                while b"\n" not in buf:
                    chunk = conn.recv(4096)
                    if not chunk:
                        break
                    buf += chunk
                if buf:
                    self.received.append(json.loads(buf.split(b"\n")[0]))
                time.sleep(self.delay)
                if self.reply is not None:
                    conn.sendall(json.dumps(self.reply).encode() + b"\n")
            except Exception:
                pass
            finally:
                conn.close()

    def close(self):
        self.server.close()


class HookTestCase(unittest.TestCase):
    def setUp(self):
        self.home = tempfile.mkdtemp(prefix="nbh")
        self.addCleanup(shutil.rmtree, self.home, True)

    def env(self, **extra):
        # Built from scratch: the session running these tests has CLAUDE_CODE_ENTRYPOINT and friends set.
        env = {"PATH": os.environ.get("PATH", "/usr/bin:/bin"), "HOME": self.home}
        env.update(extra)
        return env

    def run_hook(self, payload, env=None, args=(), stdin=None):
        data = stdin if stdin is not None else json.dumps(payload).encode()
        start = time.monotonic()
        proc = subprocess.run([sys.executable, HOOK, *args], input=data, capture_output=True,
                              env=env if env is not None else self.env(), timeout=20)
        return proc, time.monotonic() - start


def permission(tool="Bash", command="ls"):
    return {"hook_event_name": "PermissionRequest", "session_id": "s1", "cwd": "/tmp/x",
            "tool_name": tool, "tool_input": {"command": command}}


class TestSilentFailures(HookTestCase):
    def test_app_absent_is_silent_and_fast(self):
        proc, elapsed = self.run_hook({"hook_event_name": "SessionStart", "session_id": "s1"})
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        self.assertLess(elapsed, 0.5)

    def test_orphan_socket_file_is_silent(self):
        folder = os.path.join(self.home, ".local/share/coucou")
        os.makedirs(folder)
        orphan = socket.socket(socket.AF_UNIX)
        orphan.bind(os.path.join(folder, "nb.sock"))
        orphan.close()                                  # the file stays, nobody listens
        proc, elapsed = self.run_hook(permission())
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        self.assertLess(elapsed, 0.5)

    def test_missing_home_is_silent(self):
        proc, _ = self.run_hook(permission(), env={"PATH": os.environ.get("PATH", "/usr/bin")})
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))

    def test_invalid_or_empty_stdin_is_silent(self):
        for data in (b"not json", b"", b"[1,2]", b"\xff\xfe"):
            proc, _ = self.run_hook(None, stdin=data)
            self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""), data)

    def test_closed_stdout_still_exits_zero(self):
        app = FakeApp(self.home, reply={"decision": "allow"})
        self.addCleanup(app.close)
        cmd = ["sh", "-c", 'exec "$0" "$1" >&-', sys.executable, HOOK]
        proc = subprocess.run(cmd, input=json.dumps(permission()).encode(), capture_output=True,
                              env=self.env(), timeout=20)
        self.assertEqual(proc.returncode, 0)

    def test_deleted_cwd_does_not_break_the_hook(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        gone = os.path.join(self.home, "gone")
        os.makedirs(gone)
        cmd = ["sh", "-c", 'cd "$2" && rmdir "$2" && exec "$0" "$1"', sys.executable, HOOK, gone]
        proc = subprocess.run(cmd, input=json.dumps({"hook_event_name": "SessionStart", "session_id": "s1"}).encode(),
                              capture_output=True, env=self.env(), timeout=20)
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        time.sleep(0.2)
        self.assertEqual(app.received[0]["cwd"], "")


class TestForwarding(HookTestCase):
    def test_common_event_sends_one_line_and_prints_nothing(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        proc, _ = self.run_hook({"hook_event_name": "SessionStart", "session_id": "s1", "cwd": "/tmp/p"},
                                env=self.env(TERM_PROGRAM="konsole-ish"))
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        time.sleep(0.2)
        sent = app.received[0]
        self.assertEqual(sent["hook_event_name"], "SessionStart")
        self.assertEqual(sent["coucou_source"], "terminal")
        self.assertEqual(sent["term_program"], "konsole-ish")
        self.assertEqual(sent["cwd"], "/tmp/p")

    def test_source_vscodium(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        self.run_hook({"hook_event_name": "Stop", "session_id": "s1"},
                      env=self.env(CLAUDE_CODE_ENTRYPOINT="claude-vscode", FLATPAK_ID="com.vscodium.codium"))
        time.sleep(0.2)
        self.assertEqual(app.received[0]["coucou_source"], "vscodium")
        self.assertEqual(app.received[0]["flatpak_id"], "com.vscodium.codium")

    def test_source_konsole(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        self.run_hook({"hook_event_name": "Stop", "session_id": "s1"},
                      env=self.env(KONSOLE_DBUS_SERVICE=":1.77", KONSOLE_DBUS_SESSION="/Sessions/3",
                                   KONSOLE_DBUS_WINDOW="/Windows/1"))
        time.sleep(0.2)
        sent = app.received[0]
        self.assertEqual(sent["coucou_source"], "konsole")
        self.assertEqual((sent["konsole_dbus_service"], sent["konsole_dbus_session"], sent["konsole_dbus_window"]),
                         (":1.77", "/Sessions/3", "/Windows/1"))

    def test_missing_cwd_falls_back_to_the_process_cwd(self):
        app = FakeApp(self.home)
        self.addCleanup(app.close)
        self.run_hook({"hook_event_name": "Stop", "session_id": "s1"})
        time.sleep(0.2)
        self.assertTrue(app.received[0]["cwd"])


class TestPermission(HookTestCase):
    def decision(self, reply, **kw):
        app = FakeApp(self.home, reply=reply, **kw)
        self.addCleanup(app.close)
        return self.run_hook(permission())

    def test_allow_prints_the_exact_json(self):
        proc, _ = self.decision({"decision": "allow"})
        self.assertEqual(proc.stdout, b'{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"allow"}}}\n')
        self.assertEqual((proc.returncode, proc.stderr), (0, b""))

    def test_deny_prints_the_exact_json(self):
        proc, _ = self.decision({"decision": "deny"})
        self.assertEqual(proc.stdout, b'{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"deny"}}}\n')

    def test_deny_carries_the_message(self):
        proc, _ = self.decision({"decision": "deny", "message": "Denied from the island"})
        self.assertEqual(proc.stdout, b'{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"deny","message":"Denied from the island"}}}\n')

    def test_release_garbage_and_silence_print_nothing(self):
        for reply in ({"decision": "release"}, {"decision": "maybe"}, {"nothing": 1}, ["allow"], None):
            self.setUp()
            proc, _ = self.decision(reply)
            self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""), reply)

    def test_waits_for_the_decision_timeout_then_stays_silent(self):
        app = FakeApp(self.home, reply=None, delay=4)
        self.addCleanup(app.close)
        proc, elapsed = self.run_hook(permission(), args=("--decision-timeout", "1"))
        self.assertEqual((proc.returncode, proc.stdout, proc.stderr), (0, b"", b""))
        self.assertGreater(elapsed, 0.9)
        self.assertLess(elapsed, 2.5)


class TestPureFunctions(unittest.TestCase):
    def test_decision_timeout_argument(self):
        m = load_module()
        self.assertEqual(m.decision_timeout(["nb-hook"]), 110.0)
        self.assertEqual(m.decision_timeout(["nb-hook", "--decision-timeout", "30"]), 30.0)
        for bad in ("abc", "-5", "0", "nan", "inf", "99999"):
            self.assertEqual(m.decision_timeout(["nb-hook", "--decision-timeout", bad]), 110.0, bad)
        self.assertEqual(m.decision_timeout(["nb-hook", "--decision-timeout"]), 110.0)


if __name__ == "__main__":
    unittest.main()
```

- [ ] **Step 2: Rodar e ver falhar**

Run: `linux/scripts/host.sh python3 -m unittest discover -s linux/hook/tests -p "test_*.py"`
Expected: erros (`FileNotFoundError` do `nb-hook`).

- [ ] **Step 3: Escrever `linux/hook/nb-hook`**

```python
#!/usr/bin/env python3
"""nb-hook: relays Claude Code hook events to the Coucou island over a Unix socket.

Contract (design spec 6.1 and 10):
  * never blocks Claude Code: every failure means "no output, exit 0";
  * stdout is written only for a PermissionRequest answered allow/deny in the island;
  * nothing is ever written to stderr.
"""
import json
import os
import socket
import sys
import time

COMMON_DEADLINE = 0.3          # seconds for connect + send on every event except PermissionRequest
CONNECT_DEADLINE = 0.3
DEFAULT_DECISION_TIMEOUT = 110.0
MAX_REPLY = 65536


def socket_path():
    return os.path.join(os.environ["HOME"], ".local/share/coucou/nb.sock")


def decision_timeout(argv):
    """--decision-timeout SECONDS (written by the installer); anything unusable means the default."""
    try:
        value = float(argv[argv.index("--decision-timeout") + 1])
        if 0 < value < 3600:
            return value
    except (ValueError, IndexError):
        pass
    return DEFAULT_DECISION_TIMEOUT


def enrich(payload, env):
    entrypoint = env.get("CLAUDE_CODE_ENTRYPOINT", "")
    if entrypoint.startswith("claude-vscode"):
        payload["coucou_source"] = "vscodium"
        payload["flatpak_id"] = env.get("FLATPAK_ID", "")
    elif env.get("KONSOLE_DBUS_SERVICE"):
        payload["coucou_source"] = "konsole"
        for key in ("KONSOLE_DBUS_SERVICE", "KONSOLE_DBUS_SESSION", "KONSOLE_DBUS_WINDOW"):
            payload[key.lower()] = env.get(key, "")
    else:
        payload["coucou_source"] = "terminal"
        payload["term_program"] = env.get("TERM_PROGRAM", "")
    if not payload.get("cwd"):
        try:
            payload["cwd"] = os.getcwd()
        except OSError:
            payload["cwd"] = ""


def line(payload):
    return (json.dumps(payload) + "\n").encode("utf-8")


def connect(path, deadline):
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    try:
        s.settimeout(max(0.001, deadline - time.monotonic()))
        s.connect(path)
    except BaseException:
        s.close()
        raise
    return s


def tell(path, payload):
    deadline = time.monotonic() + COMMON_DEADLINE
    s = connect(path, deadline)
    try:
        s.settimeout(max(0.001, deadline - time.monotonic()))
        s.sendall(line(payload))
    finally:
        s.close()


def ask(path, payload, timeout):
    s = connect(path, time.monotonic() + CONNECT_DEADLINE)
    try:
        deadline = time.monotonic() + timeout
        s.settimeout(CONNECT_DEADLINE)
        s.sendall(line(payload))
        buf = b""
        while b"\n" not in buf and len(buf) < MAX_REPLY:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return None
            s.settimeout(remaining)
            chunk = s.recv(4096)
            if not chunk:
                break
            buf += chunk
        return json.loads(buf.split(b"\n")[0])
    finally:
        s.close()


def decision_output(reply):
    if not isinstance(reply, dict):
        return None
    behavior = reply.get("decision")
    if behavior not in ("allow", "deny"):
        return None
    decision = {"behavior": behavior}
    message = reply.get("message")
    if behavior == "deny" and isinstance(message, str) and message:
        decision["message"] = message
    return json.dumps({"hookSpecificOutput": {"hookEventName": "PermissionRequest", "decision": decision}},
                      separators=(",", ":"))


def run():
    payload = json.loads(sys.stdin.buffer.read())
    if not isinstance(payload, dict):
        return
    enrich(payload, os.environ)
    path = socket_path()
    if payload.get("hook_event_name") == "PermissionRequest":
        out = decision_output(ask(path, payload, decision_timeout(sys.argv)))
        if out:
            sys.stdout.write(out + "\n")
            sys.stdout.flush()
    else:
        tell(path, payload)


def main():
    try:
        run()
    except BaseException:
        pass
    try:
        sys.stdout.flush()
    except BaseException:
        pass
    os._exit(0)


if __name__ == "__main__":
    main()
```

Depois: `chmod +x linux/hook/nb-hook` (no host: `linux/scripts/host.sh chmod +x linux/hook/nb-hook`).

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh python3 -m unittest discover -s linux/hook/tests -p "test_*.py" -v`
Expected: todos `ok`. Se `test_closed_stdout_still_exits_zero` falhar só por ambiente do `sh -c`, ajuste o teste, não o contrato.

- [ ] **Step 5: Registrar no ctest**

Em `linux/tests/CMakeLists.txt`, no fim:

```cmake
add_test(NAME nb_hook_unittest
    COMMAND python3 -m unittest discover -s ${CMAKE_SOURCE_DIR}/hook/tests -p "test_*.py")
```

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh ctest --test-dir linux/build -R nb_hook --output-on-failure`
Expected: 1/1 passa.

- [ ] **Step 6: Commit**

```bash
git add linux/hook linux/tests/CMakeLists.txt
git commit -m "linux(L2): nb-hook relay with unittest (never blocks, exact decision JSON)

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 3: `HookEvent` (parse, projeto, rótulo do passo)

**Files:**
- Create: `linux/src/core/HookEvent.h`, `linux/src/core/HookEvent.cpp`, `linux/tests/tst_hook_event.cpp`
- Modify: `linux/src/core/CMakeLists.txt` (add `HookEvent.h HookEvent.cpp`), `linux/tests/CMakeLists.txt` (`coucou_add_test(tst_hook_event)`)

**Interfaces:**
- Produces:
  - `struct coucou::HookEvent { QString name, sessionId, cwd, source, flatpakId, konsoleService, konsoleSession, konsoleWindow, toolName, prompt, message, notificationType, lastAssistantMessage; QJsonObject toolInput; static std::optional<HookEvent> parse(const QByteArray &line); QString project() const; }`
  - `QString coucou::projectAlias(const QString &folder)`; `QString coucou::stepLabel(const QString &tool, const QJsonObject &input)`; `QString coucou::clip(const QString &s, int max)`.

- [ ] **Step 1: Escrever os testes**

`linux/tests/tst_hook_event.cpp`:

```cpp
#include <QtTest>
#include "HookEvent.h"

using namespace coucou;

class TestHookEvent : public QObject {
    Q_OBJECT
private slots:
    void parsesAFullEvent()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"PreToolUse","session_id":"abc","cwd":"/home/u/proj",
            "coucou_source":"vscodium","flatpak_id":"com.vscodium.codium","tool_name":"Bash",
            "tool_input":{"command":"npm test"},"prompt":"hi","message":"m","notification_type":"idle_prompt",
            "last_assistant_message":"done"})");
        QVERIFY(e);
        QCOMPARE(e->name, QStringLiteral("PreToolUse"));
        QCOMPARE(e->sessionId, QStringLiteral("abc"));
        QCOMPARE(e->cwd, QStringLiteral("/home/u/proj"));
        QCOMPARE(e->source, QStringLiteral("vscodium"));
        QCOMPARE(e->flatpakId, QStringLiteral("com.vscodium.codium"));
        QCOMPARE(e->toolName, QStringLiteral("Bash"));
        QCOMPARE(e->toolInput.value("command").toString(), QStringLiteral("npm test"));
        QCOMPARE(e->prompt, QStringLiteral("hi"));
        QCOMPARE(e->notificationType, QStringLiteral("idle_prompt"));
        QCOMPARE(e->lastAssistantMessage, QStringLiteral("done"));
    }

    void konsoleFields()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"Stop","konsole_dbus_service":":1.7",
            "konsole_dbus_session":"/Sessions/3","konsole_dbus_window":"/Windows/1"})");
        QVERIFY(e);
        QCOMPARE(e->konsoleService, QStringLiteral(":1.7"));
        QCOMPARE(e->konsoleSession, QStringLiteral("/Sessions/3"));
        QCOMPARE(e->konsoleWindow, QStringLiteral("/Windows/1"));
    }

    void rejectsGarbage()
    {
        QVERIFY(!HookEvent::parse(""));
        QVERIFY(!HookEvent::parse("not json"));
        QVERIFY(!HookEvent::parse("[1,2,3]"));
        QVERIFY(!HookEvent::parse(R"({"session_id":"x"})"));                 // no hook_event_name
        QVERIFY(!HookEvent::parse(R"({"hook_event_name":""})"));
        QVERIFY(!HookEvent::parse(R"({"hook_event_name":42})"));
        QVERIFY(!HookEvent::parse(QByteArray("\xff\xfe{")));
    }

    void missingFieldsGetDefaults()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"Stop"})");
        QVERIFY(e);
        QCOMPARE(e->sessionId, QStringLiteral("unknown"));
        QCOMPARE(e->cwd, QString());
        QCOMPARE(e->project(), QStringLiteral("Session"));
        QVERIFY(e->toolInput.isEmpty());
    }

    void wrongTypesAreTolerated()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"PreToolUse","session_id":7,"cwd":["x"],"tool_input":"str"})");
        QVERIFY(e);
        QCOMPARE(e->sessionId, QStringLiteral("unknown"));
        QCOMPARE(e->cwd, QString());
        QVERIFY(e->toolInput.isEmpty());
    }

    void projectUsesTheFolderNameAndAliases()
    {
        auto project = [](const char *cwd) {
            HookEvent e;
            e.cwd = QString::fromUtf8(cwd);
            return e.project();
        };
        QCOMPARE(project("/home/u/my-app"), QStringLiteral("my-app"));
        QCOMPARE(project("/home/u/my-app/"), QStringLiteral("my-app"));
        QCOMPARE(project("/"), QStringLiteral("Session"));
        QCOMPARE(project(""), QStringLiteral("Session"));
        QCOMPARE(project("/x/notch-buddy"), QStringLiteral("Notch Buddy"));
        QCOMPARE(projectAlias("NotchBuddy"), QStringLiteral("Notch Buddy"));
        QCOMPARE(projectAlias("notch_buddy"), QStringLiteral("Notch Buddy"));
    }

    void stepLabels()
    {
        QCOMPARE(stepLabel("Bash", QJsonObject{{"command", "npm test"}}), QStringLiteral("Runs · npm test"));
        QCOMPARE(stepLabel("Bash", QJsonObject{{"command", QString(60, 'x')}}), QStringLiteral("Runs · ") + QString(40, 'x'));
        QCOMPARE(stepLabel("Bash", QJsonObject{{"command", "a\nb"}}), QStringLiteral("Runs · a b"));
        QCOMPARE(stepLabel("Read", QJsonObject{{"file_path", "/a/b/Invoice.swift"}}), QStringLiteral("Reads · Invoice.swift"));
        QCOMPARE(stepLabel("Edit", QJsonObject{{"file_path", "/a/Main.cpp"}}), QStringLiteral("Edits · Main.cpp"));
        QCOMPARE(stepLabel("Glob", QJsonObject{{"path", "/src"}}), QStringLiteral("Finds · src"));
        QCOMPARE(stepLabel("Grep", QJsonObject{{"pattern", "TODO"}}), QStringLiteral("Searches · TODO"));
        QCOMPARE(stepLabel("WebSearch", QJsonObject{{"query", "qt layer shell"}}), QStringLiteral("Web search · qt layer shell"));
        QCOMPARE(stepLabel("Weird", {}), QStringLiteral("Weird"));
        QCOMPARE(stepLabel("", {}), QStringLiteral("Tool"));
    }

    void clipSingleLineAndLength()
    {
        QCOMPARE(clip("  a\n  b  ", 10), QStringLiteral("a b"));
        QCOMPARE(clip(QString(100, 'x'), 60).size(), 60);
    }
};

QTEST_APPLESS_MAIN(TestHookEvent)
#include "tst_hook_event.moc"
```

- [ ] **Step 2: Rodar e ver falhar** (não compila: `HookEvent.h` não existe)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_hook_event`

- [ ] **Step 3: Implementar**

`linux/src/core/HookEvent.h`:

```cpp
#pragma once
#include <QJsonObject>
#include <QString>
#include <optional>

namespace coucou {

// One line written by nb-hook: the Claude Code hook payload plus the context nb-hook added.
struct HookEvent {
    QString name;                 // hook_event_name
    QString sessionId;            // "unknown" when absent
    QString cwd;
    QString source;               // coucou_source: "vscodium" | "konsole" | "terminal" | ""
    QString flatpakId;
    QString konsoleService, konsoleSession, konsoleWindow;
    QString toolName;
    QJsonObject toolInput;
    QString prompt;               // UserPromptSubmit
    QString message;              // Notification
    QString notificationType;
    QString lastAssistantMessage; // Stop

    // nullopt when the line is not a JSON object with a non-empty string hook_event_name.
    static std::optional<HookEvent> parse(const QByteArray &line);
    // Alias of the cwd folder name; "Session" when there is no folder.
    QString project() const;
};

QString projectAlias(const QString &folder);
// "Runs · npm test": what the ticker shows for a tool call (PreToolUse).
QString stepLabel(const QString &tool, const QJsonObject &input);
// Single line, trimmed, cut to max characters.
QString clip(const QString &s, int max);

} // namespace coucou
```

`linux/src/core/HookEvent.cpp`:

```cpp
#include "HookEvent.h"

#include <QFileInfo>
#include <QJsonDocument>
#include <QMap>

namespace coucou {

namespace {
QString str(const QJsonObject &o, const char *key)
{
    const QJsonValue v = o.value(QLatin1String(key));
    return v.isString() ? v.toString() : QString();
}
} // namespace

std::optional<HookEvent> HookEvent::parse(const QByteArray &line)
{
    QJsonParseError err;
    const QJsonDocument doc = QJsonDocument::fromJson(line, &err);
    if (err.error != QJsonParseError::NoError || !doc.isObject())
        return std::nullopt;
    const QJsonObject o = doc.object();
    HookEvent e;
    e.name = str(o, "hook_event_name");
    if (e.name.isEmpty())
        return std::nullopt;
    e.sessionId = str(o, "session_id");
    if (e.sessionId.isEmpty())
        e.sessionId = QStringLiteral("unknown");
    e.cwd = str(o, "cwd");
    e.source = str(o, "coucou_source");
    e.flatpakId = str(o, "flatpak_id");
    e.konsoleService = str(o, "konsole_dbus_service");
    e.konsoleSession = str(o, "konsole_dbus_session");
    e.konsoleWindow = str(o, "konsole_dbus_window");
    e.toolName = str(o, "tool_name");
    if (o.value("tool_input").isObject())
        e.toolInput = o.value("tool_input").toObject();
    e.prompt = str(o, "prompt");
    if (e.prompt.isEmpty())
        e.prompt = str(o, "message");          // the Swift app read "message"; keep accepting it
    e.message = str(o, "message");
    e.notificationType = str(o, "notification_type");
    e.lastAssistantMessage = str(o, "last_assistant_message");
    return e;
}

QString HookEvent::project() const
{
    QString folder = QFileInfo(cwd).fileName();
    if (folder.isEmpty())
        return QStringLiteral("Session");
    return projectAlias(folder);
}

QString projectAlias(const QString &folder)
{
    static const QMap<QString, QString> aliases = {
        {"notch-buddy", "Notch Buddy"}, {"notchbuddy", "Notch Buddy"}, {"notch_buddy", "Notch Buddy"}};
    return aliases.value(folder.toLower(), folder);
}

QString clip(const QString &s, int max)
{
    return s.simplified().left(max);
}

QString stepLabel(const QString &tool, const QJsonObject &input)
{
    static const QMap<QString, QString> labels = {
        {"Bash", "Runs"}, {"Read", "Reads"}, {"Write", "Writes"}, {"Edit", "Edits"}, {"MultiEdit", "Edits"},
        {"Glob", "Finds"}, {"Grep", "Searches"}, {"WebSearch", "Web search"}, {"WebFetch", "Fetches"},
        {"TodoWrite", "Tasks"}, {"Task", "Agent"}, {"LS", "Lists"}, {"NotebookEdit", "Notebook"},
        {"AskUserQuestion", "Asks"}};
    const QString name = tool.isEmpty() ? QStringLiteral("Tool") : tool;
    const QString label = labels.value(name, name);
    auto field = [&](const char *k) { return input.value(QLatin1String(k)).toString(); };
    if (const QString c = field("command"); !c.isEmpty())
        return label + QStringLiteral(" · ") + clip(c, 40);
    if (const QString p = field("path"); !p.isEmpty())
        return label + QStringLiteral(" · ") + QFileInfo(p).fileName();
    if (const QString f = field("file_path"); !f.isEmpty())
        return label + QStringLiteral(" · ") + QFileInfo(f).fileName();
    if (const QString q = field("query"); !q.isEmpty())
        return label + QStringLiteral(" · ") + clip(q, 40);
    if (const QString pat = field("pattern"); !pat.isEmpty())
        return label + QStringLiteral(" · ") + clip(pat, 40);
    return label;
}

} // namespace coucou
```

Em `linux/src/core/CMakeLists.txt` adicione `HookEvent.h HookEvent.cpp` à lista; em `linux/tests/CMakeLists.txt` adicione `coucou_add_test(tst_hook_event)`.

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build --target tst_hook_event && linux/scripts/host.sh linux/build/tests/tst_hook_event`
Expected: todos PASS. (`QTEST_APPLESS_MAIN` porque o teste não usa `QCoreApplication`; se o linker reclamar, troque por `QTEST_MAIN`.)

- [ ] **Step 5: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux(L2): HookEvent parsing, project alias and step labels

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 4: `AppState`/`TaskModel` — campos de alerta, `modifyTask`, `focusTask`

**Files:**
- Modify: `linux/src/core/AgentTask.h`, `linux/src/core/TaskModel.h`, `linux/src/core/TaskModel.cpp`, `linux/src/core/AppState.h`, `linux/src/core/AppState.cpp`
- Test: `linux/tests/tst_app_state.cpp`

**Interfaces:**
- Produces:
  - `AgentTask::alertText` (`QString`) e `AgentTask::options` (`QStringList`).
  - `TaskModel::StepRole` (nome QML `step`): texto do passo atual (`steps.value(stepIndex)`).
  - `void AppState::modifyTask(const QString &id, const std::function<void(AgentTask &)> &fn)` — aplica `fn` e emite `effectiveStateChanged`, `compactOthersChanged`, `focusTaskChanged`.
  - `Q_PROPERTY(QVariantMap focusTask READ focusTask NOTIFY focusTaskChanged)` com chaves `id, name, color, state, steps, stepIndex, alertText, options, cwd, pillBadge, isIntegration` (vazio sem tarefas).
  - `Q_INVOKABLE void setFocus(const QString &id)` (já existe; agora invocável do QML).

- [ ] **Step 1: Escrever os testes**

Em `tst_app_state.cpp` (use o mesmo padrão `QSettings settings(iniPath(), QSettings::IniFormat); AppState st(&settings);` dos outros testes), antes do fecho da classe:

```cpp
    void modifyTaskMutatesAndNotifies()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        QSignalSpy focus(&st, &AppState::focusTaskChanged);
        QSignalSpy effective(&st, &AppState::effectiveStateChanged);
        st.modifyTask("integration_claude", [](AgentTask &t) {
            t.steps << "Reads · a.txt" << "Runs · ls";
            t.stepIndex = 1;
            t.alertText = "hello";
            t.options = {"A", "B"};
        });
        QCOMPARE(focus.count(), 1);
        QCOMPARE(effective.count(), 1);
        const QVariantMap f = st.focusTask();
        QCOMPARE(f.value("id").toString(), QStringLiteral("integration_claude"));
        QCOMPARE(f.value("alertText").toString(), QStringLiteral("hello"));
        QCOMPARE(f.value("steps").toStringList(), (QStringList{"Reads · a.txt", "Runs · ls"}));
        QCOMPARE(f.value("stepIndex").toInt(), 1);
        QCOMPARE(f.value("options").toStringList(), (QStringList{"A", "B"}));
        QVERIFY(f.value("isIntegration").toBool());
        QCOMPARE(f.value("state").toString(), QStringLiteral("idle"));
    }

    void modifyTaskOnUnknownIdIsANoOp()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        QSignalSpy focus(&st, &AppState::focusTaskChanged);
        st.modifyTask("nope", [](AgentTask &t) { t.alertText = "x"; });
        QCOMPARE(focus.count(), 0);
    }

    void focusTaskFollowsFocusAndStateUpdates()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        QSignalSpy focus(&st, &AppState::focusTaskChanged);
        st.setFocus("integration_n8n");
        QCOMPARE(st.focusTask().value("name").toString(), QStringLiteral("n8n"));
        QVERIFY(focus.count() >= 1);
        focus.clear();
        st.updateTask("integration_n8n", BotState::Working);
        QCOMPARE(focus.count(), 1);
        QCOMPARE(st.focusTask().value("state").toString(), QStringLiteral("working"));
    }

    void focusTaskIsEmptyWithoutTasks()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        const auto ids = [&] { QStringList out; for (const auto &t : st.taskModel()->all()) out << t.id; return out; }();
        for (const QString &id : ids)
            st.removeTask(id);
        QVERIFY(st.focusTask().isEmpty());
    }

    void stepRoleIsTheCurrentStep()
    {
        QSettings settings(iniPath(), QSettings::IniFormat);
        AppState st(&settings);
        st.modifyTask("integration_claude", [](AgentTask &t) { t.steps << "one" << "two"; t.stepIndex = 1; });
        const int row = st.taskModel()->indexOf("integration_claude");
        QCOMPARE(st.taskModel()->data(st.taskModel()->index(row), TaskModel::StepRole).toString(), QStringLiteral("two"));
        const int other = st.taskModel()->indexOf("integration_n8n");
        QCOMPARE(st.taskModel()->data(st.taskModel()->index(other), TaskModel::StepRole).toString(), QString());
    }
```

(garanta `#include <QSignalSpy>` no topo de `tst_app_state.cpp`.)

- [ ] **Step 2: Rodar e ver falhar** (não compila: símbolos novos)

Run: `linux/scripts/host.sh cmake --build linux/build --target tst_app_state 2>&1 | tail -5`

- [ ] **Step 3: Implementar**

`AgentTask.h`, dentro de `struct AgentTask`, depois de `sessionCwd`:

```cpp
    QString alertText;       // question text, finished summary or error message shown by the alert views
    QStringList options;     // AskUserQuestion option labels (read-only in the island)
```

`TaskModel.h`: no `enum Role` acrescente `StepRole` ao fim: `IsIntegrationRole, StepRole };`.

`TaskModel.cpp`: em `data()` acrescente `case StepRole: return t.steps.value(t.stepIndex);` e em `roleNames()` `{StepRole, "step"}`.

`AppState.h`: acrescente `#include <functional>` e `#include <QVariantMap>`; na lista de `Q_PROPERTY`: `Q_PROPERTY(QVariantMap focusTask READ focusTask NOTIFY focusTaskChanged)`; na seção pública: 

```cpp
    QVariantMap focusTask() const;
    void modifyTask(const QString &id, const std::function<void(AgentTask &)> &fn);
```
troque `void setFocus(const QString &id);` por `Q_INVOKABLE void setFocus(const QString &id);`; em `signals:` acrescente `void focusTaskChanged();`.

`AppState.cpp`: 
- em `setFocusInternal`, `addTask`, `removeTask` e `updateTask` (dentro do `if`) acrescente `emit focusTaskChanged();` junto dos outros `emit`s;
- novas funções:

```cpp
void AppState::modifyTask(const QString &id, const std::function<void(AgentTask &)> &fn)
{
    if (!m_tasks->update(id, fn))
        return;
    emit effectiveStateChanged();
    emit compactOthersChanged();
    emit focusTaskChanged();
}

QVariantMap AppState::focusTask() const
{
    const AgentTask *t = m_tasks->find(m_focusId);
    if (!t)
        return {};
    return {{"id", t->id},
            {"name", t->name},
            {"color", t->color},
            {"state", enumKey(t->state)},
            {"steps", t->steps},
            {"stepIndex", t->stepIndex},
            {"alertText", t->alertText},
            {"options", t->options},
            {"cwd", t->sessionCwd},
            {"pillBadge", t->pillBadge},
            {"isIntegration", t->isIntegration}};
}
```

- [ ] **Step 4: Rodar tudo**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: tudo passa.

- [ ] **Step 5: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux(L2): AppState.modifyTask, focusTask map and alert fields on AgentTask

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 5: `ApprovalQueue`

**Files:**
- Create: `linux/src/core/ApprovalQueue.h`, `linux/src/core/ApprovalQueue.cpp`, `linux/tests/tst_approval_queue.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/tests/CMakeLists.txt` (`coucou_add_test(tst_approval_queue)`)

**Interfaces:**
- Consumes: `IScheduler` (`singleShot`, `cancel`), `QSettings*` (pode ser `nullptr`).
- Produces:
  - `struct ApprovalRequest { qint64 id = 0; QString sessionId, project, cwd, tool, command; }`; `enum class Decision { Allow, Deny, Release }`.
  - `class ApprovalQueue : QObject` com `using Reply = std::function<void(Decision)>`; `qint64 enqueue(ApprovalRequest, Reply)` (responde na hora se a regra "sempre" casa; devolve o id); `void cancel(qint64 id)` (hook morreu: remove **sem** chamar `Reply`); slots `allow()`, `deny()`, `always()`, `release()` (agem no pedido atual; `release` = "decido no editor": responde `Release` e não memoriza nada); `bool active()`, `int waiting()` (pedidos atrás do atual), `int pendingCount()`, `QString project()/tool()/command()` (do atual), `void setTimeoutMs(int)` (padrão `kDefaultTimeoutMs = 105000`), `int alwaysCount()`.
  - Sinais: `changed()`, `shown(const ApprovalRequest &)`, `resolved(const ApprovalRequest &, Decision)`. Ordem ao resolver: `changed` → `Reply` → `resolved` → `shown(próximo)`.
  - `static QString alwaysKey(const ApprovalRequest &)` = JSON `[cwd, tool, tool=="Bash" ? command : ""]`; persistida em `QSettings` (`approvals/always`).
  - Q_PROPERTY para QML: `active`, `project`, `tool`, `command`, `waiting` (todas `NOTIFY changed`).

- [ ] **Step 1: Escrever os testes**

`linux/tests/tst_approval_queue.cpp`:

```cpp
#include <QtTest>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include "ApprovalQueue.h"
#include "FakeScheduler.h"

using namespace coucou;

class TestApprovalQueue : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    FakeScheduler sched;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<ApprovalQueue> queue;

    static ApprovalRequest req(const char *tool = "Bash", const char *command = "ls", const char *cwd = "/p")
    {
        ApprovalRequest r;
        r.sessionId = "s1";
        r.project = "p";
        r.cwd = cwd;
        r.tool = tool;
        r.command = command;
        return r;
    }

private slots:
    void init()
    {
        QFile::remove(dir.path() + "/a.ini");
        sched = FakeScheduler();
        settings = std::make_unique<QSettings>(dir.path() + "/a.ini", QSettings::IniFormat);
        queue = std::make_unique<ApprovalQueue>(sched, settings.get());
    }

    void firstRequestIsShownSecondWaits()
    {
        QSignalSpy shown(queue.get(), &ApprovalQueue::shown);
        QList<Decision> got;
        queue->enqueue(req("Bash", "ls"), [&](Decision d) { got << d; });
        queue->enqueue(req("Bash", "pwd"), [&](Decision d) { got << d; });
        QCOMPARE(shown.count(), 1);
        QVERIFY(queue->active());
        QCOMPARE(queue->command(), QStringLiteral("ls"));
        QCOMPARE(queue->waiting(), 1);
        QCOMPARE(queue->pendingCount(), 2);
        QVERIFY(got.isEmpty());   // nobody decided anything
    }

    void allowRepliesResolvesAndShowsTheNext()
    {
        QSignalSpy shown(queue.get(), &ApprovalQueue::shown);
        QSignalSpy resolved(queue.get(), &ApprovalQueue::resolved);
        QList<Decision> first, second;
        queue->enqueue(req("Bash", "ls"), [&](Decision d) { first << d; });
        queue->enqueue(req("Bash", "pwd"), [&](Decision d) { second << d; });
        queue->allow();
        QCOMPARE(first, QList<Decision>{Decision::Allow});
        QVERIFY(second.isEmpty());
        QCOMPARE(resolved.count(), 1);
        QCOMPARE(shown.count(), 2);                       // the second one is now in front
        QCOMPARE(queue->command(), QStringLiteral("pwd"));
        queue->deny();
        QCOMPARE(second, QList<Decision>{Decision::Deny});
        QVERIFY(!queue->active());
        QCOMPARE(sched.pending(), 0);                     // timers cancelled
    }

    void decidingWithNothingPendingDoesNothing()
    {
        queue->allow();
        queue->deny();
        queue->always();
        QVERIFY(!queue->active());
    }

    void timeoutReleasesWithoutDeciding()
    {
        QList<Decision> got;
        QSignalSpy resolved(queue.get(), &ApprovalQueue::resolved);
        queue->enqueue(req(), [&](Decision d) { got << d; });
        sched.advance(ApprovalQueue::kDefaultTimeoutMs - 1);
        QVERIFY(got.isEmpty());
        sched.advance(1);
        QCOMPARE(got, QList<Decision>{Decision::Release});
        QCOMPARE(resolved.count(), 1);
        QVERIFY(!queue->active());
    }

    void cancelRemovesWithoutReplyAndShowsTheNext()
    {
        QSignalSpy shown(queue.get(), &ApprovalQueue::shown);
        QSignalSpy resolved(queue.get(), &ApprovalQueue::resolved);
        QList<Decision> got1, got2;
        const qint64 id1 = queue->enqueue(req("Bash", "a"), [&](Decision d) { got1 << d; });
        queue->enqueue(req("Bash", "b"), [&](Decision d) { got2 << d; });
        queue->cancel(id1);                               // the hook died: there is nobody to answer
        QVERIFY(got1.isEmpty());
        QCOMPARE(resolved.count(), 1);
        QCOMPARE(queue->command(), QStringLiteral("b"));
        QCOMPARE(shown.count(), 2);
        queue->cancel(id1);                               // unknown id: no-op
        QCOMPARE(resolved.count(), 1);
    }

    void cancelOfAWaitingRequestKeepsTheCurrentOne()
    {
        QSignalSpy shown(queue.get(), &ApprovalQueue::shown);
        queue->enqueue(req("Bash", "a"), [](Decision) {});
        const qint64 id2 = queue->enqueue(req("Bash", "b"), [](Decision) {});
        queue->cancel(id2);
        QCOMPARE(queue->command(), QStringLiteral("a"));
        QCOMPARE(queue->waiting(), 0);
        QCOMPARE(shown.count(), 1);
    }

    void alwaysAllowsNowAndAutoAnswersTheSameRequestLater()
    {
        QList<Decision> got;
        queue->enqueue(req("Bash", "make"), [&](Decision d) { got << d; });
        queue->always();
        QCOMPARE(got, QList<Decision>{Decision::Allow});
        QCOMPARE(queue->alwaysCount(), 1);

        QList<Decision> again;
        queue->enqueue(req("Bash", "make"), [&](Decision d) { again << d; });
        QCOMPARE(again, QList<Decision>{Decision::Allow});   // answered synchronously, no alert
        QVERIFY(!queue->active());

        QList<Decision> other;
        queue->enqueue(req("Bash", "rm -rf x"), [&](Decision d) { other << d; });   // Bash is per exact command
        QVERIFY(other.isEmpty());
        QVERIFY(queue->active());
    }

    void alwaysForNonBashIsPerToolAndProject()
    {
        queue->enqueue(req("Edit", "/p/a.cpp", "/p"), [](Decision) {});
        queue->always();
        QList<Decision> same, otherProject;
        queue->enqueue(req("Edit", "/p/b.cpp", "/p"), [&](Decision d) { same << d; });
        QCOMPARE(same, QList<Decision>{Decision::Allow});
        queue->enqueue(req("Edit", "/q/b.cpp", "/q"), [&](Decision d) { otherProject << d; });
        QVERIFY(otherProject.isEmpty());
    }

    void alwaysAlsoResolvesQueuedIdenticalRequests()
    {
        QList<Decision> a, b;
        queue->enqueue(req("Bash", "make"), [&](Decision d) { a << d; });
        queue->enqueue(req("Bash", "make"), [&](Decision d) { b << d; });
        queue->always();
        QCOMPARE(a, QList<Decision>{Decision::Allow});
        QCOMPARE(b, QList<Decision>{Decision::Allow});
        QVERIFY(!queue->active());
    }

    void alwaysListPersists()
    {
        queue->enqueue(req("Bash", "make"), [](Decision) {});
        queue->always();
        queue.reset();
        queue = std::make_unique<ApprovalQueue>(sched, settings.get());
        QCOMPARE(queue->alwaysCount(), 1);
        QList<Decision> got;
        queue->enqueue(req("Bash", "make"), [&](Decision d) { got << d; });
        QCOMPARE(got, QList<Decision>{Decision::Allow});
    }

    void releaseHandsTheDecisionBackToTheEditorAndRemembersNothing()
    {
        QList<Decision> got;
        queue->enqueue(req("Bash", "make"), [&](Decision d) { got << d; });
        queue->release();
        QCOMPARE(got, QList<Decision>{Decision::Release});
        QCOMPARE(queue->alwaysCount(), 0);
        QVERIFY(!queue->active());
        QList<Decision> again;
        queue->enqueue(req("Bash", "make"), [&](Decision d) { again << d; });
        QVERIFY(again.isEmpty());                          // still asks next time
        QVERIFY(queue->active());
    }

    void customTimeout()
    {
        queue->setTimeoutMs(1000);
        QList<Decision> got;
        queue->enqueue(req(), [&](Decision d) { got << d; });
        sched.advance(1000);
        QCOMPARE(got, QList<Decision>{Decision::Release});
    }

    void propertiesNotifyOnChange()
    {
        QSignalSpy changed(queue.get(), &ApprovalQueue::changed);
        queue->enqueue(req(), [](Decision) {});
        QVERIFY(changed.count() >= 1);
        QCOMPARE(queue->project(), QStringLiteral("p"));
        QCOMPARE(queue->tool(), QStringLiteral("Bash"));
    }
};

QTEST_MAIN(TestApprovalQueue)
#include "tst_approval_queue.moc"
```

- [ ] **Step 2: Rodar e ver falhar** (não compila)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_approval_queue 2>&1 | tail -5`

- [ ] **Step 3: Implementar**

`linux/src/core/ApprovalQueue.h`:

```cpp
#pragma once
#include "Scheduler.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QList>
#include <QObject>
#include <QSettings>
#include <QStringList>
#include <functional>

namespace coucou {

struct ApprovalRequest {
    qint64 id = 0;
    QString sessionId, project, cwd, tool, command;
};

// Release = "I did not decide": the hook prints nothing and Claude Code shows its own prompt.
enum class Decision { Allow, Deny, Release };

// FIFO of PermissionRequest hooks waiting for a click. One is in front (what the island shows); the rest wait.
class ApprovalQueue : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool active READ active NOTIFY changed)
    Q_PROPERTY(QString project READ project NOTIFY changed)
    Q_PROPERTY(QString tool READ tool NOTIFY changed)
    Q_PROPERTY(QString command READ command NOTIFY changed)
    Q_PROPERTY(int waiting READ waiting NOTIFY changed)

public:
    using Reply = std::function<void(Decision)>;
    // Below the hook's own 110 s wait, so the app releases first and the hook exits cleanly.
    static constexpr int kDefaultTimeoutMs = 105000;

    ApprovalQueue(IScheduler &scheduler, QSettings *settings, QObject *parent = nullptr);

    // Returns the request id. A request matching an "always allow" rule is answered (Allow) before returning
    // and never becomes visible.
    qint64 enqueue(ApprovalRequest request, Reply reply);
    // The hook went away (Claude Code killed it, the user answered in the editor): drop it, no reply.
    void cancel(qint64 id);

    bool active() const { return !m_entries.isEmpty(); }
    int pendingCount() const { return int(m_entries.size()); }
    int waiting() const { return m_entries.isEmpty() ? 0 : int(m_entries.size()) - 1; }
    QString project() const { return m_entries.isEmpty() ? QString() : m_entries.first().request.project; }
    QString tool() const { return m_entries.isEmpty() ? QString() : m_entries.first().request.tool; }
    QString command() const { return m_entries.isEmpty() ? QString() : m_entries.first().request.command; }
    int alwaysCount() const { return int(m_always.size()); }
    void setTimeoutMs(int ms) { m_timeoutMs = ms; }

    static QString alwaysKey(const ApprovalRequest &r);

public slots:
    void allow();
    void deny();
    void always();
    void release();

signals:
    void changed();
    void shown(const coucou::ApprovalRequest &request);
    void resolved(const coucou::ApprovalRequest &request, coucou::Decision decision);

private:
    struct Entry {
        ApprovalRequest request;
        Reply reply;
        int timer = 0;
    };
    void resolve(qint64 id, Decision decision, bool sendReply);

    IScheduler &m_sched;
    QSettings *m_settings;
    QList<Entry> m_entries;
    QStringList m_always;
    qint64 m_nextId = 0;
    int m_timeoutMs = kDefaultTimeoutMs;
};

} // namespace coucou
```

`linux/src/core/ApprovalQueue.cpp`:

```cpp
#include "ApprovalQueue.h"

namespace coucou {

namespace {
const QString kAlwaysKey = QStringLiteral("approvals/always");
}

ApprovalQueue::ApprovalQueue(IScheduler &scheduler, QSettings *settings, QObject *parent)
    : QObject(parent), m_sched(scheduler), m_settings(settings)
{
    if (m_settings)
        m_always = m_settings->value(kAlwaysKey).toStringList();
}

QString ApprovalQueue::alwaysKey(const ApprovalRequest &r)
{
    // Bash is approved per exact command; every other tool per tool and project.
    const QString pattern = r.tool == QLatin1String("Bash") ? r.command : QString();
    return QString::fromUtf8(QJsonDocument(QJsonArray{r.cwd, r.tool, pattern}).toJson(QJsonDocument::Compact));
}

qint64 ApprovalQueue::enqueue(ApprovalRequest request, Reply reply)
{
    request.id = ++m_nextId;
    if (m_always.contains(alwaysKey(request))) {
        reply(Decision::Allow);
        return request.id;
    }
    Entry e;
    e.request = request;
    e.reply = std::move(reply);
    const qint64 id = request.id;
    e.timer = m_sched.singleShot(m_timeoutMs, [this, id] { resolve(id, Decision::Release, true); });
    m_entries.append(std::move(e));
    emit changed();
    if (m_entries.size() == 1)
        emit shown(m_entries.first().request);
    return id;
}

void ApprovalQueue::cancel(qint64 id)
{
    resolve(id, Decision::Release, false);
}

void ApprovalQueue::allow()
{
    if (!m_entries.isEmpty())
        resolve(m_entries.first().request.id, Decision::Allow, true);
}

void ApprovalQueue::deny()
{
    if (!m_entries.isEmpty())
        resolve(m_entries.first().request.id, Decision::Deny, true);
}

void ApprovalQueue::release()
{
    if (!m_entries.isEmpty())
        resolve(m_entries.first().request.id, Decision::Release, true);
}

void ApprovalQueue::always()
{
    if (m_entries.isEmpty())
        return;
    const QString key = alwaysKey(m_entries.first().request);
    if (!m_always.contains(key)) {
        m_always << key;
        if (m_settings) {
            m_settings->setValue(kAlwaysKey, m_always);
            m_settings->sync();
        }
    }
    // The front one and every identical one still waiting behind it. Back to front, so no intermediate
    // request is "shown" (pinning the island) just to be resolved a moment later.
    QList<qint64> ids;
    for (const Entry &e : std::as_const(m_entries))
        if (alwaysKey(e.request) == key)
            ids << e.request.id;
    for (qsizetype k = ids.size() - 1; k >= 0; --k)
        resolve(ids.at(k), Decision::Allow, true);
}

void ApprovalQueue::resolve(qint64 id, Decision decision, bool sendReply)
{
    int i = -1;
    for (int k = 0; k < m_entries.size(); ++k)
        if (m_entries.at(k).request.id == id)
            i = k;
    if (i < 0)
        return;
    Entry e = m_entries.takeAt(i);
    m_sched.cancel(e.timer);
    const bool wasFront = i == 0;
    emit changed();
    if (sendReply && e.reply)
        e.reply(decision);
    emit resolved(e.request, decision);
    if (wasFront && !m_entries.isEmpty())
        emit shown(m_entries.first().request);
}

} // namespace coucou
```

Registrar em `linux/src/core/CMakeLists.txt` (`ApprovalQueue.h ApprovalQueue.cpp`) e em `linux/tests/CMakeLists.txt` (`coucou_add_test(tst_approval_queue)`).

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build --target tst_approval_queue && linux/scripts/host.sh linux/build/tests/tst_approval_queue`
Expected: todos PASS. Nota: `FakeScheduler` é copiável? Se `sched = FakeScheduler();` não compilar (membro `std::vector` de lambdas é movível), troque para `sched.~FakeScheduler(); new (&sched) FakeScheduler();` ou torne `sched` um `std::unique_ptr<FakeScheduler>` como nos outros testes.

- [ ] **Step 5: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux(L2): ApprovalQueue with timeout, cancel and always-allow rules

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 6: `ClaudeSessions` — evento do hook → `AppState` e ilha

**Files:**
- Create: `linux/src/core/JumpTarget.h`, `linux/src/core/ClaudeSessions.h`, `linux/src/core/ClaudeSessions.cpp`, `linux/tests/tst_claude_sessions.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/tests/CMakeLists.txt` (`coucou_add_test(tst_claude_sessions)`)

**Interfaces:**
- Consumes: `HookEvent`, `stepLabel`, `clip`, `ApprovalQueue`, `AppState` (`addTask`, `removeTask`, `setFocus`, `updateTask`, `modifyTask`, `setPinned`, `setView`, `view()`, `mode()`, `focusId()`, `taskModel()`), `IslandController` (`reveal()`, `expand(IslandView)`, `defaultView()`), `IScheduler`, `integrationAgents()`.
- Produces:
  - `struct JumpTarget { QString source, cwd, flatpakId, konsoleService, konsoleSession, konsoleWindow; }` (`Q_DECLARE_METATYPE` não é necessário).
  - `class ClaudeSessions : QObject`: `static QString taskId(const QString &sessionId)` = `"session_" + id`; `void handleEvent(const HookEvent &)` (todos os eventos exceto `PermissionRequest`); `qint64 handlePermission(const HookEvent &, ApprovalQueue::Reply)` (devolve o id do pedido); `int sessionCount() const`; `Q_INVOKABLE void jump(const QString &taskId)`; constantes `kExpiryMs = 30*60*1000`, `kFinishedMs = 5200`.
  - Sinais: `playSound(const QString &name)`, `jumpRequested(const coucou::JumpTarget &target)`.
- Comportamento (resumo; os testes abaixo são a especificação):
  - Uma `AgentTask` por `session_id` (`id = "session_<sid>"`, nome = pasta do `cwd`, cor da paleta `#34D399 #22D3EE #F59E0B #A78BFA #F472B6 #60A5FA`). A 1ª sessão remove a pílula-espaço `integration_claude` ("VS Code"); quando a última termina, ela volta.
  - `SessionStart`: Idle + som `work` + `reveal()`. `UserPromptSubmit`: Thinking + passo (prompt, 60 car.) + foco (só se o foco atual não é outra sessão ocupada) + `reveal()`. `PreToolUse`: Working + passo; `AskUserQuestion` → estado Question, `alertText`/`options`, som `question`, foco e `expand(Question)` (sem fixar). `PostToolUse`: Working (limpa pergunta respondida e volta a view Question para Overview). `PostToolUseFailure`: Working + passo `⚠ failed`. `Notification`: `rate…`/"rate limit"/"usage limit" → Ratelimit + som `rate`; `elicitation_dialog` ou mensagem terminada em `?` → Question. `Stop`: Finished + `alertText` (1ª linha de `last_assistant_message`, até 120 car., ou "Session finished") + som `finish` + foco + `expand(Finished)` (se não há aprovação na frente) e, após 5,2 s, volta a Idle. `StopFailure`: Error + som `error` + foco + `expand(Error)`. `SubagentStart/Stop`: passos `+ subagent` / `• subagent done`. `SessionEnd`: remove.
  - Passos: no máximo 20 (`stepIndex` = último). Sessão sem evento por 30 min é removida.
  - Aprovação: `shown` → estado Approval, foco, `setPinned(true)`, som `approval`, `expand(Approval)`. `resolved` → Working; som `approve` se Allow; se a fila esvaziou: `setPinned(false)` e, se a view Approval estava na tela, `expand(defaultView())`.

- [ ] **Step 1: Escrever os testes**

`linux/tests/tst_claude_sessions.cpp`:

```cpp
#include <QtTest>
#include <QJsonArray>
#include <QJsonDocument>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "AppState.h"
#include "ApprovalQueue.h"
#include "ClaudeSessions.h"
#include "FakeScheduler.h"
#include "IslandController.h"

using namespace coucou;

static HookEvent ev(const QString &name, const QString &sid = "s1", const QString &cwd = "/home/u/proj",
                    const QJsonObject &extra = {})
{
    QJsonObject o = extra;
    o["hook_event_name"] = name;
    o["session_id"] = sid;
    o["cwd"] = cwd;
    return *HookEvent::parse(QJsonDocument(o).toJson(QJsonDocument::Compact));
}

class TestClaudeSessions : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandController> ctl;
    std::unique_ptr<ApprovalQueue> queue;
    std::unique_ptr<ClaudeSessions> sessions;
    std::unique_ptr<QSignalSpy> sounds;

    const AgentTask *task(const QString &sid) const { return state->taskModel()->find(ClaudeSessions::taskId(sid)); }
    QStringList soundList() const
    {
        QStringList out;
        for (const auto &a : *sounds)
            out << a.at(0).toString();
        return out;
    }

private slots:
    void init()
    {
        QFile::remove(dir.path() + "/c.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/c.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        sched = std::make_unique<FakeScheduler>();
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [] { return qint64(0); });
        queue = std::make_unique<ApprovalQueue>(*sched, settings.get());
        sessions = std::make_unique<ClaudeSessions>(state.get(), ctl.get(), sched.get(), queue.get());
        sounds = std::make_unique<QSignalSpy>(sessions.get(), &ClaudeSessions::playSound);
    }

    void firstSessionReplacesThePlaceholderAndTakesFocus()
    {
        QVERIFY(state->taskModel()->find("integration_claude"));
        sessions->handleEvent(ev("SessionStart"));
        QVERIFY(!state->taskModel()->find("integration_claude"));
        const AgentTask *t = task("s1");
        QVERIFY(t);
        QCOMPARE(t->name, QStringLiteral("proj"));
        QCOMPARE(t->color, QStringLiteral("#34D399"));
        QVERIFY(!t->isIntegration);
        QCOMPARE(state->focusId(), ClaudeSessions::taskId("s1"));
        QCOMPARE(sessions->sessionCount(), 1);
        QVERIFY(state->mode() == IslandMode::Compact);
        QCOMPARE(soundList(), QStringList{"work"});
    }

    void lastSessionEndingBringsThePlaceholderBack()
    {
        sessions->handleEvent(ev("SessionStart"));
        sessions->handleEvent(ev("SessionEnd"));
        QVERIFY(!task("s1"));
        QVERIFY(state->taskModel()->find("integration_claude"));
        QCOMPARE(state->focusId(), QStringLiteral("integration_claude"));
        QCOMPARE(sessions->sessionCount(), 0);
        sessions->handleEvent(ev("SessionEnd", "never-started"));   // unknown session: ignored
    }

    void twoSessionsInTheSameFolderStayDistinctWithDifferentColors()
    {
        sessions->handleEvent(ev("SessionStart", "a", "/w/app"));
        sessions->handleEvent(ev("SessionStart", "b", "/w/app"));
        QCOMPARE(sessions->sessionCount(), 2);
        QVERIFY(task("a") && task("b"));
        QVERIFY(task("a")->color != task("b")->color);
        QCOMPARE(task("a")->name, task("b")->name);
        sessions->handleEvent(ev("SessionEnd", "a"));
        QVERIFY(!state->taskModel()->find("integration_claude"));   // one session is still alive
        QCOMPARE(state->focusId(), ClaudeSessions::taskId("b"));   // focus moved to the survivor
    }

    void anyEventCreatesTheSessionAndMissingCwdKeepsTheName()
    {
        sessions->handleEvent(ev("PostToolUse", "late", "/w/first"));        // hooks installed mid-session
        QCOMPARE(task("late")->name, QStringLiteral("first"));
        sessions->handleEvent(ev("PostToolUse", "late", ""));                // an event without cwd
        QCOMPARE(task("late")->name, QStringLiteral("first"));
        sessions->handleEvent(ev("PostToolUse", "nocwd", ""));
        QCOMPARE(task("nocwd")->name, QStringLiteral("Session"));
        sessions->handleEvent(ev("PostToolUse", "nocwd", "/w/now"));
        QCOMPARE(task("nocwd")->name, QStringLiteral("now"));
    }

    void promptAndToolEventsDriveStateAndSteps()
    {
        sessions->handleEvent(ev("UserPromptSubmit", "s1", "/p", {{"prompt", "fix the login bug\nplease"}}));
        QVERIFY(task("s1")->state == BotState::Thinking);
        QCOMPARE(task("s1")->steps.last(), QStringLiteral("fix the login bug please"));
        sessions->handleEvent(ev("PreToolUse", "s1", "/p", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "npm test"}}}}));
        QVERIFY(task("s1")->state == BotState::Working);
        QCOMPARE(task("s1")->steps.last(), QStringLiteral("Runs · npm test"));
        sessions->handleEvent(ev("PostToolUseFailure"));
        QCOMPARE(task("s1")->steps.last(), QStringLiteral("⚠ failed"));
        QVERIFY(task("s1")->state == BotState::Working);
        sessions->handleEvent(ev("SubagentStart"));
        sessions->handleEvent(ev("SubagentStop"));
        QCOMPARE(task("s1")->steps.mid(task("s1")->steps.size() - 2), (QStringList{"+ subagent", "• subagent done"}));
    }

    void stepsAreCappedAtTwenty()
    {
        for (int i = 0; i < 30; ++i)
            sessions->handleEvent(ev("PreToolUse", "s1", "/p", {{"tool_name", "Read"}, {"tool_input", QJsonObject{{"file_path", QString("/a/f%1").arg(i)}}}}));
        QCOMPARE(task("s1")->steps.size(), 20);
        QCOMPARE(task("s1")->stepIndex, 19);
        QCOMPARE(task("s1")->steps.last(), QStringLiteral("Reads · f29"));
    }

    void stopShowsTheFinishedViewThenGoesIdle()
    {
        sounds->clear();
        sessions->handleEvent(ev("Stop", "s1", "/p", {{"last_assistant_message", "All done.\nSecond line"}}));
        QVERIFY(task("s1")->state == BotState::Finished);
        QCOMPARE(task("s1")->alertText, QStringLiteral("All done."));
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Finished);
        QVERIFY(soundList().contains("finish"));
        sched->advance(ClaudeSessions::kFinishedMs);
        QVERIFY(task("s1")->state == BotState::Idle);
        QVERIFY(task("s1")->alertText.isEmpty());
    }

    void stopWithoutAMessageUsesTheDefaultText()
    {
        sessions->handleEvent(ev("Stop"));
        QCOMPARE(task("s1")->alertText, QStringLiteral("Session finished"));
    }

    void stopFailureShowsTheErrorView()
    {
        sounds->clear();
        sessions->handleEvent(ev("StopFailure", "s1", "/p", {{"message", "API error"}}));
        QVERIFY(task("s1")->state == BotState::Error);
        QVERIFY(state->view() == IslandView::Error);
        QCOMPARE(task("s1")->alertText, QStringLiteral("API error"));
        QVERIFY(soundList().contains("error"));
    }

    void askUserQuestionShowsTheQuestionViewAndIsDismissedByTheNextEvent()
    {
        const QJsonObject input{{"questions", QJsonArray{QJsonObject{
            {"question", "Which search engine?"},
            {"options", QJsonArray{QJsonObject{{"label", "Postgres"}}, QJsonObject{{"label", "Meilisearch"}}}}}}}};
        sessions->handleEvent(ev("PreToolUse", "s1", "/p", {{"tool_name", "AskUserQuestion"}, {"tool_input", input}}));
        QVERIFY(task("s1")->state == BotState::Question);
        QCOMPARE(task("s1")->alertText, QStringLiteral("Which search engine?"));
        QCOMPARE(task("s1")->options, (QStringList{"Postgres", "Meilisearch"}));
        QVERIFY(state->view() == IslandView::Question);
        QVERIFY(!state->isPinned());
        sessions->handleEvent(ev("PostToolUse"));                       // answered in the editor
        QVERIFY(task("s1")->state == BotState::Working);
        QVERIFY(task("s1")->options.isEmpty());
        QVERIFY(state->view() == IslandView::Overview);
    }

    void notificationsRateLimitAndQuestions()
    {
        sessions->handleEvent(ev("Notification", "s1", "/p", {{"message", "Claude usage limit reached"}}));
        QVERIFY(task("s1")->state == BotState::Ratelimit);
        sessions->handleEvent(ev("Notification", "s1", "/p", {{"message", "Claude is waiting for your input"}, {"notification_type", "idle_prompt"}}));
        QVERIFY(task("s1")->state == BotState::Ratelimit);             // not a question: untouched
        sessions->handleEvent(ev("Notification", "s1", "/p", {{"message", "Which file?"}}));
        QVERIFY(task("s1")->state == BotState::Question);
    }

    void permissionFlowPinsTheIslandAndClickResolves()
    {
        sounds->clear();
        QList<Decision> got;
        sessions->handlePermission(ev("PermissionRequest", "s1", "/p", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "rm -rf build"}}}}),
                                   [&](Decision d) { got << d; });
        QVERIFY(task("s1")->state == BotState::Approval);
        QVERIFY(state->isPinned());
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Approval);
        QCOMPARE(state->focusId(), ClaudeSessions::taskId("s1"));
        QCOMPARE(queue->command(), QStringLiteral("rm -rf build"));
        QVERIFY(soundList().contains("approval"));
        QVERIFY(got.isEmpty());                                        // never decided without a click

        queue->allow();
        QCOMPARE(got, QList<Decision>{Decision::Allow});
        QVERIFY(!state->isPinned());
        QVERIFY(task("s1")->state == BotState::Working);
        QVERIFY(state->view() == IslandView::Overview);
        QVERIFY(soundList().contains("approve"));
    }

    void permissionForNonBashShowsTheFilePath()
    {
        sessions->handlePermission(ev("PermissionRequest", "s1", "/p", {{"tool_name", "Edit"}, {"tool_input", QJsonObject{{"file_path", "/p/src/a.cpp"}}}}), [](Decision) {});
        QCOMPARE(queue->command(), QStringLiteral("/p/src/a.cpp"));
        QCOMPARE(queue->tool(), QStringLiteral("Edit"));
    }

    void twoPermissionsAreQueuedAndTheIslandStaysPinnedUntilBothAreAnswered()
    {
        sessions->handlePermission(ev("PermissionRequest", "s1", "/p", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "a"}}}}), [](Decision) {});
        sessions->handlePermission(ev("PermissionRequest", "s2", "/q", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "b"}}}}), [](Decision) {});
        QCOMPARE(queue->waiting(), 1);
        queue->deny();
        QVERIFY(state->isPinned());                                    // the second one is still waiting
        QCOMPARE(state->focusId(), ClaudeSessions::taskId("s2"));
        queue->allow();
        QVERIFY(!state->isPinned());
    }

    void cancelledPermissionUnpins()
    {
        const qint64 id = sessions->handlePermission(ev("PermissionRequest", "s1", "/p", {{"tool_name", "Bash"}}), [](Decision) {});
        queue->cancel(id);                                             // Claude Code killed the hook
        QVERIFY(!state->isPinned());
        QVERIFY(task("s1")->state == BotState::Working);
        QVERIFY(state->view() == IslandView::Overview);
    }

    void autoAllowedPermissionNeverAppears()
    {
        sessions->handlePermission(ev("PermissionRequest", "s1", "/p", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "make"}}}}), [](Decision) {});
        queue->always();
        state->setPinned(false);
        QList<Decision> got;
        sessions->handlePermission(ev("PermissionRequest", "s1", "/p", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "make"}}}}), [&](Decision d) { got << d; });
        QCOMPARE(got, QList<Decision>{Decision::Allow});
        QVERIFY(!state->isPinned());
    }

    void silentSessionsExpireAfterThirtyMinutes()
    {
        sessions->handleEvent(ev("SessionStart", "ghost"));
        sched->advance(ClaudeSessions::kExpiryMs - 1);
        QVERIFY(task("ghost"));
        sched->advance(1);
        QVERIFY(!task("ghost"));
        QVERIFY(state->taskModel()->find("integration_claude"));       // placeholder is back
    }

    void activityRearmsTheExpiry()
    {
        sessions->handleEvent(ev("SessionStart", "live"));
        sched->advance(ClaudeSessions::kExpiryMs - 1000);
        sessions->handleEvent(ev("PostToolUse", "live"));
        sched->advance(ClaudeSessions::kExpiryMs - 1000);
        QVERIFY(task("live"));
    }

    void jumpEmitsTheSessionContext()
    {
        QSignalSpy jump(sessions.get(), &ClaudeSessions::jumpRequested);
        sessions->handleEvent(ev("SessionStart", "s1", "/w/app", {{"coucou_source", "vscodium"}, {"flatpak_id", "com.vscodium.codium"}}));
        sessions->jump(ClaudeSessions::taskId("s1"));
        QCOMPARE(jump.count(), 1);
        const auto target = jump.first().first().value<JumpTarget>();
        QCOMPARE(target.source, QStringLiteral("vscodium"));
        QCOMPARE(target.cwd, QStringLiteral("/w/app"));
        QCOMPARE(target.flatpakId, QStringLiteral("com.vscodium.codium"));
        sessions->jump("session_unknown");
        sessions->jump("integration_claude");
        QCOMPARE(jump.count(), 1);
    }

    void eventsWhileTheIslandIsHiddenPeekIt()
    {
        state->setMode(IslandMode::Hidden);
        sessions->handleEvent(ev("UserPromptSubmit", "s1", "/p", {{"prompt", "hi"}}));
        QVERIFY(state->mode() != IslandMode::Hidden);
    }
};

QTEST_MAIN(TestClaudeSessions)
#include "tst_claude_sessions.moc"
```

Nota: `jump.first().first().value<JumpTarget>()` exige `Q_DECLARE_METATYPE(coucou::JumpTarget)` — declare-o em `JumpTarget.h` (abaixo) para o `QSignalSpy`.

- [ ] **Step 2: Rodar e ver falhar** (não compila)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_claude_sessions 2>&1 | tail -5`

- [ ] **Step 3: Implementar**

`linux/src/core/JumpTarget.h`:

```cpp
#pragma once
#include <QMetaType>
#include <QString>

namespace coucou {

// Where a Claude Code session lives, so the island can take the user back to it.
struct JumpTarget {
    QString source;   // "vscodium" | "konsole" | "terminal"
    QString cwd;
    QString flatpakId;
    QString konsoleService, konsoleSession, konsoleWindow;
};

} // namespace coucou

Q_DECLARE_METATYPE(coucou::JumpTarget)
```

`linux/src/core/ClaudeSessions.h`:

```cpp
#pragma once
#include "ApprovalQueue.h"
#include "HookEvent.h"
#include "JumpTarget.h"
#include "Scheduler.h"

#include <QHash>
#include <QObject>
#include <QStringList>

namespace coucou {

class AppState;
class IslandController;

// Turns hook events into island state: one AgentTask ("pill") per Claude Code session, alerts (question, finished,
// error) and permission requests. Port of HookServer.processEvent in the Swift app, with one pill per session
// instead of the single permanent "VS Code" pill (deliberate divergence, see the L2 plan).
class ClaudeSessions : public QObject {
    Q_OBJECT
public:
    static constexpr int kExpiryMs = 30 * 60 * 1000;   // a session that never says SessionEnd is dropped
    static constexpr int kFinishedMs = 5200;           // Swift: the finished state lasts 5.2 s

    ClaudeSessions(AppState *state, IslandController *controller, IScheduler *scheduler, ApprovalQueue *queue,
                   QObject *parent = nullptr);

    static QString taskId(const QString &sessionId) { return QStringLiteral("session_") + sessionId; }
    int sessionCount() const { return int(m_sessions.size()); }

    void handleEvent(const HookEvent &e);   // every event except PermissionRequest
    // Returns the request id (HookServer cancels it if the hook disconnects).
    qint64 handlePermission(const HookEvent &e, ApprovalQueue::Reply reply);
    Q_INVOKABLE void jump(const QString &taskId);

signals:
    void playSound(const QString &name);
    void jumpRequested(const coucou::JumpTarget &target);

private:
    struct Session {
        JumpTarget jump;
        int expiry = 0;
        int finish = 0;
    };
    void ensure(const HookEvent &e);
    void touch(const QString &sid);
    void end(const QString &sid);
    void setState(const QString &sid, BotState state);
    void appendStep(const QString &sid, const QString &step);
    void dismissStale(const QString &sid);
    void focus(const QString &sid);
    void focusUnlessBusy(const QString &sid);
    void showQuestion(const QString &sid, const QString &text, const QStringList &options);
    void onStop(const QString &sid, const HookEvent &e);
    void onShown(const ApprovalRequest &r);
    void onResolved(const ApprovalRequest &r, Decision decision);
    QString nextColor() const;

    AppState *m_state;
    IslandController *m_controller;
    IScheduler *m_sched;
    ApprovalQueue *m_queue;
    QHash<QString, Session> m_sessions;
    QStringList m_order;   // session ids, most recently focused first
};

} // namespace coucou
```

`linux/src/core/ClaudeSessions.cpp`:

```cpp
#include "ClaudeSessions.h"

#include "AppState.h"
#include "IslandController.h"

#include <QJsonArray>

namespace coucou {

namespace {
const QString kClaudeId = QStringLiteral("integration_claude");
const QStringList kPalette = {"#34D399", "#22D3EE", "#F59E0B", "#A78BFA", "#F472B6", "#60A5FA"};

QString firstLine(const QString &s, int max) { return clip(s.trimmed().section('\n', 0, 0), max); }

// What the approval card shows: the command for Bash, otherwise the most telling field of the tool input.
QString approvalCommand(const HookEvent &e)
{
    for (const char *key : {"command", "file_path", "path", "url", "pattern", "query"}) {
        const QString v = e.toolInput.value(QLatin1String(key)).toString();
        if (!v.isEmpty())
            return v.left(400);
    }
    return e.toolName.isEmpty() ? QStringLiteral("Tool") : e.toolName;
}
} // namespace

ClaudeSessions::ClaudeSessions(AppState *state, IslandController *controller, IScheduler *scheduler,
                               ApprovalQueue *queue, QObject *parent)
    : QObject(parent), m_state(state), m_controller(controller), m_sched(scheduler), m_queue(queue)
{
    connect(m_queue, &ApprovalQueue::shown, this, &ClaudeSessions::onShown);
    connect(m_queue, &ApprovalQueue::resolved, this, &ClaudeSessions::onResolved);
}

QString ClaudeSessions::nextColor() const
{
    QStringList used;
    for (const AgentTask &t : m_state->taskModel()->all())
        used << t.color;
    for (const QString &c : kPalette)
        if (!used.contains(c, Qt::CaseInsensitive))
            return c;
    return kPalette.at(int(m_sessions.size()) % kPalette.size());
}

void ClaudeSessions::ensure(const HookEvent &e)
{
    const QString sid = e.sessionId;
    if (!m_sessions.contains(sid)) {
        AgentTask t;
        t.id = taskId(sid);
        t.name = e.project();
        t.color = nextColor();
        t.source = AgentSource::ClaudeCode;
        t.isIntegration = false;
        t.sessionCwd = e.cwd;
        const bool first = m_sessions.isEmpty();
        m_sessions.insert(sid, Session{});
        m_order.append(sid);
        m_state->addTask(t);
        if (first) {
            m_state->removeTask(kClaudeId);   // the "VS Code" placeholder gives way to real sessions
            m_state->setFocus(t.id);
        }
    } else if (!e.cwd.isEmpty()) {
        m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
            t.name = e.project();
            t.sessionCwd = e.cwd;
        });
    }
    Session &s = m_sessions[sid];
    s.jump = {e.source, e.cwd.isEmpty() ? s.jump.cwd : e.cwd, e.flatpakId, e.konsoleService, e.konsoleSession, e.konsoleWindow};
    touch(sid);
}

void ClaudeSessions::touch(const QString &sid)
{
    Session &s = m_sessions[sid];
    m_sched->cancel(s.expiry);
    s.expiry = m_sched->singleShot(kExpiryMs, [this, sid] {
        if (m_sessions.contains(sid))
            end(sid);
    });
}

void ClaudeSessions::end(const QString &sid)
{
    const Session s = m_sessions.take(sid);
    m_sched->cancel(s.expiry);
    m_sched->cancel(s.finish);
    m_order.removeAll(sid);
    const bool wasFocus = m_state->focusId() == taskId(sid);
    if (m_sessions.isEmpty())
        m_state->addTask(integrationAgents().first());   // the placeholder is back while nothing runs
    m_state->removeTask(taskId(sid));
    if (wasFocus)
        m_state->setFocus(m_order.isEmpty() ? kClaudeId : taskId(m_order.first()));
}

void ClaudeSessions::setState(const QString &sid, BotState state) { m_state->updateTask(taskId(sid), state); }

void ClaudeSessions::appendStep(const QString &sid, const QString &step)
{
    m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
        t.steps.append(step);
        while (t.steps.size() > 20)
            t.steps.removeFirst();
        t.stepIndex = int(t.steps.size()) - 1;
    });
}

// A later event from the same session means the question was answered in the editor.
void ClaudeSessions::dismissStale(const QString &sid)
{
    const AgentTask *t = m_state->taskModel()->find(taskId(sid));
    if (!t || (t->alertText.isEmpty() && t->options.isEmpty()))
        return;
    const bool wasQuestion = t->state == BotState::Question;
    m_state->modifyTask(taskId(sid), [](AgentTask &x) {
        x.alertText.clear();
        x.options.clear();
    });
    if (wasQuestion && m_state->focusId() == taskId(sid) && m_state->view() == IslandView::Question)
        m_state->setView(IslandView::Overview);
}

void ClaudeSessions::focus(const QString &sid)
{
    m_order.removeAll(sid);
    m_order.prepend(sid);
    m_state->setFocus(taskId(sid));
}

void ClaudeSessions::focusUnlessBusy(const QString &sid)
{
    const AgentTask *cur = m_state->taskModel()->find(m_state->focusId());
    const bool curIsLiveSession = cur && cur->id.startsWith(QLatin1String("session_")) &&
                                  m_sessions.contains(cur->id.mid(8));
    if (!cur || !curIsLiveSession || cur->state == BotState::Idle)
        focus(sid);
}

void ClaudeSessions::showQuestion(const QString &sid, const QString &text, const QStringList &options)
{
    setState(sid, BotState::Question);
    m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
        t.alertText = text;
        t.options = options;
    });
    emit playSound(QStringLiteral("question"));
    focus(sid);
    if (!m_queue->active())
        m_controller->expand(IslandView::Question);
}

void ClaudeSessions::onStop(const QString &sid, const HookEvent &e)
{
    const QString summary = firstLine(e.lastAssistantMessage, 120);
    setState(sid, BotState::Finished);
    m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
        t.alertText = summary.isEmpty() ? QStringLiteral("Session finished") : summary;
    });
    if (!summary.isEmpty())
        appendStep(sid, clip(summary, 60));
    emit playSound(QStringLiteral("finish"));
    focus(sid);
    if (!m_queue->active())
        m_controller->expand(IslandView::Finished);
    Session &s = m_sessions[sid];
    m_sched->cancel(s.finish);
    s.finish = m_sched->singleShot(kFinishedMs, [this, sid] {
        const AgentTask *t = m_state->taskModel()->find(taskId(sid));
        if (!t || t->state != BotState::Finished)
            return;
        setState(sid, BotState::Idle);
        m_state->modifyTask(taskId(sid), [](AgentTask &x) { x.alertText.clear(); });
    });
}

void ClaudeSessions::handleEvent(const HookEvent &e)
{
    if (e.name == QLatin1String("SessionEnd")) {
        if (m_sessions.contains(e.sessionId))
            end(e.sessionId);
        return;
    }
    ensure(e);
    const QString sid = e.sessionId;

    if (e.name == QLatin1String("SessionStart")) {
        setState(sid, BotState::Idle);
        emit playSound(QStringLiteral("work"));
    } else if (e.name == QLatin1String("UserPromptSubmit")) {
        dismissStale(sid);
        setState(sid, BotState::Thinking);
        if (!e.prompt.isEmpty())
            appendStep(sid, clip(e.prompt, 60));
        focusUnlessBusy(sid);
    } else if (e.name == QLatin1String("PreToolUse")) {
        if (e.toolName == QLatin1String("AskUserQuestion")) {
            const QJsonArray questions = e.toolInput.value("questions").toArray();
            const QJsonObject q = questions.isEmpty() ? QJsonObject() : questions.first().toObject();
            QStringList options;
            for (const QJsonValue &o : q.value("options").toArray())
                options << o.toObject().value("label").toString();
            showQuestion(sid, clip(q.value("question").toString(), 200), options);
        } else {
            dismissStale(sid);
            setState(sid, BotState::Working);
            appendStep(sid, stepLabel(e.toolName, e.toolInput));
        }
    } else if (e.name == QLatin1String("PostToolUse")) {
        dismissStale(sid);
        setState(sid, BotState::Working);
    } else if (e.name == QLatin1String("PostToolUseFailure")) {
        setState(sid, BotState::Working);
        appendStep(sid, QStringLiteral("⚠ failed"));
    } else if (e.name == QLatin1String("Notification")) {
        const QString lower = e.message.toLower();
        if (e.notificationType.startsWith(QLatin1String("rate")) || lower.contains(QLatin1String("rate limit")) ||
            lower.contains(QLatin1String("usage limit"))) {
            setState(sid, BotState::Ratelimit);
            emit playSound(QStringLiteral("rate"));
        } else if (e.notificationType == QLatin1String("elicitation_dialog") || e.message.trimmed().endsWith('?')) {
            showQuestion(sid, clip(e.message, 200), {});
        }
    } else if (e.name == QLatin1String("Stop")) {
        onStop(sid, e);
    } else if (e.name == QLatin1String("StopFailure")) {
        setState(sid, BotState::Error);
        m_state->modifyTask(taskId(sid), [&](AgentTask &t) {
            t.alertText = e.message.isEmpty() ? QStringLiteral("Claude Code stopped with an error") : clip(e.message, 200);
        });
        emit playSound(QStringLiteral("error"));
        focus(sid);
        m_controller->expand(IslandView::Error);
    } else if (e.name == QLatin1String("SubagentStart")) {
        appendStep(sid, QStringLiteral("+ subagent"));
    } else if (e.name == QLatin1String("SubagentStop")) {
        appendStep(sid, QStringLiteral("• subagent done"));
    }
    m_controller->reveal();   // no-op unless the island is hidden: a peek, never an expansion
}

qint64 ClaudeSessions::handlePermission(const HookEvent &e, ApprovalQueue::Reply reply)
{
    ensure(e);
    ApprovalRequest r;
    r.sessionId = e.sessionId;
    r.project = e.project();
    r.cwd = e.cwd;
    r.tool = e.toolName.isEmpty() ? QStringLiteral("Tool") : e.toolName;
    r.command = approvalCommand(e);
    return m_queue->enqueue(r, std::move(reply));
}

void ClaudeSessions::onShown(const ApprovalRequest &r)
{
    if (!m_sessions.contains(r.sessionId))
        return;
    setState(r.sessionId, BotState::Approval);
    focus(r.sessionId);
    m_state->setPinned(true);                       // before expand(): a pinned alert arms no idle timer
    emit playSound(QStringLiteral("approval"));
    m_controller->expand(IslandView::Approval);
}

void ClaudeSessions::onResolved(const ApprovalRequest &r, Decision decision)
{
    if (m_sessions.contains(r.sessionId))
        setState(r.sessionId, BotState::Working);
    if (decision == Decision::Allow)
        emit playSound(QStringLiteral("approve"));
    if (m_queue->active())
        return;                                      // the next request is shown next
    const bool showing = m_state->mode() == IslandMode::Expanded && m_state->view() == IslandView::Approval;
    m_state->setPinned(false);
    if (showing)
        m_controller->expand(m_controller->defaultView());   // back to the overview; restarts the idle timer
}

void ClaudeSessions::jump(const QString &id)
{
    if (!id.startsWith(QLatin1String("session_")))
        return;
    const auto it = m_sessions.constFind(id.mid(8));
    if (it != m_sessions.constEnd())
        emit jumpRequested(it->jump);
}

} // namespace coucou
```

Notas de implementação: (a) em `ensure`, `Session &s = m_sessions[sid]` vem depois de todo `insert`/`addTask`, então a referência não é invalidada; (b) `reveal()` no fim de `handleEvent` cobre `SessionStart`, prompt, ferramentas etc.; (c) `first ? removeTask(kClaudeId)` roda **depois** de `addTask`, para a lista nunca ficar vazia (sem piscar `Hidden→Compact`).

Registrar `ClaudeSessions.h ClaudeSessions.cpp JumpTarget.h` em `linux/src/core/CMakeLists.txt` e `coucou_add_test(tst_claude_sessions)` em `linux/tests/CMakeLists.txt`.

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: tudo passa. Se `eventsWhileTheIslandIsHiddenPeekIt` falhar porque a FSM está em `Hidden` mas o `AppState` já estava `Compact`, ajuste o teste para checar `sounds` conter `peek` no `IslandController` (ver `hoverFromHiddenPeeksWithSound` em `tst_island_controller.cpp`); não mude o comportamento.

- [ ] **Step 5: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux(L2): ClaudeSessions maps hook events to per-session pills and alerts

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```


### Task 7: `HookServer` (socket Unix, protocolo de linha, instância única)

**Files:**
- Create: `linux/src/platform/HookServer.h`, `linux/src/platform/HookServer.cpp`, `linux/tests/tst_hook_server.cpp`
- Modify: `linux/src/platform/CMakeLists.txt` (fontes + `Qt6::Network`), `linux/tests/CMakeLists.txt` (dentro do `if(TARGET coucou_platform)`)

**Interfaces:**
- Consumes: `ClaudeSessions::handleEvent/handlePermission`, `ApprovalQueue::cancel`, `HookEvent::parse`, `Paths::fitsUnixSocket/ensurePrivateDir`.
- Produces: `class coucou::HookServer : QObject` com `enum class StartResult { Started, AlreadyRunning, Failed }`, `StartResult start(const QString &socketPath)`, `QString errorString() const`, `static constexpr int kMaxLine = 1 << 20`.
- Protocolo: o cliente envia uma linha JSON terminada em `\n`. Eventos comuns: o servidor processa e fecha. `PermissionRequest`: a conexão fica aberta até `ApprovalQueue` responder; o servidor escreve `{"decision":"allow"}` / `{"decision":"deny","message":"Denied from the Coucou island"}` / `{"decision":"release"}` e fecha. Cliente que desconecta com pedido pendente → `ApprovalQueue::cancel(id)`.
- Segurança: pasta `0700` (`Paths::ensurePrivateDir`), `QLocalServer::UserAccessOption`, `SO_PEERCRED` recusa UID diferente.
- Instância única: antes de subir, tenta conectar no socket; se alguém responde → `AlreadyRunning` (não mexe no socket). Socket órfão (ninguém escuta) é apagado e recriado.

- [ ] **Step 1: Escrever os testes**

`linux/tests/tst_hook_server.cpp`:

```cpp
#include <QtTest>
#include <QJsonDocument>
#include <QLocalSocket>
#include <QSettings>
#include <QTemporaryDir>
#include <cstring>
#include <memory>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include "AppState.h"
#include "ApprovalQueue.h"
#include "ClaudeSessions.h"
#include "FakeScheduler.h"
#include "HookServer.h"
#include "IslandController.h"

using namespace coucou;

class TestHookServer : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandController> ctl;
    std::unique_ptr<ApprovalQueue> queue;
    std::unique_ptr<ClaudeSessions> sessions;
    std::unique_ptr<HookServer> server;
    std::vector<std::unique_ptr<QLocalSocket>> clients;

    QString sockPath() const { return dir.path() + "/run/nb.sock"; }
    QLocalSocket *client()
    {
        clients.push_back(std::make_unique<QLocalSocket>());
        clients.back()->connectToServer(sockPath());
        clients.back()->waitForConnected(1000);
        return clients.back().get();
    }
    static void send(QLocalSocket *c, const QByteArray &data)
    {
        c->write(data);
        c->flush();
    }
    static QByteArray event(const QString &name, const QString &sid, const QString &cwd, const QString &extra = {})
    {
        return QStringLiteral(R"({"hook_event_name":"%1","session_id":"%2","cwd":"%3"%4})")
                   .arg(name, sid, cwd, extra).toUtf8() + "\n";
    }
    const AgentTask *task(const QString &sid) const { return state->taskModel()->find(ClaudeSessions::taskId(sid)); }

private slots:
    void init()
    {
        QDir(dir.path() + "/run").removeRecursively();
        QFile::remove(dir.path() + "/s.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/s.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        sched = std::make_unique<FakeScheduler>();
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [] { return qint64(0); });
        queue = std::make_unique<ApprovalQueue>(*sched, settings.get());
        sessions = std::make_unique<ClaudeSessions>(state.get(), ctl.get(), sched.get(), queue.get());
        server = std::make_unique<HookServer>(sessions.get(), queue.get());
        QVERIFY(server->start(sockPath()) == HookServer::StartResult::Started);
    }
    void cleanup()
    {
        clients.clear();
        server.reset();
    }

    void socketFolderIsPrivate()
    {
        const QFile::Permissions p = QFileInfo(dir.path() + "/run").permissions();
        QCOMPARE(p & (QFile::ReadGroup | QFile::WriteGroup | QFile::ExeGroup | QFile::ReadOther | QFile::WriteOther | QFile::ExeOther),
                 QFile::Permissions());
    }

    void sessionStartCreatesThePill()
    {
        send(client(), event("SessionStart", "s1", "/home/u/proj"));
        QTRY_VERIFY_WITH_TIMEOUT(task("s1") != nullptr, 2000);
        QCOMPARE(task("s1")->name, QStringLiteral("proj"));
    }

    void lineWithoutNewlineIsStillHandledWhenTheClientCloses()
    {
        QLocalSocket *c = client();
        send(c, QByteArray(R"({"hook_event_name":"SessionStart","session_id":"s2","cwd":"/w/x"})"));
        c->disconnectFromServer();
        QTRY_VERIFY_WITH_TIMEOUT(task("s2") != nullptr, 2000);
    }

    void garbageIsIgnoredAndTheServerSurvives()
    {
        send(client(), "garbage\n");
        send(client(), "[1,2]\n");
        send(client(), "{\"x\":1}\n");
        send(client(), QByteArray("\xff\xfe\n"));
        send(client(), event("SessionStart", "ok", "/w/ok"));
        QTRY_VERIFY_WITH_TIMEOUT(task("ok") != nullptr, 2000);
        QCOMPARE(sessions->sessionCount(), 1);                  // no ghost pill from the garbage
    }

    void oversizedLineIsDroppedAndTheServerSurvives()
    {
        QLocalSocket *c = client();
        c->write(QByteArray(HookServer::kMaxLine + 4096, 'x'));
        c->waitForBytesWritten(1000);
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 3000);
        send(client(), event("SessionStart", "after", "/w/after"));
        QTRY_VERIFY_WITH_TIMEOUT(task("after") != nullptr, 2000);
    }

    void permissionAllowRoundTrip()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"ls -la"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        QCOMPARE(queue->command(), QStringLiteral("ls -la"));
        QVERIFY(!c->canReadLine());                             // nothing answered without a click
        queue->allow();
        QTRY_VERIFY_WITH_TIMEOUT(c->canReadLine(), 2000);
        QCOMPARE(c->readLine().trimmed(), QByteArray(R"({"decision":"allow"})"));
        QTRY_COMPARE_WITH_TIMEOUT(c->state(), QLocalSocket::UnconnectedState, 2000);
    }

    void permissionDenyCarriesAMessage()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"rm x"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        queue->deny();
        QTRY_VERIFY_WITH_TIMEOUT(c->canReadLine(), 2000);
        const auto reply = QJsonDocument::fromJson(c->readLine()).object();
        QCOMPARE(reply.value("decision").toString(), QStringLiteral("deny"));
        QVERIFY(!reply.value("message").toString().isEmpty());
    }

    void permissionTimeoutReleases()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"ls"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        sched->advance(ApprovalQueue::kDefaultTimeoutMs);
        QTRY_VERIFY_WITH_TIMEOUT(c->canReadLine(), 2000);
        QCOMPARE(c->readLine().trimmed(), QByteArray(R"({"decision":"release"})"));
    }

    void clientDisconnectCancelsThePendingRequest()
    {
        QLocalSocket *c = client();
        send(c, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"ls"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        QVERIFY(state->isPinned());
        c->abort();                                             // Claude Code killed the hook
        QTRY_VERIFY_WITH_TIMEOUT(!queue->active(), 2000);
        QVERIFY(!state->isPinned());
    }

    void alwaysAllowedRequestIsAnsweredWithoutAnAlert()
    {
        QLocalSocket *first = client();
        send(first, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"make"})"));
        QTRY_VERIFY_WITH_TIMEOUT(queue->active(), 2000);
        queue->always();
        QTRY_VERIFY_WITH_TIMEOUT(first->canReadLine(), 2000);
        QLocalSocket *again = client();
        send(again, event("PermissionRequest", "s1", "/w/p", R"(,"tool_name":"Bash","tool_input":{"command":"make"})"));
        QTRY_VERIFY_WITH_TIMEOUT(again->canReadLine(), 2000);
        QCOMPARE(again->readLine().trimmed(), QByteArray(R"({"decision":"allow"})"));
        QVERIFY(!queue->active());
    }

    void secondInstanceSeesTheFirstOneAndLeavesItAlone()
    {
        HookServer other(sessions.get(), queue.get());
        QVERIFY(other.start(sockPath()) == HookServer::StartResult::AlreadyRunning);
        send(client(), event("SessionStart", "still", "/w/still"));   // the first server keeps answering
        QTRY_VERIFY_WITH_TIMEOUT(task("still") != nullptr, 2000);
    }

    void staleSocketFileIsReplaced()
    {
        const QString stale = dir.path() + "/stale/nb.sock";
        QDir().mkpath(dir.path() + "/stale");
        const int fd = ::socket(AF_UNIX, SOCK_STREAM, 0);
        sockaddr_un addr{};
        addr.sun_family = AF_UNIX;
        std::strncpy(addr.sun_path, stale.toUtf8().constData(), sizeof(addr.sun_path) - 1);
        QVERIFY(::bind(fd, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) == 0);
        ::close(fd);                                            // the file stays, nobody listens (a crashed run)
        QVERIFY(QFile::exists(stale));
        HookServer other(sessions.get(), queue.get());
        QVERIFY(other.start(stale) == HookServer::StartResult::Started);
    }

    void tooLongSocketPathFails()
    {
        HookServer other(sessions.get(), queue.get());
        QVERIFY(other.start(dir.path() + "/" + QString(120, 'a') + "/nb.sock") == HookServer::StartResult::Failed);
        QVERIFY(!other.errorString().isEmpty());
    }
};

QTEST_MAIN(TestHookServer)
#include "tst_hook_server.moc"
```

- [ ] **Step 2: Rodar e ver falhar** (não compila)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_hook_server 2>&1 | tail -5`

- [ ] **Step 3: Implementar**

`linux/src/platform/HookServer.h`:

```cpp
#pragma once
#include <QHash>
#include <QLocalServer>
#include <QObject>

class QLocalSocket;

namespace coucou {

class ApprovalQueue;
class ClaudeSessions;

// Unix-socket server for nb-hook: one JSON line per connection (see the L2 plan, Task 7).
class HookServer : public QObject {
    Q_OBJECT
public:
    enum class StartResult { Started, AlreadyRunning, Failed };
    static constexpr int kMaxLine = 1 << 20;

    HookServer(ClaudeSessions *sessions, ApprovalQueue *queue, QObject *parent = nullptr);
    StartResult start(const QString &socketPath);
    QString errorString() const { return m_error; }

private:
    struct Conn {
        QByteArray buffer;
        qint64 requestId = 0;
        bool handled = false;
    };
    void onNewConnection();
    void onReadyRead(QLocalSocket *s);
    void onDisconnected(QLocalSocket *s);
    void dispatch(QLocalSocket *s, const QByteArray &line);

    QLocalServer m_server;
    ClaudeSessions *m_sessions;
    ApprovalQueue *m_queue;
    QHash<QLocalSocket *, Conn> m_conns;
    QString m_error;
};

} // namespace coucou
```

`linux/src/platform/HookServer.cpp`:

```cpp
#include "HookServer.h"

#include "ApprovalQueue.h"
#include "ClaudeSessions.h"
#include "Paths.h"

#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLocalSocket>
#include <QPointer>
#include <sys/socket.h>
#include <unistd.h>

namespace coucou {

namespace {

uid_t peerUid(QLocalSocket *s)
{
    ucred cred{};
    socklen_t len = sizeof(cred);
    if (getsockopt(int(s->socketDescriptor()), SOL_SOCKET, SO_PEERCRED, &cred, &len) != 0)
        return uid_t(-1);
    return cred.uid;
}

QByteArray decisionLine(Decision d)
{
    QJsonObject o;
    switch (d) {
    case Decision::Allow: o["decision"] = "allow"; break;
    case Decision::Deny:
        o["decision"] = "deny";
        o["message"] = "Denied from the Coucou island";
        break;
    case Decision::Release: o["decision"] = "release"; break;
    }
    return QJsonDocument(o).toJson(QJsonDocument::Compact) + '\n';
}

} // namespace

HookServer::HookServer(ClaudeSessions *sessions, ApprovalQueue *queue, QObject *parent)
    : QObject(parent), m_sessions(sessions), m_queue(queue)
{
}

HookServer::StartResult HookServer::start(const QString &path)
{
    if (!Paths::fitsUnixSocket(path)) {
        m_error = QStringLiteral("socket path too long: ") + path;
        return StartResult::Failed;
    }
    if (!Paths::ensurePrivateDir(QFileInfo(path).absolutePath())) {
        m_error = QStringLiteral("cannot create ") + QFileInfo(path).absolutePath();
        return StartResult::Failed;
    }
    {   // somebody already answers on this socket: another Coucou is running
        QLocalSocket probe;
        probe.connectToServer(path);
        if (probe.waitForConnected(300))
            return StartResult::AlreadyRunning;
    }
    QLocalServer::removeServer(path);   // stale file from a crashed run
    m_server.setSocketOptions(QLocalServer::UserAccessOption);
    if (!m_server.listen(path)) {
        m_error = m_server.errorString();
        return StartResult::Failed;
    }
    connect(&m_server, &QLocalServer::newConnection, this, &HookServer::onNewConnection);
    return StartResult::Started;
}

void HookServer::onNewConnection()
{
    while (QLocalSocket *s = m_server.nextPendingConnection()) {
        if (peerUid(s) != getuid()) {
            s->abort();
            s->deleteLater();
            continue;
        }
        m_conns.insert(s, Conn{});
        connect(s, &QLocalSocket::readyRead, this, [this, s] { onReadyRead(s); });
        connect(s, &QLocalSocket::disconnected, this, [this, s] { onDisconnected(s); });
    }
}

void HookServer::onReadyRead(QLocalSocket *s)
{
    auto it = m_conns.find(s);
    if (it == m_conns.end())
        return;
    it->buffer += s->readAll();
    if (it->buffer.size() > kMaxLine) {
        s->abort();                        // emits disconnected -> cleaned up there
        return;
    }
    if (it->handled)
        return;                            // anything after the first line is ignored
    const int nl = it->buffer.indexOf('\n');
    if (nl < 0)
        return;
    it->handled = true;
    const QByteArray line = it->buffer.left(nl);
    dispatch(s, line);                     // may disconnect synchronously: `it` is not used after this
}

void HookServer::dispatch(QLocalSocket *s, const QByteArray &line)
{
    const auto ev = HookEvent::parse(line);
    if (!ev) {
        s->disconnectFromServer();
        return;
    }
    if (ev->name != QLatin1String("PermissionRequest")) {
        m_sessions->handleEvent(*ev);
        s->disconnectFromServer();
        return;
    }
    QPointer<QLocalSocket> guard(s);
    const qint64 id = m_sessions->handlePermission(*ev, [guard](Decision d) {
        if (!guard)
            return;
        guard->write(decisionLine(d));
        guard->flush();
        guard->disconnectFromServer();
    });
    const auto it = m_conns.find(s);       // an "always allow" answer may already have closed it
    if (it != m_conns.end())
        it->requestId = id;
}

void HookServer::onDisconnected(QLocalSocket *s)
{
    const auto it = m_conns.find(s);
    if (it == m_conns.end())
        return;
    Conn c = *it;
    m_conns.erase(it);
    c.buffer += s->readAll();              // bytes that arrived together with the close
    if (!c.handled && !c.buffer.isEmpty() && c.buffer.size() <= kMaxLine) {
        // the client closed without a trailing newline: still a complete line, unless it asks for a decision
        const auto ev = HookEvent::parse(c.buffer);
        if (ev && ev->name != QLatin1String("PermissionRequest"))
            m_sessions->handleEvent(*ev);
    }
    if (c.requestId != 0)
        m_queue->cancel(c.requestId);      // no-op when it was already answered
    s->deleteLater();
}

} // namespace coucou
```

Em `linux/src/platform/CMakeLists.txt`: adicione `HookServer.h HookServer.cpp` às fontes e `Qt6::Network` ao `target_link_libraries`. Em `linux/tests/CMakeLists.txt`, dentro de `if(TARGET coucou_platform)`:

```cmake
    qt_add_executable(tst_hook_server tst_hook_server.cpp)
    target_link_libraries(tst_hook_server PRIVATE coucou_platform coucou_core Qt6::Test Qt6::Network)
    target_include_directories(tst_hook_server PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME tst_hook_server COMMAND tst_hook_server)
    set_tests_properties(tst_hook_server PROPERTIES ENVIRONMENT "QT_QPA_PLATFORM=offscreen;QT_QUICK_BACKEND=software")
```

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build --target tst_hook_server && linux/scripts/host.sh linux/build/tests/tst_hook_server`
Expected: todos PASS. O caso `SO_PEERCRED` com outro UID não é testável sem segundo usuário: fica documentado em `L2-notes.md` (Task 14), como no L0.

- [ ] **Step 5: Commit**

```bash
git add linux/src/platform linux/tests
git commit -m "linux(L2): HookServer on a private Unix socket (peer uid, single instance, held permission requests)

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 8: Ligar tudo no `main` + instalar o `nb-hook` no primeiro uso

**Files:**
- Create: `linux/src/core/HookScript.h`, `linux/src/core/HookScript.cpp`, `linux/tests/tst_hook_script.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/src/app/CMakeLists.txt` (recurso `/hook/nb-hook`), `linux/src/app/main.cpp`, `linux/tests/CMakeLists.txt`

**Interfaces:**
- Produces: `bool coucou::installHookScript(const QByteArray &content, const QString &dest, QString *error = nullptr)` — cria a pasta `0700`, grava `dest` com modo `0755` só se o conteúdo mudou (mesmo inode se nada mudou).
- `main`: cria `ApprovalQueue`, `ClaudeSessions`, `HookServer`; expõe `approvals` e `sessions` ao QML; sai com código 0 e uma linha no log se outra instância já roda; instala o `nb-hook` a partir do recurso Qt.

- [ ] **Step 1: Escrever o teste**

`linux/tests/tst_hook_script.cpp`:

```cpp
#include <QtTest>
#include <QTemporaryDir>
#include <sys/stat.h>
#include "HookScript.h"

using namespace coucou;

class TestHookScript : public QObject {
    Q_OBJECT
    static ino_t inode(const QString &p)
    {
        struct stat st{};
        return ::stat(p.toUtf8().constData(), &st) == 0 ? st.st_ino : 0;
    }

private slots:
    void writesAnExecutableScriptInAPrivateFolder()
    {
        QTemporaryDir dir;
        const QString dest = dir.path() + "/coucou/nb-hook";
        QString err;
        QVERIFY2(installHookScript("#!/usr/bin/env python3\nprint(1)\n", dest, &err), qPrintable(err));
        QFile f(dest);
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(f.readAll(), QByteArray("#!/usr/bin/env python3\nprint(1)\n"));
        const QFile::Permissions p = QFile::permissions(dest);
        QVERIFY(p & QFile::ExeOwner);
        QVERIFY(p & QFile::WriteOwner);
        QVERIFY(!(p & QFile::WriteGroup) && !(p & QFile::WriteOther));
        QCOMPARE(QFileInfo(dir.path() + "/coucou").permissions() & (QFile::ReadGroup | QFile::ReadOther), QFile::Permissions());
    }

    void unchangedContentIsNotRewritten()
    {
        QTemporaryDir dir;
        const QString dest = dir.path() + "/nb-hook";
        QVERIFY(installHookScript("one", dest));
        const ino_t first = inode(dest);
        QVERIFY(installHookScript("one", dest));
        QCOMPARE(inode(dest), first);
    }

    void changedContentReplacesTheScript()
    {
        QTemporaryDir dir;
        const QString dest = dir.path() + "/nb-hook";
        QVERIFY(installHookScript("one", dest));
        QVERIFY(installHookScript("two", dest));
        QFile f(dest);
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(f.readAll(), QByteArray("two"));
        QVERIFY(QFile::permissions(dest) & QFile::ExeOwner);
    }

    void executableBitIsRestoredWhenContentIsTheSame()
    {
        QTemporaryDir dir;
        const QString dest = dir.path() + "/nb-hook";
        QVERIFY(installHookScript("one", dest));
        QFile::setPermissions(dest, QFile::ReadOwner | QFile::WriteOwner);
        QVERIFY(installHookScript("one", dest));
        QVERIFY(QFile::permissions(dest) & QFile::ExeOwner);
    }

    void unwritableFolderReportsAnError()
    {
        QString err;
        QVERIFY(!installHookScript("x", "/proc/nope/nb-hook", &err));
        QVERIFY(!err.isEmpty());
    }
};

QTEST_MAIN(TestHookScript)
#include "tst_hook_script.moc"
```

- [ ] **Step 2: Rodar e ver falhar** (não compila)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_hook_script 2>&1 | tail -5`

- [ ] **Step 3: Implementar `HookScript` e ligar o `main`**

`linux/src/core/HookScript.h`:

```cpp
#pragma once
#include <QByteArray>
#include <QString>

namespace coucou {

// Writes the nb-hook script to `dest` (mode 0755; parent folder 0700) unless it already holds exactly `content`.
bool installHookScript(const QByteArray &content, const QString &dest, QString *error = nullptr);

} // namespace coucou
```

`linux/src/core/HookScript.cpp`:

```cpp
#include "HookScript.h"

#include "Paths.h"

#include <QFile>
#include <QFileInfo>
#include <QSaveFile>

namespace coucou {

namespace {
constexpr QFile::Permissions kExecutable = QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner | QFile::ReadGroup |
                                           QFile::ExeGroup | QFile::ReadOther | QFile::ExeOther;   // 0755
}

bool installHookScript(const QByteArray &content, const QString &dest, QString *error)
{
    auto fail = [&](const QString &m) {
        if (error)
            *error = m;
        return false;
    };
    const QString folder = QFileInfo(dest).absolutePath();
    if (!Paths::ensurePrivateDir(folder))
        return fail(QStringLiteral("cannot create ") + folder);

    QFile existing(dest);
    if (existing.open(QIODevice::ReadOnly)) {
        const bool same = existing.readAll() == content;
        existing.close();
        if (same)
            return QFile::setPermissions(dest, kExecutable) || fail(QStringLiteral("cannot chmod ") + dest);
    }
    QSaveFile out(dest);
    if (!out.open(QIODevice::WriteOnly))
        return fail(QStringLiteral("cannot write ") + dest + QStringLiteral(": ") + out.errorString());
    out.write(content);
    if (!out.commit())
        return fail(QStringLiteral("cannot write ") + dest + QStringLiteral(": ") + out.errorString());
    return QFile::setPermissions(dest, kExecutable) || fail(QStringLiteral("cannot chmod ") + dest);
}

} // namespace coucou
```

Registrar `HookScript.h HookScript.cpp` em `src/core/CMakeLists.txt` e `coucou_add_test(tst_hook_script)` em `tests/CMakeLists.txt`.

Em `linux/src/app/CMakeLists.txt`, depois do recurso `coucou_icons`:

```cmake
qt_add_resources(coucou "coucou_hook"
    PREFIX "/hook"
    BASE "${CMAKE_SOURCE_DIR}/hook"
    FILES "${CMAKE_SOURCE_DIR}/hook/nb-hook")
```

Substitua `linux/src/app/main.cpp` inteiro por:

```cpp
#include "AppState.h"
#include "ApprovalQueue.h"
#include "ClaudeSessions.h"
#include "HookScript.h"
#include "HookServer.h"
#include "IslandController.h"
#include "IslandWindow.h"
#include "Paths.h"
#include "Scheduler.h"
#include "SoundEngine.h"
#include "Tray.h"

#include <QDateTime>
#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QApplication>
#include <QQmlContext>
#include <QQmlEngine>
#include <QSettings>
#include <QTimer>

using namespace coucou;

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);   // KStatusNotifierItem and QMenu need Qt Widgets
    app.setApplicationName(QStringLiteral("coucou"));
    app.setDesktopFileName(QStringLiteral("fr.louisraille.NotchBuddy"));
    app.setQuitOnLastWindowClosed(false);

    QDir().mkpath(QFileInfo(Paths::configFile()).absolutePath());
    QSettings settings(Paths::configFile(), QSettings::IniFormat);

    AppState state(&settings);
    QtScheduler scheduler;
    IslandController controller(&state, &scheduler, [] { return QDateTime::currentMSecsSinceEpoch(); });

    SoundEngine sound(qEnvironmentVariable("COUCOU_SOUNDS_DIR", QStringLiteral(COUCOU_SOUNDS_DIR)));
    sound.setEnabled(state.soundEnabled());
    sound.setVolume(state.soundVolume());
    QObject::connect(&state, &AppState::soundEnabledChanged, &sound, [&] { sound.setEnabled(state.soundEnabled()); });
    QObject::connect(&state, &AppState::soundVolumeChanged, &sound, [&] { sound.setVolume(state.soundVolume()); });
    QObject::connect(&controller, &IslandController::playSound, &sound, &SoundEngine::play);

    // Claude Code: hook events -> sessions/alerts, permission requests -> approval queue.
    ApprovalQueue approvals(scheduler, &settings);
    ClaudeSessions sessions(&state, &controller, &scheduler, &approvals);
    QObject::connect(&sessions, &ClaudeSessions::playSound, &sound, &SoundEngine::play);
    HookServer hookServer(&sessions, &approvals);
    switch (hookServer.start(Paths::socketPath())) {
    case HookServer::StartResult::AlreadyRunning:
        qInfo("Coucou is already running; exiting.");
        return 0;
    case HookServer::StartResult::Failed:
        qWarning("Claude Code hooks are disabled: %s", qPrintable(hookServer.errorString()));
        break;
    case HookServer::StartResult::Started:
        break;
    }
    if (QFile script(QStringLiteral(":/hook/nb-hook")); script.open(QIODevice::ReadOnly)) {
        QString error;
        if (!installHookScript(script.readAll(), Paths::hookScriptPath(), &error))
            qWarning("Could not install nb-hook: %s", qPrintable(error));
    }

    QQmlEngine engine;
    engine.rootContext()->setContextProperty(QStringLiteral("appState"), &state);
    engine.rootContext()->setContextProperty(QStringLiteral("controller"), &controller);
    engine.rootContext()->setContextProperty(QStringLiteral("approvals"), &approvals);
    engine.rootContext()->setContextProperty(QStringLiteral("sessions"), &sessions);

    IslandWindow window(&state, &controller, &engine);
    if (!window.ok()) {
        qCritical("Could not load qrc:/qml/Island.qml");
        return 1;
    }
    Tray tray(&state, &controller);

    window.show();
    controller.launch();   // greeting -> compact, like the Mac app on launch

    // Development hook: COUCOU_DEBUG_VIEW=<view name> opens that view once the greeting has collapsed,
    // so screenshots and CPU measurements of a given state do not need a click.
    const QString debugView = qEnvironmentVariable("COUCOU_DEBUG_VIEW");
    if (!debugView.isEmpty())
        QTimer::singleShot(7000, &controller, [&controller, debugView] { controller.expandTo(debugView); });
    // COUCOU_DEBUG_MODE=hidden|compact|expanded forces a mode after the greeting (CPU measurements).
    if (auto mode = enumFromKey<IslandMode>(qEnvironmentVariable("COUCOU_DEBUG_MODE")))
        QTimer::singleShot(7000, &controller, [&controller, m = *mode] { controller.setMode(m); });
    return app.exec();
}
```

- [ ] **Step 4: Compilar, testar e rodar uma fumaça (sem ver a tela ainda)**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: tudo passa (inclui `tst_hook_script`).

Fumaça (app real, sem instalar nada no `~/.claude`). Em uma chamada:

```bash
linux/scripts/host.sh sh -c 'cd ~/src/farol/linux && (nohup build/src/app/coucou >build/l2-smoke.log 2>&1 &); sleep 4; ls -ld ~/.local/share/coucou; ls -l ~/.local/share/coucou/nb-hook ~/.local/share/coucou/nb.sock; printf "%s" "{\"hook_event_name\":\"SessionStart\",\"session_id\":\"smoke1\",\"cwd\":\"/tmp/demo-project\"}" | ~/.local/share/coucou/nb-hook; echo "hook exit=$?"; pgrep -ax coucou; build/src/app/coucou; echo "second instance exit=$?"; cat build/l2-smoke.log'
```
Expected: pasta `drwx------`, `nb-hook` `-rwxr-xr-x`, `nb.sock` existe; `hook exit=0`; um único `coucou` vivo; a segunda instância imprime `Coucou is already running; exiting.` e `exit=0`; o log sem `Claude Code hooks are disabled`. Depois, em chamada própria: `linux/scripts/host.sh pkill -x coucou`.

- [ ] **Step 5: Commit**

```bash
git add linux/src linux/tests
git commit -m "linux(L2): wire HookServer, sessions and approvals into the app; install nb-hook; single instance

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 9: Views reais no QML (aprovação, pergunta, terminou, erro, visão geral) + teclas `Y`/`N`

**Files:**
- Create: `linux/qml/Card.qml`, `linux/qml/PillButton.qml`, `linux/qml/AgentWho.qml`, `linux/qml/CodeBlock.qml`, `linux/qml/ApprovalView.qml`, `linux/qml/QuestionView.qml`, `linux/qml/FinishedView.qml`, `linux/qml/ErrorView.qml`, `linux/qml/OverviewView.qml`
- Modify: `linux/qml/ViewPlaceholder.qml`, `linux/qml/Island.qml`, `linux/src/app/CMakeLists.txt` (lista de QML do recurso), `linux/tests/tst_island_qml.cpp`

**Interfaces:**
- Consumes (context properties): `appState` (`focusTask`, `focusId`, `tasks`, `setFocus()`), `controller` (`collapse()`), `approvals` (`active`, `project`, `tool`, `command`, `waiting`, `allow()`, `deny()`, `always()`, `release()`), `sessions` (`jump(taskId)`).
- Produces: `ViewPlaceholder { contentSource: "ApprovalView.qml" }` hospeda uma view real; `Island.qml` mapeia `approval, question, finished, error, overview` para os arquivos; teclas `Y` (autorizar) e `N` (negar) com a view `approval` ativa. `objectName`s para teste: `approvalCommand`, `approvalProject`, `questionTitle`, `finishedTitle`, `errorTitle`, `overviewName`, `overviewTicker`.

As views seguem as do Swift (`IslandViewContent.swift`): cartão `#141518` com lavagem colorida, coluna do personagem de 116 pt à esquerda, `AgentWho` (bolinha + nome + rótulo), título 15 pt semibold, botões pílula de 28 pt. A paridade pixel-a-pixel com `design/captures/` é o L1c; aqui o objetivo é funcionar e ficar legível.

- [ ] **Step 1: Escrever os testes QML**

Em `tests/tst_island_qml.cpp`:

(a) acrescente os `#include "ApprovalQueue.h"`, `#include "ClaudeSessions.h"`, `<QJsonArray>`, `<QJsonDocument>`;
(b) membros `std::unique_ptr<ApprovalQueue> queue; std::unique_ptr<ClaudeSessions> sessions;`;
(c) em `init()`, depois de criar `ctl`, e **antes** de `view->setSource(...)`:

```cpp
        queue = std::make_unique<ApprovalQueue>(*sched, settings.get());
        sessions = std::make_unique<ClaudeSessions>(state.get(), ctl.get(), sched.get(), queue.get());
        view->rootContext()->setContextProperty("approvals", queue.get());
        view->rootContext()->setContextProperty("sessions", sessions.get());
```
(d) em `cleanup()`: `view.reset(); sessions.reset(); queue.reset(); ctl.reset(); state.reset();`;
(e) helper e testes:

```cpp
    static HookEvent ev(const QString &name, const QString &sid, const QString &cwd, const QJsonObject &extra = {})
    {
        QJsonObject o = extra;
        o["hook_event_name"] = name;
        o["session_id"] = sid;
        o["cwd"] = cwd;
        return *HookEvent::parse(QJsonDocument(o).toJson(QJsonDocument::Compact));
    }
    QString textOf(const char *objectName) const
    {
        QQuickItem *item = child(objectName);
        return item ? item->property("text").toString() : QString();
    }
```
```cpp
    void approvalViewShowsTheRequestAndYDecides()
    {
        QList<Decision> got;
        sessions->handlePermission(ev("PermissionRequest", "s1", "/w/proj", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "rm -rf build"}}}}),
                                   [&](Decision d) { got << d; });
        QTRY_COMPARE_WITH_TIMEOUT(child("view-approval")->opacity(), 1.0, 3000);
        QTRY_COMPARE_WITH_TIMEOUT(textOf("approvalCommand"), QStringLiteral("rm -rf build"), 3000);
        QCOMPARE(textOf("approvalProject"), QStringLiteral("proj"));
        QTest::qWaitForWindowActive(view.get());
        root->forceActiveFocus();
        QTest::keyClick(view.get(), Qt::Key_Y);
        QCOMPARE(got, QList<Decision>{Decision::Allow});
        QVERIFY(!queue->active());
    }

    void nDeniesAndOtherKeysDoNothing()
    {
        QList<Decision> got;
        sessions->handlePermission(ev("PermissionRequest", "s1", "/w/proj", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "ls"}}}}),
                                   [&](Decision d) { got << d; });
        QTRY_COMPARE_WITH_TIMEOUT(child("view-approval")->opacity(), 1.0, 3000);
        QTest::qWaitForWindowActive(view.get());
        root->forceActiveFocus();
        QTest::keyClick(view.get(), Qt::Key_Q);
        QVERIFY(got.isEmpty());
        QTest::keyClick(view.get(), Qt::Key_N);
        QCOMPARE(got, QList<Decision>{Decision::Deny});
    }

    void yWithoutAnApprovalDoesNothing()
    {
        QTest::qWaitForWindowActive(view.get());
        root->forceActiveFocus();
        QTest::keyClick(view.get(), Qt::Key_Y);            // nothing pending: must not crash or decide anything
        QVERIFY(!queue->active());
    }

    void finishedViewShowsTheSummary()
    {
        sessions->handleEvent(ev("Stop", "s1", "/w/proj", {{"last_assistant_message", "All done."}}));
        QTRY_COMPARE_WITH_TIMEOUT(child("view-finished")->opacity(), 1.0, 3000);
        QCOMPARE(textOf("finishedTitle"), QStringLiteral("All done."));
    }

    void errorViewShowsTheMessage()
    {
        sessions->handleEvent(ev("StopFailure", "s1", "/w/proj", {{"message", "API error 529"}}));
        QTRY_COMPARE_WITH_TIMEOUT(child("view-error")->opacity(), 1.0, 3000);
        QCOMPARE(textOf("errorTitle"), QStringLiteral("API error 529"));
    }

    void questionViewShowsTheQuestionReadOnly()
    {
        const QJsonObject input{{"questions", QJsonArray{QJsonObject{{"question", "Which engine?"},
            {"options", QJsonArray{QJsonObject{{"label", "Postgres"}}}}}}}};
        sessions->handleEvent(ev("PreToolUse", "s1", "/w/proj", {{"tool_name", "AskUserQuestion"}, {"tool_input", input}}));
        QTRY_COMPARE_WITH_TIMEOUT(child("view-question")->opacity(), 1.0, 3000);
        QCOMPARE(textOf("questionTitle"), QStringLiteral("Which engine?"));
    }

    void overviewShowsTheFocusedSessionAndItsLastSteps()
    {
        sessions->handleEvent(ev("SessionStart", "s1", "/w/proj"));
        sessions->handleEvent(ev("PreToolUse", "s1", "/w/proj", {{"tool_name", "Bash"}, {"tool_input", QJsonObject{{"command", "npm test"}}}}));
        ctl->expandTo("overview");
        QTRY_COMPARE_WITH_TIMEOUT(child("view-overview")->opacity(), 1.0, 3000);
        QCOMPARE(textOf("overviewName"), QStringLiteral("proj"));
        QTRY_VERIFY_WITH_TIMEOUT(child("overviewTicker") != nullptr, 3000);
    }

    void overviewWithoutASessionSaysSo()
    {
        ctl->expandTo("overview");
        QTRY_COMPARE_WITH_TIMEOUT(child("view-overview")->opacity(), 1.0, 3000);
        QCOMPARE(textOf("overviewName"), QStringLiteral("VS Code"));
    }
```

Nota: o teste antigo de `view-approval` (linha ~97 de `tst_island_qml.cpp`) usa `ctl->expandTo("approval")` **sem** pedido pendente; com a view real, `approvals.command` fica vazio e o `CodeBlock` mostra `approvals.tool` vazio — isso não deve quebrar (todas as bindings toleram vazio).

- [ ] **Step 2: Rodar e ver falhar**

Run: `linux/scripts/host.sh cmake --build linux/build --target tst_island_qml && linux/scripts/host.sh linux/build/tests/tst_island_qml 2>&1 | tail -15`
Expected: FAIL nos testes novos (não há `approvalCommand` etc.).

- [ ] **Step 3: Componentes compartilhados**

`linux/qml/Card.qml`:

```qml
import QtQuick

// CardBackground in the Swift views: dark rounded card, optionally washed from below with the alert colour.
Rectangle {
    id: card
    property color wash: "transparent"
    radius: 20
    color: "#141518"
    border.color: Qt.rgba(1, 1, 1, 0.035)
    border.width: 1

    Rectangle {
        anchors.fill: parent
        radius: card.radius
        visible: card.wash.a > 0
        gradient: Gradient {
            GradientStop { position: 0.0; color: "transparent" }
            GradientStop { position: 1.0; color: Qt.rgba(card.wash.r, card.wash.g, card.wash.b, 0.14) }
        }
    }
}
```

`linux/qml/PillButton.qml`:

```qml
import QtQuick

// PrimaryButton / SecondaryButton of the Swift views: 28 pt pill, 12.5 pt medium, pressed scale 0.94.
Rectangle {
    id: btn
    property string text: ""
    property string hint: ""       // keyboard shortcut shown small after the label ("Y", "N")
    property bool primary: false
    signal clicked()

    implicitWidth: row.implicitWidth + 28
    implicitHeight: 28
    width: implicitWidth
    height: 28
    radius: 14
    color: primary ? (hover.hovered ? "#FFFFFF" : "#F5F6F8") : Qt.rgba(1, 1, 1, hover.hovered ? 0.15 : 0.09)
    scale: tap.pressed ? 0.94 : 1
    Behavior on scale { NumberAnimation { duration: 90 } }

    Row {
        id: row
        anchors.centerIn: parent
        spacing: 6
        Text {
            height: btn.height
            verticalAlignment: Text.AlignVCenter
            text: btn.text
            color: btn.primary ? "#0B0C0E" : "#F5F6F8"
            font.family: "Inter"
            font.pixelSize: 12.5
            font.weight: Font.Medium
        }
        Text {
            visible: btn.hint !== ""
            height: btn.height
            verticalAlignment: Text.AlignVCenter
            text: btn.hint
            color: btn.primary ? "#6B7079" : "#8E939C"
            font.family: "Inter"
            font.pixelSize: 10.5
        }
    }
    HoverHandler { id: hover }
    TapHandler { id: tap; onTapped: btn.clicked() }
}
```

`linux/qml/AgentWho.qml`:

```qml
import QtQuick

// Coloured dot + agent name + grey label ("needs permission").
Row {
    id: who
    property string name: ""
    property string label: ""
    property color dot: "#8E939C"
    property alias nameObjectName: nameText.objectName
    spacing: 6
    height: 16

    Item {
        width: 7
        height: 16
        Rectangle { anchors.centerIn: parent; width: 7; height: 7; radius: 3.5; color: who.dot }
    }
    Text {
        id: nameText
        height: 16
        verticalAlignment: Text.AlignVCenter
        width: Math.min(implicitWidth, 200)
        elide: Text.ElideRight
        text: who.name
        color: "#F5F6F8"
        font.family: "Inter"
        font.pixelSize: 12
        font.weight: Font.DemiBold
    }
    Text {
        height: 16
        verticalAlignment: Text.AlignVCenter
        text: who.label
        color: "#8E939C"
        font.family: "Inter"
        font.pixelSize: 11
    }
}
```

`linux/qml/CodeBlock.qml`:

```qml
import QtQuick

// Monospace box for the command/file a permission request is about. Clips at two lines.
Rectangle {
    id: block
    property string text: ""
    implicitHeight: 34
    height: 34
    radius: 8
    color: "#0D0E11"
    border.color: Qt.rgba(1, 1, 1, 0.05)
    border.width: 1

    Text {
        anchors.fill: parent
        anchors.leftMargin: 10
        anchors.rightMargin: 10
        verticalAlignment: Text.AlignVCenter
        text: block.text
        color: "#D7DAE0"
        font.family: "monospace"
        font.pixelSize: 11.5
        wrapMode: Text.WrapAnywhere
        maximumLineCount: 2
        elide: Text.ElideRight
    }
}
```

- [ ] **Step 4: Views**

`linux/qml/ApprovalView.qml`:

```qml
import QtQuick

// ApprovalView: the permission request in front of the queue. Nothing is decided without a click (or Y/N).
Item {
    Card { anchors.fill: parent; wash: "#F5A524" }
    Column {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: 116
        anchors.rightMargin: 16
        spacing: 5

        AgentWho {
            nameObjectName: "approvalProject"
            name: approvals.project
            label: approvals.waiting > 0 ? "needs permission · +" + approvals.waiting + " waiting" : "needs permission"
            dot: appState.focusTask.color || "#8E939C"
        }
        CodeBlock {
            objectName: "approvalCommand"
            width: parent.width
            text: approvals.command !== "" ? approvals.command : approvals.tool
        }
        Row {
            spacing: 8
            PillButton { text: "Deny"; hint: "N"; onClicked: approvals.deny() }
            PillButton { text: "Allow"; hint: "Y"; primary: true; onClicked: approvals.allow() }
            PillButton { text: "Always"; onClicked: approvals.always() }
            PillButton {
                text: "Decide in editor"
                onClicked: {
                    const id = appState.focusId
                    approvals.release()            // the hook prints nothing: Claude Code asks in its own UI
                    sessions.jump(id)
                    controller.collapse()
                }
            }
        }
    }
}
```

`linux/qml/QuestionView.qml`:

```qml
import QtQuick

// QuestionView: read-only. A hook cannot answer AskUserQuestion, so the way out is to go back to the session.
Item {
    readonly property var options: appState.focusTask.options || []

    Card { anchors.fill: parent; wash: "#22D3EE" }
    Column {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: 116
        anchors.rightMargin: 16
        spacing: 5

        AgentWho {
            name: appState.focusTask.name || ""
            label: "is asking a question"
            dot: appState.focusTask.color || "#8E939C"
        }
        Text {
            objectName: "questionTitle"
            width: parent.width
            text: appState.focusTask.alertText || ""
            color: "#F5F6F8"
            font.family: "Inter"
            font.pixelSize: 15
            font.weight: Font.DemiBold
            wrapMode: Text.Wrap
            maximumLineCount: 2
            elide: Text.ElideRight
        }
        Row {
            spacing: 8
            Repeater {
                model: options.slice(0, 3)
                Rectangle {
                    required property string modelData
                    width: Math.min(chip.implicitWidth + 24, 150)
                    height: 28
                    radius: 14
                    color: Qt.rgba(1, 1, 1, 0.06)
                    Text {
                        id: chip
                        anchors.centerIn: parent
                        width: parent.width - 24
                        horizontalAlignment: Text.AlignHCenter
                        elide: Text.ElideRight
                        text: modelData
                        color: "#9398A1"
                        font.family: "Inter"
                        font.pixelSize: 12
                    }
                }
            }
            PillButton {
                text: "Answer in editor"
                primary: true
                onClicked: { sessions.jump(appState.focusId); controller.collapse() }
            }
        }
    }
}
```

`linux/qml/FinishedView.qml`:

```qml
import QtQuick

Item {
    Card { anchors.fill: parent; wash: "#34D399" }
    Column {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: 116
        anchors.rightMargin: 16
        spacing: 5

        AgentWho {
            name: appState.focusTask.name || ""
            label: "finished"
            dot: appState.focusTask.color || "#8E939C"
        }
        Text {
            objectName: "finishedTitle"
            width: parent.width
            text: appState.focusTask.alertText || "Session finished"
            color: "#F5F6F8"
            font.family: "Inter"
            font.pixelSize: 15
            font.weight: Font.DemiBold
            wrapMode: Text.Wrap
            maximumLineCount: 2
            elide: Text.ElideRight
        }
        Row {
            spacing: 8
            PillButton {
                text: "Open session"
                primary: true
                onClicked: { sessions.jump(appState.focusId); controller.collapse() }
            }
            PillButton { text: "OK"; onClicked: controller.collapse() }
        }
    }
}
```

`linux/qml/ErrorView.qml`: igual ao `FinishedView.qml`, com `wash: "#F4505E"`, `label: "stopped with an error"`, `objectName: "errorTitle"`, texto padrão `"Claude Code stopped with an error"` e o título na cor `#FF8D97` (em vez de `#F5F6F8`), sem alterar botões.

`linux/qml/OverviewView.qml`:

```qml
import QtQuick

// Overview: left card = the focused session (name, source, last steps, jump button); right card = one pill per
// session/integration. Provisional layout: the exact ticker and mini-Mochis are the L1c/L1b ports.
Item {
    id: overview
    readonly property var task: appState.focusTask
    readonly property var steps: task.steps || []
    readonly property var tail: steps.slice(-3)
    readonly property string hint: task.id === "integration_claude" ? "No Claude Code session yet"
                                   : (task.isIntegration ? "Not connected yet" : (task.state === "idle" ? "Idle" : "Working…"))

    Row {
        anchors.fill: parent
        spacing: 10

        Card {
            width: 322
            height: parent.height

            Row {
                x: 108
                y: 10
                width: parent.width - 108 - 36
                spacing: 6
                Item {
                    width: 7
                    height: 16
                    Rectangle { anchors.centerIn: parent; width: 7; height: 7; radius: 3.5; color: overview.task.color || "#8E939C" }
                }
                Text {
                    objectName: "overviewName"
                    height: 16
                    verticalAlignment: Text.AlignVCenter
                    width: Math.min(implicitWidth, 130)
                    elide: Text.ElideRight
                    text: overview.task.name || ""
                    color: "#F5F6F8"
                    font.family: "Inter"
                    font.pixelSize: 12
                    font.weight: Font.DemiBold
                }
                Text {
                    height: 16
                    verticalAlignment: Text.AlignVCenter
                    visible: !overview.task.isIntegration
                    text: "Claude Code"
                    color: "#8E939C"
                    font.family: "Inter"
                    font.pixelSize: 11
                }
                Text {
                    height: 16
                    verticalAlignment: Text.AlignVCenter
                    visible: overview.steps.length > 1
                    text: (overview.task.stepIndex + 1) + "/" + overview.steps.length
                    color: "#6B7079"
                    font.family: "Inter"
                    font.pixelSize: 11
                }
            }

            Column {
                objectName: "overviewTicker"
                x: 108
                y: 34
                width: parent.width - 108 - 12
                spacing: 3
                Repeater {
                    model: overview.tail
                    Text {
                        required property string modelData
                        required property int index
                        width: parent.width
                        elide: Text.ElideRight
                        text: modelData
                        color: index === overview.tail.length - 1 ? "#F5F6F8" : "#6B7079"
                        font.family: "Inter"
                        font.pixelSize: 12
                    }
                }
                Text {
                    visible: overview.steps.length === 0
                    width: parent.width
                    wrapMode: Text.Wrap
                    text: overview.hint
                    color: "#6B7079"
                    font.family: "Inter"
                    font.pixelSize: 12
                }
            }

            // ↗ jump to the session
            Rectangle {
                x: parent.width - 26
                y: 8
                width: 16
                height: 16
                radius: 8
                visible: !overview.task.isIntegration
                color: Qt.rgba(1, 1, 1, 0.07)
                Text { anchors.centerIn: parent; text: "↗"; color: "#8E939C"; font.pixelSize: 9 }
                TapHandler { onTapped: { sessions.jump(appState.focusId); controller.collapse() } }
            }
        }

        Card {
            width: parent.width - 322 - 10
            height: parent.height

            Flickable {
                anchors.fill: parent
                anchors.margins: 8
                contentHeight: pills.height
                clip: true
                Flow {
                    id: pills
                    width: parent.width
                    spacing: 8
                    Repeater {
                        model: appState.tasks
                        Rectangle {
                            id: pill
                            property color tint: model.color
                            readonly property bool focused: model.taskId === appState.focusId
                            width: 132
                            height: 34
                            radius: 17
                            color: Qt.rgba(tint.r, tint.g, tint.b, 0.13)
                            border.width: focused ? 2 : 1
                            border.color: Qt.rgba(tint.r, tint.g, tint.b, focused ? 0.7 : 0.32)

                            Rectangle {   // stand-in for the mini-Mochi (L1b)
                                x: 10
                                anchors.verticalCenter: parent.verticalCenter
                                width: 14
                                height: 14
                                radius: 7
                                color: pill.tint
                                opacity: model.state === "idle" ? 0.6 : 1
                            }
                            Text {
                                x: 32
                                anchors.verticalCenter: parent.verticalCenter
                                width: parent.width - 32 - 10
                                elide: Text.ElideRight
                                text: model.name
                                color: Qt.lighter(pill.tint, 1.25)
                                font.family: "Inter"
                                font.pixelSize: 12
                            }
                            TapHandler { onTapped: appState.setFocus(model.taskId) }
                        }
                    }
                }
            }
        }
    }
}
```

- [ ] **Step 5: Hospedar as views e as teclas**

`linux/qml/ViewPlaceholder.qml` (abra o arquivo antes de editar): (1) depois de `property bool active: false` acrescente `property string contentSource: ""`; (2) no `Rectangle { ... }` filho (o cartão provisório) acrescente a primeira propriedade `visible: card.contentSource === ""`; (3) como último filho do `Item`, depois do `Rectangle`:

```qml
    Loader {
        anchors.fill: parent
        active: card.contentSource !== "" && card.visible
        source: card.contentSource
    }
```

`linux/qml/Island.qml`: (1) depois de `readonly property var viewNames: [...]` acrescente

```qml
    // Views with a real implementation; the others keep the provisional card until their L1c port.
    readonly property var contentViews: ({
        approval: "ApprovalView.qml", question: "QuestionView.qml", finished: "FinishedView.qml",
        error: "ErrorView.qml", overview: "OverviewView.qml"
    })
```
(2) no delegate `ViewPlaceholder { ... }` do `Repeater`, acrescente `contentSource: root.contentViews[modelData] || ""`; (3) depois de `Keys.onEscapePressed: controller.escapePressed()`:

```qml
    // Y / N answer the permission request in front; the island only has the keyboard after a click.
    Keys.onPressed: (event) => {
        if (appState.viewName !== "approval" || !approvals.active)
            return
        if (event.key === Qt.Key_Y) { approvals.allow(); event.accepted = true }
        else if (event.key === Qt.Key_N) { approvals.deny(); event.accepted = true }
    }
```

`linux/src/app/CMakeLists.txt`: acrescente à lista `FILES` de `coucou_qml`: `Card.qml PillButton.qml AgentWho.qml CodeBlock.qml ApprovalView.qml QuestionView.qml FinishedView.qml ErrorView.qml OverviewView.qml` (com o prefixo `${CMAKE_SOURCE_DIR}/qml/` como os demais).

- [ ] **Step 6: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: tudo passa, sem `ReferenceError`/`TypeError` do QML na saída (`QT_LOGGING_RULES="qt.qml*=true"` se precisar investigar). Se `keyClick` não chegar ao `root`, troque `root->forceActiveFocus()` por `view->requestActivate()` + `QTRY_VERIFY(view->isActive())`; o contrato (teclas Y/N só com a view `approval`) não muda.

- [ ] **Step 7: Verificação visual (captura)**

Com o app rodando (Task 8, passo 4) envie um pedido de permissão pelo `nb-hook` real **sem responder**:

```bash
linux/scripts/host.sh sh -c 'cd ~/src/farol/linux && (nohup build/src/app/coucou >build/l2-smoke.log 2>&1 &); sleep 6; (printf "%s" "{\"hook_event_name\":\"SessionStart\",\"session_id\":\"smoke1\",\"cwd\":\"/tmp/demo-project\"}" | ~/.local/share/coucou/nb-hook); (printf "%s" "{\"hook_event_name\":\"PermissionRequest\",\"session_id\":\"smoke1\",\"cwd\":\"/tmp/demo-project\",\"tool_name\":\"Bash\",\"tool_input\":{\"command\":\"rm -rf build && npm run build\"}}" | ~/.local/share/coucou/nb-hook --decision-timeout 40 >build/l2-decision.out &) ; sleep 2; spectacle -b -n -f -o build/l2-approval.png'
```
Leia `linux/build/l2-approval.png` (recorte do topo central): deve mostrar a ilha aberta com o cartão âmbar, `demo-project needs permission`, o comando e os botões `Deny N / Allow Y / Always`. Clique em **Allow** com o mouse e confirme que `linux/build/l2-decision.out` contém exatamente `{"hookSpecificOutput":{"hookEventName":"PermissionRequest","decision":{"behavior":"allow"}}}` (o hook espera até 40 s). Depois `linux/scripts/host.sh pkill -x coucou` (chamada própria).

- [ ] **Step 8: Commit**

```bash
git add linux/qml linux/src/app linux/tests
git commit -m "linux(L2): real approval/question/finished/error/overview views and Y/N keys

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 10: `JsonTree` e `ClaudeSettingsMerger` (merge que preserva a ordem)

`QJsonObject` ordena as chaves: reescrever o `settings.json` com ele embaralharia o arquivo inteiro e o diff mostraria ruído. O `JsonTree` guarda a ordem das chaves e o texto original de cada valor escalar.

**Files:**
- Create: `linux/src/core/JsonTree.h`, `linux/src/core/JsonTree.cpp`, `linux/src/core/ClaudeSettingsMerger.h`, `linux/src/core/ClaudeSettingsMerger.cpp`, `linux/tests/tst_settings_merger.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/tests/CMakeLists.txt` (`coucou_add_test(tst_settings_merger)`)

**Interfaces:**
- Produces:
  - `class coucou::JsonTree` — campos públicos `kind` (`Raw|Object|Array`), `raw`, `keys`/`rawKeys`/`values` (vetores paralelos do objeto), `items` (array); fábricas `object()`, `array()`, `string(text)`, `number(n)`; `static std::optional<JsonTree> parse(const QString &text, QString *error)` (valida com `QJsonDocument` antes); `QString serialize(int indent = 2) const` (sem `\n` final); `find(key)`, `set(key, value)` (devolve referência), `remove(key)`, `isString()`, `stringValue()`, `keyList()`; `static QString decodeString(const QString &rawToken)`.
  - `struct MergeResult { bool ok; QString text; QString error; bool changed; }`; `class ClaudeSettingsMerger { static constexpr const char *kMarker = ".local/share/coucou/nb-hook"; static const QStringList &events(); static MergeResult install(const QString &existing, const QString &hookPath, int decisionTimeoutSec); static MergeResult uninstall(const QString &existing); static bool isInstalled(const QString &existing); }`.
- Regras do merge: os 12 eventos de `INTEGRATIONS.md` §1 / spec §6.6; comando `"<hookPath>"` (com aspas, o caminho pode ter espaço) e, só em `PermissionRequest`, `"<hookPath>" --decision-timeout <N>`; timeout 10 s em todos, `PermissionRequest` = `N + 10`; remove do `hooks` **apenas** os comandos que contêm `.local/share/coucou/nb-hook` (um grupo que tinha também um hook alheio mantém o alheio); nunca toca nas outras chaves; arquivo vazio/ausente → objeto novo; JSON inválido, raiz que não é objeto, `hooks` que não é objeto ou lista de evento que não é array → erro e o texto original intacto.

- [ ] **Step 1: Escrever os testes**

`linux/tests/tst_settings_merger.cpp`:

```cpp
#include <QtTest>
#include <QJsonDocument>
#include <QJsonObject>
#include "ClaudeSettingsMerger.h"
#include "JsonTree.h"

using namespace coucou;

namespace {
const QString kHook = QStringLiteral("/home/u/.local/share/coucou/nb-hook");

// Canonical 2-space formatting, as Claude Code writes it.
// Custom raw-string delimiter: the content has `)"` inside ("Bash(python3 -)").
const QString kSettings = QStringLiteral(R"JSON({
  "respectGitignore": false,
  "permissions": {
    "allow": [
      "Bash(python3 -)",
      "Bash(awk 'NR==40{print \"len=\"length\\($0\\)}')"
    ]
  },
  "model": "opus[1m]",
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "echo 'fim — ok'"
          }
        ]
      }
    ]
  },
  "theme": "dark-daltonized"
}
)JSON");

const QString kNoHooks = QStringLiteral(R"JSON({
  "model": "opus[1m]",
  "theme": "dark"
}
)JSON");
} // namespace

class TestSettingsMerger : public QObject {
    Q_OBJECT
private slots:
    void roundTripIsIdentical()
    {
        QString err;
        const auto t = JsonTree::parse(kSettings, &err);
        QVERIFY2(t, qPrintable(err));
        QCOMPARE(t->serialize() + "\n", kSettings);
    }

    void roundTripKeepsEscapesNumbersAndEmptyContainers()
    {
        const QString text = QStringLiteral(R"({
  "a": 1.50e+3,
  "b": "é\/x",
  "c": [],
  "d": {},
  "e": null,
  "f": [
    1,
    [
      2
    ]
  ]
}
)");
        const auto t = JsonTree::parse(text, nullptr);
        QVERIFY(t);
        QCOMPARE(t->serialize() + "\n", text);
    }

    void parseRejectsInvalidJson()
    {
        QString err;
        QVERIFY(!JsonTree::parse("{\"a\": ", &err));
        QVERIFY(!err.isEmpty());
        QVERIFY(!JsonTree::parse("{} trailing", &err));
        QVERIFY(!JsonTree::parse("", &err));
    }

    void installKeepsKeyOrderEverythingElseAndAddsTheTwelveEvents()
    {
        const MergeResult r = ClaudeSettingsMerger::install(kSettings, kHook, 110);
        QVERIFY2(r.ok, qPrintable(r.error));
        QVERIFY(r.changed);
        // everything before "hooks" is byte-for-byte the original
        QVERIFY(r.text.startsWith(kSettings.left(kSettings.indexOf(QStringLiteral("  \"hooks\": {")))));
        QVERIFY(r.text.endsWith(QStringLiteral("  \"theme\": \"dark-daltonized\"\n}\n")));
        const auto tree = JsonTree::parse(r.text, nullptr);
        QVERIFY(tree);
        QCOMPARE(tree->keyList(), (QStringList{"respectGitignore", "permissions", "model", "hooks", "theme"}));

        const QJsonObject hooks = QJsonDocument::fromJson(r.text.toUtf8()).object().value("hooks").toObject();
        QCOMPARE(hooks.keys().size(), 12);
        for (const QString &ev : ClaudeSettingsMerger::events())
            QVERIFY2(hooks.contains(ev), qPrintable(ev));
        // the user's own Stop hook is still first, ours is appended
        const QJsonArray stop = hooks.value("Stop").toArray();
        QCOMPARE(stop.size(), 2);
        QVERIFY(stop.at(0).toObject().value("hooks").toArray().at(0).toObject().value("command").toString().startsWith("echo"));
        const QJsonObject ours = stop.at(1).toObject().value("hooks").toArray().at(0).toObject();
        QCOMPARE(ours.value("command").toString(), QStringLiteral("\"/home/u/.local/share/coucou/nb-hook\""));
        QCOMPARE(ours.value("timeout").toInt(), 10);
        QCOMPARE(ours.value("type").toString(), QStringLiteral("command"));

        const QJsonObject perm = hooks.value("PermissionRequest").toArray().at(0).toObject().value("hooks").toArray().at(0).toObject();
        QCOMPARE(perm.value("command").toString(), QStringLiteral("\"/home/u/.local/share/coucou/nb-hook\" --decision-timeout 110"));
        QCOMPARE(perm.value("timeout").toInt(), 120);
    }

    void installIsIdempotent()
    {
        const MergeResult once = ClaudeSettingsMerger::install(kSettings, kHook, 110);
        const MergeResult twice = ClaudeSettingsMerger::install(once.text, kHook, 110);
        QVERIFY(twice.ok);
        QCOMPARE(twice.text, once.text);
        QVERIFY(!twice.changed);
    }

    void installReplacesOurOldEntriesWithANewTimeout()
    {
        const MergeResult a = ClaudeSettingsMerger::install(kSettings, kHook, 110);
        const MergeResult b = ClaudeSettingsMerger::install(a.text, kHook, 60);
        QVERIFY(b.changed);
        const QJsonObject hooks = QJsonDocument::fromJson(b.text.toUtf8()).object().value("hooks").toObject();
        QCOMPARE(hooks.value("PermissionRequest").toArray().size(), 1);   // replaced, not duplicated
        QCOMPARE(hooks.value("Stop").toArray().size(), 2);
        QCOMPARE(hooks.value("PermissionRequest").toArray().at(0).toObject().value("hooks").toArray().at(0).toObject().value("timeout").toInt(), 70);
    }

    void uninstallRestoresTheOriginalExactly()
    {
        const MergeResult installed = ClaudeSettingsMerger::install(kSettings, kHook, 110);
        const MergeResult removed = ClaudeSettingsMerger::uninstall(installed.text);
        QVERIFY(removed.ok);
        QVERIFY(removed.changed);
        QCOMPARE(removed.text, kSettings);

        const MergeResult installed2 = ClaudeSettingsMerger::install(kNoHooks, kHook, 110);
        QCOMPARE(ClaudeSettingsMerger::uninstall(installed2.text).text, kNoHooks);   // "hooks" we created is removed again
    }

    void uninstallWithNothingInstalledChangesNothing()
    {
        const MergeResult r = ClaudeSettingsMerger::uninstall(kSettings);
        QVERIFY(r.ok);
        QVERIFY(!r.changed);
        QCOMPARE(r.text, kSettings);
    }

    void missingOrEmptyFileBecomesAFreshObject()
    {
        for (const QString &existing : {QString(), QStringLiteral("  \n")}) {
            const MergeResult r = ClaudeSettingsMerger::install(existing, kHook, 110);
            QVERIFY(r.ok);
            QVERIFY(r.changed);
            QVERIFY(QJsonDocument::fromJson(r.text.toUtf8()).object().contains("hooks"));
            QCOMPARE(ClaudeSettingsMerger::uninstall(r.text).text, QStringLiteral("{}\n"));
        }
    }

    void strangeFilesAreRefusedNotCorrupted()
    {
        for (const QString &bad : {QStringLiteral("{ not json"), QStringLiteral("[1,2]"), QStringLiteral("\"text\""),
                                   QStringLiteral(R"({"hooks": []})"), QStringLiteral(R"({"hooks": {"Stop": {}}})")}) {
            const MergeResult r = ClaudeSettingsMerger::install(bad, kHook, 110);
            QVERIFY2(!r.ok, qPrintable(bad));
            QVERIFY(!r.error.isEmpty());
            QVERIFY(r.text.isEmpty());                                // never a half-edited text
            const MergeResult u = ClaudeSettingsMerger::uninstall(bad);
            if (u.ok)
                QCOMPARE(u.text, bad);                                // nothing of ours in there: untouched
            else
                QVERIFY(!u.error.isEmpty());
        }
    }

    void aForeignHookSharingOurGroupSurvivesUninstall()
    {
        const QString shared = QStringLiteral(R"({
  "hooks": {
    "Stop": [
      {
        "hooks": [
          {
            "type": "command",
            "command": "echo foreign"
          },
          {
            "type": "command",
            "command": "\"/home/u/.local/share/coucou/nb-hook\"",
            "timeout": 10
          }
        ]
      }
    ]
  }
}
)");
        const MergeResult r = ClaudeSettingsMerger::uninstall(shared);
        QVERIFY(r.ok);
        const QJsonArray stop = QJsonDocument::fromJson(r.text.toUtf8()).object().value("hooks").toObject().value("Stop").toArray();
        QCOMPARE(stop.size(), 1);
        QCOMPARE(stop.at(0).toObject().value("hooks").toArray().size(), 1);
        QCOMPARE(stop.at(0).toObject().value("hooks").toArray().at(0).toObject().value("command").toString(), QStringLiteral("echo foreign"));
    }

    void isInstalledDetectsOnlyOurEntries()
    {
        QVERIFY(!ClaudeSettingsMerger::isInstalled(kSettings));
        QVERIFY(!ClaudeSettingsMerger::isInstalled(QString()));
        QVERIFY(!ClaudeSettingsMerger::isInstalled("{ broken"));
        QVERIFY(ClaudeSettingsMerger::isInstalled(ClaudeSettingsMerger::install(kSettings, kHook, 110).text));
    }

    void pathsWithSpacesAreQuotedAndStillRecognised()
    {
        const QString spaced = QStringLiteral("/home/a b/.local/share/coucou/nb-hook");
        const MergeResult r = ClaudeSettingsMerger::install(kNoHooks, spaced, 110);
        QVERIFY(ClaudeSettingsMerger::isInstalled(r.text));
        const QJsonObject hooks = QJsonDocument::fromJson(r.text.toUtf8()).object().value("hooks").toObject();
        QCOMPARE(hooks.value("Stop").toArray().at(0).toObject().value("hooks").toArray().at(0).toObject().value("command").toString(),
                 QStringLiteral("\"/home/a b/.local/share/coucou/nb-hook\""));
    }
};

QTEST_APPLESS_MAIN(TestSettingsMerger)
#include "tst_settings_merger.moc"
```

(`#include <QJsonArray>` no topo do teste.)

- [ ] **Step 2: Rodar e ver falhar** (não compila)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_settings_merger 2>&1 | tail -5`

- [ ] **Step 3: Implementar `JsonTree`**

`linux/src/core/JsonTree.h`:

```cpp
#pragma once
#include <QString>
#include <QStringList>
#include <optional>
#include <vector>

namespace coucou {

// Minimal JSON tree that keeps member order and the exact source text of every scalar, so a settings file can be
// edited and written back without reordering or re-escaping anything the editor did not touch. (QJsonObject
// sorts its keys, which would shuffle the whole file.)
class JsonTree {
public:
    enum class Kind { Raw, Object, Array };

    Kind kind = Kind::Raw;
    QString raw;                       // Raw: the token as written ("12", "true", "\"a\\nb\"")
    std::vector<QString> keys;         // Object: decoded keys, rawKeys (with quotes) and values are parallel
    std::vector<QString> rawKeys;
    std::vector<JsonTree> values;
    std::vector<JsonTree> items;       // Array

    static JsonTree object();
    static JsonTree array();
    static JsonTree string(const QString &text);   // a Raw token: quoted and escaped
    static JsonTree number(int n);

    // Validates with QJsonDocument first, then keeps the layout. On failure: nullopt and *error set.
    static std::optional<JsonTree> parse(const QString &text, QString *error);
    // 2-space indentation, "key": value, [] and {} for empty containers. No trailing newline.
    QString serialize(int indent = 2) const;

    JsonTree *find(const QString &key);
    const JsonTree *find(const QString &key) const;
    JsonTree &set(const QString &key, JsonTree value);   // replace in place, or append; returns the stored value
    bool remove(const QString &key);
    QStringList keyList() const;
    bool isString() const { return kind == Kind::Raw && raw.startsWith('"'); }
    QString stringValue() const;                          // decoded; empty unless isString()

    static QString decodeString(const QString &rawToken);
    static QString quote(const QString &text);
};

} // namespace coucou
```

`linux/src/core/JsonTree.cpp`:

```cpp
#include "JsonTree.h"

#include <QJsonArray>
#include <QJsonDocument>

namespace coucou {

namespace {

constexpr int kMaxDepth = 64;

struct Parser {
    const QString &s;
    int i = 0;
    QString err;

    bool fail(const QString &m)
    {
        if (err.isEmpty())
            err = QStringLiteral("%1 at offset %2").arg(m).arg(i);
        return false;
    }
    void ws()
    {
        while (i < s.size() && (s.at(i) == ' ' || s.at(i) == '\t' || s.at(i) == '\n' || s.at(i) == '\r'))
            ++i;
    }
    bool stringToken(QString &raw)
    {
        if (i >= s.size() || s.at(i) != '"')
            return fail(QStringLiteral("expected a string"));
        const int start = i++;
        while (i < s.size()) {
            const QChar c = s.at(i);
            if (c == '\\')
                i += 2;
            else if (c == '"') {
                ++i;
                raw = s.mid(start, i - start);
                return true;
            } else
                ++i;
        }
        return fail(QStringLiteral("unterminated string"));
    }
    bool value(JsonTree &out, int depth)
    {
        if (depth > kMaxDepth)
            return fail(QStringLiteral("nesting too deep"));
        ws();
        if (i >= s.size())
            return fail(QStringLiteral("unexpected end"));
        const QChar c = s.at(i);
        if (c == '{')
            return object(out, depth);
        if (c == '[')
            return array(out, depth);
        out = JsonTree();
        if (c == '"')
            return stringToken(out.raw);
        const int start = i;
        while (i < s.size() && !QStringLiteral(",]} \t\r\n").contains(s.at(i)))
            ++i;
        if (i == start)
            return fail(QStringLiteral("unexpected character"));
        out.raw = s.mid(start, i - start);
        return true;
    }
    bool object(JsonTree &out, int depth)
    {
        out = JsonTree::object();
        ++i;   // {
        ws();
        if (i < s.size() && s.at(i) == '}') {
            ++i;
            return true;
        }
        for (;;) {
            ws();
            QString rawKey;
            if (!stringToken(rawKey))
                return false;
            ws();
            if (i >= s.size() || s.at(i) != ':')
                return fail(QStringLiteral("expected ':'"));
            ++i;
            JsonTree v;
            if (!value(v, depth + 1))
                return false;
            out.keys.push_back(JsonTree::decodeString(rawKey));
            out.rawKeys.push_back(rawKey);
            out.values.push_back(std::move(v));
            ws();
            if (i < s.size() && s.at(i) == ',') {
                ++i;
                continue;
            }
            if (i < s.size() && s.at(i) == '}') {
                ++i;
                return true;
            }
            return fail(QStringLiteral("expected ',' or '}'"));
        }
    }
    bool array(JsonTree &out, int depth)
    {
        out = JsonTree::array();
        ++i;   // [
        ws();
        if (i < s.size() && s.at(i) == ']') {
            ++i;
            return true;
        }
        for (;;) {
            JsonTree v;
            if (!value(v, depth + 1))
                return false;
            out.items.push_back(std::move(v));
            ws();
            if (i < s.size() && s.at(i) == ',') {
                ++i;
                continue;
            }
            if (i < s.size() && s.at(i) == ']') {
                ++i;
                return true;
            }
            return fail(QStringLiteral("expected ',' or ']'"));
        }
    }
};

void write(const JsonTree &t, int level, int indent, QString &out)
{
    const QString pad(level * indent, ' ');
    const QString inner((level + 1) * indent, ' ');
    switch (t.kind) {
    case JsonTree::Kind::Raw:
        out += t.raw;
        break;
    case JsonTree::Kind::Object:
        if (t.values.empty()) {
            out += QStringLiteral("{}");
            break;
        }
        out += QStringLiteral("{\n");
        for (size_t k = 0; k < t.values.size(); ++k) {
            out += inner + t.rawKeys[k] + QStringLiteral(": ");
            write(t.values[k], level + 1, indent, out);
            out += (k + 1 < t.values.size()) ? QStringLiteral(",\n") : QStringLiteral("\n");
        }
        out += pad + QLatin1Char('}');
        break;
    case JsonTree::Kind::Array:
        if (t.items.empty()) {
            out += QStringLiteral("[]");
            break;
        }
        out += QStringLiteral("[\n");
        for (size_t k = 0; k < t.items.size(); ++k) {
            out += inner;
            write(t.items[k], level + 1, indent, out);
            out += (k + 1 < t.items.size()) ? QStringLiteral(",\n") : QStringLiteral("\n");
        }
        out += pad + QLatin1Char(']');
        break;
    }
}

} // namespace

JsonTree JsonTree::object()
{
    JsonTree t;
    t.kind = Kind::Object;
    return t;
}

JsonTree JsonTree::array()
{
    JsonTree t;
    t.kind = Kind::Array;
    return t;
}

JsonTree JsonTree::string(const QString &text)
{
    JsonTree t;
    t.raw = quote(text);
    return t;
}

JsonTree JsonTree::number(int n)
{
    JsonTree t;
    t.raw = QString::number(n);
    return t;
}

QString JsonTree::quote(const QString &text)
{
    QString out = QStringLiteral("\"");
    for (const QChar c : text) {
        switch (c.unicode()) {
        case '"': out += QStringLiteral("\\\""); break;
        case '\\': out += QStringLiteral("\\\\"); break;
        case '\n': out += QStringLiteral("\\n"); break;
        case '\r': out += QStringLiteral("\\r"); break;
        case '\t': out += QStringLiteral("\\t"); break;
        default:
            if (c.unicode() < 0x20)
                out += QStringLiteral("\\u%1").arg(c.unicode(), 4, 16, QLatin1Char('0'));
            else
                out += c;
        }
    }
    return out + QLatin1Char('"');
}

QString JsonTree::decodeString(const QString &rawToken)
{
    const QJsonDocument doc = QJsonDocument::fromJson(("[" + rawToken + "]").toUtf8());
    return doc.array().isEmpty() ? QString() : doc.array().first().toString();
}

QString JsonTree::stringValue() const { return isString() ? decodeString(raw) : QString(); }

std::optional<JsonTree> JsonTree::parse(const QString &text, QString *error)
{
    auto fail = [&](const QString &m) -> std::optional<JsonTree> {
        if (error)
            *error = m;
        return std::nullopt;
    };
    QJsonParseError pe;
    QJsonDocument::fromJson(text.toUtf8(), &pe);
    if (pe.error != QJsonParseError::NoError)
        return fail(QStringLiteral("invalid JSON: %1 (offset %2)").arg(pe.errorString()).arg(pe.offset));
    Parser p{text};
    JsonTree t;
    if (!p.value(t, 0))
        return fail(p.err);
    p.ws();
    if (p.i != text.size())
        return fail(QStringLiteral("unexpected content after the document"));
    return t;
}

QString JsonTree::serialize(int indent) const
{
    QString out;
    write(*this, 0, indent, out);
    return out;
}

JsonTree *JsonTree::find(const QString &key)
{
    for (size_t k = 0; k < keys.size(); ++k)
        if (keys[k] == key)
            return &values[k];
    return nullptr;
}

const JsonTree *JsonTree::find(const QString &key) const
{
    return const_cast<JsonTree *>(this)->find(key);
}

JsonTree &JsonTree::set(const QString &key, JsonTree value)
{
    if (JsonTree *existing = find(key)) {
        *existing = std::move(value);
        return *existing;
    }
    keys.push_back(key);
    rawKeys.push_back(quote(key));
    values.push_back(std::move(value));
    return values.back();
}

bool JsonTree::remove(const QString &key)
{
    for (size_t k = 0; k < keys.size(); ++k) {
        if (keys[k] == key) {
            keys.erase(keys.begin() + k);
            rawKeys.erase(rawKeys.begin() + k);
            values.erase(values.begin() + k);
            return true;
        }
    }
    return false;
}

QStringList JsonTree::keyList() const
{
    QStringList out;
    for (const QString &k : keys)
        out << k;
    return out;
}

} // namespace coucou
```

`linux/src/core/ClaudeSettingsMerger.h`:

```cpp
#pragma once
#include <QString>
#include <QStringList>

namespace coucou {

struct MergeResult {
    bool ok = false;
    QString text;      // the new file text (== the input when nothing changes)
    QString error;
    bool changed = false;
};

// Adds/removes the Coucou hooks in the text of ~/.claude/settings.json without touching anything else.
class ClaudeSettingsMerger {
public:
    // A hook command is "ours" when it contains this (the nb-hook path under $HOME).
    static constexpr const char *kMarker = ".local/share/coucou/nb-hook";

    static const QStringList &events();
    // existing: the current file text ("" when the file is missing). hookPath: absolute path of nb-hook.
    static MergeResult install(const QString &existing, const QString &hookPath, int decisionTimeoutSec);
    static MergeResult uninstall(const QString &existing);
    static bool isInstalled(const QString &existing);
};

} // namespace coucou
```

`linux/src/core/ClaudeSettingsMerger.cpp`:

```cpp
#include "ClaudeSettingsMerger.h"

#include "JsonTree.h"

#include <algorithm>

namespace coucou {

namespace {

bool isOurs(const JsonTree &hook)
{
    if (hook.kind != JsonTree::Kind::Object)
        return false;
    const JsonTree *c = hook.find(QStringLiteral("command"));
    return c && c->isString() && c->stringValue().contains(QLatin1String(ClaudeSettingsMerger::kMarker));
}

// Removes our commands from a list of matcher groups; a group left without hooks goes away too.
int removeOurs(JsonTree &list)
{
    int removed = 0;
    for (size_t g = 0; g < list.items.size();) {
        JsonTree &group = list.items[g];
        JsonTree *inner = group.kind == JsonTree::Kind::Object ? group.find(QStringLiteral("hooks")) : nullptr;
        if (inner && inner->kind == JsonTree::Kind::Array) {
            const size_t before = inner->items.size();
            std::erase_if(inner->items, [](const JsonTree &h) { return isOurs(h); });
            const int n = int(before - inner->items.size());
            removed += n;
            if (n > 0 && inner->items.empty()) {
                list.items.erase(list.items.begin() + g);
                continue;
            }
        }
        ++g;
    }
    return removed;
}

JsonTree entryFor(const QString &command, int timeoutSec)
{
    JsonTree hook = JsonTree::object();
    hook.set(QStringLiteral("type"), JsonTree::string(QStringLiteral("command")));
    hook.set(QStringLiteral("command"), JsonTree::string(command));
    hook.set(QStringLiteral("timeout"), JsonTree::number(timeoutSec));
    JsonTree hooks = JsonTree::array();
    hooks.items.push_back(std::move(hook));
    JsonTree group = JsonTree::object();
    group.set(QStringLiteral("hooks"), std::move(hooks));
    return group;
}

QString quotedPath(const QString &path)
{
    QString p = path;
    p.replace('"', QStringLiteral("\\\""));
    return QLatin1Char('"') + p + QLatin1Char('"');
}

MergeResult failure(const QString &message)
{
    MergeResult r;
    r.error = message;
    return r;
}

// Parses the file into an object (an empty file becomes a new one); fills the error otherwise.
bool loadRoot(const QString &existing, JsonTree &root, QString &error)
{
    if (existing.trimmed().isEmpty()) {
        root = JsonTree::object();
        return true;
    }
    auto parsed = JsonTree::parse(existing, &error);
    if (!parsed)
        return false;
    if (parsed->kind != JsonTree::Kind::Object) {
        error = QStringLiteral("settings.json is not a JSON object");
        return false;
    }
    root = std::move(*parsed);
    return true;
}

} // namespace

const QStringList &ClaudeSettingsMerger::events()
{
    static const QStringList list = {"SessionStart", "SessionEnd", "UserPromptSubmit", "PreToolUse", "PostToolUse",
                                     "PostToolUseFailure", "PermissionRequest", "Notification", "Stop", "StopFailure",
                                     "SubagentStart", "SubagentStop"};
    return list;
}

MergeResult ClaudeSettingsMerger::install(const QString &existing, const QString &hookPath, int decisionTimeoutSec)
{
    JsonTree root;
    QString error;
    if (!loadRoot(existing, root, error))
        return failure(error);

    JsonTree *hooks = root.find(QStringLiteral("hooks"));
    if (!hooks)
        hooks = &root.set(QStringLiteral("hooks"), JsonTree::object());
    else if (hooks->kind != JsonTree::Kind::Object)
        return failure(QStringLiteral("\"hooks\" in settings.json is not an object"));

    for (const QString &event : events()) {
        JsonTree *list = hooks->find(event);
        if (!list)
            list = &hooks->set(event, JsonTree::array());
        else if (list->kind != JsonTree::Kind::Array)
            return failure(QStringLiteral("\"hooks.%1\" in settings.json is not an array").arg(event));
        removeOurs(*list);
        const bool permission = event == QLatin1String("PermissionRequest");
        const QString command = quotedPath(hookPath) +
                                (permission ? QStringLiteral(" --decision-timeout %1").arg(decisionTimeoutSec) : QString());
        list->items.push_back(entryFor(command, permission ? decisionTimeoutSec + 10 : 10));
    }
    MergeResult r;
    r.ok = true;
    r.text = root.serialize() + QLatin1Char('\n');
    r.changed = r.text != existing;
    return r;
}

MergeResult ClaudeSettingsMerger::uninstall(const QString &existing)
{
    JsonTree root;
    QString error;
    if (!loadRoot(existing, root, error))
        return failure(error);
    MergeResult r;
    r.ok = true;
    r.text = existing;
    JsonTree *hooks = root.find(QStringLiteral("hooks"));
    if (!hooks || hooks->kind != JsonTree::Kind::Object)
        return r;

    int removed = 0;
    for (const QString &event : hooks->keyList()) {
        JsonTree *list = hooks->find(event);
        if (!list || list->kind != JsonTree::Kind::Array)
            continue;
        const int n = removeOurs(*list);
        removed += n;
        if (n > 0 && list->items.empty())
            hooks->remove(event);
    }
    if (removed == 0)
        return r;
    if (hooks->values.empty())
        root.remove(QStringLiteral("hooks"));
    r.text = root.serialize() + QLatin1Char('\n');
    r.changed = true;
    return r;
}

bool ClaudeSettingsMerger::isInstalled(const QString &existing)
{
    JsonTree root;
    QString error;
    if (existing.trimmed().isEmpty() || !loadRoot(existing, root, error))
        return false;
    const JsonTree *hooks = root.find(QStringLiteral("hooks"));
    if (!hooks || hooks->kind != JsonTree::Kind::Object)
        return false;
    for (const JsonTree &list : hooks->values) {
        if (list.kind != JsonTree::Kind::Array)
            continue;
        for (const JsonTree &group : list.items) {
            const JsonTree *inner = group.kind == JsonTree::Kind::Object ? group.find(QStringLiteral("hooks")) : nullptr;
            if (inner && inner->kind == JsonTree::Kind::Array &&
                std::any_of(inner->items.begin(), inner->items.end(), [](const JsonTree &h) { return isOurs(h); }))
                return true;
        }
    }
    return false;
}

} // namespace coucou
```

Registre `JsonTree.h JsonTree.cpp ClaudeSettingsMerger.h ClaudeSettingsMerger.cpp` em `src/core/CMakeLists.txt` e `coucou_add_test(tst_settings_merger)` em `tests/CMakeLists.txt`.

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build --target tst_settings_merger && linux/scripts/host.sh linux/build/tests/tst_settings_merger`
Expected: todos PASS. Em seguida valide contra o arquivo real **sem escrever nada**:

```bash
linux/scripts/host.sh sh -c 'cd ~/src/farol/linux && python3 - <<EOF
import json,os
p=os.path.expanduser("~/.claude/settings.json")
raw=open(p).read()
json.loads(raw)
print("lines:",len(raw.splitlines()), "ends with newline:", raw.endswith("\n"))
EOF'
```
Anote no `L2-notes.md` se o `settings.json` real do usuário difere do formato canônico (indentação ≠ 2, arrays em linha): o diff da Task 11 vai mostrar a reformatação e o usuário a verá antes de confirmar.

- [ ] **Step 5: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux(L2): order-preserving JsonTree and the Claude settings merger

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 11: `TextDiff` e `HooksInstaller` (backup, checagem concorrente, symlink, escrita atômica)

**Files:**
- Create: `linux/src/core/TextDiff.h`, `linux/src/core/TextDiff.cpp`, `linux/src/core/HooksInstaller.h`, `linux/src/core/HooksInstaller.cpp`, `linux/tests/tst_text_diff.cpp`, `linux/tests/tst_hooks_installer.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/tests/CMakeLists.txt` (`coucou_add_test(tst_text_diff)`, `coucou_add_test(tst_hooks_installer)`)

**Interfaces:**
- Produces:
  - `QString coucou::unifiedDiff(const QString &a, const QString &b, const QString &labelA, const QString &labelB, int context = 3)` — vazio se iguais; cabeçalho `--- labelA` / `+++ labelB`, hunks `@@ -a,b +c,d @@`, linhas com prefixo ` `, `-`, `+`. Acima de 4 milhões de células (n·m) cai no diff "tudo removido / tudo adicionado".
  - `struct HooksPlan { bool ok; QString error; QString before, after, diff; bool changes; bool settingsExisted; }`.
  - `class HooksInstaller { HooksInstaller(QString settingsPath, QString hookPath, int decisionTimeoutSec = 110, std::function<QDateTime()> clock = now); HooksPlan planInstall() const; HooksPlan planUninstall() const; bool installed() const; QString backupPathFor() const; bool apply(const HooksPlan &plan, QString *error, QString *backupPath = nullptr) const; }`.
- Regras: backup `settings.json.bak-AAAAMMDD-HHMM` ao lado do arquivo (com sufixo `-2`, `-3`… se já existir); `apply` recusa se o arquivo mudou desde o `plan` (nada é escrito nem copiado); o backup é feito **antes** da escrita e, se falhar, nada é escrito; se `settings.json` é symlink, escreve no alvo e o link continua link; escrita atômica (`QSaveFile`); permissões originais mantidas; arquivo ausente → cria a pasta, sem backup.

- [ ] **Step 1: Escrever os testes**

`linux/tests/tst_text_diff.cpp`:

```cpp
#include <QtTest>
#include "TextDiff.h"

using namespace coucou;

class TestTextDiff : public QObject {
    Q_OBJECT
    static QString lines(int from, int to)
    {
        QStringList l;
        for (int i = from; i <= to; ++i)
            l << QStringLiteral("l%1").arg(i);
        return l.join('\n');
    }

private slots:
    void identicalTextsGiveNoDiff() { QVERIFY(unifiedDiff("a\nb", "a\nb", "A", "B").isEmpty()); }

    void insertion()
    {
        QCOMPARE(unifiedDiff("a\nb\nc\nd\ne", "a\nb\nX\nc\nd\ne", "A", "B"),
                 QStringLiteral("--- A\n+++ B\n@@ -1,5 +1,6 @@\n a\n b\n+X\n c\n d\n e\n"));
    }

    void replacement()
    {
        QCOMPARE(unifiedDiff("1\n2\n3", "1\nX\n3", "A", "B"),
                 QStringLiteral("--- A\n+++ B\n@@ -1,3 +1,3 @@\n 1\n-2\n+X\n 3\n"));
    }

    void removal()
    {
        QCOMPARE(unifiedDiff("1\n2\n3", "1\n3", "A", "B"),
                 QStringLiteral("--- A\n+++ B\n@@ -1,3 +1,2 @@\n 1\n-2\n 3\n"));
    }

    void farApartChangesMakeTwoHunks()
    {
        QString a = lines(1, 20);
        QString b = a;
        b.replace("l2\n", "L2\n");
        b.replace("l19\n", "L19\n");
        QCOMPARE(unifiedDiff(a, b, "A", "B").count("@@ -"), 2);
    }

    void nearbyChangesMergeIntoOneHunk()
    {
        QString a = lines(1, 20);
        QString b = a;
        b.replace("l2\n", "L2\n");
        b.replace("l6\n", "L6\n");
        QCOMPARE(unifiedDiff(a, b, "A", "B").count("@@ -"), 1);
    }

    void hugeInputsFallBackToWholeReplacement()
    {
        QStringList a, b;
        for (int i = 0; i < 2001; ++i) {
            a << QStringLiteral("a%1").arg(i);
            b << QStringLiteral("b%1").arg(i);
        }
        const QString d = unifiedDiff(a.join('\n'), b.join('\n'), "A", "B");
        QVERIFY(d.startsWith("--- A\n+++ B\n@@ -1,2001 +1,2001 @@\n-a0\n"));
    }
};

QTEST_APPLESS_MAIN(TestTextDiff)
#include "tst_text_diff.moc"
```

`linux/tests/tst_hooks_installer.cpp`:

```cpp
#include <QtTest>
#include <QDateTime>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTemporaryDir>
#include "HooksInstaller.h"

using namespace coucou;

namespace {
const QString kHook = QStringLiteral("/home/u/.local/share/coucou/nb-hook");
const QString kOriginal = QStringLiteral("{\n  \"model\": \"opus\",\n  \"theme\": \"dark\"\n}\n");

QDateTime fixedClock() { return QDateTime(QDate(2026, 9, 30), QTime(12, 15)); }

void writeFile(const QString &path, const QString &text)
{
    QFile f(path);
    QVERIFY(f.open(QIODevice::WriteOnly));
    f.write(text.toUtf8());
}
QString readFile(const QString &path)
{
    QFile f(path);
    return f.open(QIODevice::ReadOnly) ? QString::fromUtf8(f.readAll()) : QString();
}
} // namespace

class TestHooksInstaller : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    QString settings() const { return dir.path() + "/.claude/settings.json"; }
    HooksInstaller installer() const { return HooksInstaller(settings(), kHook, 110, fixedClock); }

private slots:
    void init()
    {
        QDir(dir.path() + "/.claude").removeRecursively();
        QDir().mkpath(dir.path() + "/.claude");
    }

    void planInstallShowsADiffAndChangesNothingOnDisk()
    {
        writeFile(settings(), kOriginal);
        const HooksPlan p = installer().planInstall();
        QVERIFY2(p.ok, qPrintable(p.error));
        QVERIFY(p.changes);
        QVERIFY(p.settingsExisted);
        QCOMPARE(p.before, kOriginal);
        QVERIFY(p.diff.contains("+  \"hooks\": {"));
        QVERIFY(p.diff.contains("--- settings.json (current)"));
        QCOMPARE(readFile(settings()), kOriginal);                         // planning writes nothing
        QVERIFY(QDir(dir.path() + "/.claude").entryList({"*.bak-*"}).isEmpty());
    }

    void applyBacksUpThenWrites()
    {
        writeFile(settings(), kOriginal);
        const HooksPlan p = installer().planInstall();
        QString err, backup;
        QVERIFY2(installer().apply(p, &err, &backup), qPrintable(err));
        QCOMPARE(readFile(settings()), p.after);
        QCOMPARE(backup, dir.path() + "/.claude/settings.json.bak-20260930-1215");
        QCOMPARE(readFile(backup), kOriginal);
        QVERIFY(installer().installed());
    }

    void backupNamesDoNotCollideWithinTheSameMinute()
    {
        writeFile(settings(), kOriginal);
        writeFile(settings() + ".bak-20260930-1215", "earlier");
        QString backup;
        QString err;
        QVERIFY(installer().apply(installer().planInstall(), &err, &backup));
        QCOMPARE(backup, dir.path() + "/.claude/settings.json.bak-20260930-1215-2");
        QCOMPARE(readFile(settings() + ".bak-20260930-1215"), QStringLiteral("earlier"));
    }

    void missingFileIsCreatedWithoutABackup()
    {
        QFile::remove(settings());
        QDir(dir.path() + "/.claude").removeRecursively();
        const HooksPlan p = installer().planInstall();
        QVERIFY(p.ok);
        QVERIFY(!p.settingsExisted);
        QString err;
        QVERIFY2(installer().apply(p, &err), qPrintable(err));
        QVERIFY(QJsonDocument::fromJson(readFile(settings()).toUtf8()).object().contains("hooks"));
        QVERIFY(QDir(dir.path() + "/.claude").entryList({"*.bak-*"}).isEmpty());
    }

    void applyRefusesWhenTheFileChangedAfterThePreview()
    {
        writeFile(settings(), kOriginal);
        const HooksPlan p = installer().planInstall();
        const QString edited = QStringLiteral("{\n  \"model\": \"sonnet\"\n}\n");
        writeFile(settings(), edited);                                     // e.g. Claude Code rewrote it meanwhile
        QString err;
        QVERIFY(!installer().apply(p, &err));
        QVERIFY(err.contains("changed"));
        QCOMPARE(readFile(settings()), edited);                            // untouched
        QVERIFY(QDir(dir.path() + "/.claude").entryList({"*.bak-*"}).isEmpty());
    }

    void invalidJsonIsRefusedAndLeftAlone()
    {
        writeFile(settings(), "{ broken");
        const HooksPlan p = installer().planInstall();
        QVERIFY(!p.ok);
        QVERIFY(!p.error.isEmpty());
        QString err;
        QVERIFY(!installer().apply(p, &err));
        QCOMPARE(readFile(settings()), QStringLiteral("{ broken"));
    }

    void uninstallFlowAndNoOp()
    {
        writeFile(settings(), kOriginal);
        QString err;
        QVERIFY(installer().apply(installer().planInstall(), &err));
        const HooksPlan off = installer().planUninstall();
        QVERIFY(off.ok);
        QVERIFY(off.changes);
        QVERIFY(installer().apply(off, &err));
        QCOMPARE(readFile(settings()), kOriginal);
        QVERIFY(!installer().installed());
        const HooksPlan again = installer().planUninstall();
        QVERIFY(again.ok);
        QVERIFY(!again.changes);
        QVERIFY(!installer().apply(again, &err));                          // nothing to write
    }

    void permissionsAreKept()
    {
        writeFile(settings(), kOriginal);
        QFile::setPermissions(settings(), QFile::ReadOwner | QFile::WriteOwner);   // 0600
        QString err;
        QVERIFY(installer().apply(installer().planInstall(), &err));
        QCOMPARE(QFile::permissions(settings()) & (QFile::ReadGroup | QFile::ReadOther | QFile::WriteGroup | QFile::WriteOther),
                 QFile::Permissions());
    }

    void symlinkedSettingsKeepTheLinkAndWriteTheTarget()
    {
        QDir().mkpath(dir.path() + "/dotfiles");
        const QString real = dir.path() + "/dotfiles/claude-settings.json";
        writeFile(real, kOriginal);
        QFile::remove(settings());
        QVERIFY(QFile::link(real, settings()));
        const HooksPlan p = installer().planInstall();
        QVERIFY(p.ok);
        QString err;
        QVERIFY2(installer().apply(p, &err), qPrintable(err));
        QVERIFY(QFileInfo(settings()).isSymLink());
        QCOMPARE(readFile(real), p.after);
    }
};

QTEST_MAIN(TestHooksInstaller)
#include "tst_hooks_installer.moc"
```

- [ ] **Step 2: Rodar e ver falhar** (não compila)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_text_diff tst_hooks_installer 2>&1 | tail -5`

- [ ] **Step 3: Implementar**

`linux/src/core/TextDiff.h`:

```cpp
#pragma once
#include <QString>

namespace coucou {

// Unified diff by lines (LCS). Empty when a == b. Past 4 million cells (n*m) it degrades to "all removed, all added".
QString unifiedDiff(const QString &a, const QString &b, const QString &labelA, const QString &labelB, int context = 3);

} // namespace coucou
```

`linux/src/core/TextDiff.cpp`:

```cpp
#include "TextDiff.h"

#include <QList>
#include <QStringList>
#include <QVector>

namespace coucou {

namespace {
struct Op {
    QChar kind;   // ' ', '-', '+'
    int ai, bi;   // line index in A / B, -1 when absent
};
} // namespace

QString unifiedDiff(const QString &a, const QString &b, const QString &labelA, const QString &labelB, int context)
{
    if (a == b)
        return {};
    const QStringList A = a.split('\n');
    const QStringList B = b.split('\n');
    const int n = int(A.size()), m = int(B.size());

    QList<Op> ops;
    if (qint64(n) * m > 4'000'000) {
        for (int i = 0; i < n; ++i)
            ops.append({'-', i, -1});
        for (int j = 0; j < m; ++j)
            ops.append({'+', -1, j});
    } else {
        QVector<int> L(qsizetype(n + 1) * (m + 1), 0);
        auto at = [&](int i, int j) -> int & { return L[qsizetype(i) * (m + 1) + j]; };
        for (int i = n - 1; i >= 0; --i)
            for (int j = m - 1; j >= 0; --j)
                at(i, j) = A[i] == B[j] ? at(i + 1, j + 1) + 1 : qMax(at(i + 1, j), at(i, j + 1));
        int i = 0, j = 0;
        while (i < n && j < m) {
            if (A[i] == B[j]) {
                ops.append({' ', i++, j++});
            } else if (at(i + 1, j) >= at(i, j + 1)) {
                ops.append({'-', i++, -1});
            } else {
                ops.append({'+', -1, j++});
            }
        }
        while (i < n)
            ops.append({'-', i++, -1});
        while (j < m)
            ops.append({'+', -1, j++});
    }

    const int N = int(ops.size());
    QVector<int> aBefore(N + 1, 0), bBefore(N + 1, 0);
    for (int k = 0; k < N; ++k) {
        aBefore[k + 1] = aBefore[k] + (ops[k].kind != '+' ? 1 : 0);
        bBefore[k + 1] = bBefore[k] + (ops[k].kind != '-' ? 1 : 0);
    }

    QStringList out;
    out << QStringLiteral("--- ") + labelA << QStringLiteral("+++ ") + labelB;
    int k = 0;
    while (k < N) {
        if (ops[k].kind == ' ') {
            ++k;
            continue;
        }
        const int start = qMax(0, k - context);
        int end = k;
        int scan = k;
        while (scan < N) {
            if (ops[scan].kind != ' ') {
                end = scan++;
                continue;
            }
            int next = scan;
            while (next < N && ops[next].kind == ' ')
                ++next;
            if (next < N && next - scan <= 2 * context) {
                scan = next;
                continue;
            }
            break;
        }
        const int stop = qMin(N, end + 1 + context);
        out << QStringLiteral("@@ -%1,%2 +%3,%4 @@")
                   .arg(aBefore[start] + 1).arg(aBefore[stop] - aBefore[start])
                   .arg(bBefore[start] + 1).arg(bBefore[stop] - bBefore[start]);
        for (int t = start; t < stop; ++t)
            out << QString(ops[t].kind) + (ops[t].kind == '+' ? B[ops[t].bi] : A[ops[t].ai]);
        k = stop;
    }
    return out.join('\n') + '\n';
}

} // namespace coucou
```

`linux/src/core/HooksInstaller.h`:

```cpp
#pragma once
#include <QDateTime>
#include <QString>
#include <functional>

namespace coucou {

struct HooksPlan {
    bool ok = false;
    QString error;
    QString before, after;   // file text now / after the change
    QString diff;
    bool changes = false;
    bool settingsExisted = false;
};

// Previews and applies the Coucou hooks in ~/.claude/settings.json: backup, diff, atomic write. It never writes
// without a plan, and a plan never writes anything.
class HooksInstaller {
public:
    using Clock = std::function<QDateTime()>;
    HooksInstaller(QString settingsPath, QString hookPath, int decisionTimeoutSec = 110,
                   Clock clock = [] { return QDateTime::currentDateTime(); });

    HooksPlan planInstall() const { return plan(true); }
    HooksPlan planUninstall() const { return plan(false); }
    bool installed() const;
    // settings.json.bak-YYYYMMDD-HHMM next to the settings file, "-2", "-3"... when it already exists.
    QString backupPathFor() const;
    // Writes plan.after. Refuses (writing and copying nothing) when the file is not exactly plan.before any more.
    bool apply(const HooksPlan &plan, QString *error, QString *backupPath = nullptr) const;

private:
    HooksPlan plan(bool install) const;
    QString targetPath() const;   // follows a symlink (dotfile managers)
    bool readCurrent(QString *text, QString *error) const;

    QString m_settingsPath, m_hookPath;
    int m_decisionTimeoutSec;
    Clock m_clock;
};

} // namespace coucou
```

`linux/src/core/HooksInstaller.cpp`:

```cpp
#include "HooksInstaller.h"

#include "ClaudeSettingsMerger.h"
#include "TextDiff.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QSaveFile>

namespace coucou {

HooksInstaller::HooksInstaller(QString settingsPath, QString hookPath, int decisionTimeoutSec, Clock clock)
    : m_settingsPath(std::move(settingsPath)), m_hookPath(std::move(hookPath)),
      m_decisionTimeoutSec(decisionTimeoutSec), m_clock(std::move(clock))
{
}

QString HooksInstaller::targetPath() const
{
    const QFileInfo fi(m_settingsPath);
    if (fi.isSymLink()) {
        const QString target = fi.canonicalFilePath();
        if (!target.isEmpty())
            return target;
    }
    return m_settingsPath;
}

bool HooksInstaller::readCurrent(QString *text, QString *error) const
{
    QFile f(targetPath());
    if (!f.exists()) {
        text->clear();
        return true;
    }
    if (!f.open(QIODevice::ReadOnly)) {
        *error = QStringLiteral("Cannot read %1: %2").arg(f.fileName(), f.errorString());
        return false;
    }
    *text = QString::fromUtf8(f.readAll());
    return true;
}

HooksPlan HooksInstaller::plan(bool install) const
{
    HooksPlan p;
    if (!readCurrent(&p.before, &p.error))
        return p;
    p.settingsExisted = QFileInfo::exists(targetPath());
    const MergeResult r = install ? ClaudeSettingsMerger::install(p.before, m_hookPath, m_decisionTimeoutSec)
                                  : ClaudeSettingsMerger::uninstall(p.before);
    if (!r.ok) {
        p.error = r.error;
        return p;
    }
    p.ok = true;
    p.after = r.text;
    p.changes = r.changed;
    p.diff = unifiedDiff(p.before, p.after, QStringLiteral("settings.json (current)"), QStringLiteral("settings.json (after)"));
    return p;
}

bool HooksInstaller::installed() const
{
    QString text, error;
    return readCurrent(&text, &error) && ClaudeSettingsMerger::isInstalled(text);
}

QString HooksInstaller::backupPathFor() const
{
    const QFileInfo fi(m_settingsPath);
    const QString base = fi.absolutePath() + QLatin1Char('/') + fi.fileName() + QStringLiteral(".bak-") +
                         m_clock().toString(QStringLiteral("yyyyMMdd-HHmm"));
    QString path = base;
    for (int n = 2; QFileInfo::exists(path); ++n)
        path = base + QStringLiteral("-%1").arg(n);
    return path;
}

bool HooksInstaller::apply(const HooksPlan &plan, QString *error, QString *backupPath) const
{
    auto fail = [&](const QString &m) {
        if (error)
            *error = m;
        return false;
    };
    if (!plan.ok || !plan.changes)
        return fail(QStringLiteral("Nothing to write."));

    QString now, err;
    if (!readCurrent(&now, &err))
        return fail(err);
    if (now != plan.before)
        return fail(QStringLiteral("settings.json changed after the preview was made. Nothing was written; open the "
                                   "dialog again to see the new diff."));

    const QString target = targetPath();
    QFile::Permissions perms;
    if (QFileInfo::exists(target)) {
        perms = QFile::permissions(target);
        const QString backup = backupPathFor();
        if (!QFile::copy(target, backup))
            return fail(QStringLiteral("Could not create the backup %1; nothing was written.").arg(backup));
        if (backupPath)
            *backupPath = backup;
    } else if (!QDir().mkpath(QFileInfo(target).absolutePath())) {
        return fail(QStringLiteral("Could not create %1").arg(QFileInfo(target).absolutePath()));
    }

    QSaveFile out(target);
    if (!out.open(QIODevice::WriteOnly))
        return fail(QStringLiteral("Cannot write %1: %2").arg(target, out.errorString()));
    out.write(plan.after.toUtf8());
    if (!out.commit())
        return fail(QStringLiteral("Cannot write %1: %2").arg(target, out.errorString()));
    if (perms)
        QFile::setPermissions(target, perms);
    return true;
}

} // namespace coucou
```

Registre `TextDiff.h TextDiff.cpp HooksInstaller.h HooksInstaller.cpp` em `src/core/CMakeLists.txt` e os dois testes em `tests/CMakeLists.txt`.

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: tudo passa.

- [ ] **Step 5: Commit**

```bash
git add linux/src/core linux/tests
git commit -m "linux(L2): TextDiff and HooksInstaller (backup, stale-preview check, symlink, atomic write)

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 12: Diálogo de confirmação + entradas no menu da bandeja

**Files:**
- Create: `linux/src/platform/HooksDialog.h`, `linux/src/platform/HooksDialog.cpp`, `linux/tests/tst_hooks_dialog.cpp`
- Modify: `linux/src/platform/Tray.h`, `linux/src/platform/Tray.cpp`, `linux/src/platform/CMakeLists.txt`, `linux/src/app/main.cpp`, `linux/tests/tst_tray.cpp`, `linux/tests/CMakeLists.txt`

**Interfaces:**
- Produces:
  - `bool coucou::confirmHooksChange(QWidget *parent, const QString &title, const QString &summary, const QString &diff, const QString &confirmLabel)` — diálogo modal com o diff colorido; **Cancelar é o botão padrão**; devolve `true` só se o usuário clicar no botão de confirmar.
  - `struct coucou::TrayHooks { std::function<void()> install, uninstall; std::function<bool()> installed; }`; `Tray(AppState*, IslandController*, TrayHooks hooks = {}, QObject *parent = nullptr)`; `QMenu *Tray::menu() const` (para teste). Submenu "Claude Code hooks" com uma linha de status desabilitada ("Hooks: installed" / "Hooks: not installed", atualizada quando o menu abre) e as ações "Install…" / "Uninstall…".
- `main` monta o fluxo: plano → (erro/sem mudança → aviso) → diálogo → `apply` → aviso final dizendo para abrir uma **nova** sessão do Claude Code (ou revisar em `/hooks`) e onde está o backup.

- [ ] **Step 1: Escrever os testes**

`linux/tests/tst_hooks_dialog.cpp`:

```cpp
#include <QtTest>
#include <QApplication>
#include <QDialogButtonBox>
#include <QPushButton>
#include <QTimer>
#include "HooksDialog.h"

using namespace coucou;

class TestHooksDialog : public QObject {
    Q_OBJECT
    static void clickLater(const QString &label)
    {
        QTimer::singleShot(150, [label] {
            QWidget *dlg = QApplication::activeModalWidget();
            QVERIFY(dlg);
            for (QPushButton *b : dlg->findChildren<QPushButton *>())
                if (b->text() == label) {
                    b->click();
                    return;
                }
            QFAIL("button not found");
        });
    }

private slots:
    void confirmButtonReturnsTrue()
    {
        clickLater("Write changes");
        QVERIFY(confirmHooksChange(nullptr, "Install", "summary", "--- a\n+++ b\n@@ -1 +1 @@\n-x\n+y\n", "Write changes"));
    }

    void cancelReturnsFalse()
    {
        clickLater("Cancel");
        QVERIFY(!confirmHooksChange(nullptr, "Install", "summary", "--- a\n+++ b\n", "Write changes"));
    }

    void escapeReturnsFalse()
    {
        QTimer::singleShot(150, [] {
            QWidget *dlg = QApplication::activeModalWidget();
            QVERIFY(dlg);
            QTest::keyClick(dlg, Qt::Key_Escape);
        });
        QVERIFY(!confirmHooksChange(nullptr, "Install", "summary", "x", "Write changes"));
    }

    void cancelIsTheDefaultButton()
    {
        QTimer::singleShot(150, [] {
            QWidget *dlg = QApplication::activeModalWidget();
            QVERIFY(dlg);
            for (QPushButton *b : dlg->findChildren<QPushButton *>())
                if (b->isDefault())
                    QCOMPARE(b->text(), QStringLiteral("Cancel"));
            QTest::keyClick(dlg, Qt::Key_Return);        // Enter must not confirm
        });
        QVERIFY(!confirmHooksChange(nullptr, "Install", "summary", "x", "Write changes"));
    }
};

QTEST_MAIN(TestHooksDialog)
#include "tst_hooks_dialog.moc"
```

Em `linux/tests/tst_tray.cpp`, substitua o conteúdo da classe por (mantendo o teste existente `createAndDestroyDoesNotCrash`):

```cpp
    void hooksSubmenuWiresInstallUninstallAndStatus()
    {
        QTemporaryDir dir;
        QSettings settings(dir.path() + "/t.ini", QSettings::IniFormat);
        AppState state(&settings);
        FakeScheduler sched;
        IslandController ctl(&state, &sched, [] { return qint64(0); });
        bool installCalled = false, uninstallCalled = false, installed = false;
        TrayHooks hooks{[&] { installCalled = true; }, [&] { uninstallCalled = true; }, [&] { return installed; }};
        Tray tray(&state, &ctl, hooks);

        QAction *submenuAction = nullptr;
        for (QAction *a : tray.menu()->actions())
            if (a->menu() && a->text() == "Claude Code hooks")
                submenuAction = a;
        QVERIFY(submenuAction);
        QMenu *sub = submenuAction->menu();
        auto find = [&](const QString &prefix) -> QAction * {
            for (QAction *a : sub->actions())
                if (a->text().startsWith(prefix))
                    return a;
            return nullptr;
        };
        QVERIFY(find("Install")->isEnabled());
        find("Install")->trigger();
        find("Uninstall")->trigger();
        QVERIFY(installCalled && uninstallCalled);

        emit tray.menu()->aboutToShow();
        QCOMPARE(find("Hooks:")->text(), QStringLiteral("Hooks: not installed"));
        installed = true;
        emit tray.menu()->aboutToShow();
        QCOMPARE(find("Hooks:")->text(), QStringLiteral("Hooks: installed"));
        QVERIFY(!find("Hooks:")->isEnabled());
    }

    void withoutHooksTheEntriesAreDisabled()
    {
        QTemporaryDir dir;
        QSettings settings(dir.path() + "/t.ini", QSettings::IniFormat);
        AppState state(&settings);
        FakeScheduler sched;
        IslandController ctl(&state, &sched, [] { return qint64(0); });
        Tray tray(&state, &ctl);
        for (QAction *a : tray.menu()->actions())
            if (a->menu() && a->text() == "Claude Code hooks")
                for (QAction *x : a->menu()->actions())
                    if (x->text().startsWith("Install") || x->text().startsWith("Uninstall"))
                        QVERIFY(!x->isEnabled());
    }
```
(+ `#include <QMenu>` e `#include <QAction>`.)

- [ ] **Step 2: Rodar e ver falhar** (não compila)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_tray tst_hooks_dialog 2>&1 | tail -5`

- [ ] **Step 3: Implementar**

`linux/src/platform/HooksDialog.h`:

```cpp
#pragma once
#include <QString>

class QWidget;

namespace coucou {

// Modal preview of a change to ~/.claude/settings.json. Returns true only when the user clicks `confirmLabel`;
// Cancel is the default button, so Enter and Esc never confirm.
bool confirmHooksChange(QWidget *parent, const QString &title, const QString &summary, const QString &diff,
                        const QString &confirmLabel);

} // namespace coucou
```

`linux/src/platform/HooksDialog.cpp`:

```cpp
#include "HooksDialog.h"

#include <QDialog>
#include <QDialogButtonBox>
#include <QFontDatabase>
#include <QLabel>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QTextBlock>
#include <QTextEdit>
#include <QVBoxLayout>

namespace coucou {

bool confirmHooksChange(QWidget *parent, const QString &title, const QString &summary, const QString &diff,
                        const QString &confirmLabel)
{
    QDialog dlg(parent);
    dlg.setWindowTitle(title);
    dlg.resize(840, 560);
    auto *layout = new QVBoxLayout(&dlg);

    auto *label = new QLabel(summary);
    label->setWordWrap(true);
    layout->addWidget(label);

    auto *view = new QPlainTextEdit;
    view->setReadOnly(true);
    view->setLineWrapMode(QPlainTextEdit::NoWrap);
    view->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    view->setPlainText(diff);
    QList<QTextEdit::ExtraSelection> marks;
    for (QTextBlock b = view->document()->begin(); b.isValid(); b = b.next()) {
        const QString text = b.text();
        QColor bg;
        if (text.startsWith('+') && !text.startsWith(QLatin1String("+++")))
            bg = QColor(46, 160, 67, 60);
        else if (text.startsWith('-') && !text.startsWith(QLatin1String("---")))
            bg = QColor(248, 81, 73, 60);
        else
            continue;
        QTextEdit::ExtraSelection sel;
        sel.cursor = QTextCursor(b);
        sel.format.setBackground(bg);
        sel.format.setProperty(QTextFormat::FullWidthSelection, true);
        marks << sel;
    }
    view->setExtraSelections(marks);
    layout->addWidget(view, 1);

    auto *buttons = new QDialogButtonBox;
    QPushButton *confirm = buttons->addButton(confirmLabel, QDialogButtonBox::AcceptRole);
    QPushButton *cancel = buttons->addButton(QStringLiteral("Cancel"), QDialogButtonBox::RejectRole);
    confirm->setAutoDefault(false);
    confirm->setDefault(false);
    cancel->setAutoDefault(true);
    cancel->setDefault(true);
    QObject::connect(buttons, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    QObject::connect(buttons, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    layout->addWidget(buttons);

    return dlg.exec() == QDialog::Accepted;
}

} // namespace coucou
```

`linux/src/platform/Tray.h`: acrescente `#include <functional>` e, no namespace antes de `class Tray`:

```cpp
struct TrayHooks {
    std::function<void()> install;
    std::function<void()> uninstall;
    std::function<bool()> installed;   // asked each time the menu opens
};
```
troque o construtor por `Tray(AppState *state, IslandController *controller, TrayHooks hooks = {}, QObject *parent = nullptr);` e acrescente `QMenu *menu() const { return m_menu; }`.

`linux/src/platform/Tray.cpp`: atualize a assinatura do construtor e, depois da entrada `Settings…` e do `addSeparator()` seguinte (antes do submenu Debug), insira:

```cpp
    QMenu *claude = m_menu->addMenu(QStringLiteral("Claude Code hooks"));
    QAction *status = claude->addAction(QStringLiteral("Hooks: not installed"));
    status->setEnabled(false);
    QAction *install = claude->addAction(QStringLiteral("Install…"), this, [hooks] { if (hooks.install) hooks.install(); });
    QAction *uninstall = claude->addAction(QStringLiteral("Uninstall…"), this, [hooks] { if (hooks.uninstall) hooks.uninstall(); });
    install->setEnabled(bool(hooks.install));
    uninstall->setEnabled(bool(hooks.uninstall));
    connect(m_menu, &QMenu::aboutToShow, this, [hooks, status] {
        if (hooks.installed)
            status->setText(hooks.installed() ? QStringLiteral("Hooks: installed") : QStringLiteral("Hooks: not installed"));
    });
```
(garanta `#include <QAction>` e que `Tray::Tray(..., TrayHooks hooks, QObject *parent) : QObject(parent)`.)

`linux/src/platform/CMakeLists.txt`: adicione `HooksDialog.h HooksDialog.cpp` às fontes. `linux/tests/CMakeLists.txt`, dentro do `if(TARGET coucou_platform)`:

```cmake
    qt_add_executable(tst_hooks_dialog tst_hooks_dialog.cpp)
    target_link_libraries(tst_hooks_dialog PRIVATE coucou_platform coucou_core Qt6::Test)
    target_include_directories(tst_hooks_dialog PRIVATE ${CMAKE_CURRENT_SOURCE_DIR})
    add_test(NAME tst_hooks_dialog COMMAND tst_hooks_dialog)
    set_tests_properties(tst_hooks_dialog PROPERTIES ENVIRONMENT "QT_QPA_PLATFORM=offscreen;QT_QUICK_BACKEND=software")
```

`linux/src/app/main.cpp`: acrescente `#include "HooksDialog.h"`, `#include "HooksInstaller.h"`, `#include <QMessageBox>` e troque a linha `Tray tray(&state, &controller);` por:

```cpp
    const auto hooksInstaller = [] { return HooksInstaller(Paths::claudeSettingsPath(), Paths::hookScriptPath(), 110); };
    const auto runHooks = [&](bool install) {
        const HooksInstaller inst = hooksInstaller();
        const HooksPlan plan = install ? inst.planInstall() : inst.planUninstall();
        const QString box = QStringLiteral("Claude Code hooks");
        if (!plan.ok) {
            QMessageBox::warning(nullptr, box, plan.error + QStringLiteral("\n\nNothing was changed."));
            return;
        }
        if (!plan.changes) {
            QMessageBox::information(nullptr, box,
                                     install ? QStringLiteral("The Coucou hooks are already installed.")
                                             : QStringLiteral("There are no Coucou hooks in settings.json."));
            return;
        }
        const QString backupNote = plan.settingsExisted
            ? QStringLiteral("A backup is saved next to it first: %1").arg(inst.backupPathFor())
            : QStringLiteral("The file does not exist yet, so there is nothing to back up.");
        const QString summary = QStringLiteral("File: %1\n%2\n\nNothing is written until you confirm. Review the changes:")
                                    .arg(Paths::claudeSettingsPath(), backupNote);
        if (!confirmHooksChange(nullptr, install ? QStringLiteral("Install Claude Code hooks") : QStringLiteral("Remove Claude Code hooks"),
                                summary, plan.diff, install ? QStringLiteral("Write changes") : QStringLiteral("Remove hooks")))
            return;
        QString error, backup;
        if (!inst.apply(plan, &error, &backup)) {
            QMessageBox::critical(nullptr, box, error);
            return;
        }
        QMessageBox::information(nullptr, box,
                                 QStringLiteral("Done.%1\n\nOpen a new Claude Code session (or review the change with /hooks) "
                                                "for it to take effect.")
                                     .arg(backup.isEmpty() ? QString() : QStringLiteral("\nBackup: ") + backup));
    };
    Tray tray(&state, &controller,
              TrayHooks{[&] { runHooks(true); }, [&] { runHooks(false); }, [&] { return hooksInstaller().installed(); }});
```

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: tudo passa. (`QTest::keyClick(dlg, Qt::Key_Return)` no teste do botão padrão: se o ambiente offscreen não entregar o Enter, troque por `cancel->click()` e mantenha a asserção sobre `isDefault()`: o contrato é "Cancelar é o padrão".)

- [ ] **Step 5: Commit**

```bash
git add linux/src linux/tests
git commit -m "linux(L2): hooks confirmation dialog and tray entries (install/uninstall with diff)

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 13: Voltar para a sessão (VSCodium e Konsole)

O foco de janela no Wayland depende do script do KWin (L5). Aqui entra o que funciona sem ele: no VSCodium, `flatpak run <app> <pasta>` (o VSCodium já aberto na pasta recebe o pedido e se anuncia/foca); no Konsole, `setCurrentSession` por D-Bus (troca a aba; levantar a janela vem no L5). Terminal genérico: não faz nada.

**Files:**
- Create: `linux/src/core/JumpCommand.h`, `linux/src/core/JumpCommand.cpp`, `linux/tests/tst_jump_command.cpp`, `linux/src/platform/SessionJumper.h`, `linux/src/platform/SessionJumper.cpp`
- Modify: `linux/src/core/CMakeLists.txt`, `linux/src/platform/CMakeLists.txt` (fontes + `Qt6::DBus`), `linux/tests/CMakeLists.txt`, `linux/src/app/main.cpp`

**Interfaces:**
- Consumes: `JumpTarget` (Task 6), `ClaudeSessions::jumpRequested`.
- Produces: `struct JumpCommand { enum class Kind { None, Process, KonsoleDBus }; Kind kind; QString program; QStringList args; QString service, objectPath; int sessionId; }`; `JumpCommand jumpCommandFor(const JumpTarget &)`; `class SessionJumper : QObject { public slots: void jump(const coucou::JumpTarget &); }`.
- Regras de `jumpCommandFor`: `vscodium` + `cwd` absoluto → `flatpak run <flatpakId|com.vscodium.codium> <cwd>` (`flatpakId` só se casar `^[A-Za-z0-9._-]+$`, senão o padrão; `cwd` que não começa com `/` → `None`, para nunca virar opção do `flatpak`); `konsole` + serviço não vazio + `konsole_dbus_session` no formato `/Sessions/<n>` → D-Bus em `konsole_dbus_window` (formato `/Windows/<n>`, senão `/Windows/1`), interface `org.kde.konsole.Window`, método `setCurrentSession(int)`; o resto → `None`.

- [ ] **Step 1: Escrever o teste**

`linux/tests/tst_jump_command.cpp`:

```cpp
#include <QtTest>
#include "JumpCommand.h"

using namespace coucou;
using K = JumpCommand::Kind;

class TestJumpCommand : public QObject {
    Q_OBJECT
private slots:
    void vscodiumOpensTheFolderThroughFlatpak()
    {
        const JumpCommand c = jumpCommandFor({"vscodium", "/home/u/proj", "com.vscodium.codium", {}, {}, {}});
        QVERIFY(c.kind == K::Process);
        QCOMPARE(c.program, QStringLiteral("flatpak"));
        QCOMPARE(c.args, (QStringList{"run", "com.vscodium.codium", "/home/u/proj"}));
    }

    void vscodiumDefaultsTheFlatpakId()
    {
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "", {}, {}, {}}).args.at(1), QStringLiteral("com.vscodium.codium"));
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "bad id;rm", {}, {}, {}}).args.at(1), QStringLiteral("com.vscodium.codium"));
        QCOMPARE(jumpCommandFor({"vscodium", "/p", "com.visualstudio.code", {}, {}, {}}).args.at(1), QStringLiteral("com.visualstudio.code"));
    }

    void vscodiumNeedsAnAbsoluteFolder()
    {
        QVERIFY(jumpCommandFor({"vscodium", "", "", {}, {}, {}}).kind == K::None);
        QVERIFY(jumpCommandFor({"vscodium", "--new-window", "", {}, {}, {}}).kind == K::None);   // never an option
        QVERIFY(jumpCommandFor({"vscodium", "relative/dir", "", {}, {}, {}}).kind == K::None);
    }

    void konsoleSwitchesTheTab()
    {
        const JumpCommand c = jumpCommandFor({"konsole", "/p", "", ":1.77", "/Sessions/3", "/Windows/2"});
        QVERIFY(c.kind == K::KonsoleDBus);
        QCOMPARE(c.service, QStringLiteral(":1.77"));
        QCOMPARE(c.objectPath, QStringLiteral("/Windows/2"));
        QCOMPARE(c.sessionId, 3);
    }

    void konsoleFallsBackToWindow1AndRejectsBadInput()
    {
        QCOMPARE(jumpCommandFor({"konsole", "/p", "", ":1.7", "/Sessions/9", ""}).objectPath, QStringLiteral("/Windows/1"));
        QCOMPARE(jumpCommandFor({"konsole", "/p", "", ":1.7", "/Sessions/9", "/etc/passwd"}).objectPath, QStringLiteral("/Windows/1"));
        QVERIFY(jumpCommandFor({"konsole", "/p", "", "", "/Sessions/3", "/Windows/1"}).kind == K::None);
        QVERIFY(jumpCommandFor({"konsole", "/p", "", ":1.7", "garbage", "/Windows/1"}).kind == K::None);
        QVERIFY(jumpCommandFor({"konsole", "/p", "", ":1.7", "/Sessions/x", "/Windows/1"}).kind == K::None);
    }

    void otherTerminalsDoNothingYet()
    {
        QVERIFY(jumpCommandFor({"terminal", "/p", "", {}, {}, {}}).kind == K::None);
        QVERIFY(jumpCommandFor({"", "/p", "", {}, {}, {}}).kind == K::None);
    }
};

QTEST_APPLESS_MAIN(TestJumpCommand)
#include "tst_jump_command.moc"
```

- [ ] **Step 2: Rodar e ver falhar** (não compila)

Run: `linux/scripts/host.sh cmake -S linux -B linux/build && linux/scripts/host.sh cmake --build linux/build --target tst_jump_command 2>&1 | tail -5`

- [ ] **Step 3: Implementar**

`linux/src/core/JumpCommand.h`:

```cpp
#pragma once
#include "JumpTarget.h"

#include <QString>
#include <QStringList>

namespace coucou {

// What to run to take the user back to a Claude Code session. Pure: SessionJumper executes it.
struct JumpCommand {
    enum class Kind { None, Process, KonsoleDBus };
    Kind kind = Kind::None;
    QString program;
    QStringList args;            // Process
    QString service, objectPath; // KonsoleDBus: org.kde.konsole.Window.setCurrentSession(sessionId)
    int sessionId = 0;
};

JumpCommand jumpCommandFor(const JumpTarget &target);

} // namespace coucou
```

`linux/src/core/JumpCommand.cpp`:

```cpp
#include "JumpCommand.h"

#include <QRegularExpression>

namespace coucou {

JumpCommand jumpCommandFor(const JumpTarget &t)
{
    JumpCommand c;
    if (t.source == QLatin1String("vscodium")) {
        if (!t.cwd.startsWith(QLatin1Char('/')))
            return c;   // empty or relative: could be taken for an option by flatpak
        static const QRegularExpression idPattern(QStringLiteral("^[A-Za-z0-9._-]+$"));
        const QString app = idPattern.match(t.flatpakId).hasMatch() ? t.flatpakId : QStringLiteral("com.vscodium.codium");
        c.kind = JumpCommand::Kind::Process;
        c.program = QStringLiteral("flatpak");
        c.args = {QStringLiteral("run"), app, t.cwd};
        return c;
    }
    if (t.source == QLatin1String("konsole") && !t.konsoleService.isEmpty()) {
        static const QRegularExpression sessionPattern(QStringLiteral("^/Sessions/(\\d+)$"));
        static const QRegularExpression windowPattern(QStringLiteral("^/Windows/\\d+$"));
        const auto m = sessionPattern.match(t.konsoleSession);
        if (!m.hasMatch())
            return c;
        c.kind = JumpCommand::Kind::KonsoleDBus;
        c.service = t.konsoleService;
        c.objectPath = windowPattern.match(t.konsoleWindow).hasMatch() ? t.konsoleWindow : QStringLiteral("/Windows/1");
        c.sessionId = m.captured(1).toInt();
    }
    return c;
}

} // namespace coucou
```

`linux/src/platform/SessionJumper.h`:

```cpp
#pragma once
#include "JumpTarget.h"

#include <QObject>

namespace coucou {

// Executes jumpCommandFor(target). Raising the window itself needs the KWin bridge (L5): until then VSCodium is
// asked to open the folder (it announces/focuses itself) and Konsole switches to the session's tab.
class SessionJumper : public QObject {
    Q_OBJECT
public:
    using QObject::QObject;
public slots:
    void jump(const coucou::JumpTarget &target);
};

} // namespace coucou
```

`linux/src/platform/SessionJumper.cpp`:

```cpp
#include "SessionJumper.h"

#include "JumpCommand.h"

#include <QDBusConnection>
#include <QDBusMessage>
#include <QProcess>

namespace coucou {

void SessionJumper::jump(const JumpTarget &target)
{
    const JumpCommand c = jumpCommandFor(target);
    switch (c.kind) {
    case JumpCommand::Kind::None:
        break;
    case JumpCommand::Kind::Process:
        QProcess::startDetached(c.program, c.args);
        break;
    case JumpCommand::Kind::KonsoleDBus: {
        QDBusMessage m = QDBusMessage::createMethodCall(c.service, c.objectPath, QStringLiteral("org.kde.konsole.Window"),
                                                        QStringLiteral("setCurrentSession"));
        m << c.sessionId;
        QDBusConnection::sessionBus().asyncCall(m, 1000);
        break;
    }
    }
}

} // namespace coucou
```

Registre `JumpCommand.h JumpCommand.cpp` em `src/core/CMakeLists.txt`; `SessionJumper.h SessionJumper.cpp` e `Qt6::DBus` em `src/platform/CMakeLists.txt`; `coucou_add_test(tst_jump_command)` em `tests/CMakeLists.txt`. Em `main.cpp`: `#include "SessionJumper.h"` e, depois de criar `sessions`:

```cpp
    SessionJumper jumper;
    QObject::connect(&sessions, &ClaudeSessions::jumpRequested, &jumper, &SessionJumper::jump);
```

- [ ] **Step 4: Rodar e ver passar**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: tudo passa.

- [ ] **Step 5: Commit**

```bash
git add linux/src linux/tests
git commit -m "linux(L2): jump back to a session (VSCodium via flatpak, Konsole tab via D-Bus)

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

---

### Task 14: Sessão real no VSCodium, medições, notas e revisão final

Esta tarefa precisa do usuário na frente da tela (instalar os hooks e clicar). O executor prepara tudo, mostra o que esperar e registra os resultados. **Nenhuma escrita no `~/.claude/settings.json` acontece fora do diálogo de confirmação.**

**Files:**
- Create: `linux/docs/L2-notes.md`
- Modify: `docs/superpowers/specs/2026-09-29-coucou-linux-design.md` (§0, nova emenda), `linux/docs/L1a-notes.md` (marcar o item do alerta fixado como resolvido), `CLAUDE.md` (seção "Linux port": hook e testes do hook), o `coucou.conf` do usuário (só com o OK dele, ver passo 2)

- [ ] **Step 1: Suíte completa limpa**

Run: `linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
Expected: todos passam (incl. `nb_hook_unittest`, `tst_hook_server`, `tst_settings_merger`, `tst_hooks_installer`).

- [ ] **Step 2: Bolinhas de integração sem função (configuração do usuário, com o OK dele)**

Hoje as quatro integrações padrão (Resend, n8n, Vercel, GitHub) aparecem como bolinhas sem nenhum dado (as integrações só chegam no L4). Pergunte ao usuário se quer escondê-las até o L4; se sim, em `~/.config/coucou/coucou.conf` troque `activeIntegrations=...` por `activeIntegrations=` (vazio = nenhuma; o `AppState` já trata o vazio como "todas desligadas"). É só configuração dele: nenhum código muda.

- [ ] **Step 3: Instalar os hooks pela bandeja (o usuário confirma)**

1. Suba o app (`build/src/app/coucou`). Clique com o direito no ícone do Coucou → **Claude Code hooks → Install…**.
2. O diálogo mostra o arquivo, o caminho do backup e o diff. Confira junto com o usuário que **só** o bloco `hooks` muda (se o `settings.json` real não estiver no formato canônico, o diff mostrará a reformatação; o usuário decide).
3. O usuário clica **Write changes**. Confirme depois:

```bash
linux/scripts/host.sh sh -c 'ls -l ~/.claude/settings.json*; python3 -c "import json,os;d=json.load(open(os.path.expanduser(\"~/.claude/settings.json\")));print(sorted(d[\"hooks\"]))"'
```
Expected: o backup `settings.json.bak-AAAAMMDD-HHMM` existe e o JSON atual é válido com os 12 eventos (mais o `Stop` antigo do usuário ainda presente).
4. Reversão se algo der errado: bandeja → **Uninstall…** (mesmo fluxo com diff) ou `cp ~/.claude/settings.json.bak-… ~/.claude/settings.json`.

- [ ] **Step 4: Validar com uma sessão real (os pontos em aberto da spec §6.3)**

Abra uma **nova** sessão do Claude Code no VSCodium (hooks são lidos no início da sessão) numa pasta de teste e verifique, anotando o resultado de cada item para o `L2-notes.md`:

| # | Verificação | Esperado |
|---|---|---|
| a | Iniciar a sessão | bolinha da sessão aparece (nome da pasta), a pílula "VS Code" some |
| b | Enviar um prompt | estado Thinking → Working; na visão geral o ticker mostra "Runs · …", "Reads · …" |
| c | Pedir uma ação que exige permissão | ilha abre na view de aprovação com o comando; nada é decidido sozinho |
| d | **Allow** | a ação roda |
| e | Repetir e clicar **Deny** | a ação **não** roda (issue anthropics/claude-code #19298: se o deny for ignorado, registrar e abrir a tarefa de mover a decisão para `PreToolUse`) |
| f | **Always** e repetir o mesmo pedido | roda sem alerta |
| g | Durante a espera pela decisão, olhar o editor | **registrar**: o VSCodium mostra o próprio pedido ao mesmo tempo, ou fica mudo até o hook terminar? (spec §6.3: se ficar mudo e incomodar, reduzir o tempo de decisão padrão) |
| h | Responder no editor enquanto a ilha mostra o alerta | a ilha tira o alerta sozinha (conexão do hook fecha → `cancel`) |
| i | Fim da resposta | view "finished" com o resumo, som, volta a idle em ~5 s |
| j | Pergunta (`AskUserQuestion`) | view "question" somente leitura + "Answer in editor" |
| k | `Y`/`N` (clicar na ilha antes) e `Esc` | `Y`/`N` decidem; `Esc` não fecha aprovação pendente |
| l | "Open session"/↗ | o VSCodium da pasta é trazido à frente (ou ao menos se anuncia); **registrar** o que o KWin faz |
| m | **Fechar o app** (Quit na bandeja) e pedir nova permissão | o pedido aparece normalmente no editor, sem atraso perceptível |
| n | Segunda sessão em outra pasta e uma no Konsole (`claude` num terminal Konsole) | uma bolinha por sessão; o ↗ do Konsole troca a aba |
| o | Fechar uma sessão | a bolinha some; ao fechar a última, "VS Code" volta |

- [ ] **Step 5: Medições**

```bash
linux/scripts/host.sh sh -c 'cd ~/src/farol/linux && scripts/measure.sh $(pgrep -x coucou) 20'
```
Faça três rodadas: ilha escondida (`COUCOU_DEBUG_MODE=hidden`), compacta com uma sessão ociosa e compacta com a sessão trabalhando (eventos chegando). Critérios: escondida 0 %, compacta < 3 %, PSS < 100 MB. Registre os números.

- [ ] **Step 6: Documentação**

1. `linux/docs/L2-notes.md`: resultado de cada linha da tabela do passo 4, medições, decisões (uma bolinha por sessão; `release` no timeout; chave da lista "sempre" por projeto+ferramenta e, no Bash, comando exato; rótulos dos passos em inglês), riscos abertos (`SO_PEERCRED` só testado com o próprio UID; levantar a janela depende do L5; o settings.json com CRLF ou arrays em linha é reformatado pelo `JsonTree`; `updatedPermissions` do Claude Code não foi usado), a pendência de expor o tempo de decisão e a lista "sempre autorizar" nas Configurações (L6; hoje o tempo é 110 s fixo no instalador e a lista só vive no `coucou.conf`), e pendências menores encontradas na execução.
2. Spec §0: acrescente a emenda "L2: uma pílula por sessão" — `ClaudeSessions` cria uma tarefa por `session_id` (o Swift só atualiza a pílula permanente "VS Code"), a pílula-espaço volta quando nenhuma sessão existe; o timeout de aprovação solta (`release`) em vez de negar; o `autoCloseInterval` agora dirige o recolhimento real.
3. `linux/docs/L1a-notes.md`: marque "FSM ignora `isPinned`" como resolvido (Task 1 do L2).
4. `CLAUDE.md`, seção "Linux port": uma linha: "Hook: `linux/hook/nb-hook` (Python stdlib), testado com `linux/scripts/host.sh python3 -m unittest discover -s linux/hook/tests`; o app o instala em `~/.local/share/coucou/nb-hook` e só edita `~/.claude/settings.json` pelo diálogo (backup + diff + confirmação)."

- [ ] **Step 7: Commit e revisão da branch**

```bash
git add linux docs CLAUDE.md
git commit -m "linux(L2): notes, spec amendment and measurements

Co-Authored-By: Claude Sonnet 5.5 <noreply@anthropic.com>"
```

Depois despache **um revisor novo** (modelo mais capaz disponível) sobre todo o intervalo do L2 (`git diff 68a9b0b..HEAD -- linux docs CLAUDE.md`), com este briefing: "Revise o L2 do port Linux do Coucou contra `docs/superpowers/plans/2026-09-30-coucou-linux-L2-claude-code.md` (Global Constraints e Review Focus). Procure violações de: nunca bloquear o Claude Code; nenhuma decisão sem clique; `settings.json` só com backup+diff+confirmação; segredos/telemetria; 0 % CPU escondido; caminhos de `$HOME`. Verifique condições de corrida do `HookServer` (desconexão durante `handlePermission`, `deleteLater`, ponteiros em `m_conns`), vazamentos de timers do `IScheduler`, e o `JsonTree`/`HooksInstaller` contra arquivos estranhos. Reporte só achados verificados, do mais grave ao menos." Corrija os achados confirmados, rode a suíte de novo e faça commits separados por correção.

