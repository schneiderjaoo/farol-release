#include "IslandProbe.h"

#include <LayerShellQt/Window>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickWindow>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    const bool hotStrip = app.arguments().contains(QStringLiteral("--hot-strip"));
    const bool autoToggle = app.arguments().contains(QStringLiteral("--auto-toggle"));

    IslandProbe probe;
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty(QStringLiteral("probe"), &probe);
    engine.setInitialProperties({{QStringLiteral("hotStrip"), hotStrip},
                                 {QStringLiteral("autoToggle"), autoToggle}});
    engine.loadFromModule("Spike", "Island");
    if (engine.rootObjects().isEmpty())
        return 1;

    auto *window = qobject_cast<QQuickWindow *>(engine.rootObjects().first());
    probe.attach(window);

    // Must be configured before the first show(): the role of a Wayland surface is fixed at creation.
    auto *layer = LayerShellQt::Window::get(window);
    layer->setLayer(LayerShellQt::Window::LayerOverlay);
    layer->setAnchors(LayerShellQt::Window::AnchorTop);
    layer->setExclusiveZone(-1);
    layer->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityNone);
    layer->setScope(QStringLiteral("farol-spike"));
    window->setScreen(QGuiApplication::primaryScreen());

    window->show();
    probe.log(QStringLiteral("shown on %1 dpr=%2").arg(window->screen()->name())
                  .arg(window->devicePixelRatio()));
    return app.exec();
}
