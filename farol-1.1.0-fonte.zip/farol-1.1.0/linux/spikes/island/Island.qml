import QtQuick
import QtQuick.Controls

Window {
    id: root
    width: 720
    height: 320
    color: "transparent"
    visible: false

    required property bool hotStrip
    property bool expanded: false
    property bool autoToggle: false   // --auto-toggle: open/close every second (CPU measurement)

    // Set by the DropArea handlers BEFORE they call updateMask(): Qt emits exited()/dropped() before
    // it flips containsDrag, so reading containsDrag there leaves a stale (click-trapping) mask.
    property bool dragActive: false

    function updateMask() {
        if (root.dragActive)
            probe.setInputRect(root.width / 2 - 220, 0, 440, island.height + 26)   // upload zone
        else if (root.hotStrip && !root.expanded)
            probe.setInputRect((root.width - 184) / 2, 0, 184, 3)
        else
            probe.setInputRect(island.x, island.y, island.width, island.height)
    }

    function collapse() {
        root.expanded = false
        field.focus = false
        probe.setKeyboardOnDemand(false)
    }

    Rectangle {
        id: island
        x: (root.width - width) / 2
        y: 0
        width: root.expanded ? 640 : 288
        height: root.expanded ? 196 : 24
        radius: root.expanded ? 30 : 14
        color: "black"
        opacity: root.hotStrip && !root.expanded && !root.dragActive ? 0 : 1
        focus: true

        Behavior on width  { NumberAnimation { duration: root.expanded ? 520 : 340; easing.type: Easing.BezierSpline
                              easing.bezierCurve: root.expanded ? [0.32, 1.22, 0.42, 1, 1, 1] : [0.45, 0, 0.2, 1, 1, 1] } }
        Behavior on height { NumberAnimation { duration: root.expanded ? 520 : 340; easing.type: Easing.BezierSpline
                              easing.bezierCurve: root.expanded ? [0.32, 1.22, 0.42, 1, 1, 1] : [0.45, 0, 0.2, 1, 1, 1] } }

        onWidthChanged: root.updateMask()
        onHeightChanged: root.updateMask()

        Keys.onEscapePressed: { probe.log("Esc"); root.collapse() }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onEntered: probe.log("hover enter")
            onExited: probe.log("hover exit")
            onClicked: {
                probe.log("click inside island")
                probe.setKeyboardOnDemand(true)
                island.forceActiveFocus()
                root.expanded = !root.expanded
                if (!root.expanded) root.collapse()
            }
        }

        TextField {
            id: field
            visible: root.expanded
            anchors.centerIn: parent
            width: 300
            placeholderText: "digite aqui"
            onActiveFocusChanged: probe.log("text field focus " + activeFocus)
            onTextChanged: probe.log("typed: " + text)
        }

        DropArea {
            id: drop
            anchors.fill: parent
            keys: ["text/uri-list"]
            onEntered: (drag) => {
                probe.log("drag enter formats=" + drag.formats.join(","))
                root.dragActive = true
                root.updateMask()
                drag.accept(Qt.CopyAction)
            }
            onExited: { probe.log("drag exit"); root.dragActive = false; root.updateMask() }
            onDropped: (dropEvent) => {
                probe.log("dropped urls=" + dropEvent.urls.join(" | "))
                dropEvent.accept(Qt.CopyAction)
                root.dragActive = false
                root.updateMask()
            }
        }
    }

    Timer {
        interval: 1000
        running: root.autoToggle
        repeat: true
        onTriggered: root.expanded = !root.expanded
    }

    Component.onCompleted: updateMask()
}
