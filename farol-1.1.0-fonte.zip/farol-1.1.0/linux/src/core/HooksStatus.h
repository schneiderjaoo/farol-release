#pragma once
#include <QObject>
#include <QString>
#include <functional>

namespace farol {

// What the Settings window's "Sobre" page says about the Claude Code hooks: "installed", "outdated" or "missing".
// The app gives the function that looks at ~/.claude/settings.json; it runs when the page asks, never on a timer.
class HooksStatus : public QObject {
    Q_OBJECT
public:
    explicit HooksStatus(std::function<QString()> look, QObject *parent = nullptr) : QObject(parent), m_look(std::move(look)) {}
    Q_INVOKABLE QString state() const { return m_look ? m_look() : QString(); }

private:
    std::function<QString()> m_look;
};

} // namespace farol
