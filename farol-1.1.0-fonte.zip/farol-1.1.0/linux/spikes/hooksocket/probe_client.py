#!/usr/bin/env python3
"""L0 probe: send one hook-like event to the Farol socket, the way farol-hook will.

Usage: probe_client.py <EventName> [decision_timeout_s]
Prints the elapsed time on stderr; prints the decision JSON on stdout only for an
allow/deny answer to PermissionRequest. Never exits non-zero.
"""
import json
import os
import socket
import sys
import time


def main() -> None:
    event = sys.argv[1] if len(sys.argv) > 1 else "PreToolUse"
    decision_timeout = float(sys.argv[2]) if len(sys.argv) > 2 else 110.0
    # Built from HOME on purpose: XDG_* are remapped inside the VSCodium Flatpak.
    sock_path = os.path.join(os.environ["HOME"], ".local/share/farol/farol.sock")
    payload = {
        "hook_event_name": event,
        "session_id": "probe",
        "cwd": os.getcwd(),
        "farol_source": "vscodium" if os.environ.get("CLAUDE_CODE_ENTRYPOINT", "").startswith("claude-vscode") else "terminal",
        "flatpak_id": os.environ.get("FLATPAK_ID", ""),
    }
    start = time.monotonic()
    out = ""
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(0.3)
        s.connect(sock_path)
        s.sendall((json.dumps(payload) + "\n").encode())
        if event == "PermissionRequest":
            s.settimeout(decision_timeout)
            buf = b""
            while b"\n" not in buf:
                chunk = s.recv(4096)
                if not chunk:
                    break
                buf += chunk
            answer = json.loads(buf.decode().strip() or "{}")
            if answer.get("decision") in ("allow", "deny"):
                out = json.dumps({"hookSpecificOutput": {"hookEventName": "PermissionRequest",
                                                         "decision": {"behavior": answer["decision"]}}})
        s.close()
    except Exception as exc:  # app absent, timeout, bad JSON: stay silent
        print(f"(silent: {type(exc).__name__})", file=sys.stderr)
    print(f"elapsed={time.monotonic() - start:.3f}s", file=sys.stderr)
    if out:
        print(out)


if __name__ == "__main__":
    main()
    sys.exit(0)
