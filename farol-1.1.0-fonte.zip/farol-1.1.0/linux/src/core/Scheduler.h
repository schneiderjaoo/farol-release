#pragma once
#include <functional>
#include <QHash>

class QTimer;

namespace farol {

// One-shot timers behind an interface so tests can drive time by hand.
class IScheduler {
public:
    virtual ~IScheduler() = default;
    // Runs fn once after ms milliseconds. The returned id (never 0) can be passed to cancel().
    virtual int singleShot(int ms, std::function<void()> fn) = 0;
    virtual void cancel(int id) = 0;
};

class QtScheduler : public IScheduler {
public:
    QtScheduler() = default;
    ~QtScheduler() override;
    int singleShot(int ms, std::function<void()> fn) override;
    void cancel(int id) override;

private:
    QHash<int, QTimer *> m_timers;
    int m_next = 0;
};

} // namespace farol
