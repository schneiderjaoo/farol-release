#pragma once
#include <QObject>
#include <QString>

namespace farol {

// The text of a notification as its body. A server that advertises "body-markup" (Plasma and GNOME do) reads the
// body as markup, and the text is a model's: for such a server &, < and > are escaped, so it is shown as written.
QString notificationBody(const QString &text, bool markup);

// Sends a desktop notification (org.freedesktop.Notifications) for what the island calls for, but only while the
// user is away: the screen is locked, or nobody touched the computer for kIdleMs. On KDE Plasma being idle comes
// from the compositor through KIdleTime (an event when it starts and one when it ends); on another X11 desktop the
// server is asked when there is something to notify. Nothing is polled.
class DesktopNotifier : public QObject {
    Q_OBJECT
public:
    static constexpr int kIdleMs = 2 * 60 * 1000;

    explicit DesktopNotifier(QObject *parent = nullptr);

    void notifyIfAway(const QString &title, const QString &text);
    // Development (FAROL_DEBUG_NOTIFY): behave as if the user were always away.
    void setAlwaysAway(bool on) { m_alwaysAway = on; }

private:
    void send(const QString &title, const QString &text);

    bool m_idle = false;
    bool m_alwaysAway = false;
    bool m_bodyMarkup = true;   // what GetCapabilities said; not known yet: the body is escaped
};

} // namespace farol
