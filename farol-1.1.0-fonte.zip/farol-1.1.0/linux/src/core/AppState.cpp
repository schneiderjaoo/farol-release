#include "AppState.h"

#include "Paths.h"

#include <QDir>
#include <QSettings>
#include <algorithm>
#include <cmath>

namespace farol {

namespace {
constexpr double kMaxVolume = 0.2;
constexpr double kDefaultAutoClose = 15;
constexpr int kDefaultSessionIdle = 30;
bool isSessionIdle(int s) { return s == 0 || (s >= 10 && s <= 24 * 60 * 60); }
constexpr int kDefaultWaitReminder = 120;
bool isWaitReminder(int s) { return s == 0 || (s >= 30 && s <= 60 * 60); }
const QString kClaudeId = QStringLiteral("integration_claude");
// Empty on purpose (the Swift app pre-activates Resend, n8n, Vercel and GitHub): the user adds each integration.
const QStringList kDefaultIntegrations = {};
bool isEdge(const QString &e) { return enumFromKey<IslandEdge>(e).has_value(); }
bool isThemeMode(const QString &m) { return m == QLatin1String("system") || m == QLatin1String("dark") || m == QLatin1String("light"); }
// An absolute path without "." / ".." / trailing slash; anything else (relative, empty) gives an empty string.
QString cleanDir(const QString &dir) { return QDir::isAbsolutePath(dir) ? QDir::cleanPath(dir) : QString(); }
} // namespace

AppState::AppState(QSettings *settings, QObject *parent)
    : QObject(parent), m_settings(settings), m_tasks(new TaskModel(this)), m_activeIntegrations(kDefaultIntegrations)
{
    if (m_settings)
        load();
    loadIntegrationTasks();   // also runs syncMode(): hidden + tasks + present -> compact, like Swift's init
}

void AppState::load()
{
    m_soundEnabled = m_settings->value("soundEnabled", true).toBool();
    double vol = m_settings->value("soundVolume", 0.12).toDouble();
    if (!std::isfinite(vol))
        vol = 0.12;
    m_soundVolume = std::clamp(vol, 0.0, kMaxVolume);

    double ac = m_settings->value("autoCloseInterval", kDefaultAutoClose).toDouble();
    if (ac == 60 || !std::isfinite(ac) || !(ac > 0))   // 60 s was the old default; invalid values fall back too
        ac = kDefaultAutoClose;
    m_autoClose = ac;

    const QString mode = m_settings->value("themeMode", "system").toString();
    m_themeMode = isThemeMode(mode) ? mode : QStringLiteral("system");
    m_reduceMotion = m_settings->value("reduceMotion", false).toBool();
    m_workspaceDir = cleanDir(m_settings->value("workspaceDir").toString());
    m_skillsDir = cleanDir(m_settings->value("skillsDir").toString());
    bool idleOk = false;
    const int idle = m_settings->value("sessionIdleSeconds", kDefaultSessionIdle).toInt(&idleOk);
    m_sessionIdle = idleOk && isSessionIdle(idle) ? idle : kDefaultSessionIdle;
    m_autoHide = m_settings->value("autoHide", false).toBool();
    m_notifyAway = m_settings->value("notifyAway", true).toBool();
    m_largeContextModels = m_settings->value("largeContextModels").toString().split(';', Qt::SkipEmptyParts);
    bool remindOk = false;
    const int remind = m_settings->value("waitReminderSeconds", kDefaultWaitReminder).toInt(&remindOk);
    m_waitReminder = remindOk && isWaitReminder(remind) ? remind : kDefaultWaitReminder;
    const QString edge = m_settings->value("edge", "top").toString();
    m_edge = isEdge(edge) ? edge : QStringLiteral("top");

    if (m_settings->contains("activeIntegrations")) {
        const QString raw = m_settings->value("activeIntegrations").toString();
        if (raw.isEmpty()) {
            m_activeIntegrations.clear();                        // user turned every pill off
        } else {
            QStringList ids;
            for (const QString &id : raw.split(';', Qt::SkipEmptyParts))
                if (toggleableIntegrationIds().contains(id) && !ids.contains(id))
                    ids << id;
            if (!ids.isEmpty())                                  // nothing valid -> keep the defaults
                m_activeIntegrations = ids;
        }
    }
}

void AppState::persist()
{
    if (!m_settings)
        return;
    m_settings->setValue("soundEnabled", m_soundEnabled);
    m_settings->setValue("soundVolume", m_soundVolume);
    m_settings->setValue("autoCloseInterval", m_autoClose);
    m_settings->setValue("themeMode", m_themeMode);
    m_settings->setValue("reduceMotion", m_reduceMotion);
    m_settings->setValue("workspaceDir", m_workspaceDir);
    m_settings->setValue("skillsDir", m_skillsDir);
    m_settings->setValue("sessionIdleSeconds", m_sessionIdle);
    m_settings->setValue("autoHide", m_autoHide);
    m_settings->setValue("notifyAway", m_notifyAway);
    m_settings->setValue("largeContextModels", m_largeContextModels.join(';'));
    m_settings->setValue("waitReminderSeconds", m_waitReminder);
    m_settings->setValue("edge", m_edge);
    m_settings->setValue("activeIntegrations", m_activeIntegrations.join(';'));
    m_settings->sync();
}

void AppState::setMode(IslandMode m)
{
    if (m == m_mode)
        return;
    m_mode = m;
    emit modeChanged();
}

void AppState::setView(IslandView v)
{
    if (v == m_view)
        return;
    m_view = v;
    emit viewChanged();
}

void AppState::setViewName(const QString &name)
{
    if (auto v = enumFromKey<IslandView>(name))
        setView(*v);
}

void AppState::setFocusInternal(const QString &id)
{
    if (id == m_focusId)
        return;
    m_focusId = id;
    emit focusChanged();
    emit focusTaskChanged();
    emit effectiveStateChanged();
    emit compactOthersChanged();
}

void AppState::setFocus(const QString &id)
{
    if (!m_tasks->find(id))
        return;
    m_tasks->update(id, [](AgentTask &t) { t.pillBadge.clear(); });   // bringing a task to focus clears its badge
    setFocusInternal(id);
}

void AppState::addTask(const AgentTask &task)
{
    if (m_tasks->find(task.id))
        return;
    m_tasks->append(task);
    if (m_focusId.isEmpty())
        setFocusInternal(task.id);
    emit compactOthersChanged();
    emit focusTaskChanged();
    syncMode();
    syncView();
}

void AppState::removeTask(const QString &id)
{
    if (!m_tasks->removeById(id))
        return;
    if (m_focusId == id)
        setFocusInternal(m_tasks->all().isEmpty() ? QString() : m_tasks->all().first().id);
    emit compactOthersChanged();
    emit focusTaskChanged();
    syncMode();
    syncView();
}

void AppState::updateTask(const QString &id, BotState state)
{
    if (m_tasks->update(id, [state](AgentTask &t) { t.state = state; })) {
        emit effectiveStateChanged();
        emit compactOthersChanged();
        emit focusTaskChanged();
    }
}

void AppState::modifyTask(const QString &id, const std::function<void(AgentTask &)> &fn)
{
    if (!m_tasks->update(id, fn))
        return;
    emit effectiveStateChanged();
    emit compactOthersChanged();
    emit focusTaskChanged();
}

QVariantMap AppState::focusTask() const
{
    const AgentTask *t = m_tasks->find(m_focusId);
    if (!t)
        return {};
    QStringList labels;
    QVariantList steps;                 // the same steps with what an edit's step knows: its file, its counts, its diff
    for (const Step &step : t->steps) {
        labels << step.label;
        steps << QVariantMap{{"label", step.label}, {"file", step.file}, {"added", step.added}, {"removed", step.removed},
                             {"diff", step.diff}};
    }
    return {{"id", t->id},
            {"name", t->name},
            {"titled", t->titled},
            {"dormant", t->dormant},
            {"contextTokens", t->contextTokens},
            {"contextUsed", t->contextWindow > 0 ? qMin(1.0, double(t->contextTokens) / t->contextWindow) : 0.0},
            {"color", t->color},
            {"state", enumKey(t->state)},
            {"steps", labels},
            {"stepList", steps},
            {"stepIndex", t->stepIndex},
            {"alertText", t->alertText},
            {"finalMessage", t->finalMessage},
            {"options", t->options},
            {"cwd", t->sessionCwd},
            {"pillBadge", t->pillBadge},
            {"isIntegration", t->isIntegration}};
}

BotState AppState::effectiveState() const
{
    if (m_stateOverride)
        return *m_stateOverride;
    if (const AgentTask *t = m_tasks->find(m_focusId))
        return t->state;
    return m_tasks->all().isEmpty() ? BotState::Idle : m_tasks->all().first().state;
}

void AppState::setStateOverride(std::optional<BotState> s)
{
    m_stateOverride = s;
    emit effectiveStateChanged();
}

void AppState::setSoundEnabled(bool on)
{
    if (on == m_soundEnabled)
        return;
    m_soundEnabled = on;
    persist();
    emit soundEnabledChanged();
}

void AppState::setSoundVolume(double v)
{
    if (!std::isfinite(v))
        return;
    v = std::clamp(v, 0.0, kMaxVolume);
    if (v == m_soundVolume)
        return;
    m_soundVolume = v;
    persist();
    emit soundVolumeChanged();
}

void AppState::setAutoCloseInterval(double seconds)
{
    if (!std::isfinite(seconds) || !(seconds > 0) || seconds == m_autoClose)
        return;
    m_autoClose = seconds;
    persist();
    emit autoCloseIntervalChanged();
}

void AppState::setThemeMode(const QString &mode)
{
    if (!isThemeMode(mode) || mode == m_themeMode)
        return;
    m_themeMode = mode;
    persist();
    emit themeModeChanged();
}

void AppState::setEdge(const QString &edge)
{
    if (!isEdge(edge) || edge == m_edge)
        return;
    m_edge = edge;
    persist();
    emit edgeChanged();
}

void AppState::setReduceMotion(bool on)
{
    if (on == m_reduceMotion)
        return;
    m_reduceMotion = on;
    persist();
    emit reduceMotionChanged();
}

void AppState::setWorkspaceDir(const QString &dir)
{
    if (!dir.isEmpty() && !QDir::isAbsolutePath(dir))
        return;
    const QString clean = cleanDir(dir);
    if (clean == m_workspaceDir)
        return;
    m_workspaceDir = clean;
    persist();
    emit workspaceDirChanged();
}

void AppState::setSkillsDir(const QString &dir)
{
    if (!dir.isEmpty() && !QDir::isAbsolutePath(dir))
        return;
    const QString clean = cleanDir(dir);
    if (clean == m_skillsDir)
        return;
    m_skillsDir = clean;
    persist();
    emit skillsDirChanged();
}

void AppState::setSessionIdleSeconds(int seconds)
{
    if (!isSessionIdle(seconds) || seconds == m_sessionIdle)
        return;
    m_sessionIdle = seconds;
    persist();
    emit sessionIdleSecondsChanged();
}

int AppState::contextWindowFor(const QString &model, int tokens)
{
    constexpr int kWindow = 200000, kLargeWindow = 1000000;
    if (m_largeContextModels.contains(model))
        return kLargeWindow;
    if (tokens <= kWindow)
        return kWindow;
    if (!model.isEmpty() && !model.contains(';')) {
        m_largeContextModels << model;
        persist();
    }
    return kLargeWindow;
}

void AppState::setWaitReminderSeconds(int seconds)
{
    if (!isWaitReminder(seconds) || seconds == m_waitReminder)
        return;
    m_waitReminder = seconds;
    persist();
    emit waitReminderSecondsChanged();
}

void AppState::setNotifyAway(bool on)
{
    if (on == m_notifyAway)
        return;
    m_notifyAway = on;
    persist();
    emit notifyAwayChanged();
}

void AppState::setAutoHide(bool on)
{
    if (on == m_autoHide)
        return;
    m_autoHide = on;
    persist();
    emit autoHideChanged();
}

// For the screen: "~/dev" instead of the whole home path.
static QString homeLabel(const QString &dir)
{
    const QString home = Paths::home();
    if (dir == home)
        return QStringLiteral("~");
    if (dir.startsWith(home + QLatin1Char('/')))
        return QLatin1Char('~') + dir.mid(home.size());
    return dir;
}

QString AppState::workspaceDirLabel() const
{
    return homeLabel(m_workspaceDir);
}

QString AppState::skillsDirLabel() const
{
    return homeLabel(m_skillsDir);
}

void AppState::setPinned(bool on)
{
    if (on == m_pinned)
        return;
    m_pinned = on;
    emit pinnedChanged();
}

void AppState::setChatCount(int n)
{
    n = std::max(0, n);
    if (n == m_chatCount)
        return;
    m_chatCount = n;
    emit chatCountChanged();
}

void AppState::setUploadProgress(double p)
{
    p = std::clamp(p, 0.0, 1.0);
    if (p == m_uploadProgress)
        return;
    m_uploadProgress = p;
    emit uploadProgressChanged();
}

void AppState::setLastActivityMs(qint64 ms)
{
    m_lastActivityMs = ms;
    emit lastActivityChanged();
}

void AppState::setNotchSize(qreal w, qreal h)
{
    if (!(w > 0))
        w = IslandConst::notchWidth;
    if (!(h > 0))
        h = IslandConst::notchHeight;
    if (w == m_notchW && h == m_notchH)
        return;
    m_notchW = w;
    m_notchH = h;
    emit notchChanged();
}

void AppState::setPresent(bool on)
{
    m_present = on;
    syncMode();
}

void AppState::toggleIntegration(const QString &id)
{
    if (id == kClaudeId || !toggleableIntegrationIds().contains(id))
        return;
    if (m_activeIntegrations.contains(id)) {
        m_activeIntegrations.removeAll(id);
        m_tasks->removeById(id);
        if (m_focusId == id)
            setFocusInternal(kClaudeId);
    } else {
        if (m_activeIntegrations.size() >= 4)      // max 4 active pills, like Swift
            return;
        m_activeIntegrations << id;
        if (!m_tasks->find(id))
            for (const AgentTask &t : integrationAgents())
                if (t.id == id)
                    m_tasks->append(t);
    }
    persist();
    emit compactOthersChanged();
    syncMode();
}

void AppState::loadIntegrationTasks()
{
    for (const AgentTask &t : integrationAgents()) {
        const bool shouldLoad = t.id == kClaudeId || m_activeIntegrations.contains(t.id);
        const bool loaded = m_tasks->find(t.id) != nullptr;
        if (shouldLoad && !loaded)
            m_tasks->append(t);
        if (!shouldLoad && loaded)
            m_tasks->removeById(t.id);
    }
    if (m_focusId.isEmpty())
        setFocusInternal(kClaudeId);
    emit compactOthersChanged();
    syncMode();
}

void AppState::syncMode()
{
    const bool empty = m_tasks->all().isEmpty();
    if (empty && m_mode == IslandMode::Compact)
        setMode(IslandMode::Hidden);
    else if (!empty && m_mode == IslandMode::Hidden && m_present)
        setMode(IslandMode::Compact);
}

void AppState::syncView()
{
    if (m_mode != IslandMode::Expanded)
        return;
    const bool empty = m_tasks->all().isEmpty();
    if (m_view == IslandView::Empty && !empty)
        setView(IslandView::Overview);
    else if (m_view == IslandView::Overview && empty)
        setView(IslandView::Empty);
}

int AppState::sessionCount() const
{
    int n = 0;
    for (const AgentTask &t : m_tasks->all())
        n += !t.isIntegration;
    return n;
}

int AppState::awakeSessionCount() const
{
    int n = 0;
    for (const AgentTask &t : m_tasks->all())
        n += !t.isIntegration && !t.dormant;
    return n;
}

int AppState::waitingCount() const
{
    int n = 0;
    for (const AgentTask &t : m_tasks->all())
        n += !t.isIntegration && (t.state == BotState::Approval || t.state == BotState::Question);
    return n;
}

int AppState::errorCount() const
{
    int n = 0;
    for (const AgentTask &t : m_tasks->all())
        n += !t.isIntegration && (t.state == BotState::Error || t.state == BotState::Ratelimit);
    return n;
}

bool AppState::sessionBusy() const
{
    for (const AgentTask &t : m_tasks->all())
        if (!t.isIntegration && (t.state == BotState::Working || t.state == BotState::Thinking || t.state == BotState::Searching))
            return true;
    return false;
}

QVariantList AppState::compactOthers() const
{
    QVariantList out;
    for (const AgentTask &t : m_tasks->all()) {
        if (t.id == m_focusId)
            continue;
        out.append(QVariantMap{{"id", t.id}, {"color", t.color}, {"state", enumKey(t.state)}});
        if (out.size() == 4)
            break;
    }
    return out;
}

} // namespace farol
