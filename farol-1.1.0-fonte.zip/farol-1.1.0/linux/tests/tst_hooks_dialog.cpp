#include <QtTest>
#include <QApplication>
#include <QDialogButtonBox>
#include <QPushButton>
#include <QTimer>
#include "HooksDialog.h"

using namespace farol;

class TestHooksDialog : public QObject {
    Q_OBJECT
    static void clickLater(const QString &label)
    {
        QTimer::singleShot(150, [label] {
            QWidget *dlg = QApplication::activeModalWidget();
            QVERIFY(dlg);
            for (QPushButton *b : dlg->findChildren<QPushButton *>())
                if (b->text() == label) {
                    b->click();
                    return;
                }
            QFAIL("button not found");
        });
    }

private slots:
    void confirmButtonReturnsTrue()
    {
        clickLater("Write changes");
        QVERIFY(confirmHooksChange(nullptr, "Install", "summary", "--- a\n+++ b\n@@ -1 +1 @@\n-x\n+y\n", "Write changes"));
    }

    void cancelReturnsFalse()
    {
        clickLater("Cancel");
        QVERIFY(!confirmHooksChange(nullptr, "Install", "summary", "--- a\n+++ b\n", "Write changes"));
    }

    void escapeReturnsFalse()
    {
        QTimer::singleShot(150, [] {
            QWidget *dlg = QApplication::activeModalWidget();
            QVERIFY(dlg);
            QTest::keyClick(dlg, Qt::Key_Escape);
        });
        QVERIFY(!confirmHooksChange(nullptr, "Install", "summary", "x", "Write changes"));
    }

    void cancelIsTheDefaultButton()
    {
        QTimer::singleShot(150, [] {
            QWidget *dlg = QApplication::activeModalWidget();
            QVERIFY(dlg);
            for (QPushButton *b : dlg->findChildren<QPushButton *>())
                if (b->isDefault())
                    QCOMPARE(b->text(), QStringLiteral("Cancel"));
            QTest::keyClick(dlg, Qt::Key_Return);        // Enter must not confirm
        });
        QVERIFY(!confirmHooksChange(nullptr, "Install", "summary", "x", "Write changes"));
    }
};

QTEST_MAIN(TestHooksDialog)
#include "tst_hooks_dialog.moc"
