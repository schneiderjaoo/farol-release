#include <QtTest>
#include "IslandTypes.h"
#include "IslandWindow.h"

using namespace farol;

class TestIslandWindow : public QObject {
    Q_OBJECT
private slots:
#if FAROL_KDE
    // One anchor only: the compositor centres the surface along the other axis.
    void eachEdgeAnchorsToItsOwnSideOnly()
    {
        using A = LayerShellQt::Window::Anchor;
        QCOMPARE(IslandWindow::anchorFor(IslandEdge::Top), LayerShellQt::Window::Anchors(A::AnchorTop));
        QCOMPARE(IslandWindow::anchorFor(IslandEdge::Bottom), LayerShellQt::Window::Anchors(A::AnchorBottom));
        QCOMPARE(IslandWindow::anchorFor(IslandEdge::Left), LayerShellQt::Window::Anchors(A::AnchorLeft));
        QCOMPARE(IslandWindow::anchorFor(IslandEdge::Right), LayerShellQt::Window::Anchors(A::AnchorRight));
    }
#endif

    // Where Farol places the window itself (X11): against the edge and centred along it, on a screen that does
    // not start at 0,0 too.
    void theWindowGoesAgainstItsEdgeCentredAlongIt()
    {
        const QRect screen(1920, 100, 1600, 900);
        QCOMPARE(IslandWindow::positionFor(IslandEdge::Top, screen, QSize(720, 320)), QPoint(1920 + 440, 100));
        QCOMPARE(IslandWindow::positionFor(IslandEdge::Bottom, screen, QSize(720, 320)), QPoint(1920 + 440, 100 + 900 - 320));
        QCOMPARE(IslandWindow::positionFor(IslandEdge::Left, screen, QSize(320, 720)), QPoint(1920, 100 + 90));
        QCOMPARE(IslandWindow::positionFor(IslandEdge::Right, screen, QSize(320, 720)), QPoint(1920 + 1600 - 320, 100 + 90));
    }
};

QTEST_MAIN(TestIslandWindow)
#include "tst_island_window.moc"
