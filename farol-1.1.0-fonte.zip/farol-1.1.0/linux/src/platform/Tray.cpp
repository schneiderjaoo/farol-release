#include "Tray.h"

#include "AppState.h"
#include "IslandController.h"

#include "X11.h"

#include <QAction>
#include <QGuiApplication>
#include <QIcon>
#include <QMenu>
#include <QSystemTrayIcon>
#if FAROL_KDE
#include <KStatusNotifierItem>
#endif

namespace farol {

Tray::Tray([[maybe_unused]] AppState *state, IslandController *controller, TrayHooks hooks, QObject *parent) : QObject(parent)
{
    m_menu = new QMenu;
    m_menu->addAction(QStringLiteral("Open Farol"), this, [controller] { controller->expand(controller->defaultView()); });
    m_menu->addSeparator();
    m_menu->addAction(QStringLiteral("Settings…"), this, [controller] { controller->expandTo(QStringLiteral("settings")); });
    m_menu->addSeparator();

    QMenu *claude = m_menu->addMenu(QStringLiteral("Claude Code hooks"));
    QAction *status = claude->addAction(QStringLiteral("Hooks: not installed"));
    status->setEnabled(false);
    QAction *install = claude->addAction(QStringLiteral("Install…"), this, [hooks] { if (hooks.install) hooks.install(); });
    QAction *uninstall = claude->addAction(QStringLiteral("Uninstall…"), this, [hooks] { if (hooks.uninstall) hooks.uninstall(); });
    install->setEnabled(bool(hooks.install));
    uninstall->setEnabled(bool(hooks.uninstall));
    connect(m_menu, &QMenu::aboutToShow, this, [hooks, status] {
        if (!hooks.installed)
            return;
        if (!hooks.installed())
            status->setText(QStringLiteral("Hooks: not installed"));
        else if (hooks.upToDate && !hooks.upToDate())
            status->setText(QStringLiteral("Hooks: update needed (Install…)"));   // written by an older Farol
        else
            status->setText(QStringLiteral("Hooks: installed"));
    });
    m_menu->addSeparator();
    m_menu->addAction(QStringLiteral("Quit"), qApp, &QCoreApplication::quit);

    const QIcon icon(QStringLiteral(":/icons/local.joao.Farol.svg"));
#if FAROL_KDE
    if (desktopIsKde()) {
        auto *item = new KStatusNotifierItem(QStringLiteral("local.joao.Farol"), this);
        item->setCategory(KStatusNotifierItem::ApplicationStatus);
        item->setStatus(KStatusNotifierItem::Active);
        item->setTitle(QStringLiteral("Farol"));
        item->setIconByPixmap(icon);
        item->setStandardActionsEnabled(false);
        item->setContextMenu(m_menu);
        m_item = item;
        return;
    }
#endif
    auto *item = new QSystemTrayIcon(icon, this);
    item->setToolTip(QStringLiteral("Farol"));
    item->setContextMenu(m_menu);
    connect(item, &QSystemTrayIcon::activated, this, [controller](QSystemTrayIcon::ActivationReason reason) {
        if (reason == QSystemTrayIcon::Trigger)
            controller->expand(controller->defaultView());
    });
    item->show();
    m_item = item;
    m_ownsMenu = true;
}

Tray::~Tray()
{
    if (m_ownsMenu)
        delete m_menu;
}

} // namespace farol
