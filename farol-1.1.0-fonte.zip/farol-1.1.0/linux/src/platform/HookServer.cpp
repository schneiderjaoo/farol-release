#include "HookServer.h"

#include "ApprovalQueue.h"
#include "ClaudeSessions.h"
#include "Paths.h"

#include <QFile>
#include <QFileInfo>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLocalSocket>
#include <QPointer>
#ifndef Q_OS_WIN
#include <sys/socket.h>
#include <unistd.h>
#endif

namespace farol {

namespace {

#ifdef Q_OS_WIN
// The pipe is made for this user alone (QLocalServer::UserAccessOption): nobody else can open it.
bool fromThisUser(QLocalSocket *) { return true; }
#else
uid_t peerUid(QLocalSocket *s)
{
    ucred cred{};
    socklen_t len = sizeof(cred);
    if (getsockopt(int(s->socketDescriptor()), SOL_SOCKET, SO_PEERCRED, &cred, &len) != 0)
        return uid_t(-1);
    return cred.uid;
}

bool fromThisUser(QLocalSocket *s) { return peerUid(s) == getuid(); }
#endif

QByteArray decisionLine(Decision d)
{
    QJsonObject o;
    switch (d) {
    case Decision::Allow: o["decision"] = "allow"; break;
    case Decision::Deny:
        o["decision"] = "deny";
        o["message"] = "Denied from the Farol island";
        break;
    case Decision::Release: o["decision"] = "release"; break;
    }
    return QJsonDocument(o).toJson(QJsonDocument::Compact) + '\n';
}

// Answer to the PermissionRequest of an AskUserQuestion: the tool input with the answers, or "ask in the editor".
QByteArray questionLine(const QJsonObject &updatedInput)
{
    if (updatedInput.isEmpty())
        return decisionLine(Decision::Release);
    const QJsonObject o{{"decision", "allow"}, {"updatedInput", updatedInput}};
    return QJsonDocument(o).toJson(QJsonDocument::Compact) + '\n';
}

} // namespace

HookServer::HookServer(ClaudeSessions *sessions, ApprovalQueue *queue, QObject *parent)
    : QObject(parent), m_sessions(sessions), m_queue(queue)
{
}

HookServer::~HookServer()
{
    // Close every open hook connection while the table is still alive, and without running onDisconnected:
    // the sockets are children of this object and would otherwise be aborted after m_conns is destroyed.
    const QList<QLocalSocket *> open = m_conns.keys();
    m_conns.clear();
    for (QLocalSocket *s : open) {
        s->disconnect(this);
        s->abort();
    }
}

HookServer::StartResult HookServer::start(const QString &path)
{
#ifndef Q_OS_WIN   // on Windows `path` is the name of a pipe: no file, no folder
    if (!Paths::fitsUnixSocket(path)) {
        m_error = QStringLiteral("socket path too long: ") + path;
        return StartResult::Failed;
    }
    if (!Paths::ensurePrivateDir(QFileInfo(path).absolutePath())) {
        m_error = QStringLiteral("cannot create ") + QFileInfo(path).absolutePath();
        return StartResult::Failed;
    }
#endif
    {   // somebody already answers on this socket: another Farol is running
        QLocalSocket probe;
        probe.connectToServer(path);
        if (probe.waitForConnected(300))
            return StartResult::AlreadyRunning;
    }
    QLocalServer::removeServer(path);   // stale file from a crashed run
    m_server.setSocketOptions(QLocalServer::UserAccessOption);
    if (!m_server.listen(path)) {
        m_error = m_server.errorString();
        return StartResult::Failed;
    }
    connect(&m_server, &QLocalServer::newConnection, this, &HookServer::onNewConnection);
    return StartResult::Started;
}

void HookServer::onNewConnection()
{
    while (QLocalSocket *s = m_server.nextPendingConnection()) {
        if (!fromThisUser(s)) {
            s->abort();
            s->deleteLater();
            continue;
        }
        m_conns.insert(s, Conn{});
        connect(s, &QLocalSocket::readyRead, this, [this, s] { onReadyRead(s); });
        connect(s, &QLocalSocket::disconnected, this, [this, s] { onDisconnected(s); });
    }
}

void HookServer::onReadyRead(QLocalSocket *s)
{
    auto it = m_conns.find(s);
    if (it == m_conns.end() || !s->isOpen())   // a queued readyRead can arrive after abort()
        return;
    it->buffer += s->readAll();
    if (it->buffer.size() > kMaxLine) {
        m_conns.erase(it);                 // forget it first: abort() emits disconnected synchronously
        s->abort();
        s->deleteLater();
        return;
    }
    if (it->handled)
        return;                            // anything after the first line is ignored
    const int nl = it->buffer.indexOf('\n');
    if (nl < 0)
        return;
    it->handled = true;
    const QByteArray line = it->buffer.left(nl);
    dispatch(s, line);                     // may disconnect synchronously: `it` is not used after this
}

void HookServer::dispatch(QLocalSocket *s, const QByteArray &line)
{
    if (!m_eventLog.isEmpty()) {
        if (QFile f(m_eventLog); f.open(QIODevice::Append))
            f.write(line + '\n');
    }
    const auto ev = HookEvent::parse(line);
    if (!ev) {
        s->disconnectFromServer();
        return;
    }
    QPointer<QLocalSocket> guard(s);
    if (ev->name != QLatin1String("PermissionRequest")) {
        m_sessions->handleEvent(*ev);
        s->disconnectFromServer();
        return;
    }
    if (ev->toolName == QLatin1String("AskUserQuestion")) {
        const qint64 id = m_sessions->handleQuestion(*ev, [guard](const QJsonObject &updatedInput) {
            if (!guard)
                return;
            guard->write(questionLine(updatedInput));
            guard->flush();
            guard->disconnectFromServer();
        });
        const auto it = m_conns.find(s);   // left to the editor at once: it may already be closed
        if (it != m_conns.end())
            it->questionId = id;
        return;
    }
    const qint64 id = m_sessions->handlePermission(*ev, [guard](Decision d) {
        if (!guard)
            return;
        guard->write(decisionLine(d));
        guard->flush();
        guard->disconnectFromServer();
    });
    const auto it = m_conns.find(s);       // an "always allow" answer may already have closed it
    if (it != m_conns.end())
        it->requestId = id;
}

void HookServer::onDisconnected(QLocalSocket *s)
{
    const auto it = m_conns.find(s);
    if (it == m_conns.end())
        return;
    Conn c = *it;
    m_conns.erase(it);
    if (s->isOpen())
        c.buffer += s->readAll();          // bytes that arrived together with the close
    if (!c.handled && !c.buffer.isEmpty() && c.buffer.size() <= kMaxLine) {
        // the client closed without a trailing newline: still a complete line, unless it asks for a decision
        const auto ev = HookEvent::parse(c.buffer);
        if (ev && ev->name != QLatin1String("PermissionRequest"))
            m_sessions->handleEvent(*ev);
    }
    if (c.requestId != 0)
        m_queue->cancel(c.requestId);      // no-op when it was already answered
    if (c.questionId != 0)
        m_sessions->cancelQuestion(c.questionId);
    s->deleteLater();
}

} // namespace farol
