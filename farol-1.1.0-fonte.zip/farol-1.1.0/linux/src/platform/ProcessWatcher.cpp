#include "ProcessWatcher.h"

#include <QDir>
#include <QFile>
#include <QSocketNotifier>
#include <sys/syscall.h>
#include <unistd.h>

namespace farol {

namespace {

QByteArray readProc(const QString &procDir, qint64 pid, const char *file)
{
    QFile f(procDir + QLatin1Char('/') + QString::number(pid) + QLatin1Char('/') + QLatin1String(file));
    return f.open(QIODevice::ReadOnly) ? f.readAll() : QByteArray();
}

// Field 22 of stat, counted after the process name (which may itself hold spaces and parentheses); -1 when unreadable.
qint64 startTime(const QString &procDir, qint64 pid)
{
    const QByteArray stat = readProc(procDir, pid, "stat");
    const QList<QByteArray> rest = stat.mid(stat.lastIndexOf(')') + 2).split(' ');
    bool ok = false;
    const qint64 start = rest.value(19).trimmed().toLongLong(&ok);
    return ok ? start : -1;
}

// The pid the process has in the innermost PID namespace it lives in (last number of "NSpid:" in status).
qint64 innerPid(const QString &procDir, qint64 pid)
{
    for (const QByteArray &line : readProc(procDir, pid, "status").split('\n')) {
        if (!line.startsWith("NSpid:"))
            continue;
        bool ok = false;
        const qint64 inner = line.simplified().split(' ').last().toLongLong(&ok);
        return ok ? inner : -1;
    }
    return -1;
}

bool matches(const QString &procDir, qint64 candidate, qint64 pid, qint64 start)
{
    return startTime(procDir, candidate) == start && innerPid(procDir, candidate) == pid;
}

} // namespace

ProcessWatcher::ProcessWatcher(QObject *parent) : QObject(parent) {}

ProcessWatcher::~ProcessWatcher()
{
    for (const Watch &w : std::as_const(m_watches))
        release(w);
}

qint64 ProcessWatcher::hostPid(qint64 pid, qint64 start, const QString &procDir)
{
    if (pid <= 0 || start <= 0)
        return 0;
    if (matches(procDir, pid, pid, start))   // same namespace as ours: the usual case outside a sandbox
        return pid;
    const QStringList entries = QDir(procDir).entryList(QDir::Dirs | QDir::NoDotAndDotDot);
    for (const QString &entry : entries) {
        bool ok = false;
        const qint64 candidate = entry.toLongLong(&ok);
        if (ok && candidate != pid && matches(procDir, candidate, pid, start))
            return candidate;
    }
    return 0;
}

int ProcessWatcher::watch(qint64 pid, qint64 start, std::function<void()> gone)
{
    const qint64 host = hostPid(pid, start);
    if (host <= 0)
        return 0;
    const int fd = int(::syscall(SYS_pidfd_open, pid_t(host), 0u));
    if (fd < 0)
        return 0;
    if (startTime(QStringLiteral("/proc"), host) != start) {   // it exited meanwhile and the pid went to another process
        ::close(fd);
        return 0;
    }
    const int id = ++m_next;
    auto *notifier = new QSocketNotifier(fd, QSocketNotifier::Read, this);   // a pidfd turns readable when the process exits
    m_watches.insert(id, Watch{fd, notifier, std::move(gone)});
    connect(notifier, &QSocketNotifier::activated, this, [this, id] {
        const auto it = m_watches.constFind(id);
        if (it == m_watches.constEnd())
            return;
        const Watch w = *it;
        m_watches.erase(it);
        release(w);
        if (w.gone)
            w.gone();
    });
    return id;
}

void ProcessWatcher::cancel(int id)
{
    const auto it = m_watches.constFind(id);
    if (it == m_watches.constEnd())
        return;
    release(*it);
    m_watches.erase(it);
}

void ProcessWatcher::release(const Watch &w)
{
    w.notifier->setEnabled(false);
    w.notifier->deleteLater();
    ::close(w.fd);
}

} // namespace farol
