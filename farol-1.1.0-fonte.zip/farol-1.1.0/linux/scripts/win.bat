@echo off
rem Runs a command with the MSVC environment and Qt on PATH (the Windows side of host.sh):
rem   linux\scripts\win.bat cmake -S linux -B linux/build -G Ninja -DFAROL_BUILD_SPIKES=OFF
rem   linux\scripts\win.bat cmake --build linux/build
rem   linux\scripts\win.bat ctest --test-dir linux/build --output-on-failure
rem FAROL_QT is the Qt to use (default C:\Qt\6.10.3\msvc2022_64).
if "%FAROL_QT%"=="" set "FAROL_QT=C:\Qt\6.10.3\msvc2022_64"
set "VSWHERE=%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe"
for /f "usebackq delims=" %%i in (`"%VSWHERE%" -latest -products * -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath`) do set "VSROOT=%%i"
if "%VSROOT%"=="" echo Visual Studio C++ tools not found & exit /b 1
call "%VSROOT%\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1 || exit /b 1
set "CMAKE_PREFIX_PATH=%FAROL_QT%"
set "PATH=%FAROL_QT%\bin;%PATH%"
%*
