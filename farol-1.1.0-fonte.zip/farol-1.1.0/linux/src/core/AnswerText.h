#pragma once
#include <QString>

namespace farol {

// How an answer is drawn: the theme's colours ("#RRGGBB") and font families.
struct AnswerStyle {
    QString link;       // a link's text
    QString codeBg;     // behind code
    QString line;       // a table's border
    QString bodyFont;
    QString monoFont;   // code
};

// A link an answer may open: http or https with a host and nobody's name in front of it
// ("https://good.com@evil.com/" goes to evil.com).
bool isWebLink(const QString &href);

// Where a web link goes, for the line that says so: its host with the port, in the letters the network uses ("xn--…"
// for a name with letters outside ASCII, which can look like another name), and what comes after the host, as it is
// sent. Both are empty for anything that is not a web link.
QString linkHost(const QString &href);
QString linkRest(const QString &href);

// The Markdown of an answer, which is text from outside, as HTML for a rich text item. Raw HTML in it is shown as the
// text it is (but a <br> outside code breaks the line), an image becomes "[imagem: <alt>]" (rich text fetches
// whatever an image points to), and only a web link stays a link. Works without a QGuiApplication.
QString answerHtml(const QString &markdown, const AnswerStyle &style);

} // namespace farol
