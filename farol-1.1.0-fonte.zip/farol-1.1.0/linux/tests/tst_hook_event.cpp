#include <QtTest>
#include "HookEvent.h"

using namespace farol;
using namespace Qt::StringLiterals;

class TestHookEvent : public QObject {
    Q_OBJECT
private slots:
    void parsesAFullEvent()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"PreToolUse","session_id":"abc","cwd":"/home/u/proj",
            "transcript_path":"/home/u/.claude/projects/-home-u-proj/abc.jsonl",
            "farol_source":"vscodium","flatpak_id":"com.vscodium.codium","tool_name":"Bash",
            "tool_input":{"command":"npm test"},"prompt":"hi","message":"m","notification_type":"idle_prompt",
            "last_assistant_message":"done"})");
        QVERIFY(e);
        QCOMPARE(e->name, QStringLiteral("PreToolUse"));
        QCOMPARE(e->sessionId, QStringLiteral("abc"));
        QCOMPARE(e->cwd, QStringLiteral("/home/u/proj"));
        QCOMPARE(e->transcriptPath, QStringLiteral("/home/u/.claude/projects/-home-u-proj/abc.jsonl"));
        QCOMPARE(e->source, QStringLiteral("vscodium"));
        QCOMPARE(e->flatpakId, QStringLiteral("com.vscodium.codium"));
        QCOMPARE(e->toolName, QStringLiteral("Bash"));
        QCOMPARE(e->toolInput.value("command").toString(), QStringLiteral("npm test"));
        QCOMPARE(e->prompt, QStringLiteral("hi"));
        QCOMPARE(e->notificationType, QStringLiteral("idle_prompt"));
        QCOMPARE(e->lastAssistantMessage, QStringLiteral("done"));
    }

    void claudeProcess()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"Stop","claude_pid":1548,"claude_start":10907223})");
        QVERIFY(e);
        QCOMPARE(e->claudePid, qint64(1548));
        QCOMPARE(e->claudeStart, qint64(10907223));
        // absent (an older farol-hook, or no ancestor named claude), or only half of it: no process
        for (const char *line : {R"({"hook_event_name":"Stop"})", R"({"hook_event_name":"Stop","claude_pid":1548})",
                                 R"({"hook_event_name":"Stop","claude_pid":"x","claude_start":-4})"}) {
            const auto none = HookEvent::parse(line);
            QVERIFY(none);
            QCOMPARE(none->claudePid, qint64(0));
            QCOMPARE(none->claudeStart, qint64(0));
        }
    }

    void editorAndAncestors()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"Stop","farol_editor":"code",
            "farol_ancestors":[[30,800],[20,700],["x",1],[1,5],[10]]})");
        QVERIFY(e);
        QCOMPARE(e->editor, QStringLiteral("code"));
        QCOMPARE(e->ancestors, (QList<QPair<qint64, qint64>>{{30, 800}, {20, 700}}));   // malformed pairs and init are dropped
        QVERIFY(HookEvent::parse(R"({"hook_event_name":"Stop","farol_ancestors":"no"})")->ancestors.isEmpty());
    }

    void konsoleFields()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"Stop","konsole_dbus_service":":1.7",
            "konsole_dbus_session":"/Sessions/3","konsole_dbus_window":"/Windows/1"})");
        QVERIFY(e);
        QCOMPARE(e->konsoleService, QStringLiteral(":1.7"));
        QCOMPARE(e->konsoleSession, QStringLiteral("/Sessions/3"));
        QCOMPARE(e->konsoleWindow, QStringLiteral("/Windows/1"));
    }

    void rejectsGarbage()
    {
        QVERIFY(!HookEvent::parse(""));
        QVERIFY(!HookEvent::parse("not json"));
        QVERIFY(!HookEvent::parse("[1,2,3]"));
        QVERIFY(!HookEvent::parse(R"({"session_id":"x"})"));                 // no hook_event_name
        QVERIFY(!HookEvent::parse(R"({"hook_event_name":""})"));
        QVERIFY(!HookEvent::parse(R"({"hook_event_name":42})"));
        QVERIFY(!HookEvent::parse(QByteArray("\xff\xfe{")));
    }

    void missingFieldsGetDefaults()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"Stop"})");
        QVERIFY(e);
        QCOMPARE(e->sessionId, QStringLiteral("unknown"));
        QCOMPARE(e->cwd, QString());
        QCOMPARE(e->project(), QStringLiteral("Session"));
        QVERIFY(e->toolInput.isEmpty());
    }

    // What a file tool did: the call's id (the same in its PreToolUse and its PostToolUse), what the tool gave back
    // and the counts farol-hook made of it.
    void anEditCarriesItsCallItsResponseAndItsCounts()
    {
        const auto e = HookEvent::parse(R"({"hook_event_name":"PostToolUse","session_id":"abc","tool_name":"Edit",
            "tool_use_id":"toolu_01YDmKuPC53k4VScwj7AcUYK","tool_input":{"file_path":"/w/small.txt","replace_all":false},
            "tool_response":{"filePath":"/w/small.txt","structuredPatch":[{"oldStart":1,"oldLines":4,"newStart":1,
            "newLines":5,"lines":[" alpha","-beta","+beta2","+beta3"," gamma"," delta"]}],"userModified":false},
            "farol_edit":{"added":2,"removed":1,"cut":true}})");
        QVERIFY(e);
        QCOMPARE(e->toolUseId, QStringLiteral("toolu_01YDmKuPC53k4VScwj7AcUYK"));
        QCOMPARE(e->toolResponse.value("filePath").toString(), QStringLiteral("/w/small.txt"));
        QCOMPARE(e->toolResponse.value("structuredPatch").toArray().size(), 1);
        QCOMPARE(e->editAdded, 2);
        QCOMPARE(e->editRemoved, 1);
        QVERIFY(e->editCut);
    }

    void whatAnEditDoesNotSayStaysUnknown()
    {
        const auto none = HookEvent::parse(R"({"hook_event_name":"PostToolUse","tool_name":"Edit"})");   // an older farol-hook
        QVERIFY(none);
        QCOMPARE(none->toolUseId, QString());
        QVERIFY(none->toolResponse.isEmpty());
        QCOMPARE(none->editAdded, -1);
        QCOMPARE(none->editRemoved, -1);
        QVERIFY(!none->editCut);

        // a response that is no object (a string, a list) is not kept; an id that is no string is none
        for (const char *line : {R"({"hook_event_name":"PostToolUse","tool_response":"File written","tool_use_id":7})",
                                 R"({"hook_event_name":"PostToolUse","tool_response":[{"type":"text"}],"tool_use_id":null})"}) {
            const auto e = HookEvent::parse(line);
            QVERIFY(e);
            QVERIFY(e->toolResponse.isEmpty());
            QCOMPARE(e->toolUseId, QString());
        }

        // counts come as a pair of whole numbers that are not negative, or not at all
        for (const char *edit : {R"("3 lines")", R"([3,1])", R"({"added":3})", R"({"added":"3","removed":1})", R"({"added":-1,"removed":2})",
                                 R"({"added":3,"removed":null})", R"({"added":1.5,"removed":2})", R"({"added":3,"removed":4000000000})"}) {
            const auto e = HookEvent::parse(QByteArray(R"({"hook_event_name":"PostToolUse","farol_edit":)") + edit + "}");
            QVERIFY2(e, edit);
            QVERIFY2(e->editAdded == -1 && e->editRemoved == -1, edit);
            QVERIFY2(!e->editCut, edit);
        }
        // a notebook cell that was cut: nothing counted, and it says so
        const auto cell = HookEvent::parse(R"({"hook_event_name":"PostToolUse","farol_edit":{"cut":true}})");
        QVERIFY(cell->editCut);
        QCOMPARE(cell->editAdded, -1);
        const auto odd = HookEvent::parse(R"({"hook_event_name":"PostToolUse","farol_edit":{"added":0,"removed":0,"cut":"yes"}})");
        QCOMPARE(odd->editAdded, 0);
        QCOMPARE(odd->editRemoved, 0);
        QVERIFY(!odd->editCut);
    }

    // What Claude says when a turn ends is Markdown; the session card shows a few lines of plain text.
    void aMessageBecomesPlainText_data()
    {
        QTest::addColumn<QString>("markdown");
        QTest::addColumn<QString>("plain");
        const auto row = [](const char *name, const QString &markdown, const QString &plain) {
            QTest::newRow(name) << markdown << plain;
        };
        row("plain text", u"Tudo pronto."_s, u"Tudo pronto."_s);
        row("heading", u"## Resumo\n\nFeito."_s, u"Resumo\nFeito."_s);
        row("every heading level", u"# Um\n###### Seis\n####### sete\n#etiqueta"_s, u"Um\nSeis\n####### sete\n#etiqueta"_s);
        row("bold and strike", u"**Pronto**: o build __passou__ e ~~falhou~~."_s, u"Pronto: o build passou e falhou."_s);
        row("italic pairs only", u"Foi *muito* bem: 2 * 3 * 4 = 24"_s, u"Foi muito bem: 2 * 3 * 4 = 24"_s);
        row("bold italic", u"***Atenção***"_s, u"Atenção"_s);
        row("code", u"Rode `ctest` em ``linux/build``"_s, u"Rode ctest em linux/build"_s);
        row("code keeps what it holds", u"`__init__.py`, `**kwargs` e ``a`b``"_s, u"__init__.py, **kwargs e a`b"_s);
        row("a lone backtick goes", u"sobrou ` aqui"_s, u"sobrou aqui"_s);
        row("link", u"Veja [a documentação](https://example.org/a_(b) \"t\") aqui"_s, u"Veja a documentação aqui"_s);
        row("link to a file", u"Mudei [`Island.qml`](linux/qml/Island.qml#L12)."_s, u"Mudei Island.qml."_s);
        row("image", u"![o gráfico](https://example.org/g.png) pronto"_s, u"o gráfico pronto"_s);
        row("linked image", u"[![selo](https://example.org/s.svg)](https://example.org)"_s, u"selo"_s);
        row("bullets", u"- um\n* dois\n+ três"_s, u"• um\n• dois\n• três"_s);
        row("nested bullets", u"- um\n  - **dois**\n    - três"_s, u"• um\n• dois\n• três"_s);
        row("ordered", u"1. Abra\n2) Some\n10. Confira\n3.5 segundos"_s, u"Abra\nSome\nConfira\n3.5 segundos"_s);
        row("tasks", u"- [ ] fazer\n- [x] feito\n* [X] feito também"_s, u"• fazer\n• feito\n• feito também"_s);
        row("quote", u"> **Nota:** cuidado\n>> mais\n> - item"_s, u"Nota: cuidado\nmais\n• item"_s);
        row("a marker alone", u"-\n#\n>\n1.\n- \n+\nfim"_s, u"fim"_s);
        row("fenced code", u"Rodei:\n```sh\nmake -j8\n# não é título\n```\nPassou."_s, u"Rodei:\nPassou."_s);
        row("tilde fence", u"~~~\nx\n```\n~~~\nfim"_s, u"fim"_s);
        row("fence inside a list", u"1. Some:\n   ```sh\n   awk '{ s += $2 }'\n   ```\n2. Confira"_s, u"Some:\nConfira"_s);
        row("longer fence", u"````\n```\nx\n```\n````\nfim"_s, u"fim"_s);
        row("fence left open", u"Antes\n```\ncódigo\nmais"_s, u"Antes"_s);
        row("code in one line is no fence", u"```make``` roda tudo\nfim"_s, u"make roda tudo\nfim"_s);
        row("table", u"Resultado:\n| a | b |\n|---|---|\n| 1 | 2 |\nfim"_s, u"Resultado:\nfim"_s);
        row("rules", u"um\n---\n***\n___\n- - -\n  -----  \ndois"_s, u"um\ndois"_s);
        row("blank lines", u"\n\n  um  \n\n\n   \ndois  e   três\n"_s, u"um\ndois e três"_s);
        row("windows line ends", u"um\r\ndois\r\n"_s, u"um\ndois"_s);
        row("snake case", u"Mudei session_idle_seconds, _privado_ e a_b_c"_s, u"Mudei session_idle_seconds, _privado_ e a_b_c"_s);
        row("html is text", u"<b>x</b> <img src='http://example.org/y.png'> &amp; <!-- z -->"_s,
            u"<b>x</b> <img src='http://example.org/y.png'> &amp; <!-- z -->"_s);
        row("escapes", u"\\*literal\\* e 1\\. item em C:\\Users"_s, u"*literal* e 1. item em C:\\Users"_s);
        row("bidi and control characters", u"ab\u202Ec\u2066d\u2069\u200B\uFEFF\u0007e\u001B[0m\u200Ef\u0008g\u00ADh"_s, u"abcde[0mfgh"_s);
        row("white space of any kind is a blank", u"a\tb\u000Bc\u000Cd\u0085e\u2028f\u2029g\u00A0h\ri"_s, u"a b c d e f g h i"_s);
        row("joined emoji stay joined", u"\U0001F468\u200D\U0001F469\u200D\U0001F467 ok"_s, u"\U0001F468\u200D\U0001F469\u200D\U0001F467 ok"_s);
        row("hidden tag characters", u"ok\U000E0041\U000E0042!"_s, u"ok!"_s);
        row("half a surrogate pair", u"a"_s + QChar(0xD83D) + u"b"_s + QChar(0xDE00) + u"c"_s, u"abc"_s);
        row("the way a turn often ends",
            u"Done. I've made the following changes:\n\n1. **`src/foo.ts`** — added the `bar()` helper\n"
            "2. **Tests** — 3 new cases in [foo.test.ts](src/foo.test.ts#L10)\n\nAll tests pass (`npm test`)."_s,
            u"Done. I've made the following changes:\nsrc/foo.ts — added the bar() helper\n"
            "Tests — 3 new cases in foo.test.ts\nAll tests pass (npm test)."_s);
        row("emphasis around code", u"*`x`* e **`y_z`**"_s, u"x e y_z"_s);
        row("numbered heading and task", u"## 1. Resumo\n1. [x] feito"_s, u"Resumo\nfeito"_s);
        row("brackets that are no link", u"array[0] = x; [WIP] título; [x](y"_s, u"array[0] = x; [WIP] título; [x](y"_s);
        row("stars that are no emphasis", u"*.cpp e *.h; 2 ** 10"_s, u"*.cpp e *.h; 2 10"_s);
        row("nothing but marks", u"**\n``\n![](a.png)\n- \n> \nfim"_s, u"fim"_s);
        row("only code", u"```\nx\n```"_s, QString());
        row("only a table", u"| a |\n|---|\n| 1 |"_s, QString());
        row("empty", QString(), QString());
        row("only blanks", u" \n\t\r\n  "_s, QString());
    }

    void aMessageBecomesPlainText()
    {
        QFETCH(QString, markdown);
        QFETCH(QString, plain);
        QCOMPARE(plainMessage(markdown), plain);
    }

    // The card has room for four lines: the rest is left out, and the text says that there was more.
    void aLongMessageIsCutToAFewLinesAndCharacters()
    {
        QCOMPARE(plainMessage(u"a\n\nb\n- c\nd"_s), u"a\nb\n• c\nd"_s);                  // four lines: whole
        QCOMPARE(plainMessage(u"a\n\nb\n- c\nd\n```\nx\n```\n"_s), u"a\nb\n• c\nd"_s);  // what is skipped is not "more"
        QCOMPARE(plainMessage(u"a\nb\nc\nd\ne\nf"_s), u"a\nb\nc\nd…"_s);
        QCOMPARE(plainMessage(u"um\ndois\ntrês"_s, 2), u"um\ndois…"_s);
        QCOMPARE(plainMessage(u"um\ndois\ntrês"_s, 1, 120), u"um…"_s);

        QCOMPARE(plainMessage(QString(300, u'a')), QString(300, u'a'));                 // 300 characters: whole
        const QString cut = plainMessage(QString(600, u'a'));
        QCOMPARE(cut.size(), 300);
        QCOMPARE(cut, QString(299, u'a') + u"…"_s);
        QCOMPARE(plainMessage(u"abcdef"_s, 4, 4), u"abc…"_s);
        QCOMPARE(plainMessage(u"ab cdef"_s, 4, 4), u"ab…"_s);                           // no blank before the "…"
        QCOMPARE(plainMessage(u"abc\ndef"_s, 4, 5), u"abc…"_s);                         // nor an empty line

        // the limit counts what is shown, not the Markdown around it
        const QString link = u"[texto](https://example.org/"_s + QString(500, u'x') + u")"_s;
        QCOMPARE(plainMessage(link), u"texto"_s);

        QCOMPARE(plainMessage(u"abc"_s, 0, 300), QString());
        QCOMPARE(plainMessage(u"abc"_s, 4, 0), QString());
    }

    void aCutNeverSplitsASurrogatePair()
    {
        const auto whole = [](const QString &s) { return QString::fromUtf8(s.toUtf8()) == s; };   // half a pair reads back as U+FFFD
        const QString faces = u"\U0001F600"_s.repeated(200);                               // 400 UTF-16 units
        for (const QString &text : {faces, u"a"_s + faces}) {                                     // the cut falls on either half
            const QString cut = plainMessage(text);
            QVERIFY(cut.size() <= 300 && cut.size() >= 298);
            QVERIFY(cut.endsWith(u"…"_s));
            QVERIFY2(whole(cut), qPrintable(cut.right(4)));
        }
    }

    // The hook forwards the whole message (up to 1 MiB a line): only its start is looked at.
    void aHugeMessageIsNoMoreWorkThanAShortOne()
    {
        const QString line = u"**palavra** "_s.repeated(90000);                             // one line, 1 MiB
        const QString one = plainMessage(line);
        QCOMPARE(one.size(), 300);
        QVERIFY(one.startsWith(u"palavra palavra palavra"_s));
        QVERIFY(!one.contains(u'*'));
        const QString many = plainMessage(u"- linha\n"_s.repeated(130000));                 // 130 000 lines
        QCOMPARE(many, u"• linha\n• linha\n• linha\n• linha…"_s);
    }
};

QTEST_APPLESS_MAIN(TestHookEvent)
#include "tst_hook_event.moc"
