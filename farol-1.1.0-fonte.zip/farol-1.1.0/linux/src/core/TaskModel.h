#pragma once
#include "AgentTask.h"

#include <QAbstractListModel>
#include <functional>

namespace farol {

class TaskModel : public QAbstractListModel {
    Q_OBJECT
public:
    enum Role { IdRole = Qt::UserRole + 1, NameRole, ColorRole, StateRole, PillBadgeRole, IsIntegrationRole, StepRole, TitledRole, BoatRole, DormantRole, ContextUsedRole };

    explicit TaskModel(QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = {}) const override;
    QVariant data(const QModelIndex &index, int role) const override;
    QHash<int, QByteArray> roleNames() const override;

    const QList<AgentTask> &all() const { return m_tasks; }
    int indexOf(const QString &id) const;
    const AgentTask *find(const QString &id) const;
    void append(const AgentTask &task);
    bool removeById(const QString &id);
    bool update(const QString &id, const std::function<void(AgentTask &)> &fn);

private:
    QList<AgentTask> m_tasks;
};

} // namespace farol
