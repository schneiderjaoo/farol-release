#pragma once
#include "CommandRunner.h"

#include <QObject>
#include <QString>
#include <QStringList>
#include <functional>

class QSettings;

namespace farol {

class AppState;

// The Skills tab: keeps Claude Code linked to the company's skills folder (AppState::skillsDir) and that folder up
// to date. The folder is updated with `git pull --ff-only` when the app starts and when the tab opens, at most once
// an hour, and at once on "Atualizar agora"; nothing runs on a timer. What stands in the way is said, never forced:
// no stash, reset, merge or rebase.
class Skills : public QObject {
    Q_OBJECT
    Q_PROPERTY(int linked READ linked NOTIFY changed)             // skills of the folder Claude Code uses
    Q_PROPERTY(QString status READ status NOTIFY changed)         // none | ok | plain | warn
    Q_PROPERTY(QString message READ message NOTIFY changed)       // pt-BR, one line
    Q_PROPERTY(QString detail READ detail NOTIFY changed)         // pt-BR, the line under it
    Q_PROPERTY(QStringList conflicts READ conflicts NOTIFY changed)
    Q_PROPERTY(bool busy READ busy NOTIFY changed)
    Q_PROPERTY(bool warning READ warning NOTIFY changed)          // the mark on the rail's tab
public:
    static constexpr qint64 kUpdateEveryMs = 60 * 60 * 1000;
    static constexpr int kPullTimeoutMs = 30 * 1000;

    Skills(AppState *state, ICommandRunner *runner, QSettings *settings, const QString &claudeSkillsDir,
           std::function<qint64()> nowMs, QObject *parent = nullptr);

    int linked() const { return m_linked; }
    QString status() const;
    QString message() const;
    QString detail() const;
    QStringList conflicts() const { return m_conflicts; }
    bool busy() const { return m_busy; }
    bool warning() const { return status() == QLatin1String("warn"); }

    // The app started or the tab opened: links are checked, and the folder is updated if it is time.
    Q_INVOKABLE void refresh();
    Q_INVOKABLE void updateNow();
    Q_INVOKABLE void openFolder() { emit openFolderRequested(m_dir); }

signals:
    void changed();
    void openFolderRequested(const QString &dir);

private:
    enum class Pull { Never, Ok, Dirty, Offline, NoGit, NoRepository };
    void onDirChanged();
    void relink(const QString &previousDir = {});
    void pull();
    static Pull classify(const ICommandRunner::Result &r);

    AppState *m_state;
    ICommandRunner *m_runner;
    QSettings *m_settings;
    QString m_claudeDir;
    std::function<qint64()> m_now;
    QString m_dir;
    int m_linked = 0;
    QStringList m_conflicts;
    QString m_linkError;
    Pull m_pull = Pull::Never;
    qint64 m_pulledAt = 0;     // last attempt, for the hourly limit
    qint64 m_updatedAt = 0;    // last success, for "atualizado há ..."
    bool m_busy = false;
};

} // namespace farol
