import QtQuick

// One tab of the rail (26x26): filled when its view is the one on screen.
Item {
    id: tab
    property string icon: ""
    property bool on: false
    property bool mark: false      // a lamp-coloured dot: something in that tab wants a look
    signal clicked()

    width: 26
    height: 26

    Rectangle {
        anchors.fill: parent
        radius: 9
        color: tab.on ? theme.card : (hover.hovered ? theme.pillHoverFill : theme.pillFill)
    }
    IconGlyph {
        anchors.centerIn: parent
        name: tab.icon
        size: 14
        color: tab.on ? theme.text : (hover.hovered ? theme.textHover : theme.muted)
    }
    Rectangle {
        objectName: tab.objectName + "Mark"
        visible: tab.mark
        x: parent.width - 9
        y: 3
        width: 6
        height: 6
        radius: 3
        color: theme.lamp
    }
    HoverHandler { id: hover }
    TapHandler { onTapped: tab.clicked() }
}
