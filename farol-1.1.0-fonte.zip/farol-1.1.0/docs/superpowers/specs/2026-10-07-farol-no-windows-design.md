# Farol no Windows — desenho do port

Data: 2026-10-07 · Status: aguardando revisão · Base: `27dba5e` (o commit que trouxe o X11 / Linux Mint 22)

## 1. Objetivo

O Farol rodar no Windows 10 e 11 com o que ele faz hoje no Fedora e no Mint: a ilha na borda da tela, as sessões do Claude Code como barcos, aprovar permissões e responder perguntas com um clique, voltar para a janela do editor, e as abas Nova sessão, Perguntar, Skills e Ajustes.

Sucesso: numa máquina com Windows 11 e o Claude Code no VS Code, instalar o Farol sem ser administrador, clicar em **Claude Code hooks → Install…** e ver a sessão aparecer na ilha; nenhuma regra da casa (seção 7) vale menos no Windows do que no Linux.

## 2. De onde se parte

O commit do Mint já fez a parte mais cara do desenho: a camada de plataforma deixou de ser "KDE" e passou a ter dois tipos de desktop escolhidos na compilação (`FAROL_KDE`, `FAROL_X11`) e na hora de rodar (`desktopIsKde()`). O Windows entra como o terceiro tipo, `FAROL_WIN`, pelo mesmo caminho. Três peças já servem como estão:

- `Tray`: fora do Plasma já usa `QSystemTrayIcon`, que no Windows é o ícone da área de notificação.
- `GlobalShortcuts::Backend`: é uma interface; falta só o backend do Windows.
- `windowToRaise` (`core/JumpCommand`): a escolha da janela do editor é pura e trabalha sobre uma lista de `DesktopWindow`. No Windows muda só quem monta a lista.

`farol_core` (FSM, sessões, fila de permissões, diff, `AnswerText`, `AiRequest`, tema) não fala com o sistema e deve compilar sem mudança de desenho. O QML não muda.

### Medido nesta máquina (Windows 11 Pro, Claude Code 2.1.292 no VS Code)

| O quê | Resultado |
|---|---|
| Processo do Claude Code | `claude.exe`, em `~\.vscode\extensions\anthropic.claude-code-<versão>-win32-x64\resources\native-binary\` |
| Quem está acima dele | `Code.exe` (duas vezes); um comando de ferramenta roda como `claude.exe → cmd.exe → powershell.exe` |
| `CLAUDE_CODE_ENTRYPOINT` | `claude-vscode`, como no Linux |
| `claude` no `PATH` | não existe: só o binário da extensão |
| `~\.claude\settings.json` | existe, mesmo lugar do Linux (`%USERPROFILE%\.claude`) |
| Python | só o atalho da Microsoft Store: `python` responde "Python was not found" |
| Compilador, CMake, Qt, WSL, Docker | nenhum (o ferramental está sendo instalado: seção 8) |

A linha do Python decide o desenho do hook (seção 4).

## 3. Peça por peça

| Peça (`linux/src`) | Hoje | No Windows | Tamanho |
|---|---|---|---|
| `platform/IslandWindow` | layer-shell (Plasma) ou janela sem moldura posta à mão (X11) | o ramo da janela sem moldura (`Qt::Tool`, sempre por cima, sem foco); o clique fora da ilha é a dúvida (5.1) | médio, **risco alto** |
| `platform/X11` | janelas, janela ativa, ativar, tecla global, tempo ocioso | arquivo irmão `Win32.h/.cpp` com as mesmas perguntas: `EnumWindows`, `GetForegroundWindow`, `SetForegroundWindow`, `GetLastInputInfo` | médio |
| `platform/Tray` | `KStatusNotifierItem` ou `QSystemTrayIcon` | `QSystemTrayIcon`, nada novo | nenhum |
| `platform/GlobalShortcuts` | KGlobalAccel ou tecla agarrada no X | backend com `RegisterHotKey` + `WM_HOTKEY` num filtro de eventos nativos; combinação ocupada devolve vazio, como já é o contrato | pequeno |
| `platform/HookServer` | `QLocalServer` num socket Unix; confere o dono com `SO_PEERCRED` | `QLocalServer` num named pipe (`\\.\pipe\farol-<usuário>`), com `UserAccessOption`; a conferência do dono passa a ser pelo token do cliente do pipe | pequeno |
| `hook/farol-hook` | script Python | `farol-hook.exe` nativo (seção 4) | **grande** |
| `platform/ProcessWatcher` | pidfd + `/proc` (e o pid de dentro do Flatpak) | `OpenProcess(SYNCHRONIZE)` + `QWinEventNotifier` no handle: o sistema avisa quando o processo sai, nada é consultado em laço. A hora de início vem de `GetProcessTimes`. Não há namespace de pid | pequeno |
| `platform/SecretServiceStore` | D-Bus `org.freedesktop.secrets` | `WinCredentialStore`: o Gerenciador de Credenciais (`CredWriteW`/`CredReadW`/`CredDeleteW`, alvo `Farol/<nome>`), que guarda cifrado para o usuário | pequeno |
| `platform/DesktopNotifier` | D-Bus `Notifications`; ausência por KIdleTime ou pelo servidor X | envio por `QSystemTrayIcon::showMessage` (texto puro: não há marcação a escapar); ocioso por `GetLastInputInfo` na hora de notificar; tela bloqueada por `WTSRegisterSessionNotification` (um evento, nada consultado) | pequeno |
| `platform/SystemTheme` | Qt ≥ 6.5 responde sozinho; portal D-Bus só no Qt 6.4 | o ramo do Qt; o do portal fica fora da compilação | nenhum |
| `platform/SessionJumper` | script do KWin, Konsole por D-Bus, ou EWMH no X11 | lista de janelas do `Win32` + `windowToRaise` + `SetForegroundWindow` (5.3); sem KWin, sem Konsole, sem Flatpak | médio |
| `core/JumpCommand` | `flatpak run …` ou o programa do editor; URI `vscodium://…` | o executável do editor (o hook manda o caminho do `Code.exe` que achou acima do Claude); a URI `vscode://anthropic.claude-code/open` vai por `QDesktopServices::openUrl` | pequeno |
| `core/Paths` | tudo a partir de `$HOME` (regra por causa do Flatpak) | `%LOCALAPPDATA%\Farol\` para `farol.conf` e o estado; `~\.claude` igual. `fitsUnixSocket` e `ensurePrivateDir` não se aplicam (a pasta do perfil já é só do usuário) | pequeno |
| `core/ClaudeLocator` | `claude` no PATH, `~/.local/bin`, nvm, extensões, Flatpaks | `claude.exe`; `PATH` separado por `;` (hoje `:` está escrito em `claudeEnvironment` e no `main.cpp`); `%APPDATA%\npm\claude.cmd`; as mesmas pastas de extensão (o padrão `anthropic.claude-code-*` já casa com `…-win32-x64`) | pequeno |
| `core/SkillsFolder` | `QFile::link` (link simbólico) | **`QFile::link` no Windows cria um atalho `.lnk`, não um link.** Usar junção de diretório (não pede privilégio; link simbólico pede modo desenvolvedor ou administrador). Conferir se o Claude Code segue junções em `~\.claude\skills` | pequeno, risco médio |
| `core/HookScript` | grava o script e dá `chmod 0755` | não há o que gravar: o `.exe` fica na pasta do programa | pequeno |
| `core/ClaudeSettingsMerger` | reconhece o que é seu por `.local/share/farol/farol-hook` no comando | um marcador que valha nos dois sistemas (`farol-hook`, mais a pasta); o caminho escrito com `/` | pequeno |
| `platform/ProcessRunner` | `QProcess` (git, claude) | igual, com `CREATE_NO_WINDOW` para não piscar um console a cada `git pull` | pequeno |
| `SoundEngine`, `NetworkClient`, `RefusingNetworkFactory`, `HooksDialog` | Qt puro | iguais; o instalador leva os plugins de multimídia e TLS | nenhum |
| `CMakeLists.txt` | exige KDE ou X11; liga `Qt6::DBus` sempre | `FAROL_WIN` quando `WIN32`; D-Bus só fora do Windows; `WIN32_EXECUTABLE`; ícone `.ico` num `.rc` | pequeno |
| `qml/` | — | uma frase: "KWallet ou GNOME Keyring" em `SettingsView.qml:388` vira texto vindo do C++ | mínimo |

## 4. O hook

É a peça que mais muda, por duas razões medidas: no Windows não há Python garantido (o `python3` que existe é um atalho que imprime um erro, e o Claude Code mostraria esse erro a cada evento), e o script fala por socket Unix e lê `/proc`.

**Decisão proposta: um `farol-hook.exe` nativo, só no Windows.** O Python continua no Linux, onde está publicado e testado.

- **Lógica:** o que hoje é `slim()`, `enrich()`, `packed()` e `decision_output()` ganha um gêmeo em C++ dentro de `farol_core` (`core/HookRelay`, puro, sem E/S), com os mesmos limites (300 linhas × 240 caracteres, 32 768 por célula, 900 000 bytes por linha).
- **Para os dois não se afastarem:** os casos de teste viram arquivos (`linux/hook/tests/cases/*.json`: payload de entrada, linha esperada). O `unittest` do Python e um `tst_hook_relay` leem os mesmos arquivos. Uma mudança em `slim()` que não for feita nos dois lados quebra um dos testes.
- **Transporte:** um named pipe é um arquivo: `CreateFileW`, `WriteFile`, `ReadFile`. Sem servidor, `CreateFileW` falha na hora (`ERROR_FILE_NOT_FOUND`) e o hook sai: a regra "nunca bloquear o Claude Code" fica mais barata que no socket. Pipe ocupado: `WaitNamedPipe` até 0,3 s.
- **Prazos:** uma thread vigia chama `ExitProcess(0)` ao fim do prazo (0,3 s em todo evento, o `--decision-timeout` no `PermissionRequest`). Nenhum caminho de erro escreve em stdout ou stderr.
- **Quem é o Claude:** `CreateToolhelp32Snapshot` dá o pai de cada processo; o hook sobe até o `claude.exe` mais próximo e manda `claude_pid` + `claude_start` (a hora de criação de `GetProcessTimes`: é ela que impede confundir com outro processo que herdou o pid), `farol_ancestors`, e o caminho do executável do editor.
- **Peso:** liga só a `Qt6::Core` (JSON) e a API do Windows; roda a cada evento de cada sessão, então a meta é sair em menos de 30 ms quando o Farol está fechado. Medir no F2.
- **Onde fica:** ao lado do `farol.exe`, na pasta do programa. O `settings.json` aponta para lá; atualizar o Farol troca o arquivo no lugar.

Alternativa descartada: manter o Python e pedir que a pessoa o instale. Quebra o "instalar e funcionar" e, sem ele, cada evento do Claude Code viraria um erro de hook na tela.

Efeito colateral bom: `tst_hook_server`, que hoje chama o script por `FAROL_HOOK_PATH`, passa a exercitar o hook real nos dois sistemas.

## 5. O que precisa de prova antes de escrever (F0)

Três perguntas que não se respondem lendo, e que mudam o desenho conforme a resposta. Cada uma é uma sonda de poucas dezenas de linhas, como foram as do L0 no Wayland.

### 5.1 Clique fora da ilha

A janela é 720×320 e transparente; só a ilha deve pegar o ponteiro. No Wayland isso é a região de entrada; no X11, `xcb-shape`. No Windows:

1. **Máscara (`setMask`)**: é o que o código já faz no X11 sem compositor. Funciona com certeza, mas corta também o desenho: o facho do Lumi e qualquer sombra fora do retângulo da ilha somem.
2. **Região só de entrada**: o Windows não tem o equivalente direto. `WM_NCHITTEST` devolvendo `HTTRANSPARENT` só repassa o clique para janelas do mesmo processo. `WS_EX_TRANSPARENT` vale para a janela inteira.
3. **Janela do tamanho da ilha**: a janela acompanha o retângulo da ilha em vez de ser fixa. Mexe em quem anima o quê.

Proposta: sondar a 1 e olhar. Se o corte do facho for aceitável na ilha pequena (na aberta o Lumi fica dentro do trilho), fica a 1 e não há código novo. Senão, a 3.

A mesma sonda responde: a janela `Qt::Tool` sem foco fica mesmo por cima de tudo, inclusive da barra de tarefas quando a ilha está na base? Aparece em Alt+Tab? Some com um app em tela cheia (deveria)?

### 5.2 Como o Claude Code roda o comando de um hook no Windows

Com um hook de dez linhas que só grava o que recebeu: qual shell executa o comando (Git Bash, `cmd`, PowerShell), como o caminho precisa ser escrito e citado no `settings.json`, a codificação do stdin, a cadeia de processos entre o hook e o `claude.exe`, e o que acontece com um hook que demora. Disso saem `quotedPath` e o marcador do `ClaudeSettingsMerger`.

### 5.3 Trazer a janela do editor para a frente

O Windows só deixa um processo roubar o primeiro plano se ele recebeu o último evento de entrada. Um clique na ilha deveria contar, mesmo com a janela sem foco; um atalho global (`WM_HOTKEY`, "Ir à que espera") também. Sondar os dois. Se falhar, o editor só pisca na barra de tarefas, e aí o desenho muda (a ilha aceitaria foco no clique de "Ir à sessão").

## 6. Fases

Cada fase termina em algo que se compila e se testa nesta máquina.

| Fase | O que entra | Pronto quando |
|---|---|---|
| **F0** Ferramental e sondas | MSVC, CMake, Ninja, Qt 6.11.2 (a versão do `Dockerfile` do Mint); as três sondas da seção 5 em `linux/spikes/windows/` | as três perguntas têm resposta escrita nesta spec |
| **F1** Núcleo portátil | `FAROL_WIN` no CMake, D-Bus opcional, `Paths`, `ClaudeLocator`, separador do `PATH`; o que o MSVC recusar | `farol_core` compila e todo teste de `core` passa no Windows; job `windows-latest` no `build.yml` |
| **F2** Hook | `core/HookRelay`, os casos em arquivo, `farol-hook.exe`, `HookServer` em named pipe | `tst_hook_relay` e `tst_hook_server` passam; o hook sem servidor sai em < 30 ms |
| **F3** A ilha na tela | ramo do Windows em `IslandWindow`, `Win32.cpp` (janela ativa, ativar), `Tray`, tema, sons; `ClaudeSettingsMerger` | `farol.exe` abre, **Install…** mostra o diff, uma sessão real aparece e uma permissão é aprovada pela ilha |
| **F4** O desktop | atalhos globais, notificações, `ProcessWatcher`, cofre de credenciais, voltar à sessão, Nova sessão, junções das Skills | cada item da tabela da seção 3 conferido à mão num roteiro escrito |
| **F5** Pacote | ícone `.ico`, `windeployqt`, instalador por usuário, job da pipeline, README, `farol-release` | o instalador da pipeline instala e roda numa máquina limpa |

F1 e F2 não dependem das sondas e podem andar junto com o F0. A primeira versão que alguém de fora pode usar é o fim do F4; o F3 já serve para o autor.

Fora desta versão: abas e janelas do Windows Terminal (o terminal não é pai do shell, então a janela não se acha pelos processos; v1 traz à frente a janela cujo título nomeia a pasta, ou nenhuma), WSL (um Claude Code dentro do WSL não enxerga o pipe), ARM64, abrir junto com o sistema pelo Farol (o instalador oferece o atalho na pasta Inicializar).

## 7. Regras da casa no Windows

| Regra | Como se cumpre |
|---|---|
| Nunca bloquear o Claude Code | o hook sai na hora sem servidor; thread vigia nos prazos (seção 4) |
| Segredos só no cofre do sistema | Gerenciador de Credenciais; `farol.conf` segue guardando só quais serviços têm chave |
| `settings.json` só com backup + diff + confirmação | o mesmo `HooksInstaller`; conferir que um arquivo com fim de linha CRLF volta com CRLF |
| Nenhuma aprovação sem clique ou Enter | mesmo código |
| 0 % de CPU com a ilha escondida | nada novo consulta em laço: handle de processo, `WM_HOTKEY` e `WM_WTSSESSION_CHANGE` são eventos; medir no F4 |
| Texto de fora é texto puro; a ilha não acessa a rede | mesmo QML e mesmo `RefusingNetworkFactory`; `tst_plain_text` e `tst_refusing_network` rodam no Windows |
| Sem dependência de terceiros | só Qt e a API do Windows no programa. O instalador é ferramenta de build, não dependência (seção 9) |

## 8. Ferramental

Instalado nesta máquina em 2026-10-07: Visual Studio 2022 Build Tools com a carga de C++ (MSVC 14.44, CMake e Ninja), Python 3.12 só para o `aqtinstall` (em `C:\Qt\aqt`), e o Qt **6.10.3** `win64_msvc2022_64` com `qtmultimedia` em `C:\Qt`.

O Qt não é o 6.11.2 com que o Farol é desenvolvido no Linux: o `aqtinstall` 3.3.0 (o mais novo) não lê o formato em que o Qt publica a 6.11 para Windows (um `Updates.xml` por compilador, em `qt6_6112/qt6_6112_msvc2022_64/`). O 6.10.3 serve para desenvolver; para o pacote do F5, igualar a versão à do Linux (instalador oficial do Qt, ou um `aqtinstall` que já conheça o formato), porque as regras de "texto de fora" do CLAUDE.md foram medidas no Qt 6.11.

Compilar, de um "Developer PowerShell for VS 2022" (ou depois de `vcvars64.bat`):

```powershell
cmake -S linux -B linux/build -G Ninja -DCMAKE_PREFIX_PATH=C:\Qt\6.10.3\msvc2022_64 -DFAROL_BUILD_SPIKES=OFF
cmake --build linux/build
ctest --test-dir linux/build --output-on-failure
```

Hoje a configuração acha o compilador e o Qt e para onde se espera: no `FATAL_ERROR` do `CMakeLists.txt` que exige KDE ou X11. Tirar essa parada é o primeiro passo do F1.

`linux/scripts/host.sh` não se usa aqui: ele existe por causa do Flatpak do VSCodium.

## 9. Em aberto (decisões do autor)

1. **Hook nativo só no Windows, Python no Linux** (proposto), ou o nativo nos dois de uma vez? O segundo acaba com a duplicação, mas troca uma peça publicada e testada no Linux sem ganho para quem já usa.
2. **Instalador:** começar por um `.zip` (`cpack -G ZIP`, descompactar e rodar) e depois um instalador por usuário em `%LOCALAPPDATA%\Programs\Farol`, sem pedir administrador. O Inno Setup faz isso e o `cpack` sabe chamá-lo; é uma ferramenta a mais na pipeline.
3. **Assinatura:** um `.exe` sem assinatura mostra o aviso do SmartScreen ("O Windows protegeu o computador") a quem baixa. Certificado custa dinheiro por ano. Sem ele, o README do `farol-release` precisa dizer o que a pessoa vai ver e publicar o SHA-256, como já faz com o RPM.
4. **Editores da v1:** o medido aqui é o VS Code. VSCodium e Cursor no Windows entram se houver onde testar.
5. **A pasta `linux/`** passa a guardar também o código do Windows. Renomear (`app/`) mexe em todo caminho do CLAUDE.md, das specs e da pipeline: proposta, deixar para depois do F5.

## 10. O que muda no CLAUDE.md

Quando o F3 entrar: a primeira linha ("native Linux app"), a regra dos caminhos (`$HOME` no Linux, `%LOCALAPPDATA%` no Windows), a do hook (dois hooks, uma lógica, casos compartilhados), a do cofre, e o comando de build do Windows ao lado do `host.sh`.

## 11. F1, primeira medição (2026-10-07)

Com `FAROL_WIN` no CMake (só `src/core` e `tests`; `src/platform` e `src/app` ficam de fora no Windows até o F3), MSVC 19.44 e Qt 6.10.3, em Debug: **tudo compila sem nenhum erro** e 19 dos 31 testes passam pelo `ctest` (20 rodando um a um: `tst_settings_view` passa, o `ctest` é que não conseguiu iniciá-lo). O que falha, por causa:

| Causa | Testes | O que fazer |
|---|---|---|
| Permissões Unix (0700, bit de execução) não existem no NTFS | `tst_paths` (2), `tst_hook_script` (3), `tst_hooks_installer` (1) | no Windows a pasta do perfil já é só do usuário e não há script a marcar como executável: as verificações valem só fora do Windows |
| `QFile::link` cria `.lnk`, não um link | `tst_skills_folder` (6+), `tst_skills` (12), `tst_repos` (1), `tst_hooks_installer` (1) | junções de diretório (seção 3); é a maior parte do F1 |
| Separador do `PATH` (`:`) e caminho que ganha a letra da unidade | `tst_plugins` (1), `tst_ask` (1) | `QDir::listSeparator()`; os testes usam caminhos de Linux escritos à mão |
| `claude` sem `.exe`; pasta de extensão `…-linux-x64` | `tst_plugins` (1) | seção 3, `ClaudeLocator` |
| `~` no rótulo da pasta: `$HOME` não é o que o Windows usa | `tst_app_state` (1) | `Paths::home()` |
| `/proc/nope` usado como "pasta onde não se escreve" | `tst_hook_script` (1) | outro caminho impossível no Windows |
| Lentidão do build Debug | `tst_answer_text` (10 s para um limite de 1,5 s), `tst_island_qml` (passa de 180 s) | medir em Release antes de mexer |

À parte: pelo `ctest` os testes não escrevem nada na saída (só com `-o arquivo,txt`), então `--output-on-failure` vem vazio. Descobrir por quê antes de pôr o job na pipeline.

Nenhuma dessas falhas é de lógica do núcleo: são suposições de Linux nos caminhos, nos links e nas permissões.

## 12. F1, estado em 2026-10-07 (branch `windows`)

Feito:

- `core/Links` (link simbólico no Linux, junção de diretório no Windows), usado por `SkillsFolder` e pelos testes; `Repos` e `scanSkills` pulam pasta com ponto pelo nome no Windows.
- `Paths` no Windows: `%LOCALAPPDATA%\Farol` para tudo que é do Farol, e `socketPath()` é o nome de um pipe (`farol-<usuário>`).
- `ClaudeLocator` no Windows: `claude.exe` e `claude.cmd` no PATH, `~\.local\bin`, `~\.claude\local`, `%APPDATA%\npm`, extensões do VS Code, VSCodium e Cursor; o PATH é montado com o separador do sistema.
- Testes: as verificações de modo Unix e de link para arquivo são puladas no Windows; `/proc/nope` virou "uma pasta debaixo de um arquivo", que é impossível nos dois sistemas (no Windows o teste antigo criava `C:\proc`).
- `linux/scripts/win.bat` e o job `windows` na pipeline (núcleo e testes, em Release).

**O Smart App Control barrou os testes no meio do caminho.** No Windows 11 desta máquina ele estava ligado e bloqueia executáveis recém-compilados sem assinatura ("An Application Control policy has blocked this file"; evento 3077 do CodeIntegrity). No começo alguns testes rodavam; depois de recompilados passaram a ser bloqueados um a um. Desligar é decisão do dono da máquina e não tem volta sem reinstalar o Windows. Enquanto estiver ligado, quem roda os testes do Windows é a pipeline. Isso pesa também no F5: um `farol.exe` sem assinatura será bloqueado em toda máquina com o Smart App Control ligado, não só avisado pelo SmartScreen. A assinatura (item 3 da seção 9) deixa de ser opcional para esse público.

O dono da máquina desligou o Smart App Control no mesmo dia, e a suíte passou a rodar aqui.

**Resultado (MSVC 19.44, Qt 6.10.3):** em Release, **31 de 31 testes passam** (173 s; `tst_island_qml` sozinho leva 162 s no renderizador por software). Em Debug passam 29: `tst_answer_text` estoura um limite de tempo (16,7 s para 1,5 s) e `tst_island_qml` falha em duas verificações que dependem de uma animação terminar. São do build lento, não de lógica: a referência no Windows é o Release, como na pipeline. No mesmo commit, Fedora e Mint passaram na pipeline.

O F1 está fechado. `HookScript`/`hookScriptPath` ficam para o F2 (no Windows não há script a gravar).
