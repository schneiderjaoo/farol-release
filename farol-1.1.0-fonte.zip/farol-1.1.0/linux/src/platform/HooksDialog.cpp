#include "HooksDialog.h"

#include <QDialog>
#include <QDialogButtonBox>
#include <QFontDatabase>
#include <QLabel>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QTextBlock>
#include <QTextEdit>
#include <QVBoxLayout>

namespace farol {

bool confirmHooksChange(QWidget *parent, const QString &title, const QString &summary, const QString &diff,
                        const QString &confirmLabel)
{
    QDialog dlg(parent);
    dlg.setWindowTitle(title);
    dlg.resize(840, 560);
    auto *layout = new QVBoxLayout(&dlg);

    auto *label = new QLabel(summary);
    label->setWordWrap(true);
    layout->addWidget(label);

    auto *view = new QPlainTextEdit;
    view->setReadOnly(true);
    view->setLineWrapMode(QPlainTextEdit::NoWrap);
    view->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
    view->setPlainText(diff);
    QList<QTextEdit::ExtraSelection> marks;
    for (QTextBlock b = view->document()->begin(); b.isValid(); b = b.next()) {
        const QString text = b.text();
        QColor bg;
        if (text.startsWith('+') && !text.startsWith(QLatin1String("+++")))
            bg = QColor(46, 160, 67, 60);
        else if (text.startsWith('-') && !text.startsWith(QLatin1String("---")))
            bg = QColor(248, 81, 73, 60);
        else
            continue;
        QTextEdit::ExtraSelection sel;
        sel.cursor = QTextCursor(b);
        sel.format.setBackground(bg);
        sel.format.setProperty(QTextFormat::FullWidthSelection, true);
        marks << sel;
    }
    view->setExtraSelections(marks);
    layout->addWidget(view, 1);

    auto *buttons = new QDialogButtonBox;
    QPushButton *confirm = buttons->addButton(confirmLabel, QDialogButtonBox::AcceptRole);
    QPushButton *cancel = buttons->addButton(QStringLiteral("Cancel"), QDialogButtonBox::RejectRole);
    confirm->setAutoDefault(false);
    confirm->setDefault(false);
    cancel->setAutoDefault(true);
    cancel->setDefault(true);
    QObject::connect(buttons, &QDialogButtonBox::accepted, &dlg, &QDialog::accept);
    QObject::connect(buttons, &QDialogButtonBox::rejected, &dlg, &QDialog::reject);
    layout->addWidget(buttons);

    return dlg.exec() == QDialog::Accepted;
}

} // namespace farol
