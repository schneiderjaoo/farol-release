import QtQuick

// The "Perguntar" tab: files dropped on the island (or picked with "Escolher…") and questions about them, answered
// by the AI service whose key the user saved in Settings -> IA (core/Ask). Nothing is sent before "Perguntar" or
// Enter, and the tab says where it goes. An answer is Markdown from outside: `answers` (core/Answers) makes the HTML
// that is shown, with no image and no raw HTML in it, and opens a link only when it is a web link.
Item {
    id: view
    readonly property bool vertical: appState.vertical
    readonly property real pad: vertical ? 12 : 16
    readonly property var files: ask.files
    readonly property var turns: ask.turns
    property string link: ""   // the address of the answer's link under the pointer

    function send() {
        const question = field.text
        if (ask.busy || question.trim() === "")
            return
        field.text = ""
        ask.ask(question)
    }

    // the view is loaded each time the tab opens, by a click: the field is ready to type in
    Component.onCompleted: {
        controller.requestKeyboard(true)   // the island only gets keys when asked
        field.forceActiveFocus()
    }
    Connections {
        target: ask
        function onFailed(question) { if (field.text === "") field.text = question }   // not lost: asked again with Enter
        function onTurnsChanged() { toEnd.restart() }
        function onBusyChanged() { toEnd.restart() }
    }
    Timer {   // once the new text is laid out
        id: toEnd
        interval: 0
        onTriggered: talk.contentY = Math.max(0, talk.contentHeight - talk.height)
    }

    // ---- the files ----
    Card {
        id: filesCard
        width: view.vertical ? parent.width : 190
        height: view.vertical ? 170 : parent.height
        border.color: dropZone.containsDrag ? theme.primary : theme.line

        Item {
            anchors.fill: parent
            anchors.leftMargin: view.pad
            anchors.rightMargin: view.pad
            anchors.topMargin: 12
            anchors.bottomMargin: 12

            Text {
                id: filesTitle
                textFormat: Text.PlainText
                text: "Arquivos"
                color: theme.text
                font.family: theme.titleFont
                font.pixelSize: 14
                font.weight: Font.DemiBold
            }
            Text {
                objectName: "askCount"
                anchors.right: parent.right
                anchors.verticalCenter: filesTitle.verticalCenter
                visible: view.files.length > 0
                textFormat: Text.PlainText
                text: view.files.length
                color: theme.dim
                font.family: theme.bodyFont
                font.pixelSize: 12
            }

            Text {
                objectName: "askDropHint"
                y: 28
                width: parent.width
                visible: view.files.length === 0
                wrapMode: Text.Wrap
                textFormat: Text.PlainText
                text: "Solte arquivos aqui: texto, código, imagem ou PDF."
                color: theme.muted
                font.family: theme.bodyFont
                font.pixelSize: 12
            }
            Flickable {
                y: 28
                width: parent.width
                height: Math.max(0, buttons.y - y - 6 - (notice.visible ? notice.height + 4 : 0))
                visible: view.files.length > 0
                contentHeight: fileList.height
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: fileList
                    objectName: "askFiles"
                    width: parent.width
                    spacing: 4
                    Repeater {
                        model: view.files
                        Item {
                            required property var modelData
                            required property int index
                            width: fileList.width
                            height: 30
                            Text {
                                objectName: "askFile_" + index
                                width: parent.width - 22
                                elide: Text.ElideMiddle
                                textFormat: Text.PlainText
                                text: modelData.name
                                color: theme.text
                                font.family: theme.bodyFont
                                font.pixelSize: 12
                            }
                            Text {
                                y: 15
                                width: parent.width - 22
                                elide: Text.ElideRight
                                textFormat: Text.PlainText
                                text: modelData.kind + " · " + modelData.size
                                color: theme.dim
                                font.family: theme.bodyFont
                                font.pixelSize: 10
                            }
                            Text {
                                objectName: "askRemove_" + index
                                signal clicked()
                                anchors.right: parent.right
                                width: 18
                                height: 18
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                                textFormat: Text.PlainText
                                text: "×"
                                color: removeHover.hovered ? theme.text : theme.muted
                                font.family: theme.bodyFont
                                font.pixelSize: 15
                                onClicked: ask.removeFile(index)
                                HoverHandler { id: removeHover }
                                TapHandler { onTapped: parent.clicked() }
                            }
                        }
                    }
                }
            }
            Text {
                id: notice
                objectName: "askNotice"
                anchors.bottom: buttons.top
                anchors.bottomMargin: 6
                width: parent.width
                visible: text !== ""
                wrapMode: Text.Wrap
                maximumLineCount: 3
                elide: Text.ElideRight
                textFormat: Text.PlainText
                text: ask.notice
                color: theme.lamp
                font.family: theme.bodyFont
                font.pixelSize: 11
            }
            Flow {
                id: buttons
                anchors.bottom: parent.bottom
                width: parent.width
                spacing: 6
                PillButton {
                    objectName: "askChoose"
                    text: "Escolher…"
                    onClicked: ask.chooseFiles()
                }
                PillButton {
                    objectName: "askClear"
                    visible: view.files.length > 0 || view.turns.length > 0
                    text: "Limpar"
                    onClicked: ask.clear()
                }
            }
        }
    }

    // ---- the conversation ----
    Card {
        x: view.vertical ? 0 : filesCard.width + 8
        y: view.vertical ? filesCard.height + 8 : 0
        width: parent.width - x
        height: parent.height - y

        Item {
            anchors.fill: parent
            anchors.leftMargin: view.pad
            anchors.rightMargin: view.pad
            anchors.topMargin: 12
            anchors.bottomMargin: 10

            Column {
                visible: !ask.ready
                width: parent.width
                spacing: 8
                Text {
                    objectName: "askNoKey"
                    width: parent.width
                    wrapMode: Text.Wrap
                    textFormat: Text.PlainText
                    text: "Para perguntar, guarde uma chave de " + ask.providerLabel + " em Ajustes → IA. Ela fica no cofre de senhas do sistema."
                    color: theme.muted
                    font.family: theme.bodyFont
                    font.pixelSize: 13
                }
                PillButton {
                    objectName: "askSettings"
                    text: "Abrir Ajustes"
                    primary: true
                    onClicked: controller.showView("settings")
                }
            }

            Flickable {
                id: talk
                objectName: "askTalk"
                visible: ask.ready
                width: parent.width
                // the line under it is there whenever the conversation is, as the service's or as a link's
                height: Math.max(0, inputRow.y - 6 - (ask.ready ? where.height + 4 : 0))
                contentHeight: talkColumn.height
                clip: true
                boundsBehavior: Flickable.StopAtBounds
                Column {
                    id: talkColumn
                    width: talk.width
                    spacing: 8
                    Text {
                        objectName: "askHint"
                        width: parent.width
                        visible: view.turns.length === 0 && !ask.busy && ask.error === ""
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: "Solte um arquivo na ilha e pergunte o que quiser sobre ele. Sem arquivo, é uma pergunta direta."
                        color: theme.muted
                        font.family: theme.bodyFont
                        font.pixelSize: 13
                    }
                    Repeater {
                        model: view.turns
                        Column {
                            required property var modelData
                            required property int index
                            width: talkColumn.width
                            spacing: 2
                            Row {
                                spacing: 10
                                Text {
                                    textFormat: Text.PlainText
                                    text: modelData.user ? "Você" : ask.providerLabel
                                    color: modelData.user ? theme.dim : theme.lamp
                                    font.family: theme.bodyFont
                                    font.pixelSize: 10
                                    font.weight: Font.Medium
                                }
                                Text {   // the answer as it came (its Markdown) goes to the clipboard
                                    objectName: "askCopy_" + index
                                    signal clicked()
                                    visible: !modelData.user
                                    textFormat: Text.PlainText
                                    text: copied.running ? "Copiado" : "Copiar"
                                    color: copied.running ? theme.ok : copyHover.hovered ? theme.text : theme.dim
                                    font.family: theme.bodyFont
                                    font.pixelSize: 10
                                    font.weight: Font.Medium
                                    onClicked: {
                                        ask.copy(index)
                                        copied.restart()
                                    }
                                    Timer { id: copied; interval: 1500 }
                                    HoverHandler { id: copyHover; cursorShape: Qt.PointingHandCursor }
                                    TapHandler { onTapped: parent.clicked() }
                                }
                            }
                            // Read-only, so the turn can be selected and copied; the pointer is the TextEdit's own: a
                            // hand over a link, an I-beam over the rest.
                            TextEdit {
                                objectName: "askTurn_" + index
                                width: parent.width
                                readOnly: true
                                selectByMouse: true
                                wrapMode: TextEdit.Wrap
                                // the user's own words are plain text; an answer is the HTML core/AnswerText made of it
                                textFormat: modelData.user ? TextEdit.PlainText : TextEdit.RichText
                                text: modelData.user ? modelData.text : answers.html(modelData.text, theme.dark)
                                color: modelData.user ? theme.muted : theme.text
                                selectionColor: theme.primary
                                selectedTextColor: theme.primaryText
                                font.family: theme.bodyFont
                                font.pixelSize: 13
                                onLinkActivated: (link) => {
                                    deselect()           // Qt leaves the clicked link selected
                                    answers.open(link)   // a web link, after this click; nothing else is opened
                                }
                                onHoveredLinkChanged: view.link = hoveredLink
                                Component.onDestruction: if (hoveredLink !== "") view.link = ""
                            }
                        }
                    }
                    Text {
                        objectName: "askBusy"
                        visible: ask.busy
                        textFormat: Text.PlainText
                        text: ask.providerLabel + " está lendo…"
                        color: theme.lamp
                        font.family: theme.bodyFont
                        font.pixelSize: 12
                    }
                    Text {
                        objectName: "askError"
                        width: parent.width
                        visible: text !== ""
                        wrapMode: Text.Wrap
                        textFormat: Text.PlainText
                        text: ask.error
                        color: theme.alertText
                        font.family: theme.bodyFont
                        font.pixelSize: 12
                    }
                }
            }

            Text {
                id: where
                objectName: "askWhere"
                visible: ask.ready && view.link === ""
                anchors.bottom: inputRow.top
                anchors.bottomMargin: 6
                width: parent.width
                elide: Text.ElideRight
                textFormat: Text.PlainText
                text: "Arquivos e pergunta vão para " + ask.providerLabel + " (" + ask.modelLabel + ")."
                color: theme.dim
                font.family: theme.bodyFont
                font.pixelSize: 10
            }
            // Over a link of an answer, in the same place: where it really goes, whatever its text says. The name that
            // counts in a host is at its end ("banco.com.br.evil.example" goes to evil.example), so a host too long for
            // the line loses its beginning, never its end, and the rest of the address has only what the host leaves.
            Row {
                objectName: "askLink"
                visible: ask.ready && view.link !== ""
                anchors.bottom: inputRow.top
                anchors.bottomMargin: 6
                width: parent.width
                Text {
                    id: linkHost
                    objectName: "askLinkHost"
                    width: Math.min(implicitWidth, parent.width)
                    elide: Text.ElideLeft
                    textFormat: Text.PlainText
                    text: answers.host(view.link)
                    color: theme.muted
                    font.family: theme.bodyFont
                    font.pixelSize: 10
                }
                Text {
                    objectName: "askLinkRest"
                    width: parent.width - linkHost.width
                    elide: Text.ElideRight
                    textFormat: Text.PlainText
                    text: answers.rest(view.link)
                    color: theme.dim
                    font.family: theme.bodyFont
                    font.pixelSize: 10
                }
            }

            Item {
                id: inputRow
                visible: ask.ready
                anchors.bottom: parent.bottom
                width: parent.width
                height: 30
                Rectangle {
                    width: parent.width - sendButton.width - 8
                    height: 30
                    radius: 12
                    color: theme.codeBg
                    border.width: 1
                    border.color: field.activeFocus ? theme.primary : theme.line
                    TextInput {
                        id: field
                        objectName: "askField"
                        anchors.fill: parent
                        anchors.leftMargin: 12
                        anchors.rightMargin: 12
                        verticalAlignment: TextInput.AlignVCenter
                        clip: true
                        color: theme.text
                        selectionColor: theme.primary
                        selectedTextColor: theme.primaryText
                        font.family: theme.bodyFont
                        font.pixelSize: 13
                        maximumLength: 4000
                        Keys.onReturnPressed: view.send()
                        Keys.onEnterPressed: view.send()
                        Keys.onEscapePressed: text !== "" ? text = "" : controller.collapse()
                        Text {
                            anchors.fill: parent
                            verticalAlignment: Text.AlignVCenter
                            visible: field.text === "" && !field.activeFocus
                            textFormat: Text.PlainText
                            text: "Pergunte…"
                            color: theme.dim
                            font: field.font
                            elide: Text.ElideRight
                        }
                    }
                }
                PillButton {
                    id: sendButton
                    objectName: "askSend"
                    anchors.right: parent.right
                    y: 1
                    text: ask.busy ? "Cancelar" : "Perguntar"
                    primary: !ask.busy
                    onClicked: ask.busy ? ask.cancel() : view.send()
                }
            }
        }
    }

    // A file dropped anywhere on the tab joins the list; it is only read here, and sent with the next question.
    DropArea {
        id: dropZone
        objectName: "askDrop"
        anchors.fill: parent
        function take(urls) { ask.addUrls(urls) }
        onDropped: (drop) => {
            if (drop.hasUrls) {
                take(drop.urls)
                drop.accept()
            }
        }
    }
}
