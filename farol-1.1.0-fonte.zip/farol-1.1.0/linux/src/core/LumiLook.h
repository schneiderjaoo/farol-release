#pragma once
#include "IslandTypes.h"

#include <QObject>
#include <QString>
#include <QVariantMap>

namespace farol {

// How Lumi (the mascot) and the session signal look for each BotState.
// `lamp` names a Theme colour (lamp, ok, alert, working, idle); `signal` is one of working, waiting, done, error, idle.
struct LumiLook {
    QString eyes;     // open | sleep | wide | happy
    QString lamp;
    QString beam;     // steady | breathe | sway | sweep | tremble | off
    bool z = false;   // snoring
    QString signal;
};

LumiLook lumiLookFor(BotState state);

// QML side: look("finished") -> {eyes, lamp, beam, z, signal}; unknown names look idle.
class LumiLooks : public QObject {
    Q_OBJECT
public:
    using QObject::QObject;
    Q_INVOKABLE QVariantMap look(const QString &stateName) const;
};

} // namespace farol
