#include "RefusingNetworkFactory.h"

#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QUrl>

namespace farol {

namespace {
class RefusingManager : public QNetworkAccessManager {
public:
    using QNetworkAccessManager::QNetworkAccessManager;

protected:
    QNetworkReply *createRequest(Operation op, const QNetworkRequest &request, QIODevice *data) override
    {
        QNetworkRequest nowhere(request);
        nowhere.setUrl(QUrl());   // no scheme: Qt answers "protocol unknown" at once and opens no socket
        return QNetworkAccessManager::createRequest(op, nowhere, data);
    }
};
} // namespace

QNetworkAccessManager *RefusingNetworkFactory::create(QObject *parent)
{
    return new RefusingManager(parent);
}

} // namespace farol
