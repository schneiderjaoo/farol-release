#include "Answers.h"

#include "AnswerText.h"
#include "Theme.h"

namespace farol {

Answers::Answers(Theme *theme, QObject *parent) : QObject(parent), m_theme(theme), m_kept(kKeptChars) {}

QString Answers::html(const QString &markdown, bool dark)
{
    // The colours are the theme's of this moment; what is kept is kept under the theme the caller named, and only
    // when the two agree.
    const bool current = dark == m_theme->dark();
    const QString key = QLatin1Char(dark ? 'd' : 'l') + markdown;
    if (const QString *kept = current ? m_kept.object(key) : nullptr)
        return *kept;
    ++m_conversions;
    const QString html = answerHtml(markdown, {m_theme->link(), m_theme->codeBg(), m_theme->line(), m_theme->bodyFont(), m_theme->monoFont()});
    if (current)
        m_kept.insert(key, new QString(html), key.size() + html.size());
    return html;
}

bool Answers::isWebLink(const QString &link) const
{
    return farol::isWebLink(link);
}

QString Answers::host(const QString &link) const
{
    return linkHost(link);
}

QString Answers::rest(const QString &link) const
{
    return linkRest(link);
}

void Answers::open(const QString &link)
{
    if (farol::isWebLink(link))
        emit openRequested(QUrl(link, QUrl::StrictMode));
}

} // namespace farol
