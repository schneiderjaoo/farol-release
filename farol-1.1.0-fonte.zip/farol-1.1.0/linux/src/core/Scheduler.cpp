#include "Scheduler.h"

#include <QTimer>

namespace farol {

QtScheduler::~QtScheduler()
{
    qDeleteAll(m_timers);
}

int QtScheduler::singleShot(int ms, std::function<void()> fn)
{
    const int id = ++m_next;
    auto *timer = new QTimer;
    timer->setSingleShot(true);
    m_timers.insert(id, timer);
    QObject::connect(timer, &QTimer::timeout, timer, [this, id, timer, fn = std::move(fn)]() {
        m_timers.remove(id);
        timer->deleteLater();
        fn();
    });
    timer->start(ms);
    return id;
}

void QtScheduler::cancel(int id)
{
    if (QTimer *t = m_timers.take(id)) {
        t->stop();
        t->deleteLater();
    }
}

} // namespace farol
