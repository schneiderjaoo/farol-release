#include <QtTest>
#include "AiRequest.h"
#include "ClaudeLocator.h"
#include "ProcessRunner.h"
#include <QDir>

using namespace farol;

class TestProcessRunner : public QObject {
    Q_OBJECT
    static bool wait(const int &answers, int want = 1) { return QTest::qWaitFor([&] { return answers >= want; }, 5000); }

private slots:
    void aCommandAnswersOnceWithItsOutputAndExitCode()
    {
        ProcessRunner runner;
        ICommandRunner::Result got;
        int answers = 0;
        runner.run("sh", {"-c", "echo out; echo err >&2; echo \"$FAROL_TEST_VALUE\"; exit 3"}, {"FAROL_TEST_VALUE=a=b"}, 5000,
                   [&](const ICommandRunner::Result &r) { got = r; ++answers; });
        QCOMPARE(answers, 0);                                  // never blocks
        QVERIFY(wait(answers));
        QTest::qWait(50);
        QCOMPARE(answers, 1);
        QVERIFY(got.started && !got.timedOut);
        QCOMPARE(got.exitCode, 3);
        QCOMPARE(got.out, QStringLiteral("out\na=b\n"));       // the added variable reached it, '=' in the value kept
        QCOMPARE(got.err, QStringLiteral("err\n"));
    }

    void aMissingProgramIsReportedAsNotStarted()
    {
        ProcessRunner runner;
        ICommandRunner::Result got;
        got.started = true;
        int answers = 0;
        runner.run("farol-no-such-program", {}, {}, 5000, [&](const ICommandRunner::Result &r) { got = r; ++answers; });
        QVERIFY(wait(answers));
        QTest::qWait(50);
        QCOMPARE(answers, 1);
        QVERIFY(!got.started);
    }

    void aCommandOverItsTimeIsKilled()
    {
        ProcessRunner runner;
        ICommandRunner::Result got;
        int answers = 0;
        QElapsedTimer clock;
        clock.start();
        runner.run("sleep", {"30"}, {}, 150, [&](const ICommandRunner::Result &r) { got = r; ++answers; });
        QVERIFY(wait(answers));
        QVERIFY(clock.elapsed() < 4000);
        QVERIFY(got.started && got.timedOut);
        QTest::qWait(50);
        QCOMPARE(answers, 1);
    }

    void aCommandWaitingForInputGetsNone()
    {
        ProcessRunner runner;
        ICommandRunner::Result got;
        int answers = 0;
        runner.run("sh", {"-c", "read line; echo \"[$line]\""}, {}, 5000, [&](const ICommandRunner::Result &r) { got = r; ++answers; });
        QVERIFY(wait(answers));
        QVERIFY(!got.timedOut);                                // end of input at once, it did not hang
        QCOMPARE(got.out, QStringLiteral("[]\n"));
    }
    void aCommandReadsWhatItIsGiven()
    {
        ProcessRunner runner;
        ICommandRunner::Result got;
        int answers = 0;
        const QByteArray input = QByteArray(300000, 'a') + "\nfim\n";   // more than a pipe holds at once
        runner.run("sh", {"-c", "wc -c; echo ok >&2"}, {}, 5000, [&](const ICommandRunner::Result &r) { got = r; ++answers; }, input);
        QVERIFY(wait(answers));
        QCOMPARE(got.exitCode, 0);
        QCOMPARE(got.out.trimmed(), QString::number(input.size()));
    }
    void cancelEndsWhatIsRunning()
    {
        ProcessRunner runner;
        ICommandRunner::Result got;
        int answers = 0;
        runner.run("sleep", {"30"}, {}, 20000, [&](const ICommandRunner::Result &r) { got = r; ++answers; });
        QTest::qWait(100);
        runner.cancel();
        QVERIFY(wait(answers));
        QCOMPARE(answers, 1);
        QCOMPARE(got.exitCode, -1);
        QVERIFY(!got.timedOut);
    }
    // The real Claude Code, only when asked for (FAROL_TEST_CLAUDE=1): it needs it installed and logged in, and it
    // spends a little of the account's usage. Run it after Claude Code changes its options.
    void claudeCodeForReal()
    {
        if (qEnvironmentVariable("FAROL_TEST_CLAUDE") != "1")
            QSKIP("set FAROL_TEST_CLAUDE=1 to ask the Claude Code installed here");
        const QString path = qEnvironmentVariable("PATH");
        const QString claude = findClaude(QDir::homePath(), path.split(':', Qt::SkipEmptyParts));
        QVERIFY2(!claude.isEmpty(), "Claude Code is not installed");
        ProcessRunner runner;
        ICommandRunner::Result got;
        int answers = 0;
        const QList<AskFile> files{{"senha.txt", AskFile::Text, {}, "A senha é 4711."}};
        runner.run(claude, claudeArguments("sonnet"), claudeEnvironment(claude, path), 120000,
                   [&](const ICommandRunner::Result &r) { got = r; ++answers; }, claudeInput(files, {{true, "Qual é a senha? Responda só o número."}}));
        QTRY_COMPARE_WITH_TIMEOUT(answers, 1, 125000);
        const AiAnswer answer = parseClaudeOutput(got.exitCode, got.out, got.err);
        QVERIFY2(answer.ok, qPrintable(answer.text + " | " + got.err));
        QVERIFY2(answer.text.contains("4711"), qPrintable(answer.text));
    }
};

QTEST_GUILESS_MAIN(TestProcessRunner)
#include "tst_process_runner.moc"
