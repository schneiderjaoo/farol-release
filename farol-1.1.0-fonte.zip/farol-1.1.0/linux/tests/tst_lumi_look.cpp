#include <QtTest>
#include "LumiLook.h"

using namespace farol;

class TestLumiLook : public QObject {
    Q_OBJECT
    static LumiLook of(BotState s) { return lumiLookFor(s); }

private slots:
    void everyStateHasALookAndASignal()
    {
        for (int i = 0; i <= int(BotState::Dizzy); ++i) {
            const LumiLook l = of(BotState(i));
            QVERIFY2(!l.eyes.isEmpty() && !l.lamp.isEmpty() && !l.beam.isEmpty() && !l.signal.isEmpty(), qPrintable(QString::number(i)));
        }
    }

    void workingStatesAreAwakeWithAMovingBeamAndTheWorkingSignal()
    {
        QCOMPARE(of(BotState::Thinking).beam, QStringLiteral("breathe"));
        QCOMPARE(of(BotState::Working).beam, QStringLiteral("sway"));
        QCOMPARE(of(BotState::Searching).beam, QStringLiteral("sweep"));
        for (BotState s : {BotState::Thinking, BotState::Working, BotState::Searching}) {
            QCOMPARE(of(s).eyes, QStringLiteral("open"));
            QCOMPARE(of(s).signal, QStringLiteral("working"));
        }
    }

    void waitingForTheUserIsAmberNotRed()
    {
        for (BotState s : {BotState::Approval, BotState::Question}) {
            QCOMPARE(of(s).eyes, QStringLiteral("wide"));
            QCOMPARE(of(s).lamp, QStringLiteral("lamp"));
            QCOMPARE(of(s).signal, QStringLiteral("waiting"));
        }
    }

    void errorIsTheOnlyRedOne()
    {
        QCOMPARE(of(BotState::Error).lamp, QStringLiteral("alert"));
        QCOMPARE(of(BotState::Error).signal, QStringLiteral("error"));
        for (int i = 0; i <= int(BotState::Dizzy); ++i)
            if (BotState(i) != BotState::Error)
                QVERIFY(of(BotState(i)).lamp != QStringLiteral("alert"));
    }

    void finishedIsHappyAndGreen()
    {
        QCOMPARE(of(BotState::Finished).eyes, QStringLiteral("happy"));
        QCOMPARE(of(BotState::Finished).lamp, QStringLiteral("ok"));
        QCOMPARE(of(BotState::Finished).signal, QStringLiteral("done"));
    }

    void restingStatesHaveNoBeamAndTheIdleSignal()
    {
        for (BotState s : {BotState::Ratelimit, BotState::Sleeping}) {
            QCOMPARE(of(s).beam, QStringLiteral("off"));
            QCOMPARE(of(s).lamp, QStringLiteral("idle"));
            QCOMPARE(of(s).signal, QStringLiteral("idle"));
        }
        QVERIFY(of(BotState::Sleeping).z);
        QCOMPARE(of(BotState::Sleeping).eyes, QStringLiteral("sleep"));
        QVERIFY(!of(BotState::Ratelimit).z);
        QCOMPARE(of(BotState::Dizzy).beam, QStringLiteral("tremble"));
        QCOMPARE(of(BotState::Dizzy).signal, QStringLiteral("idle"));
        QCOMPARE(of(BotState::Idle).signal, QStringLiteral("idle"));
    }

    void lookByNameFallsBackToIdle()
    {
        LumiLooks looks;
        QCOMPARE(looks.look("finished").value("eyes").toString(), QStringLiteral("happy"));
        QCOMPARE(looks.look("nonsense").value("signal").toString(), QStringLiteral("idle"));
        QCOMPARE(looks.look("sleeping").value("z").toBool(), true);
    }
};

QTEST_APPLESS_MAIN(TestLumiLook)
#include "tst_lumi_look.moc"
