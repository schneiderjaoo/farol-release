#include <QtTest>
#include <QProcess>
#include <QSignalSpy>
#include <QStandardPaths>
#include <QWindow>
#include "GlobalShortcuts.h"
#include "X11.h"

using namespace farol;

// The X11 side of the desktop (Cinnamon on Linux Mint), against a real X server and window manager. It opens
// windows, moves the keyboard between them and presses keys, so it only runs when asked to with FAROL_TEST_X11=1
// (linux/packaging/mint22/session.sh does, on a screen nobody sees) and is skipped otherwise.
class TestX11 : public QObject {
    Q_OBJECT

    static bool managed(const QWindow &window)
    {
        for (const DesktopWindow &w : x11::windows())
            if (w.id == quint64(window.winId()))
                return true;
        return false;
    }

private slots:
    void initTestCase()
    {
        if (!x11::available())
            QSKIP("not asked to (FAROL_TEST_X11=1 in an X11 session)");
        QWindow probe;
        probe.resize(200, 100);
        probe.show();
        if (!QTest::qWaitFor([&] { return managed(probe); }, 3000))
            QSKIP("no window manager that lists its windows");
    }

    void theWindowsAreReadWithTheirClassTitleAndProcess()
    {
        QWindow window;
        window.setTitle(QStringLiteral("main.cpp - pasta-do-x11 - Editor"));
        window.resize(300, 200);
        window.show();
        QTRY_VERIFY_WITH_TIMEOUT(managed(window), 3000);
        for (const DesktopWindow &w : x11::windows()) {
            if (w.id != quint64(window.winId()))
                continue;
            QCOMPARE(w.title, window.title());
            QCOMPARE(w.pid, QCoreApplication::applicationPid());
            QVERIFY(!w.windowClass.isEmpty());
            QCOMPARE(windowToRaise(x11::windows(), {QStringLiteral("pasta-do-x11")}, {w.windowClass.toLower()}),
                     int(x11::windows().indexOf(w)));   // found the way a session's editor window is
        }
    }

    void aWindowIsBroughtForwardThroughTheWindowManager()
    {
        QWindow first, second;
        for (QWindow *w : {&first, &second}) {
            w->resize(300, 200);
            w->show();
            QTRY_VERIFY_WITH_TIMEOUT(managed(*w), 3000);
        }
        x11::activate(first.winId());
        QTRY_COMPARE_WITH_TIMEOUT(x11::activeWindow(), quint64(first.winId()), 3000);
        x11::activate(second.winId());
        QTRY_COMPARE_WITH_TIMEOUT(x11::activeWindow(), quint64(second.winId()), 3000);
        first.showMinimized();
        QTest::qWait(300);
        x11::activate(first.winId());                    // a minimized one comes back too
        QTRY_COMPARE_WITH_TIMEOUT(x11::activeWindow(), quint64(first.winId()), 3000);
    }

    void theServerSaysHowLongNobodyTouchedAnything()
    {
        QVERIFY(x11::idleMs() >= 0);
    }

    // A key grabbed from the server reaches Farol whatever window has the keyboard. xdotool presses it.
    void aShortcutWorksWithAnotherWindowInFront()
    {
        if (desktopIsKde())
            QSKIP("KDE Plasma: the shortcuts go through KGlobalAccel");
        const QString xdotool = QStandardPaths::findExecutable(QStringLiteral("xdotool"));
        if (xdotool.isEmpty())
            QSKIP("no xdotool to press the keys");
        GlobalShortcuts shortcuts;
        QSignalSpy triggered(&shortcuts, &GlobalShortcuts::triggered);
        const int combo = int(Qt::ControlModifier | Qt::AltModifier) | int(Qt::Key_K);
        QCOMPARE(shortcuts.bind(QStringLiteral("toggle"), combo), QStringLiteral("Ctrl+Alt+K"));
        QCOMPARE(shortcuts.bind(QStringLiteral("jump"), int(Qt::MetaModifier | Qt::ShiftModifier) | int(Qt::Key_J)), QStringLiteral("Meta+Shift+J"));
        QVERIFY(shortcuts.bind(QStringLiteral("nothing"), combo).isEmpty());

        QWindow front;
        front.resize(300, 200);
        front.show();
        QTRY_VERIFY_WITH_TIMEOUT(managed(front), 3000);
        QCOMPARE(QProcess::execute(xdotool, {QStringLiteral("key"), QStringLiteral("ctrl+alt+k")}), 0);
        QTRY_COMPARE_WITH_TIMEOUT(triggered.count(), 1, 3000);
        QCOMPARE(triggered.at(0).at(0).toString(), QStringLiteral("toggle"));
        QCOMPARE(QProcess::execute(xdotool, {QStringLiteral("key"), QStringLiteral("super+shift+j")}), 0);
        QTRY_COMPARE_WITH_TIMEOUT(triggered.count(), 2, 3000);
        QCOMPARE(triggered.at(1).at(0).toString(), QStringLiteral("jump"));

        // given up: the key is nobody's again
        QCOMPARE(shortcuts.bind(QStringLiteral("toggle"), 0), QStringLiteral("-"));
        QCOMPARE(QProcess::execute(xdotool, {QStringLiteral("key"), QStringLiteral("ctrl+alt+k")}), 0);
        QTest::qWait(500);
        QCOMPARE(triggered.count(), 2);
    }
};

int main(int argc, char *argv[])
{
    qputenv("QT_QPA_PLATFORM", qEnvironmentVariableIsSet("FAROL_TEST_X11") ? "xcb" : "offscreen");
    QGuiApplication app(argc, argv);
    TestX11 test;
    return QTest::qExec(&test, argc, argv);
}
#include "tst_x11.moc"
