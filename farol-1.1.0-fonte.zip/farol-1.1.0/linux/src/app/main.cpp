#include "Answers.h"
#include "AppState.h"
#include "Ask.h"
#include "ApprovalQueue.h"
#include "ClaudeSessions.h"
#include "DesktopNotifier.h"
#include "EditDiffs.h"
#include "GlobalShortcuts.h"
#include "HookScript.h"
#include "HookServer.h"
#include "HooksDialog.h"
#include "HooksInstaller.h"
#include "HooksStatus.h"
#include "IslandController.h"
#include "IslandWindow.h"
#include "SecretServiceStore.h"
#include "LumiLook.h"
#include "NetworkClient.h"
#include "Paths.h"
#include "ClaudeLocator.h"
#include "Plugins.h"
#include "ProcessRunner.h"
#include "ProcessWatcher.h"
#include "QuestionDesk.h"
#include "RefusingNetworkFactory.h"
#include "Repos.h"
#include "Scheduler.h"
#include "Shortcuts.h"
#include "Skills.h"
#include "Theme.h"
#include "SessionJumper.h"
#include "SoundEngine.h"
#include "SystemTheme.h"
#include "Tray.h"

#include <QClipboard>
#include <QDateTime>
#include <QDesktopServices>
#include <QDir>
#include <QFile>
#include <QFileDialog>
#include <QFileInfo>
#include <QFontDatabase>
#include <QGuiApplication>
#include <QMessageBox>
#include <QPointer>
#include <QApplication>
#include <QQmlContext>
#include <QQmlEngine>
#include <QSettings>
#include <QTimer>
#include <QUrl>

using namespace farol;

#ifdef Q_OS_WIN
// Windows does not read a script's first line: farol-hook is run by a Python 3 of this machine. The "python" of
// the WindowsApps folder is the Store's stand-in, which only says how to install one.
static QString findPython()
{
    QStringList candidates;
    const QString programs = Paths::home() + QStringLiteral("/AppData/Local/Programs/Python");
    const QStringList own = QDir(programs).entryList({QStringLiteral("Python3*")}, QDir::Dirs, QDir::Name | QDir::Reversed);
    for (const QString &version : own)
        candidates << programs + QLatin1Char('/') + version + QStringLiteral("/python.exe");
    const QStringList path = qEnvironmentVariable("PATH").split(QDir::listSeparator(), Qt::SkipEmptyParts);
    for (const QString &dir : path)
        if (!dir.contains(QLatin1String("WindowsApps"), Qt::CaseInsensitive))
            candidates << QDir::fromNativeSeparators(dir) + QStringLiteral("/python.exe");
    for (const QString &candidate : std::as_const(candidates))
        if (QFileInfo(candidate).isFile())
            return candidate;
    return {};
}
#endif

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);   // the tray icon and its QMenu need Qt Widgets
    app.setApplicationName(QStringLiteral("farol"));
    app.setDesktopFileName(QStringLiteral("local.joao.Farol"));
    app.setApplicationVersion(QStringLiteral(FAROL_VERSION));
    app.setQuitOnLastWindowClosed(false);

    QDir().mkpath(QFileInfo(Paths::configFile()).absolutePath());
    QSettings settings(Paths::configFile(), QSettings::IniFormat);

    AppState state(&settings);
    QtScheduler scheduler;
    IslandController controller(&state, &scheduler, [] { return QDateTime::currentMSecsSinceEpoch(); });

    SoundEngine sound(qEnvironmentVariable("FAROL_SOUNDS_DIR", QStringLiteral(FAROL_SOUNDS_DIR)));
    if (QDir(qEnvironmentVariable("FAROL_SOUNDS_DIR", QStringLiteral(FAROL_SOUNDS_DIR))).entryList({"*.wav"}, QDir::Files).isEmpty())
        qWarning("No sounds found (see linux/sounds/README.md): Farol will be silent.");
    sound.setEnabled(state.soundEnabled());
    sound.setVolume(state.soundVolume());
    QObject::connect(&state, &AppState::soundEnabledChanged, &sound, [&] { sound.setEnabled(state.soundEnabled()); });
    QObject::connect(&state, &AppState::soundVolumeChanged, &sound, [&] { sound.setVolume(state.soundVolume()); });
    QObject::connect(&controller, &IslandController::playSound, &sound, &SoundEngine::play);

    // Claude Code: hook events -> sessions/alerts, permission requests -> approval queue, questions -> question desk.
    ApprovalQueue approvals(scheduler, &settings);
    QuestionDesk questions(scheduler);
    ProcessWatcher processes;   // a session whose Claude Code process exits is over, with or without a SessionEnd
    EditDiffs diffs(&state, &controller);   // the diffs of the sessions' edits, in memory, for the island's "diff" view
    ClaudeSessions sessions(&state, &controller, &scheduler, &approvals, &questions, &processes, &diffs);
    QObject::connect(&sessions, &ClaudeSessions::playSound, &sound, &SoundEngine::play);
    // A question, a permission request, a finished turn or an error also goes to the desktop's notifications while
    // the user is away. FAROL_DEBUG_NOTIFY treats the user as always away.
    DesktopNotifier notifier;
    notifier.setAlwaysAway(qEnvironmentVariableIsSet("FAROL_DEBUG_NOTIFY"));
    QObject::connect(&sessions, &ClaudeSessions::attention, &notifier, [&](const QString &session, const QString &text) {
        if (state.notifyAway())
            notifier.notifyIfAway(session, text);
    });
    SessionJumper jumper;
    QObject::connect(&sessions, &ClaudeSessions::jumpRequested, &jumper, &SessionJumper::jump);
    // "Nova sessão": a repository of the workspace folder clicked in the island opens in the editor with a new session.
    Repos repos(&state);
    // in the editor the last session was heard from (VSCodium until one was)
    QObject::connect(&repos, &Repos::openRequested, &jumper, [&](const QString &repo) { jumper.openSession(repo, sessions.lastEditor()); });
    HookServer hookServer(&sessions, &approvals);
    hookServer.setEventLog(qEnvironmentVariable("FAROL_DEBUG_EVENTS"));
    switch (hookServer.start(Paths::socketPath())) {
    case HookServer::StartResult::AlreadyRunning:
        qWarning("Farol is already running; exiting.");   // qInfo is hidden by default on Fedora
        return 0;
    case HookServer::StartResult::Failed:
        qWarning("Claude Code hooks are disabled: %s", qPrintable(hookServer.errorString()));
        break;
    case HookServer::StartResult::Started:
        break;
    }
    if (QFile script(QStringLiteral(":/hook/farol-hook")); script.open(QIODevice::ReadOnly)) {
        QString error;
        if (!installHookScript(script.readAll(), Paths::hookScriptPath(), &error))
            qWarning("Could not install farol-hook: %s", qPrintable(error));
    }

    // The identity fonts ship inside the executable; a missing one just falls back to the system font.
    for (const char *font : {":/fonts/BricolageGrotesque.ttf", ":/fonts/InstrumentSans.ttf"})
        if (QFontDatabase::addApplicationFont(QString::fromLatin1(font)) < 0)
            qWarning("Could not load font %s", font);

    // "Sistema" theme: follow the desktop's light/dark preference live.
    Theme theme(&state);
    SystemTheme systemTheme;
    theme.setSystemDark(systemTheme.dark());
    QObject::connect(&systemTheme, &SystemTheme::changed, &theme, [&] { theme.setSystemDark(systemTheme.dark()); });

    // The island shows text that comes from outside (a model's answer, a hook payload, a file name), and Qt Quick
    // fetches whatever an image in rich text points to. Nothing of the island is loaded from the network, so its
    // engine's network access manager refuses every request: a Text that slips through still calls nobody. (Qt
    // Multimedia, web sockets and web views have network code of their own; the island uses none of them.) Farol's
    // own requests (the "Perguntar" tab) go through NetworkClient, which has its own QNetworkAccessManager.
    RefusingNetworkFactory noNetwork;   // before the engine: it must outlive it
    QQmlEngine engine;
    engine.setNetworkAccessManagerFactory(&noNetwork);
    engine.rootContext()->setContextProperty(QStringLiteral("theme"), &theme);
    LumiLooks lumiLooks;
    engine.rootContext()->setContextProperty(QStringLiteral("lumiLooks"), &lumiLooks);
    engine.rootContext()->setContextProperty(QStringLiteral("appState"), &state);
    engine.rootContext()->setContextProperty(QStringLiteral("controller"), &controller);
    engine.rootContext()->setContextProperty(QStringLiteral("approvals"), &approvals);
    engine.rootContext()->setContextProperty(QStringLiteral("questions"), &questions);
    engine.rootContext()->setContextProperty(QStringLiteral("sessions"), &sessions);
    engine.rootContext()->setContextProperty(QStringLiteral("diffs"), &diffs);
    engine.rootContext()->setContextProperty(QStringLiteral("repos"), &repos);
    // Settings -> Atalhos: system-wide keys to open or close the island and to go to the session that waits.
    GlobalShortcuts globalShortcuts;
    Shortcuts shortcuts(&settings, [&globalShortcuts](const QString &action, int combo) { return globalShortcuts.bind(action, combo); });
    shortcuts.restore();
    QObject::connect(&globalShortcuts, &GlobalShortcuts::triggered, &app, [&](const QString &action) {
        if (action == QLatin1String("jump")) {
            if (sessions.jumpToWaiting())
                controller.collapse();
        } else if (state.mode() == IslandMode::Expanded) {
            controller.collapse();
        } else {
            controller.expand(controller.defaultView());
        }
    });
    engine.rootContext()->setContextProperty(QStringLiteral("shortcuts"), &shortcuts);
    // Skills tab: the company's skills folder, linked into ~/.claude/skills and kept up to date with git.
    ProcessRunner commands;
    Skills skills(&state, &commands, &settings, Paths::claudeSkillsDir(), [] { return QDateTime::currentMSecsSinceEpoch(); });
    QObject::connect(&skills, &Skills::openFolderRequested, &app, [](const QString &dir) { QDesktopServices::openUrl(QUrl::fromLocalFile(dir)); });
    engine.rootContext()->setContextProperty(QStringLiteral("skills"), &skills);
    // ...and Claude Code's plugins, managed through its own program wherever it is installed (the path that
    // worked last is kept, key `claudePath`).
    const QString searchPath = qEnvironmentVariable("PATH");
    const auto locateClaude = [&settings, searchPath] {
        const QString found = findClaude(Paths::home(), searchPath.split(QDir::listSeparator(), Qt::SkipEmptyParts), settings.value("claudePath").toString());
        if (!found.isEmpty() && found != settings.value("claudePath").toString())
            settings.setValue("claudePath", found);
        return found;
    };
    Plugins plugins(&commands, locateClaude, searchPath);
    engine.rootContext()->setContextProperty(QStringLiteral("plugins"), &plugins);
    // "Perguntar" tab: files and questions for the service chosen in Settings -> IA. Claude Code itself answers
    // with the account it is logged in with (a runner of its own: "Cancelar" ends only the question); the others
    // want a key, which lives in the desktop's secret service. The only network calls are the questions.
    SecretServiceStore wallet;
    NetworkClient network;
    ProcessRunner asking;
    Ask ask(&settings, &wallet, &network, &asking, locateClaude, searchPath);
    engine.rootContext()->setContextProperty(QStringLiteral("ask"), &ask);
    QObject::connect(&ask, &Ask::copyRequested, &app, [](const QString &text) { QGuiApplication::clipboard()->setText(text); });
    // An answer is shown as HTML made from its Markdown (no image, no raw HTML), and a web link in it opens in the
    // browser after a click on it.
    Answers answers(&theme);
    QObject::connect(&answers, &Answers::openRequested, &app, [](const QUrl &url) { QDesktopServices::openUrl(url); });
    engine.rootContext()->setContextProperty(QStringLiteral("answers"), &answers);
    // An answer that arrives after the island went back to the compact one opens it again on the tab.
    QObject::connect(&ask, &Ask::answered, &app, [&] {
        if (state.mode() != IslandMode::Expanded && !approvals.active() && !questions.active())
            controller.expandTo(QStringLiteral("ask"));
    });

    IslandWindow window(&state, &controller, &engine);
    if (!window.ok()) {
        qCritical("Could not load qrc:/qml/Island.qml");
        return 1;
    }
#ifdef Q_OS_WIN
    const QString python = findPython();
    const auto hooksInstaller = [python] {
        return HooksInstaller(Paths::claudeSettingsPath(), Paths::hookScriptPath(), 110, [] { return QDateTime::currentDateTime(); }, python);
    };
#else
    const auto hooksInstaller = [] { return HooksInstaller(Paths::claudeSettingsPath(), Paths::hookScriptPath(), 110); };
#endif
    const auto runHooks = [&](bool install) {
#ifdef Q_OS_WIN
        if (install && python.isEmpty()) {
            QMessageBox::warning(nullptr, QStringLiteral("Claude Code hooks"),
                                 QStringLiteral("Python 3 was not found on this computer, and the hook needs it.\n\nNothing was changed."));
            return;
        }
#endif
        const HooksInstaller inst = hooksInstaller();
        const HooksPlan plan = install ? inst.planInstall() : inst.planUninstall();
        const QString box = QStringLiteral("Claude Code hooks");
        if (!plan.ok) {
            QMessageBox::warning(nullptr, box, plan.error + QStringLiteral("\n\nNothing was changed."));
            return;
        }
        if (!plan.changes) {
            QMessageBox::information(nullptr, box,
                                     install ? QStringLiteral("The Farol hooks are already installed.")
                                             : QStringLiteral("There are no Farol hooks in settings.json."));
            return;
        }
        const QString backupNote = plan.settingsExisted
            ? QStringLiteral("A backup is saved next to it first: %1").arg(inst.backupPathFor())
            : QStringLiteral("The file does not exist yet, so there is nothing to back up.");
        const QString summary = QStringLiteral("File: %1\n%2\n\nNothing is written until you confirm. Review the changes:")
                                    .arg(Paths::claudeSettingsPath(), backupNote);
        if (!confirmHooksChange(nullptr, install ? QStringLiteral("Install Claude Code hooks") : QStringLiteral("Remove Claude Code hooks"),
                                summary, plan.diff, install ? QStringLiteral("Write changes") : QStringLiteral("Remove hooks")))
            return;
        QString error, backup;
        if (!inst.apply(plan, &error, &backup)) {
            QMessageBox::critical(nullptr, box, error);
            return;
        }
        QMessageBox::information(nullptr, box,
                                 QStringLiteral("Done.%1\n\nOpen a new Claude Code session (or review the change with /hooks) "
                                                "for it to take effect.")
                                     .arg(backup.isEmpty() ? QString() : QStringLiteral("\nBackup: ") + backup));
    };
    // Settings -> Sobre: the state of the Claude Code hooks, looked at when that page opens.
    HooksStatus hooksStatus([&] {
        const HooksInstaller inst = hooksInstaller();
        return !inst.installed() ? QStringLiteral("missing") : inst.upToDate() ? QStringLiteral("installed") : QStringLiteral("outdated");
    });
    engine.rootContext()->setContextProperty(QStringLiteral("hooks"), &hooksStatus);
    Tray tray(&state, &controller,
              TrayHooks{[&] { runHooks(true); }, [&] { runHooks(false); }, [&] { return hooksInstaller().installed(); },
                        [&] { return hooksInstaller().upToDate(); }});

    // Settings -> Workspace: the island asks, the desktop's folder dialog answers (it never blocks the event loop).
    QPointer<QFileDialog> workspaceDialog;
    QObject::connect(&state, &AppState::workspaceDirRequested, &app, [&state, &workspaceDialog] {
        if (workspaceDialog) {
            workspaceDialog->raise();
            return;
        }
        workspaceDialog = new QFileDialog(nullptr, QStringLiteral("Pasta da workspace"),
                                          state.workspaceDir().isEmpty() ? Paths::home() : state.workspaceDir());
        workspaceDialog->setFileMode(QFileDialog::Directory);
        workspaceDialog->setOption(QFileDialog::ShowDirsOnly);
        workspaceDialog->setAttribute(Qt::WA_DeleteOnClose);
        QObject::connect(workspaceDialog, &QFileDialog::fileSelected, &state, &AppState::setWorkspaceDir);
        workspaceDialog->open();
    });

    // Skills -> "Escolher…": the same folder dialog, for the company's skills folder.
    QPointer<QFileDialog> skillsDialog;
    QObject::connect(&state, &AppState::skillsDirRequested, &app, [&state, &skillsDialog] {
        if (skillsDialog) {
            skillsDialog->raise();
            return;
        }
        skillsDialog = new QFileDialog(nullptr, QStringLiteral("Pasta das skills da empresa"),
                                       state.skillsDir().isEmpty() ? (state.workspaceDir().isEmpty() ? Paths::home() : state.workspaceDir())
                                                                   : state.skillsDir());
        skillsDialog->setFileMode(QFileDialog::Directory);
        skillsDialog->setOption(QFileDialog::ShowDirsOnly);
        skillsDialog->setAttribute(Qt::WA_DeleteOnClose);
        QObject::connect(skillsDialog, &QFileDialog::fileSelected, &state, &AppState::setSkillsDir);
        skillsDialog->open();
    });

    // Perguntar -> "Escolher…": the desktop's file dialog, for one or more files.
    QPointer<QFileDialog> askDialog;
    QObject::connect(&ask, &Ask::filesRequested, &app, [&] {
        if (askDialog) {
            askDialog->raise();
            return;
        }
        askDialog = new QFileDialog(nullptr, QStringLiteral("Arquivos para perguntar"),
                                    state.workspaceDir().isEmpty() ? Paths::home() : state.workspaceDir());
        askDialog->setFileMode(QFileDialog::ExistingFiles);
        askDialog->setAttribute(Qt::WA_DeleteOnClose);
        QObject::connect(askDialog, &QFileDialog::filesSelected, &ask, [&](const QStringList &files) {
            for (const QString &file : files)
                ask.addFile(file);
            controller.expandTo(QStringLiteral("ask"));   // the island closed while the dialog was in front
        });
        askDialog->open();
    });

    window.show();
    controller.launch();
    QTimer::singleShot(0, &skills, &Skills::refresh);   // at start: check the links, update the folder   // greeting -> compact, like the Mac app on launch

    // Development hook: FAROL_DEBUG_VIEW=<view name> opens that view once the greeting has collapsed,
    // so screenshots and CPU measurements of a given state do not need a click.
    const QString debugView = qEnvironmentVariable("FAROL_DEBUG_VIEW");
    if (!debugView.isEmpty())
        QTimer::singleShot(7000, &controller, [&controller, debugView] { controller.expandTo(debugView); });
    // FAROL_DEBUG_EDGE=top|bottom|left|right changes the docked edge 7 s after start (the live path of the setting).
    if (const QString edge = qEnvironmentVariable("FAROL_DEBUG_EDGE"); !edge.isEmpty())
        QTimer::singleShot(7000, &state, [&state, edge] { state.setEdge(edge); });
    // FAROL_DEBUG_JUMP=<folder> jumps to that folder's VSCodium window 7 s after start (try it with another window focused).
    if (const QString folder = qEnvironmentVariable("FAROL_DEBUG_JUMP"); !folder.isEmpty())
        QTimer::singleShot(7000, &jumper, [&jumper, folder] { jumper.jump({"vscodium", folder, "com.vscodium.codium", {}, {}, {}, {}, {}}); });
    // FAROL_DEBUG_OPEN=<repository> starts a new Claude Code session in it 7 s after start (what a click in "Nova sessão" does).
    if (const QString repo = qEnvironmentVariable("FAROL_DEBUG_OPEN"); !repo.isEmpty())
        QTimer::singleShot(7000, &jumper, [&jumper, repo] { jumper.openSession(repo); });
    // FAROL_DEBUG_MODE=hidden|compact|expanded forces a mode after the greeting (CPU measurements).
    if (auto mode = enumFromKey<IslandMode>(qEnvironmentVariable("FAROL_DEBUG_MODE")))
        QTimer::singleShot(7000, &controller, [&controller, m = *mode] { controller.setMode(m); });
    return app.exec();
}
