#include <QtTest>
#include <QDir>
#include <QFile>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "AppState.h"
#include "FakeCommandRunner.h"
#include "Links.h"
#include "Skills.h"

using namespace farol;

class TestSkills : public QObject {
    Q_OBJECT
    std::unique_ptr<QTemporaryDir> dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<FakeCommandRunner> runner;
    std::unique_ptr<Skills> skills;
    qint64 now = 1000000;

    QString company() const { return dir->path() + "/workspace/skills"; }
    QString claude() const { return dir->path() + "/home/.claude/skills"; }
    void skill(const QString &base, const QString &folder) const
    {
        QVERIFY(QDir().mkpath(base + "/" + folder));
        QFile f(base + "/" + folder + "/SKILL.md");
        QVERIFY(f.open(QIODevice::WriteOnly));
        f.write("# skill\n");
    }
    void clone(const QString &base) const { QVERIFY(QDir().mkpath(base + "/.git")); }
    void make() { skills = std::make_unique<Skills>(state.get(), runner.get(), settings.get(), claude(), [this] { return now; }); }

private slots:
    void init()
    {
        dir = std::make_unique<QTemporaryDir>();
        settings = std::make_unique<QSettings>(dir->path() + "/f.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        runner = std::make_unique<FakeCommandRunner>();
        now = 1000000;
        skill(company(), "a");
        skill(company(), "b");
        clone(company());
        make();
    }
    void cleanup()
    {
        skills.reset();
        state.reset();
    }

    void withNoFolderNothingRunsAndItAsksForOne()
    {
        skills->refresh();
        skills->updateNow();
        QCOMPARE(runner->calls.size(), 0);
        QCOMPARE(skills->status(), QStringLiteral("none"));
        QVERIFY(skills->message().contains("Escolha a pasta"));
        QVERIFY(!skills->warning());
        QVERIFY(!QDir(claude()).exists());                                    // nothing was created either
    }

    void choosingTheFolderLinksItsSkillsAndUpdatesIt()
    {
        state->setSkillsDir(company());
        QCOMPARE(skills->linked(), 2);                                        // linked before git answers
        QVERIFY(links::isLink(claude() + "/a") && links::isLink(claude() + "/b"));
        QVERIFY(skills->busy());
        QCOMPARE(skills->message(), QStringLiteral("Atualizando…"));
        QCOMPARE(runner->calls.size(), 1);
        const auto &call = runner->calls.first();
        QCOMPARE(call.program, QStringLiteral("git"));
        QCOMPARE(call.arguments, (QStringList{"-C", company(), "pull", "--ff-only"}));
        QVERIFY(call.env.contains("GIT_TERMINAL_PROMPT=0"));                  // never waits for a password
        QVERIFY(call.env.join(' ').contains("BatchMode=yes"));
        QCOMPARE(call.timeoutMs, 30000);

        skill(company(), "c");                                                // the pull brought a new skill
        QFile::remove(company() + "/b/SKILL.md");                             // ...and took one away
        runner->answer(0, {}, "Updating 1a2b..3c4d\n");
        QVERIFY(!skills->busy());
        QCOMPARE(skills->status(), QStringLiteral("ok"));
        QCOMPARE(skills->message(), QStringLiteral("Em dia com o GitHub"));
        QCOMPARE(skills->detail(), QStringLiteral("atualizado agora"));
        QCOMPARE(skills->linked(), 2);
        QVERIFY(links::isLink(claude() + "/c"));
        QVERIFY(!links::isLink(claude() + "/b"));
        now += 5 * 60000;
        QCOMPARE(skills->detail(), QStringLiteral("atualizado há 5 min"));
        now += 3 * 3600000;
        QCOMPARE(skills->detail(), QStringLiteral("atualizado há 3 h"));
    }

    void theFolderIsUpdatedAtMostOnceAnHourUnlessAsked()
    {
        state->setSkillsDir(company());
        runner->answer(0);
        skills->refresh();                                                    // the tab opened right after
        QCOMPARE(runner->calls.size(), 1);
        now += Skills::kUpdateEveryMs - 1;
        skills->refresh();
        QCOMPARE(runner->calls.size(), 1);
        now += 1;
        skills->refresh();                                                    // an hour later: again
        QCOMPARE(runner->calls.size(), 2);
        skills->refresh();                                                    // while it runs: not twice
        skills->updateNow();
        QCOMPARE(runner->calls.size(), 2);
        runner->answer(0);
        skills->updateNow();                                                  // "Atualizar agora" does not wait the hour
        QCOMPARE(runner->calls.size(), 3);
        runner->answer(0);
        skill(company(), "added-by-hand");                                    // opening the tab still checks the links
        skills->refresh();
        QCOMPARE(runner->calls.size(), 3);
        QCOMPARE(skills->linked(), 3);
    }

    void whatStopsAnUpdateIsSaidAndTheLinksStay_data()
    {
        QTest::addColumn<int>("exitCode");
        QTest::addColumn<QString>("err");
        QTest::addColumn<bool>("timedOut");
        QTest::addColumn<bool>("started");
        QTest::addColumn<QString>("says");
        QTest::newRow("local changes") << 1 << "error: Your local changes to the following files would be overwritten by merge" << false << true << "mudanças suas";
        QTest::newRow("own commits") << 128 << "fatal: Not possible to fast-forward, aborting." << false << true << "mudanças suas";
        QTest::newRow("no network") << 128 << "ssh: Could not resolve hostname github.com: Name or service not known" << false << true << "falar com o GitHub";
        QTest::newRow("no access") << 128 << "git@github.com: Permission denied (publickey).\nfatal: Could not read from remote repository." << false << true << "falar com o GitHub";
        QTest::newRow("password wanted") << 128 << "fatal: could not read Username for 'https://github.com': terminal prompts disabled" << false << true << "falar com o GitHub";
        QTest::newRow("too slow") << -1 << "" << true << true << "falar com o GitHub";
        QTest::newRow("no git program") << -1 << "" << false << false << "Instale o git";
    }
    void whatStopsAnUpdateIsSaidAndTheLinksStay()
    {
        QFETCH(int, exitCode);
        QFETCH(QString, err);
        QFETCH(bool, timedOut);
        QFETCH(bool, started);
        QFETCH(QString, says);
        state->setSkillsDir(company());
        ICommandRunner::Result r;
        r.started = started;
        r.timedOut = timedOut;
        r.exitCode = exitCode;
        r.err = err;
        runner->finish(r);
        QVERIFY(!skills->busy());
        QCOMPARE(skills->status(), QStringLiteral("warn"));
        QVERIFY(skills->warning());
        QVERIFY2(skills->message().contains(says), qPrintable(skills->message()));
        QVERIFY(!skills->detail().isEmpty());
        QCOMPARE(skills->linked(), 2);                                        // nothing is undone
        QVERIFY(QFileInfo(claude() + "/a/SKILL.md").isFile());
        QCOMPARE(runner->calls.size(), 1);                                    // and nothing else was tried (no stash, no reset)
        skills->updateNow();                                                  // "Tentar de novo" works, and clears the warning
        runner->answer(0);
        QCOMPARE(skills->status(), QStringLiteral("ok"));
    }

    void aFolderThatIsNotACloneIsLinkedAndLeftToTheUser()
    {
        const QString plain = dir->path() + "/plain";
        skill(plain, "x");
        state->setSkillsDir(plain);
        QCOMPARE(runner->calls.size(), 0);                                    // git is not even run
        QCOMPARE(skills->linked(), 1);
        QCOMPARE(skills->status(), QStringLiteral("plain"));
        QVERIFY(!skills->warning());
        QCOMPARE(skills->message(), QStringLiteral("Pasta sem git"));
    }

    void aNameTakenByAnotherSkillIsAWarningNotAnOverwrite()
    {
        skill(claude(), "a");                                                 // the user's own "a", a real folder
        state->setSkillsDir(company());
        runner->answer(0);
        QCOMPARE(skills->linked(), 1);
        QCOMPARE(skills->conflicts(), QStringList{"a"});
        QCOMPARE(skills->status(), QStringLiteral("warn"));
        QVERIFY(skills->detail().contains("a"));
        QVERIFY(!links::isLink(claude() + "/a"));
    }

    void anotherFolderOrNoneTakesTheOldLinksAway()
    {
        state->setSkillsDir(company());
        runner->answer(0);
        const QString other = dir->path() + "/other";
        skill(other, "z");
        clone(other);
        state->setSkillsDir(other);
        QCOMPARE(runner->calls.size(), 2);                                    // the new folder is updated at once
        QVERIFY(!links::isLink(claude() + "/a"));
        QVERIFY(links::isLink(claude() + "/z"));
        state->setSkillsDir(QString());                                       // "Limpar" while git still runs
        QCOMPARE(skills->status(), QStringLiteral("none"));
        QCOMPARE(skills->linked(), 0);
        QVERIFY(!links::isLink(claude() + "/z"));
        runner->answer(0);                                                    // the late answer changes nothing
        QCOMPARE(skills->status(), QStringLiteral("none"));
        QVERIFY(!links::isLink(claude() + "/z"));
    }

    void theLastUpdateIsRememberedAcrossRuns()
    {
        state->setSkillsDir(company());
        runner->answer(0);
        now += 10 * 60000;
        skills.reset();
        make();                                                               // Farol started again
        QCOMPARE(runner->calls.size(), 1);
        skills->refresh();                                                    // at start: links checked, folder updated
        QCOMPARE(runner->calls.size(), 2);
        QCOMPARE(skills->linked(), 2);
        ICommandRunner::Result offline;
        offline.started = true;
        offline.exitCode = 128;
        offline.err = "ssh: Could not resolve hostname github.com";
        runner->finish(offline);
        QVERIFY(skills->warning());
        skills->updateNow();
        runner->answer(0);
        QCOMPARE(skills->detail(), QStringLiteral("atualizado agora"));
    }

    void theFolderIsOpenedByTheApp()
    {
        state->setSkillsDir(company());
        QSignalSpy asked(skills.get(), &Skills::openFolderRequested);
        skills->openFolder();
        QCOMPARE(asked.count(), 1);
        QCOMPARE(asked.first().first().toString(), company());
    }
};

QTEST_GUILESS_MAIN(TestSkills)
#include "tst_skills.moc"
