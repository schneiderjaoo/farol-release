#pragma once
#include "ProcessWatch.h"

#include <QHash>
#include <QObject>
#include <QString>

class QSocketNotifier;
class QWinEventNotifier;

namespace farol {

// Watches processes through pidfds: the kernel wakes the event loop when one exits, nothing is polled.
// On Windows (ProcessWatcher_win.cpp) the same is done with a process handle.
class ProcessWatcher : public QObject, public IProcessWatch {
    Q_OBJECT
public:
    explicit ProcessWatcher(QObject *parent = nullptr);
    ~ProcessWatcher() override;

    int watch(qint64 pid, qint64 start, std::function<void()> gone) override;
    void cancel(int id) override;

    // The pid, as seen from here, of the process that calls itself `pid` in its own PID namespace and started at
    // `start` (field 22 of /proc/<pid>/stat); 0 when there is none. Claude Code inside the VSCodium Flatpak has a
    // pid of its own in there. procDir is a parameter for the tests.
    static qint64 hostPid(qint64 pid, qint64 start, const QString &procDir = QStringLiteral("/proc"));

private:
    struct Watch {
#ifdef Q_OS_WIN
        void *process = nullptr;   // a HANDLE
        QWinEventNotifier *notifier = nullptr;
#else
        int fd = -1;
        QSocketNotifier *notifier = nullptr;
#endif
        std::function<void()> gone;
    };
    void release(const Watch &w);

    QHash<int, Watch> m_watches;
    int m_next = 0;
};

} // namespace farol
