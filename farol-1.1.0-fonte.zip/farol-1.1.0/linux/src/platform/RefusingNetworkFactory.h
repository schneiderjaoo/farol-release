#pragma once
#include <QQmlNetworkAccessManagerFactory>

namespace farol {

// The network access manager of the island's QML engine: one that refuses every request (images, fonts, components,
// XMLHttpRequest). What the island shows comes from outside (a model's answer, a hook payload, a file name), and Qt
// Quick fetches whatever an image or a stylesheet in rich text points to, the moment it is shown. Every Text is
// plain and answers are converted (core/AnswerText); this is the barrier behind those. It does not reach what has
// network code of its own (Qt Multimedia, web sockets, web views), which is why the island has none of them.
// Farol's own requests go through NetworkClient, which has a QNetworkAccessManager of its own.
class RefusingNetworkFactory : public QQmlNetworkAccessManagerFactory {
public:
    QNetworkAccessManager *create(QObject *parent) override;
};

} // namespace farol
