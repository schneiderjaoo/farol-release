#include "LumiLook.h"

namespace farol {

LumiLook lumiLookFor(BotState state)
{
    switch (state) {
    case BotState::Thinking: return {"open", "lamp", "breathe", false, "working"};
    case BotState::Working: return {"open", "lamp", "sway", false, "working"};
    case BotState::Searching: return {"open", "lamp", "sweep", false, "working"};
    case BotState::Approval:
    case BotState::Question: return {"wide", "lamp", "steady", false, "waiting"};
    case BotState::Error: return {"wide", "alert", "steady", false, "error"};
    case BotState::Finished: return {"happy", "ok", "steady", false, "done"};
    case BotState::Ratelimit: return {"open", "idle", "off", false, "idle"};
    case BotState::Sleeping: return {"sleep", "idle", "off", true, "idle"};
    case BotState::Dizzy: return {"wide", "working", "tremble", false, "idle"};
    case BotState::Idle: break;
    }
    return {"open", "lamp", "steady", false, "idle"};
}

QVariantMap LumiLooks::look(const QString &stateName) const
{
    const auto state = enumFromKey<BotState>(stateName);
    const LumiLook l = lumiLookFor(state.value_or(BotState::Idle));
    return {{"eyes", l.eyes}, {"lamp", l.lamp}, {"beam", l.beam}, {"z", l.z}, {"signal", l.signal}};
}

} // namespace farol
