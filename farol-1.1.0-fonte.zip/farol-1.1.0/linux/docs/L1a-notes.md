# L1a — notas (casca da ilha)

Alvo de fidelidade: o Swift entregue (spec §0). Tela de teste: `eDP-1`, 1920×1200, escala 1.

## Checagens manuais (Task 7, Step 6) — feitas pelo João em 2026-09-30

| # | Comportamento | Resultado | Observação |
|---|---|---|---|
| 1 | Saudação abre e recolhe sozinha | Funciona | ilha 640×150 com o cartão provisório, depois a pílula compacta |
| 2 | Clique abre; hover não abre; overshoot | Funciona | como no Swift (`click()` só na compacta). O overshoot vem da curva da spec `[.32, 1.22, .42, 1]` (520 ms); o Swift usa `spring(response: 0.5, dampingFraction: 0.72)`, então é uma decisão do plano, não cópia. O que o João viu foi só a primeira abertura; depois da revisão o overshoot vale em **todos** os ciclos (`openAndCloseCurvesStayCorrectAcrossCycles`) |
| 3 | Recolhe em ~15 s; barra de contagem | Funciona | barra nos últimos ~9 s |
| 4 | `Esc` fecha; teclado não é roubado | Funciona | `OnDemand` só depois do clique |
| 5 | Cliques atravessam abaixo da ilha | Funciona | aberta e compacta |
| 6 | Bandeja e menu Debug | Funciona | Open, Settings (cinza), Debug ▸ Mode/View/Launch greeting/Toggle sound; trocar de View muda a altura. **Quit não foi clicado** nessa checagem; a revisão achou que ele derrubava o app (delete duplo do menu), já corrigido e coberto por `tst_tray` — conferir na mão |
| 7 | 60 s → some; topo → peek com som | Funciona | |

## Geometria medida por captura (Spectacle, pixels)

| Estado | Esperado (Swift) | Medido |
|---|---|---|
| Saudação | 640×150 | linhas pretas 0–149, largura 640 (x 640–1279) |
| Compacta | 344×32 (184+160 × 32) | linhas 0–31, largura 344 (x 788–1131) |
| Visão geral | 640×160 | linhas 0–159, largura 640 |
| Escondida | invisível | nenhuma linha preta no topo |

## Comparação com design/captures

As capturas são do **protótipo HTML**, não do Swift entregue; onde os dois divergem o Swift vence (spec §0).

- **02_compact:** o protótipo mostra o notch do Mac com "orelhas" côncavas nos cantos de cima. O Swift entregue usa cantos de cima retos (`topRadius = 0`), e no Linux não há notch físico, então a pílula é um retângulo com cantos de baixo de 14 pt. Proporção, posição do Mochi (x = 40 da borda esquerda da ilha) e a grade 2×2 à direita batem; o Mochi e os mini-Mochis ainda são círculos provisórios.
- **03_overview:** o protótipo tem 196 pt de altura e dois cartões (agente + pílulas); o Swift usa 160 pt. Cabeçalho igual ao Swift: casa, balão e mais à esquerda; engrenagem e alto-falante à direita (o rótulo "N em cursos" do protótipo não existe no Swift). O conteúdo real é o L1c.
- Fonte: Inter no lugar do SF Pro; ícones desenhados em QML no lugar dos SF Symbols.

## Medições (`linux/scripts/measure.sh`)

| Estado | CPU % | PSS MB | Janela |
|---|---|---|---|
| compacta parada | 0,00 | 73,9 | 20 s |
| escondida (forçada por `COUCOU_DEBUG_MODE=hidden`) | 0,00 | 74,0 | 20 s |
| visão geral aberta (`COUCOU_DEBUG_VIEW=overview`) | 0,88 | 74,0 | 8 s |

Metas (SPEC §12): escondida ≈ 0 %, compacta < 3 %, memória < 100 MB. **Ficou dentro**, mas o PSS já parte de ~74 MB só com a casca (Qt Widgets + Quick + Multimedia); o Mochi do L1b precisa caber nos ~26 MB restantes — medir de novo lá.

Uma tentativa anterior de medir "escondida" esperando os 60 s da FSM mostrou a pílula ainda visível (0,15 %): o cursor do usuário provavelmente estava dentro da região da ilha, o que cancela o timer de esconder; a checagem 7 feita à mão confirmou o comportamento.

## Correções da revisão final (mesmo dia)

Um revisor independente achou e reproduziu, e cada item virou teste vermelho → verde:

- **Quit derrubava o app** (SIGSEGV): `~Tray` apagava o menu que o `KStatusNotifierItem` já é dono. Teste `tst_tray`.
- **Curvas de abrir e fechar se invertiam depois do primeiro ciclo** (`shrinking` compartilhava o sinal com o tamanho; o `Behavior` lia o valor antigo). Agora `shrinkingChanged` sai antes de `layoutChanged`. Teste `openAndCloseCurvesStayCorrectAcrossCycles`.
- **FSM ficava em `home` depois do `Esc`**: a pílula não reabria por clique e um timer velho fechava a ilha aberta pela bandeja. Novo `IslandStateMachine::closeExternally()`.
- **`openExternally()` ignorava a saudação** e um timer pendente em `home`: agora assume a saudação e reinicia o timer.
- **O teclado ficava `OnDemand` depois de recolher por timer**: `setMode()` devolve o teclado sempre que sai de `expanded`.
- **O círculo provisório saía da pílula ao fechar**: virou filho da ilha (como o `BotPlacement` do Swift).
- **A barra de contagem congelava na pílula compacta.**
- **`NaN`/`inf` na configuração passavam pelo `clamp`** (volume e intervalo) e agora caem no padrão; `flappingHoverDoesNotInterruptTheGreeting` substitui um teste que passava mesmo sem o debouncer (conferido por mutação).

## Ganchos de desenvolvimento

- `COUCOU_DEBUG_VIEW=<view>`: abre essa view 7 s depois de iniciar (após a saudação), para capturas e medições sem clique.
- `COUCOU_DEBUG_MODE=hidden|compact|expanded`: força o modo 7 s depois de iniciar.
- `COUCOU_SOUNDS_DIR=<pasta>`: troca a pasta dos WAVs.

## Pendências para L1b/L1c e além

- Menores adiados da revisão: `unknownNameAndDisabledAreHarmless` não afirma nada; os testes de QML leem o QML do disco e não a lista de recursos do app; folga do debounce (120 ms contra o piscar de ~100 ms do L0) — considerar 200–250 ms; `Mail` também pede teclado `OnDemand` (o Swift só faz isso no `prompt`); reabrir a saudação em cima dela pode deixar o timer do QML parado (só pelo menu Debug); os fades do cabeçalho "confused" e da grade compacta são lineares (o Swift usa easeInOut).

- Provisórios a trocar: círculo creme (Mochi, L1b), mini-pontos da grade compacta (mini-Mochis, L1b), cartões das views (L1c).
- O conteúdo das views não é recortado pelo canto arredondado de baixo (raio 22); com cartões reais, conferir se algo vaza.
- **L2:** os timers da FSM ainda chamam `setMode()` sem olhar `isPinned`, como o Swift; um alerta fixado pode ser recolhido depois que o ponteiro sai. Guardar em `onFsmTransition` com teste.
- **L6:** sem guarda de instância única (um segundo `coucou` abriria outra ilha e outra bandeja).
- `FSM.openExternally()` é acréscimo nosso ao Swift (ver o ledger do L1a): abrir a ilha pela bandeja/alertas leva a FSM a `home`.

- **Fix pós-L1a (2026-09-30):** `autoCloseInterval` agora dirige o atraso real `home→petit` da FSM (no Swift ele só desenhava a barra de contagem e o recolhimento ficava fixo em 15 s). Teste: `homeCollapseFollowsTheAutoCloseSetting`.
