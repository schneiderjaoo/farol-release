#include <QtTest>
#include "IslandTypes.h"

using namespace farol;

class TestIslandTypes : public QObject {
    Q_OBJECT
private slots:
    void layoutTableMatchesSwift() {
        QCOMPARE(viewLayout(IslandView::Overview).height, 160.0);
        QCOMPARE(viewLayout(IslandView::Overview).botX, 68.0);
        QCOMPARE(viewLayout(IslandView::Overview).botDiameter, 58.0);
        QVERIFY(!viewLayout(IslandView::Overview).botY.has_value());
        QCOMPARE(int(viewLayout(IslandView::Overview).agentMode), int(AgentLayoutMode::Pills));
        QCOMPARE(viewLayout(IslandView::Empty).botX, 70.0);
        QCOMPARE(viewLayout(IslandView::Confused).botDiameter, 66.0);
        QCOMPARE(viewLayout(IslandView::Upload).height, 280.0);   // Farol: the repository list
        QCOMPARE(*viewLayout(IslandView::Upload).botY, 104.0);
        QCOMPARE(viewLayout(IslandView::Upload).botX, 140.0);
        QCOMPARE(viewLayout(IslandView::Uploading).botDiameter, 20.0);
        QCOMPARE(*viewLayout(IslandView::Uploading).botY, 118.0);
        QCOMPARE(*viewLayout(IslandView::Choose).botY, 101.0);
        QCOMPARE(viewLayout(IslandView::Mail).height, 240.0);
        QCOMPARE(viewLayout(IslandView::Greeting).height, 150.0);
        QCOMPARE(viewLayout(IslandView::Greeting).botX, 320.0);
        QCOMPARE(viewLayout(IslandView::Greeting).botDiameter, 0.0);
    }

    void sizesPerMode() {
        QCOMPARE(islandSize(IslandMode::Hidden, IslandView::Overview, 184, 32), QSizeF(184, 32));
        QCOMPARE(islandSize(IslandMode::Compact, IslandView::Overview, 184, 32), QSizeF(344, 32));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Overview, 184, 32), QSizeF(640, 160));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Upload, 184, 32), QSizeF(640, 280));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Mail, 184, 32), QSizeF(640, 240));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Greeting, 184, 32), QSizeF(640, 150));
        // a wider physical notch widens the compact island too
        QCOMPARE(islandSize(IslandMode::Compact, IslandView::Overview, 200, 38), QSizeF(360, 38));
    }

    // Docked to a side edge the island is portrait (Farol): a narrow column with its own heights, the screen edge on
    // its long side. Top and bottom keep the landscape sizes.
    void verticalSizes() {
        constexpr bool v = true;
        QCOMPARE(islandSize(IslandMode::Hidden, IslandView::Overview, 184, 32, 0, v), QSizeF(32, 184));
        QCOMPARE(islandSize(IslandMode::Compact, IslandView::Overview, 184, 32, 0, v), QSizeF(36, 100));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Overview, 184, 32, 0, v), QSizeF(280, 420));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Approval, 184, 32, 0, v), QSizeF(280, 300));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Settings, 184, 32, 0, v), QSizeF(280, 600));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Skills, 184, 32, 0, v), QSizeF(280, 620));
        QCOMPARE(viewLayout(IslandView::Skills).height, 280.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Ask, 184, 32, 0, v), QSizeF(280, 620));
        QCOMPARE(viewLayout(IslandView::Ask).height, 300.0);
        QCOMPARE(viewLayout(IslandView::Settings).height, 300.0);            // the tallest the 320 window allows with air
        // the diff of an edit: as tall as Settings in both shapes, for as many lines as the windows allow
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Diff, 184, 32), QSizeF(640, 300));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Diff, 184, 32, 0, v), QSizeF(280, 600));
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Diff, 184, 32, 7, v), QSizeF(280, 600));   // whatever the chat count
        for (int i = 0; i <= int(IslandView::Greeting); ++i) {          // every view fits the 320x720 window
            const QSizeF s = islandSize(IslandMode::Expanded, IslandView(i), 184, 32, 99, v);
            QVERIFY2(s.width() == 280 && s.height() >= 200 && s.height() <= 720, qPrintable(enumKey(IslandView(i))));
        }
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Overview, 184, 32, 0, false), QSizeF(640, 160));   // unchanged
    }

    void promptHeightGrowsWithChatAndCaps() {
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, 0).height(), 240.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, 1).height(), 280.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, 2).height(), 300.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, 50).height(), 300.0);
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Prompt, 184, 32, -3).height(), 240.0);
        // chat count does not affect any other view
        QCOMPARE(islandSize(IslandMode::Expanded, IslandView::Overview, 184, 32, 9).height(), 160.0);
    }

    void invalidNotchFallsBack() {
        QCOMPARE(islandSize(IslandMode::Hidden, IslandView::Overview, 0, 0), QSizeF(184, 32));
        QCOMPARE(islandSize(IslandMode::Compact, IslandView::Overview, -10, -1), QSizeF(344, 32));
        QCOMPARE(islandSize(IslandMode::Hidden, IslandView::Overview, qQNaN(), 32), QSizeF(184, 32));
    }

    void corners() {
        QCOMPARE(islandCornerRadius(IslandMode::Hidden), 14.0);
        QCOMPARE(islandCornerRadius(IslandMode::Compact), 14.0);
        QCOMPARE(islandCornerRadius(IslandMode::Expanded), 22.0);
    }

    void botPlacements() {
        auto h = botPosition(IslandMode::Hidden, IslandView::Overview, 32, 0);
        QCOMPARE(h.cx, 46.0); QCOMPARE(h.cy, 16.0); QCOMPARE(h.diameter, 6.0); QCOMPARE(h.opacity, 0.0);
        auto c = botPosition(IslandMode::Compact, IslandView::Overview, 32, 0);
        // Farol: Lumi hugs the left corner of the compact pill (the Swift app keeps the mascot at cx = 40 because of the notch)
        QCOMPARE(c.cx, 16.0); QCOMPARE(c.cy, 16.0); QCOMPARE(c.diameter, 20.0); QCOMPARE(c.opacity, 1.0);
        // Portrait island: Lumi hugs the top corner when compact and sits top-left of the card when open.
        auto vc = botPosition(IslandMode::Compact, IslandView::Overview, 100, 0, true);
        QCOMPARE(vc.cx, 18.0); QCOMPARE(vc.cy, 16.0); QCOMPARE(vc.diameter, 20.0); QCOMPARE(vc.opacity, 1.0);
        for (int v = 0; v <= int(IslandView::Greeting); ++v) {
            if (IslandView(v) == IslandView::Greeting)
                continue;
            auto p = botPosition(IslandMode::Expanded, IslandView(v), 360, 0.5, true);
            QVERIFY2(p.cx == 44 && p.cy == 44 && p.diameter == 52, qPrintable(enumKey(IslandView(v))));
        }
        // Farol: one spot for every open view, on top of the rail, so the mascot does not move when the tab changes
        auto o = botPosition(IslandMode::Expanded, IslandView::Overview, 160, 0);
        QCOMPARE(o.cx, 54.0); QCOMPARE(o.cy, 48.0); QCOMPARE(o.diameter, 52.0); QCOMPARE(o.opacity, 1.0);
        for (int v = 0; v <= int(IslandView::Greeting); ++v) {
            const IslandView view = IslandView(v);
            if (view == IslandView::Uploading || view == IslandView::Greeting)
                continue;
            for (qreal h : {160.0, 176.0, 240.0}) {
                auto p = botPosition(IslandMode::Expanded, view, h, 0);
                QVERIFY2(p.cx == o.cx && p.cy == o.cy && p.diameter == o.diameter, qPrintable(enumKey(view)));
            }
        }
        // uploading: the dot rides the progress bar (left 36, width 526)
        auto p = botPosition(IslandMode::Expanded, IslandView::Uploading, 176, 0.5);
        QCOMPARE(p.cx, 36 + 0.5 * 526); QCOMPARE(p.cy, 118.0); QCOMPARE(p.diameter, 20.0);   // the upload keeps its own motion
    }

    // The strip that wakes a hidden island lies along the docked edge, centred, 3 px thick.
    void hiddenStripFollowsTheEdge() {
        const QSizeF window(720, 320);
        QCOMPARE(hiddenStrip(IslandEdge::Top, window, 184), QRectF(268, 0, 184, 3));
        QCOMPARE(hiddenStrip(IslandEdge::Bottom, window, 184), QRectF(268, 317, 184, 3));
        QCOMPARE(hiddenStrip(IslandEdge::Left, window, 184), QRectF(0, 68, 3, 184));
        QCOMPARE(hiddenStrip(IslandEdge::Right, window, 184), QRectF(717, 68, 3, 184));
    }

    void edgeKeysRoundTrip() {
        QCOMPARE(enumKey(IslandEdge::Bottom), QStringLiteral("bottom"));
        for (auto e : {IslandEdge::Top, IslandEdge::Bottom, IslandEdge::Left, IslandEdge::Right})
            QVERIFY(enumFromKey<IslandEdge>(enumKey(e)).value() == e);
        QVERIFY(!enumFromKey<IslandEdge>("centre").has_value());
    }

    void enumKeysRoundTrip() {
        QCOMPARE(enumKey(IslandView::Overview), QStringLiteral("overview"));
        QCOMPARE(enumKey(IslandView::Greeting), QStringLiteral("greeting"));
        QCOMPARE(enumKey(BotState::Ratelimit), QStringLiteral("ratelimit"));
        QCOMPARE(enumKey(IslandMode::Expanded), QStringLiteral("expanded"));
        QVERIFY(enumFromKey<IslandView>("approval").value() == IslandView::Approval);
        QVERIFY(enumFromKey<IslandMode>("compact").value() == IslandMode::Compact);
        QCOMPARE(enumKey(IslandView::Diff), QStringLiteral("diff"));
        QVERIFY(enumFromKey<IslandView>("diff").value() == IslandView::Diff);
        QCOMPARE(int(IslandView::Diff), int(IslandView::Greeting) - 1);       // the greeting stays the last view
        QVERIFY(!enumFromKey<IslandView>("nope").has_value());
        QVERIFY(!enumFromKey<IslandView>("").has_value());
        for (int v = 0; v <= int(IslandView::Greeting); ++v)
            QVERIFY(enumFromKey<IslandView>(enumKey(IslandView(v))).value() == IslandView(v));
    }
};

QTEST_APPLESS_MAIN(TestIslandTypes)
#include "tst_island_types.moc"
