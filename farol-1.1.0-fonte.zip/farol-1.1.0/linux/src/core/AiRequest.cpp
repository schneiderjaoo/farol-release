#include "AiRequest.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>

namespace farol {

QStringList aiProviders()
{
    return {QStringLiteral("claude"), QStringLiteral("anthropic"), QStringLiteral("openai"), QStringLiteral("gemini")};
}

bool aiNeedsKey(const QString &provider)
{
    return provider != QLatin1String("claude");
}

QString aiProviderLabel(const QString &provider)
{
    if (provider == QLatin1String("openai"))
        return QStringLiteral("ChatGPT");
    if (provider == QLatin1String("gemini"))
        return QStringLiteral("Gemini");
    if (provider == QLatin1String("claude"))
        return QStringLiteral("Claude Code");
    return QStringLiteral("Anthropic");
}

QList<AiModel> aiModels(const QString &provider)
{
    if (provider == QLatin1String("openai"))
        return {{QStringLiteral("gpt-5-nano"), QStringLiteral("GPT-5 nano")},
                {QStringLiteral("gpt-5-mini"), QStringLiteral("GPT-5 mini")},
                {QStringLiteral("gpt-5"), QStringLiteral("GPT-5")}};
    if (provider == QLatin1String("gemini"))   // Google's own aliases for the newest of each line
        return {{QStringLiteral("gemini-flash-lite-latest"), QStringLiteral("Flash-Lite")},
                {QStringLiteral("gemini-flash-latest"), QStringLiteral("Flash")},
                {QStringLiteral("gemini-pro-latest"), QStringLiteral("Pro")}};
    if (provider == QLatin1String("claude"))   // Claude Code's own aliases for the newest of each line
        return {{QStringLiteral("sonnet"), QStringLiteral("Sonnet")},
                {QStringLiteral("fable"), QStringLiteral("Fable")},
                {QStringLiteral("opus"), QStringLiteral("Opus")}};
    return {{QStringLiteral("claude-sonnet-5-5"), QStringLiteral("Sonnet 5.5")},
            {QStringLiteral("claude-fable-5-1"), QStringLiteral("Fable 5.1")},
            {QStringLiteral("claude-opus-5-5"), QStringLiteral("Opus 5.5")}};
}

// The most capable of the three.
QString aiDefaultModel(const QString &provider)
{
    return aiModels(provider).last().id;
}

static QString fileAsText(const AskFile &f)
{
    return QStringLiteral("Arquivo: %1\n\n%2").arg(f.name, QString::fromUtf8(f.data));
}

static QString dataUrl(const AskFile &f)
{
    return QStringLiteral("data:%1;base64,%2").arg(f.mime, QString::fromLatin1(f.data.toBase64()));
}

// The files as Anthropic's content blocks, which Claude Code takes too.
static QJsonArray anthropicFiles(const QList<AskFile> &files)
{
    QJsonArray content;
    for (const AskFile &f : files) {
        if (f.kind == AskFile::Text) {
            content.append(QJsonObject{{"type", "text"}, {"text", fileAsText(f)}});
            continue;
        }
        content.append(QJsonObject{
            {"type", f.kind == AskFile::Pdf ? "document" : "image"},
            {"source", QJsonObject{{"type", "base64"}, {"media_type", f.mime}, {"data", QString::fromLatin1(f.data.toBase64())}}}});
    }
    return content;
}

static QJsonArray anthropicMessages(const QList<AskFile> &files, const QList<AskTurn> &turns)
{
    QJsonArray messages;
    bool first = true;
    for (const AskTurn &t : turns) {
        QJsonArray content;
        if (t.user && first) {
            content = anthropicFiles(files);
            first = false;
        }
        content.append(QJsonObject{{"type", "text"}, {"text", t.text}});
        messages.append(QJsonObject{{"role", t.user ? "user" : "assistant"}, {"content", content}});
    }
    return messages;
}

static QJsonArray openAiMessages(const QList<AskFile> &files, const QList<AskTurn> &turns)
{
    QJsonArray messages;
    bool first = true;
    for (const AskTurn &t : turns) {
        if (!t.user) {
            messages.append(QJsonObject{{"role", "assistant"}, {"content", t.text}});
            continue;
        }
        QJsonArray content;
        if (first) {
            for (const AskFile &f : files) {
                if (f.kind == AskFile::Text)
                    content.append(QJsonObject{{"type", "text"}, {"text", fileAsText(f)}});
                else if (f.kind == AskFile::Image)
                    content.append(QJsonObject{{"type", "image_url"}, {"image_url", QJsonObject{{"url", dataUrl(f)}}}});
                else
                    content.append(QJsonObject{{"type", "file"}, {"file", QJsonObject{{"filename", f.name}, {"file_data", dataUrl(f)}}}});
            }
            first = false;
        }
        content.append(QJsonObject{{"type", "text"}, {"text", t.text}});
        messages.append(QJsonObject{{"role", "user"}, {"content", content}});
    }
    return messages;
}

static QJsonArray geminiContents(const QList<AskFile> &files, const QList<AskTurn> &turns)
{
    QJsonArray contents;
    bool first = true;
    for (const AskTurn &t : turns) {
        QJsonArray parts;
        if (t.user && first) {
            for (const AskFile &f : files) {
                if (f.kind == AskFile::Text)
                    parts.append(QJsonObject{{"text", fileAsText(f)}});
                else
                    parts.append(QJsonObject{{"inline_data", QJsonObject{{"mime_type", f.mime}, {"data", QString::fromLatin1(f.data.toBase64())}}}});
            }
            first = false;
        }
        parts.append(QJsonObject{{"text", t.text}});
        contents.append(QJsonObject{{"role", t.user ? "user" : "model"}, {"parts", parts}});
    }
    return contents;
}

HttpRequest buildAiRequest(const QString &provider, const QString &model, const QString &key, const QList<AskFile> &files,
                           const QList<AskTurn> &turns)
{
    HttpRequest r;
    r.headers.emplaceBack("Content-Type", "application/json");
    QJsonObject body;
    if (provider == QLatin1String("openai")) {
        r.url = QUrl(QStringLiteral("https://api.openai.com/v1/chat/completions"));
        r.headers.emplaceBack("Authorization", "Bearer " + key.toUtf8());
        body = {{"model", model}, {"messages", openAiMessages(files, turns)}};
    } else if (provider == QLatin1String("gemini")) {
        r.url = QUrl(QStringLiteral("https://generativelanguage.googleapis.com/v1beta/models/%1:generateContent")
                         .arg(QString::fromLatin1(QUrl::toPercentEncoding(model))));
        r.headers.emplaceBack("x-goog-api-key", key.toUtf8());
        body = {{"contents", geminiContents(files, turns)}};
    } else {
        r.url = QUrl(QStringLiteral("https://api.anthropic.com/v1/messages"));
        r.headers.emplaceBack("x-api-key", key.toUtf8());
        r.headers.emplaceBack("anthropic-version", "2023-06-01");
        body = {{"model", model}, {"max_tokens", 4096}, {"messages", anthropicMessages(files, turns)}};
    }
    r.body = QJsonDocument(body).toJson(QJsonDocument::Compact);
    return r;
}

AiAnswer parseAiReply(const QString &provider, int status, const QByteArray &body)
{
    const QJsonDocument doc = QJsonDocument::fromJson(body);
    const QJsonObject o = doc.object();
    // The three services report a problem the same way: {"error": {"message": "..."}}.
    const QString problem = o.value("error").toObject().value("message").toString();
    if (status < 200 || status >= 300 || !problem.isEmpty()) {
        if (!problem.isEmpty())
            return {false, problem};
        return {false, QStringLiteral("O serviço respondeu com o erro %1.").arg(status)};
    }
    QString text;
    if (provider == QLatin1String("openai")) {
        text = o.value("choices").toArray().at(0).toObject().value("message").toObject().value("content").toString();
    } else if (provider == QLatin1String("gemini")) {
        const QJsonArray parts = o.value("candidates").toArray().at(0).toObject().value("content").toObject().value("parts").toArray();
        for (const QJsonValue &p : parts)
            text += p.toObject().value("text").toString();
    } else {
        for (const QJsonValue &c : o.value("content").toArray())
            if (c.toObject().value("type").toString() == QLatin1String("text"))
                text += c.toObject().value("text").toString();
    }
    if (text.trimmed().isEmpty())
        return {false, QStringLiteral("A resposta veio vazia ou num formato que não entendi.")};
    return {true, text.trimmed()};
}

QStringList claudeArguments(const QString &model)
{
    return {QStringLiteral("-p"),
            QStringLiteral("--input-format"), QStringLiteral("stream-json"),
            QStringLiteral("--output-format"), QStringLiteral("stream-json"),
            QStringLiteral("--verbose"),                       // stream-json output wants it
            QStringLiteral("--tools"), QString(),              // it only reads what it is sent and answers
            QStringLiteral("--safe-mode"),
            QStringLiteral("--strict-mcp-config"),
            QStringLiteral("--no-session-persistence"),
            QStringLiteral("--model"), model,
            QStringLiteral("--system-prompt"),
            QStringLiteral("Você responde a perguntas sobre os arquivos que a pessoa enviou. Não tem ferramentas: use só o "
                           "que está na conversa. Responda na língua da pergunta.")};
}

QByteArray claudeInput(const QList<AskFile> &files, const QList<AskTurn> &turns)
{
    // Only a user's message can be sent, so what was said before is told in it.
    QJsonArray content = anthropicFiles(files);
    QString before;
    for (int i = 0; i + 1 < turns.size(); ++i)
        before += QStringLiteral("\n\n%1: %2").arg(turns.at(i).user ? QStringLiteral("Pessoa") : QStringLiteral("Você"), turns.at(i).text);
    if (!before.isEmpty())
        content.append(QJsonObject{{"type", "text"}, {"text", QStringLiteral("A conversa até aqui:") + before}});
    if (!turns.isEmpty())
        content.append(QJsonObject{{"type", "text"}, {"text", turns.last().text}});
    const QJsonObject line{{"type", "user"}, {"message", QJsonObject{{"role", "user"}, {"content", content}}}};
    return QJsonDocument(line).toJson(QJsonDocument::Compact) + '\n';
}

AiAnswer parseClaudeOutput(int exitCode, const QString &out, const QString &err)
{
    const QStringList lines = out.split(QLatin1Char('\n'), Qt::SkipEmptyParts);
    for (auto it = lines.crbegin(); it != lines.crend(); ++it) {
        const QJsonObject o = QJsonDocument::fromJson(it->toUtf8()).object();
        if (o.value("type").toString() != QLatin1String("result"))
            continue;
        const QString text = o.value("result").toString().trimmed();
        if (o.value("is_error").toBool()) {
            if (text.contains(QLatin1String("/login")))
                return {false, QStringLiteral("o Claude Code não está com uma conta aberta. Abra o Claude Code e entre na sua conta.")};
            return {false, text.isEmpty() ? QStringLiteral("não respondeu.") : text};
        }
        if (text.isEmpty())
            break;
        return {true, text};
    }
    const QString said = err.trimmed().section(QLatin1Char('\n'), 0, 0);
    if (!said.isEmpty())
        return {false, said};
    if (exitCode != 0)
        return {false, QStringLiteral("terminou com o erro %1.").arg(exitCode)};
    return {false, QStringLiteral("A resposta veio vazia ou num formato que não entendi.")};
}

} // namespace farol
