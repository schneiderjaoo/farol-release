#include <QtTest>
#include <QColor>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include "AppState.h"
#include "Theme.h"

using namespace farol;

namespace {
double luminance(const QString &hex)
{
    const QColor c(hex);
    auto f = [](double v) { return v <= 0.03928 ? v / 12.92 : std::pow((v + 0.055) / 1.055, 2.4); };
    return 0.2126 * f(c.redF()) + 0.7152 * f(c.greenF()) + 0.0722 * f(c.blueF());
}
double contrast(const QString &a, const QString &b)
{
    const double la = luminance(a), lb = luminance(b);
    return (std::max(la, lb) + 0.05) / (std::min(la, lb) + 0.05);
}
} // namespace

class TestTheme : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    QString iniPath() const { return dir.path() + "/t.ini"; }

private slots:
    void init() { QFile::remove(iniPath()); }

    void systemModeFollowsTheSystemScheme()
    {
        QSettings s(iniPath(), QSettings::IniFormat);
        AppState st(&s);
        Theme theme(&st);
        theme.setSystemDark(true);
        QVERIFY(theme.dark());
        QCOMPARE(theme.islandBg(), QStringLiteral("#0A1F36"));
        QSignalSpy spy(&theme, &Theme::changed);
        theme.setSystemDark(false);
        QVERIFY(!theme.dark());
        QCOMPARE(theme.islandBg(), QStringLiteral("#F4F8F9"));
        QCOMPARE(spy.count(), 1);
    }

    void explicitModeIgnoresTheSystem()
    {
        QSettings s(iniPath(), QSettings::IniFormat);
        AppState st(&s);
        Theme theme(&st);
        theme.setSystemDark(true);
        st.setThemeMode("light");
        QVERIFY(!theme.dark());
        theme.setSystemDark(false);
        st.setThemeMode("dark");
        QVERIFY(theme.dark());
        QSignalSpy spy(&theme, &Theme::changed);
        theme.setSystemDark(true);                          // irrelevant while the mode is explicit
        QCOMPARE(spy.count(), 0);
    }

    void signalColorsAreTheSameInBothThemes()
    {
        QSettings s(iniPath(), QSettings::IniFormat);
        AppState st(&s);
        Theme theme(&st);
        theme.setSystemDark(true);
        const QStringList dark{theme.lamp(), theme.ok(), theme.alert(), theme.working(), theme.idle()};
        theme.setSystemDark(false);
        const QStringList light{theme.lamp(), theme.ok(), theme.alert(), theme.working(), theme.idle()};
        QCOMPARE(dark, light);
        QCOMPARE(dark, (QStringList{"#FFC233", "#2FBF8F", "#FF5A4E", "#8FB3C7", "#5B7892"}));
    }

    void textStaysReadableOnEveryTextSurface()
    {
        QSettings s(iniPath(), QSettings::IniFormat);
        AppState st(&s);
        Theme theme(&st);
        for (bool dark : {true, false}) {
            theme.setSystemDark(dark);
            for (const QString &surface : {theme.islandBg(), theme.card()}) {
                QVERIFY2(contrast(theme.text(), surface) >= 7.0, qPrintable(QStringLiteral("text on %1").arg(surface)));
                QVERIFY2(contrast(theme.muted(), surface) >= 4.5, qPrintable(QStringLiteral("muted on %1").arg(surface)));
                QVERIFY2(contrast(theme.dim(), surface) >= 3.0, qPrintable(QStringLiteral("dim on %1").arg(surface)));
            }
            QVERIFY(contrast(theme.primaryText(), theme.primary()) >= 7.0);
            QVERIFY(contrast(theme.alertText(), theme.card()) >= 4.5);
        }
    }

    // A link in an answer: a colour the identity already has (Bruma at night, Correnteza by day), readable on the card.
    void aLinkIsAnIdentityColourReadableOnTheCard()
    {
        QSettings s(iniPath(), QSettings::IniFormat);
        AppState st(&s);
        Theme theme(&st);
        theme.setSystemDark(true);
        QCOMPARE(theme.link(), QStringLiteral("#8FB3C7"));
        QSignalSpy spy(&theme, &Theme::changed);
        theme.setSystemDark(false);
        QCOMPARE(theme.link(), QStringLiteral("#3E7C9E"));
        QCOMPARE(spy.count(), 1);
        for (bool dark : {true, false}) {
            theme.setSystemDark(dark);
            QVERIFY2(contrast(theme.link(), theme.card()) >= 4.5, qPrintable(QStringLiteral("link on %1").arg(theme.card())));
            QVERIFY(theme.link() != theme.text());                  // it stands out from the text around it
        }
    }

    void fontsHaveAFallbackName()
    {
        QSettings s(iniPath(), QSettings::IniFormat);
        AppState st(&s);
        Theme theme(&st);
        QCOMPARE(theme.bodyFont(), QStringLiteral("Instrument Sans"));
        QCOMPARE(theme.titleFont(), QStringLiteral("Bricolage Grotesque"));
        QCOMPARE(theme.monoFont(), QStringLiteral("monospace"));    // the system's fixed-width font: commands and code
        QCOMPARE(theme.property("monoFont").toString(), QStringLiteral("monospace"));
    }
};

QTEST_APPLESS_MAIN(TestTheme)
#include "tst_theme.moc"
