import QtQuick
import QtQuick.Shapes

// Lumi, the Farol mascot: a little lighthouse with the lamp where the head would be. A wide tower with two dark
// stripes, a marked gallery and roof, standing on its quay (the 2026-10 "Cais" drawing).
// Drawn from the paths of "Farol — identidade visual" (viewBox -6 0 132 160); the eyes, the lamp colour and the
// beam come from the session state through LumiLooks, so the mood follows what the sessions are doing.
Item {
    id: lumi
    property string botState: "idle"
    property bool lit: true        // false: the lamp is out and there is no beam (nobody at sea)
    readonly property var look: lumiLooks.look(botState)
    readonly property color lampColor: ({
        "lamp": theme.lamp, "ok": theme.ok, "alert": theme.alert, "working": theme.working, "idle": theme.idle
    })[lit ? look.lamp : "idle"]
    // The beam only moves while Lumi is on screen and the user did not ask for less motion.
    readonly property bool animated: visible && !appState.reduceMotion

    // Lumi's own palette: the character looks the same in both themes, like in the identity sheet.
    readonly property color mare: "#0E2A47"
    readonly property color ardosia: "#2B4A6B"
    readonly property color bruma: "#8FB3C7"
    readonly property color espuma: "#EAF3F4"

    implicitHeight: 160
    width: height * 132 / 160    // the drawing is scaled by height, so the box must follow or it drifts off-centre

    function circle(cx, cy, r) {
        return "M" + (cx - r) + " " + cy + "a" + r + " " + r + " 0 1 0 " + (2 * r) + " 0a" + r + " " + r + " 0 1 0 " + (-2 * r) + " 0z"
    }
    function roundRect(x, y, w, h, r) {
        return "M" + (x + r) + " " + y + "H" + (x + w - r) + "A" + r + " " + r + " 0 0 1 " + (x + w) + " " + (y + r)
            + "V" + (y + h - r) + "A" + r + " " + r + " 0 0 1 " + (x + w - r) + " " + (y + h)
            + "H" + (x + r) + "A" + r + " " + r + " 0 0 1 " + x + " " + (y + h - r)
            + "V" + (y + r) + "A" + r + " " + r + " 0 0 1 " + (x + r) + " " + y + "Z"
    }

    Item {
        id: art
        width: 132
        height: 160
        scale: lumi.height / 160
        transformOrigin: Item.TopLeft

        // Beam: two triangles leaving the lamp, swung around its centre. Each mood moves it differently.
        Shape {
            id: beam
            objectName: "lumiBeam"
            x: 6
            preferredRendererType: Shape.CurveRenderer
            property real level: 1      // opacity factor (breathe)
            property real angle: 0      // degrees around the lamp (sway, sweep)
            property real shift: 0      // px (tremble)
            opacity: lumi.look.beam === "off" || !lumi.lit ? 0 : Math.min(1, level)
            transform: [Rotation { origin.x: 60; origin.y: 47; angle: beam.angle }, Translate { x: beam.shift }]
            ShapePath {
                fillColor: Qt.rgba(lumi.lampColor.r, lumi.lampColor.g, lumi.lampColor.b, 0.32)
                strokeColor: "transparent"
                PathSvg { path: "M78 50L126 30V70Z M42 50L-6 30V70Z" }
            }
        }

        Shape {
            x: 6    // the viewBox starts at x = -6
            preferredRendererType: Shape.CurveRenderer

            // the quay it stands on
            ShapePath { fillColor: lumi.bruma; strokeColor: "transparent"; PathSvg { path: lumi.roundRect(26, 148, 68, 10, 5) } }
            // the tower: wide, two dark stripes, its outline drawn over them
            ShapePath { fillColor: lumi.espuma; strokeColor: "transparent"; PathSvg { path: "M41 64H79L87 150H33Z" } }
            ShapePath { fillColor: lumi.ardosia; strokeColor: "transparent"; PathSvg { path: "M38.95 86H81.05L82.53 102H37.47ZM35.79 120H84.21L85.7 136H34.3Z" } }
            ShapePath {
                fillColor: "transparent"; strokeColor: lumi.mare; strokeWidth: 2.5; joinStyle: ShapePath.RoundJoin
                PathSvg { path: "M41 64H79L87 150H33Z" }
            }
            // gallery, lamp house (the face) and roof
            ShapePath {
                fillColor: lumi.ardosia; strokeColor: lumi.mare; strokeWidth: 2.5; joinStyle: ShapePath.RoundJoin
                PathSvg { path: lumi.roundRect(34, 60, 52, 8, 4) }
            }
            ShapePath {
                fillColor: lumi.lampColor; strokeColor: lumi.mare; strokeWidth: 2.5; joinStyle: ShapePath.RoundJoin
                PathSvg { path: lumi.roundRect(42, 30, 36, 30, 10) }
            }
            ShapePath {
                fillColor: lumi.ardosia; strokeColor: lumi.mare; strokeWidth: 2.5; joinStyle: ShapePath.RoundJoin
                PathSvg { path: "M36 32L60 11L84 32Z" }
            }
            ShapePath { fillColor: lumi.ardosia; strokeColor: "transparent"; PathSvg { path: lumi.circle(60, 8, 3.5) } }

            // Eyes
            ShapePath {   // open and wide: filled dots
                fillColor: lumi.mare; strokeColor: "transparent"
                PathSvg {
                    path: lumi.look.eyes === "open" ? lumi.circle(54, 47, 3) + lumi.circle(66, 47, 3)
                        : lumi.look.eyes === "wide" ? lumi.circle(54, 47, 4.2) + lumi.circle(66, 47, 4.2) + lumi.circle(60, 56, 2.6)
                        : ""
                }
            }
            ShapePath {   // mouth and closed/happy eyes: strokes
                fillColor: "transparent"; strokeColor: lumi.mare; strokeWidth: 2; capStyle: ShapePath.RoundCap
                PathSvg {
                    path: lumi.look.eyes === "open" ? "M56 54q4 3 8 0"
                        : lumi.look.eyes === "sleep" ? "M50 47q4 3 8 0M62 47q4 3 8 0M57 55h6"
                        : lumi.look.eyes === "happy" ? "M50 48q4-5 8 0M62 48q4-5 8 0M55 54q5 5 10 0"
                        : ""
                }
            }
        }

        Text {   // snoring
            visible: lumi.look.z
            x: 86 + 6; y: 14
            textFormat: Text.PlainText
            text: "z"; color: lumi.bruma; font.pixelSize: 16; font.weight: Font.ExtraBold
        }
        Text {
            visible: lumi.look.z
            x: 98 + 6; y: 4
            textFormat: Text.PlainText
            text: "z"; color: lumi.bruma; font.pixelSize: 11; font.weight: Font.ExtraBold
        }
    }
    // Beam animations: only one runs at a time, and none while hidden or with "reduce motion" on.
    component Swing: SequentialAnimation {
        id: swing
        property Item item
        property string prop
        property bool active: false
        property real amplitude
        property int half
        property real rest: 0
        running: active
        loops: Animation.Infinite
        NumberAnimation { target: swing.item; property: swing.prop; from: swing.rest - swing.amplitude; to: swing.rest + swing.amplitude; duration: swing.half; easing.type: Easing.InOutSine }
        NumberAnimation { target: swing.item; property: swing.prop; from: swing.rest + swing.amplitude; to: swing.rest - swing.amplitude; duration: swing.half; easing.type: Easing.InOutSine }
        onRunningChanged: if (!running) item[prop] = rest
    }
    Swing { item: beam; active: lumi.animated && lumi.look.beam === "breathe"; prop: "level"; rest: 1; amplitude: 0.3; half: 1200 }   // 0.7 .. 1.3 of the base 0.32
    Swing { item: beam; active: lumi.animated && lumi.look.beam === "sway"; prop: "angle"; amplitude: 8; half: 1500 }
    Swing { item: beam; active: lumi.animated && lumi.look.beam === "sweep"; prop: "angle"; amplitude: 18; half: 1000 }
    Swing { item: beam; active: lumi.animated && lumi.look.beam === "tremble"; prop: "shift"; amplitude: 1.5; half: 60 }
}
