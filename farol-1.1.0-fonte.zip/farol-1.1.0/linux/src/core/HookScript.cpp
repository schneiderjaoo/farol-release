#include "HookScript.h"

#include "Paths.h"

#include <QFile>
#include <QFileInfo>
#include <QSaveFile>

namespace farol {

namespace {
constexpr QFile::Permissions kExecutable = QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner | QFile::ReadGroup |
                                           QFile::ExeGroup | QFile::ReadOther | QFile::ExeOther;   // 0755
}

bool installHookScript(const QByteArray &content, const QString &dest, QString *error)
{
    auto fail = [&](const QString &m) {
        if (error)
            *error = m;
        return false;
    };
    const QString folder = QFileInfo(dest).absolutePath();
    if (!Paths::ensurePrivateDir(folder))
        return fail(QStringLiteral("cannot create ") + folder);

    QFile existing(dest);
    if (existing.open(QIODevice::ReadOnly)) {
        const bool same = existing.readAll() == content;
        existing.close();
        if (same)
            return QFile::setPermissions(dest, kExecutable) || fail(QStringLiteral("cannot chmod ") + dest);
    }
    QSaveFile out(dest);
    if (!out.open(QIODevice::WriteOnly))
        return fail(QStringLiteral("cannot write ") + dest + QStringLiteral(": ") + out.errorString());
    out.write(content);
    if (!out.commit())
        return fail(QStringLiteral("cannot write ") + dest + QStringLiteral(": ") + out.errorString());
    return QFile::setPermissions(dest, kExecutable) || fail(QStringLiteral("cannot chmod ") + dest);
}

} // namespace farol
