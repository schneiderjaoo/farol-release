#pragma once
#include <QJsonObject>
#include <QList>
#include <QPair>
#include <QString>
#include <optional>

namespace farol {

// One line written by farol-hook: the Claude Code hook payload plus the context farol-hook added.
struct HookEvent {
    QString name;                 // hook_event_name
    QString sessionId;            // "unknown" when absent
    QString cwd;
    QString transcriptPath;       // the session's .jsonl: the name Claude Code gave the session is in there
    QString source;               // farol_source: "vscodium" | "konsole" | "terminal" | ""
    QString flatpakId;
    QString editor;               // farol_editor: the editor's program when it is not a Flatpak ("code", "cursor", ...)
    QList<QPair<qint64, qint64>> ancestors;   // farol_ancestors: (pid, start time) of the processes above Claude Code
    QString konsoleService, konsoleSession, konsoleWindow;
    QString toolName;
    QJsonObject toolInput;
    QString toolUseId;            // tool_use_id: the same in the PreToolUse and the PostToolUse of one call
    QJsonObject toolResponse;     // PostToolUse: what the tool gave back, when it is an object
    // farol_edit: the lines an edit added and removed, as farol-hook counted them before cutting the patch
    // (-1: it did not say), and whether it cut what it sent.
    int editAdded = -1, editRemoved = -1;
    bool editCut = false;
    QString prompt;               // UserPromptSubmit
    QString message;              // Notification
    QString notificationType;
    QString lastAssistantMessage; // Stop
    QString errorType;            // StopFailure: "rate_limit", "server_error", ...
    QString errorMessage;         // StopFailure
    qint64 claudePid = 0;         // the Claude Code process as farol-hook sees it (its own PID namespace); 0 = unknown
    qint64 claudeStart = 0;       // start time of that process: clock ticks since boot, the same in every namespace

    // nullopt when the line is not a JSON object with a non-empty string hook_event_name.
    static std::optional<HookEvent> parse(const QByteArray &line);
    // Alias of the cwd folder name; "Session" when there is no folder.
    QString project() const;
};

QString projectAlias(const QString &folder);
// "Runs · npm test": what the ticker shows for a tool call (PreToolUse).
QString stepLabel(const QString &tool, const QJsonObject &input);
// Single line, trimmed, cut to max characters.
QString clip(const QString &s, int max);
// A Markdown message of Claude's as the few lines of plain text a card has room for: no code blocks, tables or
// rules, no markers (a bullet becomes "• "), links and images by their text, and none of the characters that draw
// nothing or turn the text around. HTML stays as it was written: it is shown as text. Ends with "…" when the
// message had more to say.
QString plainMessage(const QString &markdown, int maxLines = 4, int maxChars = 300);

} // namespace farol
