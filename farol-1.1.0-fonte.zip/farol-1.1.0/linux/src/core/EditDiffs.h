#pragma once
#include "EditDiff.h"

#include <QHash>
#include <QList>
#include <QObject>
#include <QString>
#include <QVariantList>

namespace farol {

class AppState;
class IslandController;

// The diffs of the edits the sessions made, for the island to show (DiffView.qml): the last kPerSession of each
// session, in memory only, gone when the session ends. Opening one copies it, so the diff on screen stays whole
// while newer edits push it out of the store. A session goes by the id of its task (AgentTask::id), which is what
// QML has. Nothing here runs unless a hook line arrives or the user clicks.
class EditDiffs : public QObject {
    Q_OBJECT
    // The diff that is open (a copy).
    Q_PROPERTY(bool active READ active NOTIFY currentChanged)
    Q_PROPERTY(qint64 id READ id NOTIFY currentChanged)
    Q_PROPERTY(QString file READ file NOTIFY currentChanged)
    Q_PROPERTY(QString fileName READ fileName NOTIFY currentChanged)
    Q_PROPERTY(QString session READ session NOTIFY sessionChanged)   // what the island calls its session now
    Q_PROPERTY(bool created READ created NOTIFY currentChanged)
    Q_PROPERTY(int added READ added NOTIFY currentChanged)
    Q_PROPERTY(int removed READ removed NOTIFY currentChanged)
    Q_PROPERTY(bool cut READ cut NOTIFY currentChanged)
    Q_PROPERTY(QVariantList rows READ rows NOTIFY currentChanged)    // {kind: " " | "+" | "-" | "@", text}
    Q_PROPERTY(int columns READ columns NOTIFY currentChanged)       // the length of its longest row
    // Where it is among the diffs its session keeps: 0 is the oldest, -1 when it was pushed out meanwhile.
    Q_PROPERTY(int position READ position NOTIFY changed)
    Q_PROPERTY(int count READ count NOTIFY changed)
    // Changes whenever has() or kept() may answer something else: a binding that reads it is evaluated again.
    Q_PROPERTY(int revision READ revision NOTIFY changed)

public:
    static constexpr int kPerSession = 20;

    EditDiffs(AppState *state, IslandController *controller, QObject *parent = nullptr);

    // Keeps the diff (the oldest of that session leaves when it has kPerSession) and returns its id, which no
    // other diff ever had.
    qint64 add(const QString &session, const EditDiff &diff);
    // The session ended: its diffs go, and the view too when it shows one of them.
    void forget(const QString &session);

    Q_INVOKABLE bool has(qint64 id) const;
    Q_INVOKABLE int kept(const QString &session) const;
    // Shows the diff in the island (view "diff"). false when it is not kept any more.
    Q_INVOKABLE bool open(qint64 id);
    Q_INVOKABLE bool openLatest(const QString &session);
    // From the open diff to an older (delta < 0) or a newer one of its session, as far as there are.
    Q_INVOKABLE void step(int delta);
    // Back to the overview. The diff stays kept.
    Q_INVOKABLE void close();

    bool active() const { return m_current.id != 0; }
    qint64 id() const { return m_current.id; }
    QString file() const { return m_current.diff.file; }
    QString fileName() const;
    QString session() const { return m_current.name; }
    bool created() const { return m_current.diff.created; }
    int added() const { return m_current.diff.added; }
    int removed() const { return m_current.diff.removed; }
    bool cut() const { return m_current.diff.cut; }
    QVariantList rows() const { return m_current.rows; }
    int columns() const { return m_current.columns; }
    int position() const;
    int count() const { return active() ? kept(m_current.session) : 0; }
    int revision() const { return m_revision; }

signals:
    void changed();
    void currentChanged();
    void sessionChanged();

private:
    struct Kept {
        qint64 id = 0;
        EditDiff diff;
    };
    struct Current {
        qint64 id = 0;
        QString session, name;
        EditDiff diff;
        QVariantList rows;
        int columns = 0;
    };
    const Kept *find(qint64 id, QString *session = nullptr) const;
    void show(const QString &session, const Kept &kept);
    QString nameOf(const QString &session) const;
    void drop();
    void touch();

    AppState *m_state;
    IslandController *m_controller;
    QHash<QString, QList<Kept>> m_kept;   // by session, oldest first
    Current m_current;
    qint64 m_nextId = 0;
    int m_revision = 0;
};

} // namespace farol
