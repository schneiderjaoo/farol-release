import QtQuick

// On/off switch: 36x20 track, sliding knob. Space and Enter toggle it while it has the keyboard focus.
Item {
    id: sw
    property bool checked: false
    signal toggled()

    implicitWidth: 36
    implicitHeight: 20
    width: implicitWidth
    height: implicitHeight
    activeFocusOnTab: true
    Accessible.role: Accessible.CheckBox
    Accessible.checked: checked

    function toggle() {
        checked = !checked
        toggled()
    }

    Rectangle {
        anchors.fill: parent
        radius: height / 2
        color: sw.checked ? theme.lamp : theme.pillFill
        border.width: sw.activeFocus ? 2 : 1
        border.color: sw.activeFocus ? theme.text : theme.line
        Behavior on color { ColorAnimation { duration: 120 } }
        Rectangle {
            width: 14
            height: 14
            radius: 7
            y: 3
            x: sw.checked ? parent.width - width - 3 : 3
            color: sw.checked ? "#0E2A47" : theme.muted
            Behavior on x { NumberAnimation { duration: 120; easing.type: Easing.OutCubic } }
        }
    }
    Keys.onSpacePressed: toggle()
    Keys.onReturnPressed: toggle()
    TapHandler { onTapped: { sw.forceActiveFocus(); sw.toggle() } }
}
