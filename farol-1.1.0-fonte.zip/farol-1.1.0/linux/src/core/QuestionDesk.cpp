#include "QuestionDesk.h"

#include <QVariantMap>

namespace farol {

namespace {
// Something to click: every question has a text and at least one labelled option.
bool usable(const QJsonArray &questions)
{
    if (questions.isEmpty())
        return false;
    for (const QJsonValue &v : questions) {
        const QJsonObject q = v.toObject();
        if (q.value("question").toString().isEmpty())
            return false;
        const QJsonArray options = q.value("options").toArray();
        if (options.isEmpty())
            return false;
        for (const QJsonValue &o : options)
            if (o.toObject().value("label").toString().isEmpty())
                return false;
    }
    return true;
}
} // namespace

QuestionDesk::QuestionDesk(IScheduler &scheduler, QObject *parent) : QObject(parent), m_sched(scheduler) {}

QuestionDesk::~QuestionDesk() { m_sched.cancel(m_timer); }

qint64 QuestionDesk::hold(const QString &sessionId, const QString &project, const QJsonObject &toolInput, Reply reply)
{
    const QJsonArray questions = toolInput.value("questions").toArray();
    if (active() || !usable(questions))
        return 0;
    m_id = ++m_nextId;
    m_sessionId = sessionId;
    m_project = project;
    m_input = toolInput;
    m_questions = questions;
    m_answers = QJsonObject();
    m_selected.clear();
    m_index = 0;
    m_reply = std::move(reply);
    m_timer = m_sched.singleShot(kTimeoutMs, [this] {
        m_timer = 0;
        finish(QJsonObject(), true);
    });
    emit changed();
    return m_id;
}

QStringList QuestionDesk::labels() const
{
    QStringList out;
    for (const QJsonValue &o : current().value("options").toArray())
        out << o.toObject().value("label").toString();
    return out;
}

QVariantList QuestionDesk::options() const
{
    QVariantList out;
    for (const QJsonValue &v : current().value("options").toArray()) {
        const QJsonObject o = v.toObject();
        const QString label = o.value("label").toString();
        out << QVariantMap{{"label", label}, {"description", o.value("description").toString()},
                           {"selected", m_selected.contains(label)}};
    }
    return out;
}

void QuestionDesk::choose(const QString &label)
{
    if (!active() || !labels().contains(label))
        return;
    if (!multiSelect()) {
        answer(label);
        return;
    }
    if (!m_selected.removeOne(label))
        m_selected << label;
    emit changed();
}

void QuestionDesk::confirm()
{
    if (!active() || !multiSelect() || m_selected.isEmpty())
        return;
    QStringList ordered;   // in the order of the options, not of the clicks
    for (const QString &l : labels())
        if (m_selected.contains(l))
            ordered << l;
    answer(ordered.join(QStringLiteral(", ")));
}

void QuestionDesk::answer(const QString &text)
{
    m_answers.insert(question(), text);
    m_selected.clear();
    if (m_index + 1 < m_questions.size()) {
        ++m_index;
        emit changed();
        return;
    }
    QJsonObject updated = m_input;
    updated.insert("answers", m_answers);
    finish(updated, true);
}

void QuestionDesk::release() { finish(QJsonObject(), true); }

void QuestionDesk::cancel(qint64 id)
{
    if (id != 0 && id == m_id)
        finish(QJsonObject(), false);
}

void QuestionDesk::forget(const QString &sessionId)
{
    if (active() && m_sessionId == sessionId)
        finish(QJsonObject(), true);
}

void QuestionDesk::finish(const QJsonObject &updatedInput, bool reply)
{
    if (!active())
        return;
    m_sched.cancel(m_timer);
    m_timer = 0;
    const Reply r = std::move(m_reply);
    const QString sid = m_sessionId;
    m_reply = nullptr;
    m_id = 0;
    m_sessionId.clear();
    m_project.clear();
    m_input = QJsonObject();
    m_questions = QJsonArray();
    m_answers = QJsonObject();
    m_selected.clear();
    m_index = 0;
    if (reply && r)
        r(updatedInput);
    emit changed();
    emit finished(sid, !updatedInput.isEmpty());
}

} // namespace farol
