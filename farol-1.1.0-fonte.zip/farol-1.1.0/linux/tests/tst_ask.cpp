#include <QtTest>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "Ask.h"
#include "FakeAsk.h"
#include "FakeCommandRunner.h"

using namespace farol;

class TestAsk : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<FakeSecretStore> wallet;
    std::unique_ptr<FakeHttpClient> http;
    std::unique_ptr<FakeCommandRunner> runner;
    std::unique_ptr<Ask> ask;
    QString claude;                    // where "Claude Code is installed"; empty: it is not

    QString write(const QString &name, const QByteArray &data)
    {
        QFile f(dir.path() + "/" + name);
        f.open(QIODevice::WriteOnly);
        f.write(data);
        return f.fileName();
    }
    void fresh()
    {
        ask = std::make_unique<Ask>(settings.get(), wallet.get(), http.get(), runner.get(), [this] { return claude; }, QStringLiteral("/usr/bin"));
    }
    static QString reply(const QString &text)
    {
        return QString::fromUtf8(QJsonDocument(QJsonObject{{"type", "result"}, {"is_error", false}, {"result", text}}).toJson(QJsonDocument::Compact)) + "\n";
    }

private slots:
    void init()
    {
        QFile::remove(dir.path() + "/a.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/a.ini", QSettings::IniFormat);
        wallet = std::make_unique<FakeSecretStore>();
        http = std::make_unique<FakeHttpClient>();
        runner = std::make_unique<FakeCommandRunner>();
        claude = "/opt/claude/bin/claude";
        settings->setValue("ai/provider", "anthropic");   // most of these tests are about a service with a key
        fresh();
    }
    // Claude Code is the service of someone who never opened Settings -> IA: it needs no key.
    void claudeCodeIsTheDefaultAndNeedsNoKey()
    {
        settings->remove("ai/provider");
        fresh();
        QCOMPARE(ask->provider(), QString("claude"));
        QVERIFY(!ask->needsKey());
        QVERIFY(ask->ready());
        QVERIFY(ask->claudeFound());
        ask->saveKey("claude", "sk-ant-oat-token");         // there is no key to keep for it
        QVERIFY(wallet->values.isEmpty());
        ask->setProvider("openai");
        QVERIFY(ask->needsKey());
        QVERIFY(!ask->ready());
        claude.clear();
        QVERIFY(!ask->claudeFound());
    }
    void claudeCodeAnswersWithoutAKey()
    {
        ask->setProvider("claude");
        ask->setModel("claude", "sonnet");
        ask->addFile(write("a.txt", "conteúdo"));
        QSignalSpy answered(ask.get(), &Ask::answered);
        ask->ask("O que é isto?");
        QVERIFY(ask->busy());
        QCOMPARE(http->calls.size(), 0);                    // no request of Farol's own
        QCOMPARE(wallet->reads, 0);
        QCOMPARE(runner->calls.size(), 1);
        const auto &call = runner->calls.last();
        QCOMPARE(call.program, QString("/opt/claude/bin/claude"));
        QCOMPARE(call.arguments, claudeArguments("sonnet"));
        QCOMPARE(call.env, QStringList{"PATH=" + QDir::toNativeSeparators(QFileInfo(claude).absolutePath()) + QDir::listSeparator() + "/usr/bin"});
        QCOMPARE(call.timeoutMs, int(Ask::kTimeoutMs));
        QVERIFY(call.input.contains("O que \u00e9 isto?") || call.input.contains("O que é isto?"));
        QVERIFY(call.input.contains("a.txt"));
        runner->answer(0, {}, reply("Um texto."));
        QVERIFY(!ask->busy());
        QCOMPARE(answered.count(), 1);
        QCOMPARE(ask->turns().size(), 2);
        QCOMPARE(ask->turns()[1].toMap()["text"].toString(), QString("Um texto."));
        ask->ask("E depois?");                              // the conversation goes along
        QVERIFY(runner->calls.last().input.contains("Um texto."));
    }
    void claudeCodeFailuresGiveTheQuestionBack()
    {
        ask->setProvider("claude");
        QSignalSpy failed(ask.get(), &Ask::failed);
        ask->ask("oi?");
        runner->answer(1, "boom\n");
        QVERIFY(!ask->busy());
        QVERIFY(ask->error().contains("boom"));
        QCOMPARE(ask->turns().size(), 0);
        QCOMPARE(failed.last().at(0).toString(), QString("oi?"));
        ask->ask("oi?");
        ICommandRunner::Result r;
        r.started = true;
        r.timedOut = true;
        runner->finish(r);
        QVERIFY(ask->error().contains("3 minutos"));
        ask->ask("oi?");
        runner->finish(ICommandRunner::Result{});           // it could not be started
        QVERIFY(ask->error().contains("Claude Code"));
        QCOMPARE(runner->calls.size(), 3);
        claude.clear();                                     // not installed: nothing is run
        ask->ask("oi?");
        QCOMPARE(runner->calls.size(), 3);
        QVERIFY(ask->error().contains("Não encontrei"));
        QCOMPARE(failed.count(), 4);
        QVERIFY(!ask->busy());
    }
    void claudeCodeCancelled()
    {
        ask->setProvider("claude");
        ask->ask("um");
        ask->cancel();
        QCOMPARE(runner->cancels, 1);
        QCOMPARE(http->cancels, 0);
        QVERIFY(!ask->busy());
        QVERIFY(ask->error().isEmpty());
        runner->answer(-1);                                 // the killed process reports: dropped
        QVERIFY(ask->error().isEmpty());
        QCOMPARE(ask->turns().size(), 0);
        ask->ask("dois");
        ask->clear();
        QCOMPARE(runner->cancels, 2);
        runner->answer(0, {}, reply("tarde"));
        QCOMPARE(ask->turns().size(), 0);
    }
    void keysLiveInTheWalletOnly()
    {
        QCOMPARE(ask->provider(), QString("anthropic"));
        QVERIFY(!ask->hasKey());
        ask->saveKey("anthropic", "  sk-ant-secret \n");
        QVERIFY(ask->hasKey());
        QCOMPARE(wallet->values.value("anthropic"), QString("sk-ant-secret"));
        settings->sync();
        QFile conf(dir.path() + "/a.ini");
        QVERIFY(conf.open(QIODevice::ReadOnly));
        QVERIFY2(!conf.readAll().contains("sk-ant-secret"), "the key must never reach farol.conf");
        fresh();                                    // another run: it remembers which services have a key
        QVERIFY(ask->hasKey());
        QCOMPARE(wallet->reads, 0);                 // ...without opening the wallet
        ask->setProvider("gemini");
        QVERIFY(!ask->hasKey());
        ask->removeKey("anthropic");
        ask->setProvider("anthropic");
        QVERIFY(!ask->hasKey());
        QVERIFY(!wallet->values.contains("anthropic"));
    }
    // A token of the Claude subscription is not an API key: the web API refuses it, so it is not kept.
    void aSubscriptionTokenIsNotAnApiKey()
    {
        ask->saveKey("anthropic", " sk-ant-oat01-abcdef ");
        QVERIFY(!ask->hasKey());
        QVERIFY(wallet->values.isEmpty());
        QVERIFY(ask->keyError().contains("Claude Code"));
        ask->saveKey("anthropic", "sk-ant-api03-abcdef");
        QVERIFY(ask->hasKey());
        QVERIFY(ask->keyError().isEmpty());
    }
    void aWalletThatRefusesIsSaid()
    {
        wallet->failing = true;
        ask->saveKey("openai", "sk-1");
        QVERIFY(!ask->keys().contains("openai"));
        QVERIFY(!ask->keyError().isEmpty());
        ask->saveKey("openai", "   ");
        QVERIFY(!ask->keyError().isEmpty());
    }
    void providerAndModelAreKept()
    {
        ask->setProvider("openai");
        QCOMPARE(ask->models().size(), 3);                       // three to pick from, the default among them
        const QString mini = ask->models()[1].toMap()["id"].toString();
        QVERIFY(mini != aiDefaultModel("openai"));
        ask->setModel("openai", mini);
        ask->setModel("openai", "gpt-made-up");                  // only a listed one is taken
        ask->setProvider("nope");
        fresh();
        QCOMPARE(ask->provider(), QString("openai"));
        QCOMPARE(ask->model(), mini);
        QCOMPARE(ask->modelLabel(), ask->models()[1].toMap()["label"].toString());
        QCOMPARE(ask->modelOf("gemini"), aiDefaultModel("gemini"));
        settings->setValue("ai/model_openai", "gpt-retired");    // one that is no longer offered: the default again
        QCOMPARE(ask->model(), aiDefaultModel("openai"));
    }
    void filesByKind()
    {
        ask->addFile(write("a.cpp", "int main() {}\n"));
        ask->addFile(write("log.xyz", "plain words, odd extension"));
        ask->addFile(write("p.png", QByteArray("\x89PNG\r\n\x1a\n\0\0\0\rIHDR", 16)));
        ask->addFile(write("d.pdf", "%PDF-1.7\n\0\1\2 binary"));
        const QVariantList files = ask->files();
        QCOMPARE(files.size(), 4);
        QCOMPARE(files[0].toMap()["kind"].toString(), QString("texto"));
        QCOMPARE(files[1].toMap()["kind"].toString(), QString("texto"));
        QCOMPARE(files[2].toMap()["kind"].toString(), QString("imagem"));
        QCOMPARE(files[3].toMap()["kind"].toString(), QString("PDF"));
        QVERIFY(ask->notice().isEmpty());
        ask->removeFile(1);
        ask->removeFile(99);
        QCOMPARE(ask->files().size(), 3);
    }
    void whatCannotBeReadIsRefusedWithAReason()
    {
        ask->addFile(write("pack.bin", QByteArray("\x01\x02\0\xff\xfe binary", 16)));
        QCOMPARE(ask->files().size(), 0);
        QVERIFY(ask->notice().contains("pack.bin"));
        ask->addFile(dir.path());
        QVERIFY(ask->notice().contains("pastas"));
        ask->addFile(dir.path() + "/gone.txt");
        QCOMPARE(ask->files().size(), 0);
        ask->addFile(write("big.txt", QByteArray(Ask::kMaxTextBytes + 1, 'a')));
        QCOMPARE(ask->files().size(), 0);
        QVERIFY(ask->notice().contains("grande"));
        for (int i = 0; i < Ask::kMaxFiles + 2; ++i)
            ask->addFile(write(QString("f%1.txt").arg(i), "x"));
        QCOMPARE(ask->files().size(), int(Ask::kMaxFiles));
        QVERIFY(ask->notice().contains("máximo"));
        ask->addUrls({QUrl("https://example.com/x.txt")});      // only local files
        QCOMPARE(ask->files().size(), int(Ask::kMaxFiles));
    }
    void nothingIsSentWithoutAKey()
    {
        QSignalSpy failed(ask.get(), &Ask::failed);
        ask->ask("oi?");
        QCOMPARE(http->calls.size(), 0);
        QVERIFY(ask->error().contains("Ajustes"));
        QCOMPARE(failed.count(), 1);
        QCOMPARE(ask->turns().size(), 0);
    }
    void aQuestionAndItsAnswer()
    {
        ask->saveKey("anthropic", "sk-ant-1");
        ask->addFile(write("a.txt", "conteúdo"));
        QSignalSpy answered(ask.get(), &Ask::answered);
        ask->ask("  O que é isto? ");
        QVERIFY(ask->busy());
        QCOMPARE(http->calls.size(), 1);
        QCOMPARE(http->header("x-api-key"), QByteArray("sk-ant-1"));
        QCOMPARE(http->calls.last().timeoutMs, int(Ask::kTimeoutMs));
        ask->ask("outra");                               // one at a time
        QCOMPARE(http->calls.size(), 1);
        http->answer(200, R"({"content":[{"type":"text","text":"Um **texto**."}]})");
        QVERIFY(!ask->busy());
        QCOMPARE(answered.count(), 1);
        QCOMPARE(ask->turns().size(), 2);
        QCOMPARE(ask->turns()[0].toMap()["text"].toString(), QString("O que é isto?"));
        QCOMPARE(ask->turns()[1].toMap()["user"].toBool(), false);
        QCOMPARE(ask->turns()[1].toMap()["text"].toString(), QString("Um **texto**."));
        ask->ask("E depois?");                           // the conversation goes along
        const QJsonObject body = QJsonDocument::fromJson(http->calls.last().request.body).object();
        QCOMPARE(body["messages"].toArray().size(), 3);
    }
    // "Copiar" on an answer: the Markdown it came as goes to the app, which owns the clipboard.
    void copyingAnAnswerGivesItsMarkdown()
    {
        ask->setProvider("claude");
        QSignalSpy copied(ask.get(), &Ask::copyRequested);
        ask->copy(0);                                       // nothing there yet
        QCOMPARE(copied.count(), 0);
        ask->ask("Como somo a coluna?");
        const QString markdown = QStringLiteral("Use **awk**:\n\n```sh\nawk '{ s += $2 } END { print s }' a.csv\n```\n\nVeja a [documentação](https://example.com).");
        runner->answer(0, {}, reply(markdown));
        ask->copy(1);
        QCOMPARE(copied.count(), 1);
        QCOMPARE(copied.last().at(0).toString(), markdown);
        ask->copy(0);                                       // only an answer is copied this way
        ask->copy(2);
        ask->copy(-1);
        QCOMPARE(copied.count(), 1);
    }

    void aFailureGivesTheQuestionBack()
    {
        ask->saveKey("anthropic", "bad");
        QSignalSpy failed(ask.get(), &Ask::failed);
        ask->ask("oi?");
        http->answer(401, R"({"error":{"message":"invalid x-api-key"}})");
        QVERIFY(!ask->busy());
        QVERIFY(ask->error().contains("invalid x-api-key"));
        QVERIFY(ask->error().contains("recusou a chave"));          // said in the user's language...
        QVERIFY(ask->error().contains("Claude Code"));              // ...with the way out for who has the subscription
        QCOMPARE(ask->turns().size(), 0);
        QCOMPARE(failed.count(), 1);
        QCOMPARE(failed.last().at(0).toString(), QString("oi?"));
        ask->ask("oi?");
        QVERIFY(ask->error().isEmpty());
        IHttpClient::Reply r;
        r.timedOut = true;
        http->finish(r);
        QVERIFY(ask->error().contains("3 minutos"));
        ask->ask("oi?");
        r = {};
        r.error = "Host not found";
        http->finish(r);
        QVERIFY(ask->error().contains("Host not found"));
        wallet->failing = true;
        ask->ask("oi?");
        QVERIFY(ask->error().contains("cofre"));
        QCOMPARE(http->calls.size(), 3);
    }
    void cancelAndClear()
    {
        ask->saveKey("anthropic", "k");
        ask->addFile(write("a.txt", "x"));
        ask->ask("um");
        ask->cancel();
        QCOMPARE(http->cancels, 1);
        QVERIFY(!ask->busy());
        QVERIFY(ask->error().isEmpty());
        QCOMPARE(ask->turns().size(), 0);
        http->answer(200, R"({"content":[{"type":"text","text":"tarde demais"}]})");   // a late answer is dropped
        QCOMPARE(ask->turns().size(), 0);
        ask->ask("dois");
        http->answer(200, R"({"content":[{"type":"text","text":"ok"}]})");
        ask->ask("três");
        ask->clear();
        QVERIFY(!ask->busy());
        QCOMPARE(ask->turns().size(), 0);
        QCOMPARE(ask->files().size(), 0);
        http->answer(200, R"({"content":[{"type":"text","text":"tarde"}]})");
        QCOMPARE(ask->turns().size(), 0);
    }
};

QTEST_GUILESS_MAIN(TestAsk)
#include "tst_ask.moc"
