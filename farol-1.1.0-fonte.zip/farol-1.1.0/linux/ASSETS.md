# Farol — artwork and assets

## Farol's own
- The name **Farol** and the mascot **Lumi** (the little lighthouse), drawn in code in `qml/Lumi.qml`.
- The app icon (`resources/icons/`), the session signals, the interface icons and the colour palettes
  ("Noite no cais", "Amanhecer"), as described in `design/identidade-visual.html`.

The licence terms for these are still to be written by the project owner; until then nothing here is granted to anyone.

## Third-party
- **Bricolage Grotesque** and **Instrument Sans** (`resources/fonts/`), under the SIL Open Font License 1.1: see the
  `OFL-*.txt` files next to them.

## Not included
- **Sounds.** The app plays 28 short effects, but no sound files ship with this repository. Add your own (see
  `sounds/README.md`); without them Farol is silent.
- Nothing of the original Coucou artwork (its mascot, icons, sounds and media) is part of this repository.
