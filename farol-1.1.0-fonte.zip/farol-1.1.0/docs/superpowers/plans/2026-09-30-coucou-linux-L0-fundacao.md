# Coucou Linux — L0 Fundação + spike Wayland — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Criar o esqueleto de build do port Linux e provar, com programas pequenos e isolados, cada mecanismo arriscado do Wayland/KDE antes de investir na UI (L1).

**Architecture:** Um projeto CMake em `linux/` com a biblioteca `coucou_core` (sem UI, testada com Qt Test) e cinco probes em `linux/spikes/`. Cada probe é um executável mínimo que exercita um mecanismo e imprime o que aconteceu. O resultado do marco é `linux/docs/L0-findings.md`, com "funciona / não funciona / alternativa" por mecanismo — ele decide os detalhes do plano do L1.

**Tech Stack:** C++20, CMake 4.3 + Ninja, Qt 6.11 (Core, Gui, Quick, QuickControls2, Multimedia, DBus, Network, Test), LayerShellQt 6.7 (`LayerShellQt::Interface`), QtKeychain 0.16 (`Qt6Keychain::Qt6Keychain`), Python 3 (stdlib), script JavaScript do KWin 6.7.

**Spec:** `docs/superpowers/specs/2026-09-29-coucou-linux-design.md`

## Global Constraints

- Nada em `NotchBuddy/` é alterado. Todo código novo fica em `linux/`.
- C++20, Qt ≥ 6.8, sem dependências fora do repositório do Fedora 44.
- Todos os caminhos do app derivam de `$HOME`, nunca de `$XDG_DATA_HOME`/`$XDG_RUNTIME_DIR` (o Flatpak do VSCodium remapeia essas variáveis).
- Pasta de dados: `~/.local/share/coucou/` com permissão `0700`; socket `~/.local/share/coucou/nb.sock`.
- ID do app / nomes D-Bus / serviço do KWallet: prefixo `fr.louisraille.NotchBuddy`. Nos probes, use o sufixo `.Spike` para não colidir com o app real.
- O agente roda dentro do Flatpak do VSCodium: **todo build, teste e execução de GUI vai para o host via `linux/scripts/host.sh`**. Exceção proposital: o cliente Python do Task 5 roda também **dentro** do sandbox.
- Janela da ilha: 720 × 320, camada overlay, âncora no topo, zona exclusiva −1, teclado `None` por padrão.
- Curvas: abrir `[.32,1.22,.42,1]` 520 ms; fechar `[.45,0,.2,1]` 340 ms.
- Checagens marcadas com 👤 precisam do João (clicar, arrastar, olhar). O agente pede, espera a resposta e registra no findings.
- Commits na branch `feat/for-fedora`, terminando com o trailer `Co-Authored-By` que o harness da sessão especificar (os blocos de commit abaixo mostram um exemplo; troque pelo trailer da sua sessão).

## Review Focus

1. **`$HOME` longo ou com caracteres especiais** (o real é `/home/user`): o caminho do socket precisa caber em 107 bytes e o `@` não pode quebrar nada — teste `socketPathLimit` (Task 1) e o probe do Task 5 usa o `$HOME` real.
2. **Pasta de dados já existente com permissões abertas** (ex.: criada antes com `0755`): tem que ser apertada para `0700`, senão outro usuário conecta no socket — teste `ensurePrivateDirTightensExisting` (Task 1).
3. **App ausente quando o hook dispara**: o cliente não pode imprimir nada nem demorar mais que 0,5 s — cenário "servidor desligado" do Task 5, medido de dentro do sandbox.
4. **Socket órfão de uma execução anterior** (app morto sem apagar `nb.sock`): o servidor tem que conseguir escutar de novo — cenário "arquivo de socket velho" do Task 5.
5. **Script do KWin que fica carregado depois que o app sai** (crash ou Ctrl+C): tem que ser descarregado no próximo início, senão o KWin continua chamando D-Bus para ninguém — o probe do Task 6 descarrega antes de carregar e o cenário "segunda execução" verifica.

---

## File Structure

```
linux/
  CMakeLists.txt                     projeto raiz, opções, subdiretórios
  .gitignore                         build/
  scripts/host.sh                    executa no host quando dentro do Flatpak
  scripts/measure.sh                 CPU% e PSS de um PID
  src/core/CMakeLists.txt            biblioteca coucou_core
  src/core/Paths.h / Paths.cpp       caminhos derivados de $HOME + pasta privada
  tests/CMakeLists.txt               registra testes no ctest
  tests/tst_paths.cpp                testes do Paths
  spikes/CMakeLists.txt              agrega os probes
  spikes/island/                     Task 2 e 3: layer surface, máscara, foco, DnD
    CMakeLists.txt  main.cpp  IslandProbe.h  IslandProbe.cpp  Island.qml
  spikes/services/                   Task 4: som e KWallet
    CMakeLists.txt  main.cpp
  spikes/hooksocket/                 Task 5: socket visto do Flatpak
    CMakeLists.txt  server.cpp  probe_client.py
  spikes/kwinbridge/                 Task 6: script do KWin ↔ D-Bus
    CMakeLists.txt  main.cpp  BridgeReceiver.h  BridgeReceiver.cpp
    coucou-bridge-spike/metadata.json  coucou-bridge-spike/contents/code/main.js
  docs/L0-findings.md                resultado do marco
CLAUDE.md                            nova seção "Linux port"
```

---

### Task 1: Esqueleto CMake, `host.sh` e `Paths`

**Files:**
- Create: `linux/CMakeLists.txt`, `linux/.gitignore`, `linux/scripts/host.sh`, `linux/src/core/CMakeLists.txt`, `linux/src/core/Paths.h`, `linux/src/core/Paths.cpp`, `linux/tests/CMakeLists.txt`, `linux/tests/tst_paths.cpp`, `linux/spikes/CMakeLists.txt`

**Interfaces:**
- Produces: target CMake `coucou_core`; classe `coucou::Paths` com `static QString home()`, `dataDir()`, `socketPath()`, `hookScriptPath()`, `inboxDir()`, `configFile()`, `logFile()`, `claudeSettingsPath()`, `static bool ensurePrivateDir(const QString &path)`, `static bool fitsUnixSocket(const QString &path)`; script `linux/scripts/host.sh <cmd...>`.

- [ ] **Step 1: Criar `host.sh` e o CMake raiz**

`linux/scripts/host.sh`:
```sh
#!/bin/sh
# Runs a command on the host session. Inside the VSCodium Flatpak (/.flatpak-info exists)
# the toolchain and the Wayland/D-Bus session live on the host, so we hop out with flatpak-spawn.
if [ -f /.flatpak-info ]; then
    exec flatpak-spawn --host "$@"
fi
exec "$@"
```

`linux/.gitignore`:
```
build/
```

`linux/CMakeLists.txt`:
```cmake
cmake_minimum_required(VERSION 3.25)
project(Coucou VERSION 0.1 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

find_package(Qt6 6.8 REQUIRED COMPONENTS Core Gui Quick QuickControls2 Multimedia DBus Network Test)
qt_standard_project_setup(REQUIRES 6.8)

option(COUCOU_BUILD_SPIKES "Build the L0 Wayland probes" ON)

enable_testing()
add_subdirectory(src/core)
add_subdirectory(tests)
if(COUCOU_BUILD_SPIKES)
    add_subdirectory(spikes)
endif()
```

`linux/spikes/CMakeLists.txt` (os probes são adicionados nas próximas tasks):
```cmake
# L0 probes — one subdirectory per mechanism under test.
```

Run: `chmod +x linux/scripts/host.sh`

- [ ] **Step 2: Escrever o teste que falha**

`linux/tests/CMakeLists.txt`:
```cmake
qt_add_executable(tst_paths tst_paths.cpp)
target_link_libraries(tst_paths PRIVATE coucou_core Qt6::Test)
add_test(NAME tst_paths COMMAND tst_paths)
```

`linux/tests/tst_paths.cpp`:
```cpp
#include <QtTest>
#include <QDir>
#include <QTemporaryDir>
#include <QFileInfo>
#include <QFile>
#include "Paths.h"

using coucou::Paths;

namespace {
constexpr QFile::Permissions kGroupOrOther =
    QFile::ReadGroup | QFile::WriteGroup | QFile::ExeGroup |
    QFile::ReadOther | QFile::WriteOther | QFile::ExeOther;
constexpr QFile::Permissions kOwnerRwx = QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner;
}

class TestPaths : public QObject {
    Q_OBJECT
private slots:
    void derivesFromHomeNotXdg() {
        QTemporaryDir tmp;
        QVERIFY(tmp.isValid());
        qputenv("HOME", tmp.path().toUtf8());
        qputenv("XDG_DATA_HOME", "/elsewhere/data");
        qputenv("XDG_CONFIG_HOME", "/elsewhere/config");
        qputenv("XDG_RUNTIME_DIR", "/elsewhere/run");

        QCOMPARE(Paths::home(), tmp.path());
        QCOMPARE(Paths::dataDir(), tmp.path() + "/.local/share/coucou");
        QCOMPARE(Paths::socketPath(), tmp.path() + "/.local/share/coucou/nb.sock");
        QCOMPARE(Paths::hookScriptPath(), tmp.path() + "/.local/share/coucou/nb-hook");
        QCOMPARE(Paths::inboxDir(), tmp.path() + "/.local/share/coucou/inbox");
        QCOMPARE(Paths::configFile(), tmp.path() + "/.config/coucou/coucou.conf");
        QCOMPARE(Paths::logFile(), tmp.path() + "/.local/state/coucou/coucou.log");
        QCOMPARE(Paths::claudeSettingsPath(), tmp.path() + "/.claude/settings.json");
    }

    void homeWithAtSign() {
        QTemporaryDir tmp;
        const QString home = tmp.path() + "/first.last@corp.example";
        QVERIFY(QDir().mkpath(home));
        qputenv("HOME", home.toUtf8());
        QCOMPARE(Paths::socketPath(), home + "/.local/share/coucou/nb.sock");
        QVERIFY(Paths::ensurePrivateDir(Paths::dataDir()));
        QVERIFY(QFileInfo(Paths::dataDir()).isDir());
    }

    void ensurePrivateDirCreatesWith0700() {
        QTemporaryDir tmp;
        const QString dir = tmp.path() + "/a/b/coucou";
        QVERIFY(Paths::ensurePrivateDir(dir));
        const auto perms = QFileInfo(dir).permissions();
        QCOMPARE(perms & kOwnerRwx, kOwnerRwx);
        QCOMPARE(perms & kGroupOrOther, QFile::Permissions());
    }

    void ensurePrivateDirTightensExisting() {
        QTemporaryDir tmp;
        const QString dir = tmp.path() + "/coucou";
        QVERIFY(QDir().mkpath(dir));
        QVERIFY(QFile::setPermissions(dir, kOwnerRwx | QFile::ReadGroup | QFile::ExeGroup |
                                               QFile::ReadOther | QFile::ExeOther));
        QVERIFY(Paths::ensurePrivateDir(dir));
        QCOMPARE(QFileInfo(dir).permissions() & kGroupOrOther, QFile::Permissions());
    }

    void socketPathLimit() {
        // sockaddr_un.sun_path is 108 bytes including the terminating NUL.
        QVERIFY(Paths::fitsUnixSocket(QString(107, 'a')));
        QVERIFY(!Paths::fitsUnixSocket(QString(108, 'a')));
        QVERIFY(Paths::fitsUnixSocket("/home/user/.local/share/coucou/nb.sock"));
    }
};

QTEST_APPLESS_MAIN(TestPaths)
#include "tst_paths.moc"
```

`linux/src/core/CMakeLists.txt` (só o alvo, sem fontes ainda para o teste falhar na compilação):
```cmake
add_library(coucou_core STATIC Paths.cpp)
target_include_directories(coucou_core PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})
target_link_libraries(coucou_core PUBLIC Qt6::Core)
```

- [ ] **Step 3: Rodar e confirmar que falha**

Run:
```sh
linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja -DCMAKE_BUILD_TYPE=Debug
linux/scripts/host.sh cmake --build linux/build
```
Expected: FAIL — `Paths.cpp` / `Paths.h` não existem.

- [ ] **Step 4: Implementar `Paths`**

`linux/src/core/Paths.h`:
```cpp
#pragma once
#include <QString>

namespace coucou {

// Every path derives from $HOME, never from XDG_* variables: inside the VSCodium
// Flatpak those point to ~/.var/app/... and /run/user/UID is not shared, so the
// hook (sandbox) and the app (host) would disagree on where the socket lives.
struct Paths {
    static QString home();
    static QString dataDir();            // ~/.local/share/coucou
    static QString socketPath();         // ~/.local/share/coucou/nb.sock
    static QString hookScriptPath();     // ~/.local/share/coucou/nb-hook
    static QString inboxDir();           // ~/.local/share/coucou/inbox
    static QString configFile();         // ~/.config/coucou/coucou.conf
    static QString logFile();            // ~/.local/state/coucou/coucou.log
    static QString claudeSettingsPath(); // ~/.claude/settings.json

    // mkdir -p, then force mode 0700 (also on a directory that already existed).
    static bool ensurePrivateDir(const QString &path);
    // sockaddr_un.sun_path holds 108 bytes including the terminating NUL.
    static bool fitsUnixSocket(const QString &path);
};

} // namespace coucou
```

`linux/src/core/Paths.cpp`:
```cpp
#include "Paths.h"

#include <QDir>
#include <QFile>

namespace coucou {

QString Paths::home()
{
    const QString h = qEnvironmentVariable("HOME");
    return h.isEmpty() ? QDir::homePath() : h;
}

QString Paths::dataDir() { return home() + QStringLiteral("/.local/share/coucou"); }
QString Paths::socketPath() { return dataDir() + QStringLiteral("/nb.sock"); }
QString Paths::hookScriptPath() { return dataDir() + QStringLiteral("/nb-hook"); }
QString Paths::inboxDir() { return dataDir() + QStringLiteral("/inbox"); }
QString Paths::configFile() { return home() + QStringLiteral("/.config/coucou/coucou.conf"); }
QString Paths::logFile() { return home() + QStringLiteral("/.local/state/coucou/coucou.log"); }
QString Paths::claudeSettingsPath() { return home() + QStringLiteral("/.claude/settings.json"); }

bool Paths::ensurePrivateDir(const QString &path)
{
    if (!QDir().mkpath(path))
        return false;
    return QFile::setPermissions(path, QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
}

bool Paths::fitsUnixSocket(const QString &path)
{
    return path.toUtf8().size() < 108;
}

} // namespace coucou
```

- [ ] **Step 5: Rodar e confirmar que passa**

Run:
```sh
linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: `100% tests passed, 0 tests failed out of 1`.

- [ ] **Step 6: Commit**

```sh
git add linux/CMakeLists.txt linux/.gitignore linux/scripts/host.sh linux/src/core linux/tests linux/spikes/CMakeLists.txt
git commit -m "linux: CMake skeleton, host.sh and HOME-based Paths

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 2: Probe da ilha — layer surface, região de clique, foco

**Files:**
- Create: `linux/spikes/island/CMakeLists.txt`, `linux/spikes/island/main.cpp`, `linux/spikes/island/IslandProbe.h`, `linux/spikes/island/IslandProbe.cpp`, `linux/spikes/island/Island.qml`
- Modify: `linux/spikes/CMakeLists.txt`

**Interfaces:**
- Consumes: nada do core.
- Produces: executável `probe-island` (flags `--hot-strip`, usada no Task 3); classe `IslandProbe` (QObject) com `Q_INVOKABLE void setInputRect(qreal x, qreal y, qreal w, qreal h)` e `Q_INVOKABLE void setKeyboardOnDemand(bool on)` — padrão que o L1 vai promover para `src/platform/IslandWindow`.

- [ ] **Step 1: CMake do probe**

`linux/spikes/CMakeLists.txt` — acrescentar:
```cmake
add_subdirectory(island)
```

`linux/spikes/island/CMakeLists.txt`:
```cmake
find_package(LayerShellQt REQUIRED)

qt_add_executable(probe-island main.cpp IslandProbe.cpp IslandProbe.h)
qt_add_qml_module(probe-island
    URI Spike
    QML_FILES Island.qml
)
target_link_libraries(probe-island PRIVATE
    Qt6::Gui Qt6::Quick Qt6::QuickControls2 LayerShellQt::Interface)
```

- [ ] **Step 2: `IslandProbe` (máscara de entrada + interatividade de teclado)**

`linux/spikes/island/IslandProbe.h`:
```cpp
#pragma once
#include <QObject>
#include <QPointer>

class QQuickWindow;

// Owns the two Wayland knobs the island needs: the input region (clicks outside
// the island fall through to the window below) and the layer-shell keyboard mode.
class IslandProbe : public QObject {
    Q_OBJECT
public:
    explicit IslandProbe(QObject *parent = nullptr);
    void attach(QQuickWindow *window);

    Q_INVOKABLE void setInputRect(qreal x, qreal y, qreal w, qreal h);
    Q_INVOKABLE void setKeyboardOnDemand(bool on);
    Q_INVOKABLE void log(const QString &message);

private:
    QPointer<QQuickWindow> m_window;
};
```

`linux/spikes/island/IslandProbe.cpp`:
```cpp
#include "IslandProbe.h"

#include <LayerShellQt/Window>
#include <QDateTime>
#include <QQuickWindow>
#include <QRegion>
#include <cstdio>

IslandProbe::IslandProbe(QObject *parent) : QObject(parent) {}

void IslandProbe::attach(QQuickWindow *window) { m_window = window; }

void IslandProbe::setInputRect(qreal x, qreal y, qreal w, qreal h)
{
    if (!m_window)
        return;
    // 6 px of slack around the island, like the macOS hit test (SPEC §1).
    QRect r = QRectF(x, y, w, h).toAlignedRect().adjusted(-6, -6, 6, 6);
    r = r.intersected(QRect(QPoint(0, 0), m_window->size()));
    m_window->setMask(QRegion(r));
}

void IslandProbe::setKeyboardOnDemand(bool on)
{
    if (!m_window)
        return;
    auto *layer = LayerShellQt::Window::get(m_window);
    layer->setKeyboardInteractivity(on ? LayerShellQt::Window::KeyboardInteractivityOnDemand
                                       : LayerShellQt::Window::KeyboardInteractivityNone);
    log(QStringLiteral("keyboard -> %1").arg(on ? "OnDemand" : "None"));
}

void IslandProbe::log(const QString &message)
{
    std::printf("%s %s\n", qPrintable(QTime::currentTime().toString("HH:mm:ss.zzz")),
                qPrintable(message));
    std::fflush(stdout);
}
```

- [ ] **Step 3: `main.cpp` — configurar a layer surface antes de mostrar**

`linux/spikes/island/main.cpp`:
```cpp
#include "IslandProbe.h"

#include <LayerShellQt/Window>
#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QQuickWindow>

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    const bool hotStrip = app.arguments().contains(QStringLiteral("--hot-strip"));

    IslandProbe probe;
    QQmlApplicationEngine engine;
    engine.rootContext()->setContextProperty(QStringLiteral("probe"), &probe);
    engine.setInitialProperties({{QStringLiteral("hotStrip"), hotStrip}});
    engine.loadFromModule("Spike", "Island");
    if (engine.rootObjects().isEmpty())
        return 1;

    auto *window = qobject_cast<QQuickWindow *>(engine.rootObjects().first());
    probe.attach(window);

    // Must be configured before the first show(): the role of a Wayland surface is fixed at creation.
    auto *layer = LayerShellQt::Window::get(window);
    layer->setLayer(LayerShellQt::Window::LayerOverlay);
    layer->setAnchors(LayerShellQt::Window::AnchorTop);
    layer->setExclusiveZone(-1);
    layer->setKeyboardInteractivity(LayerShellQt::Window::KeyboardInteractivityNone);
    layer->setScope(QStringLiteral("coucou-spike"));
    layer->setScreenConfiguration(LayerShellQt::Window::ScreenFromQWindow);
    window->setScreen(QGuiApplication::primaryScreen());

    window->show();
    probe.log(QStringLiteral("shown on %1 dpr=%2").arg(window->screen()->name())
                  .arg(window->devicePixelRatio()));
    return app.exec();
}
```

- [ ] **Step 4: `Island.qml` — pílula que expande com a curva real, campo de texto, Esc**

`linux/spikes/island/Island.qml`:
```qml
import QtQuick
import QtQuick.Controls

Window {
    id: root
    width: 720
    height: 320
    color: "transparent"
    visible: false

    required property bool hotStrip
    property bool expanded: false

    function updateMask() {
        if (root.hotStrip && !root.expanded && !drop.containsDrag)
            probe.setInputRect((root.width - 184) / 2, 0, 184, 3)
        else
            probe.setInputRect(island.x, island.y, island.width, island.height)
    }

    function collapse() {
        root.expanded = false
        field.focus = false
        probe.setKeyboardOnDemand(false)
    }

    Rectangle {
        id: island
        x: (root.width - width) / 2
        y: 0
        width: root.expanded ? 640 : 288
        height: root.expanded ? 196 : 24
        radius: root.expanded ? 30 : 14
        color: "black"
        opacity: root.hotStrip && !root.expanded && !drop.containsDrag ? 0 : 1
        focus: true

        Behavior on width  { NumberAnimation { duration: root.expanded ? 520 : 340; easing.type: Easing.BezierSpline
                              easing.bezierCurve: root.expanded ? [0.32, 1.22, 0.42, 1, 1, 1] : [0.45, 0, 0.2, 1, 1, 1] } }
        Behavior on height { NumberAnimation { duration: root.expanded ? 520 : 340; easing.type: Easing.BezierSpline
                              easing.bezierCurve: root.expanded ? [0.32, 1.22, 0.42, 1, 1, 1] : [0.45, 0, 0.2, 1, 1, 1] } }

        onWidthChanged: root.updateMask()
        onHeightChanged: root.updateMask()

        Keys.onEscapePressed: { probe.log("Esc"); root.collapse() }

        MouseArea {
            anchors.fill: parent
            hoverEnabled: true
            onEntered: probe.log("hover enter")
            onExited: probe.log("hover exit")
            onClicked: {
                probe.log("click inside island")
                probe.setKeyboardOnDemand(true)
                island.forceActiveFocus()
                root.expanded = !root.expanded
                if (!root.expanded) root.collapse()
            }
        }

        TextField {
            id: field
            visible: root.expanded
            anchors.centerIn: parent
            width: 300
            placeholderText: "digite aqui"
            onActiveFocusChanged: probe.log("text field focus " + activeFocus)
            onTextChanged: probe.log("typed: " + text)
        }

        DropArea {
            id: drop
            anchors.fill: parent
            // Task 3 fills in the handlers.
        }
    }

    Component.onCompleted: updateMask()
}
```

- [ ] **Step 5: Compilar e rodar**

Run:
```sh
linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja -DCMAKE_BUILD_TYPE=Debug
linux/scripts/host.sh cmake --build linux/build --target probe-island
linux/scripts/host.sh linux/build/spikes/island/probe-island
```
(rodar em background; guardar o PID com `pgrep -f probe-island` via `host.sh`)
Expected: stdout mostra `shown on <tela> dpr=<n>`, sem erro `wl_surface`/`layer_shell`.

- [ ] **Step 6: Verificar posição por captura (agente)**

Run:
```sh
linux/scripts/host.sh spectacle -b -n -f -o "$PWD/linux/build/probe-island.png"
```
Abrir `linux/build/probe-island.png` com a ferramenta Read. Expected: pílula preta ~288 × 24 no topo, centralizada horizontalmente, colada na borda.

- [ ] **Step 7: Checagens com o João 👤 — registrar cada resultado**

Pedir ao João, uma por vez, e anotar SIM/NÃO + observação:
1. A pílula fica por cima de uma janela maximizada **e** de um vídeo em tela cheia (F11 no navegador)?
2. Clicar **logo abaixo** da pílula (fora dela, na barra de título de uma janela maximizada) atinge a janela de baixo?
3. Passar o mouse na pílula imprime `hover enter` / `hover exit`?
4. Clicar abre com o leve "passar do ponto" da curva; ao expandir e contrair a área clicável acompanha (clicar logo fora da ilha expandida atinge a janela de baixo)?
5. Com a ilha aberta, clicar no campo e digitar funciona (`typed: ...`); `Esc` fecha; depois de fechar, o teclado volta para o app anterior sem clicar?
6. Com a ilha aberta e **sem** clicar nela, digitar no VSCodium continua indo para o VSCodium (nenhum `typed:` no log)?

- [ ] **Step 8: Commit**

```sh
git add linux/spikes/CMakeLists.txt linux/spikes/island
git commit -m "linux(spike): layer-shell island probe with input mask and on-demand keyboard

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 3: Probe de arrastar arquivo (DnD) na layer surface

**Files:**
- Modify: `linux/spikes/island/Island.qml` (bloco `DropArea`)

**Interfaces:**
- Consumes: `probe.setInputRect`, `probe.log`, flag `--hot-strip` do Task 2.
- Produces: resposta registrada no findings: DnD entra numa layer surface? Entra pela faixa de 3 px?

- [ ] **Step 1: Preencher o `DropArea`**

Substituir o bloco `DropArea { ... }` em `Island.qml` por:
```qml
        DropArea {
            id: drop
            anchors.fill: parent
            keys: ["text/uri-list"]
            onEntered: (drag) => {
                probe.log("drag enter formats=" + drag.formats.join(","))
                // Grow the input region to the upload zone (±220 px, 26 px below) while a drag is over us.
                probe.setInputRect(root.width / 2 - 220, 0, 440, island.height + 26)
                drag.accept(Qt.CopyAction)
            }
            onExited: { probe.log("drag exit"); root.updateMask() }
            onDropped: (drop) => {
                probe.log("dropped urls=" + drop.urls.join(" | "))
                drop.accept(Qt.CopyAction)
                root.updateMask()
            }
        }
```

- [ ] **Step 2: Compilar e rodar no modo normal**

Run:
```sh
linux/scripts/host.sh cmake --build linux/build --target probe-island
linux/scripts/host.sh linux/build/spikes/island/probe-island
```

- [ ] **Step 3: Checagem 👤 — pílula visível**

Pedir ao João: arrastar um arquivo do Dolphin até a pílula e soltar. Expected no log: `drag enter formats=...text/uri-list...` e `dropped urls=file:///...`. Registrar SIM/NÃO.

- [ ] **Step 4: Checagem 👤 — modo "faixa de 3 px"**

Encerrar o probe e rodar `linux/scripts/host.sh linux/build/spikes/island/probe-island --hot-strip`. Pedir ao João: (a) encostar o mouse na borda de cima no centro — aparece `hover enter`? (b) arrastar um arquivo do Dolphin até a borda de cima no centro — aparece `drag enter`? Registrar. Se (b) falhar, anotar a alternativa para o L1: com a ilha escondida, a zona de drop é o notch falso visível ou uma faixa maior (ex.: 184 × 8).

- [ ] **Step 5: Commit**

```sh
git add linux/spikes/island/Island.qml
git commit -m "linux(spike): drag-and-drop into the layer surface

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 4: Probe de serviços — som e KWallet

**Files:**
- Create: `linux/spikes/services/CMakeLists.txt`, `linux/spikes/services/main.cpp`
- Modify: `linux/spikes/CMakeLists.txt`

**Interfaces:**
- Consumes: WAVs em `NotchBuddy/Resources/sounds/` (só leitura).
- Produces: executável `probe-services` com subcomandos `sound` e `secret`; o padrão de uso do QtKeychain que o L3 reaproveita.

- [ ] **Step 1: CMake**

`linux/spikes/CMakeLists.txt` — acrescentar:
```cmake
add_subdirectory(services)
```

`linux/spikes/services/CMakeLists.txt`:
```cmake
find_package(Qt6Keychain REQUIRED)

qt_add_executable(probe-services main.cpp)
target_link_libraries(probe-services PRIVATE Qt6::Gui Qt6::Multimedia Qt6Keychain::Qt6Keychain)
target_compile_definitions(probe-services PRIVATE
    COUCOU_SOUNDS_DIR="${CMAKE_SOURCE_DIR}/../NotchBuddy/Resources/sounds")
```

- [ ] **Step 2: `main.cpp`**

`linux/spikes/services/main.cpp`:
```cpp
#include <QDateTime>
#include <QElapsedTimer>
#include <QGuiApplication>
#include <QSoundEffect>
#include <QTimer>
#include <QUrl>
#include <qt6keychain/keychain.h>
#include <cstdio>
#include <memory>
#include <vector>

static void say(const QString &s) { std::printf("%s\n", qPrintable(s)); std::fflush(stdout); }

// sound: preload a pool of 3 effects per WAV (like the macOS AVAudioPlayer pool),
// play "greet" then three overlapping "peek" 60 ms apart, report play()->playing latency.
static int runSound(QGuiApplication &app)
{
    const QString dir = QStringLiteral(COUCOU_SOUNDS_DIR);
    std::vector<std::unique_ptr<QSoundEffect>> pool;
    for (const char *name : {"greet", "peek", "peek", "peek"}) {
        auto fx = std::make_unique<QSoundEffect>();
        fx->setSource(QUrl::fromLocalFile(dir + "/" + name + ".wav"));
        fx->setVolume(0.12f);
        pool.push_back(std::move(fx));
    }
    auto *timer = new QElapsedTimer;
    QTimer::singleShot(800, &app, [&pool, timer]() {  // give the effects time to load
        for (size_t i = 0; i < pool.size(); ++i) {
            say(QStringLiteral("status[%1]=%2").arg(i).arg(pool[i]->status()));
            QTimer::singleShot(int(i) * 60, pool[i].get(), [fx = pool[i].get(), timer, i]() {
                timer->start();
                QObject::connect(fx, &QSoundEffect::playingChanged, fx, [fx, timer, i]() {
                    if (fx->isPlaying())
                        say(QStringLiteral("effect %1 playing after %2 ms").arg(i).arg(timer->elapsed()));
                });
                fx->play();
            });
        }
    });
    QTimer::singleShot(3000, &app, &QGuiApplication::quit);
    return app.exec();
}

// secret: write, read back and delete a throwaway key in the Secret Service / KWallet.
static int runSecret(QGuiApplication &app)
{
    const QString service = QStringLiteral("fr.louisraille.NotchBuddy.Spike");
    const QString key = QStringLiteral("probe");
    const QString value = QStringLiteral("s3cret-%1").arg(QDateTime::currentMSecsSinceEpoch());
    int exitCode = 1;

    auto *write = new QKeychain::WritePasswordJob(service);
    write->setKey(key);
    write->setTextData(value);
    QObject::connect(write, &QKeychain::Job::finished, &app, [&, service, key, value](QKeychain::Job *w) {
        say(QStringLiteral("write: %1").arg(w->error() ? w->errorString() : "ok"));
        auto *read = new QKeychain::ReadPasswordJob(service);
        read->setKey(key);
        QObject::connect(read, &QKeychain::Job::finished, &app, [&, service, key, value](QKeychain::Job *r) {
            const auto *rj = static_cast<QKeychain::ReadPasswordJob *>(r);
            const bool same = !r->error() && rj->textData() == value;
            say(QStringLiteral("read: %1 match=%2").arg(r->error() ? r->errorString() : "ok").arg(same));
            auto *del = new QKeychain::DeletePasswordJob(service);
            del->setKey(key);
            QObject::connect(del, &QKeychain::Job::finished, &app, [&, same](QKeychain::Job *d) {
                say(QStringLiteral("delete: %1").arg(d->error() ? d->errorString() : "ok"));
                exitCode = same && !d->error() ? 0 : 1;
                QGuiApplication::quit();
            });
            del->start();
        });
        read->start();
    });
    write->start();
    app.exec();
    return exitCode;
}

int main(int argc, char *argv[])
{
    QGuiApplication app(argc, argv);
    const QString cmd = app.arguments().value(1);
    if (cmd == "sound")
        return runSound(app);
    if (cmd == "secret")
        return runSecret(app);
    say("usage: probe-services sound|secret");
    return 2;
}
```

- [ ] **Step 3: Compilar e rodar `secret` (agente)**

Run:
```sh
linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja
linux/scripts/host.sh cmake --build linux/build --target probe-services
linux/scripts/host.sh linux/build/spikes/services/probe-services secret; echo "exit=$?"
```
Expected: `write: ok`, `read: ok match=true`, `delete: ok`, `exit=0`. Se o KWallet pedir senha/permissão, o João responde 👤 e isso vai para o findings.

- [ ] **Step 4: Rodar `sound` (agente + 👤)**

Run: `linux/scripts/host.sh linux/build/spikes/services/probe-services sound`
Expected: `status[i]=2` (Ready) para os 4 e `effect i playing after <n> ms` com n pequeno (anotar os valores). 👤 João confirma: ouviu o "greet" e três "peek" sobrepostos, volume baixo, sem estalo.

- [ ] **Step 5: Commit**

```sh
git add linux/spikes/CMakeLists.txt linux/spikes/services
git commit -m "linux(spike): QSoundEffect pool and QtKeychain/KWallet probes

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 5: Probe do socket do hook — host ↔ Flatpak do VSCodium

**Files:**
- Create: `linux/spikes/hooksocket/CMakeLists.txt`, `linux/spikes/hooksocket/server.cpp`, `linux/spikes/hooksocket/probe_client.py`
- Modify: `linux/spikes/CMakeLists.txt`

**Interfaces:**
- Consumes: `coucou::Paths::socketPath()`, `dataDir()`, `ensurePrivateDir()`, `fitsUnixSocket()` (Task 1).
- Produces: executável `probe-hook-server`; `probe_client.py` com o mesmo protocolo de linha JSON que o `nb-hook` do L2 vai usar (uma linha JSON de ida; para `PermissionRequest`, uma linha de volta).

- [ ] **Step 1: CMake**

`linux/spikes/CMakeLists.txt` — acrescentar:
```cmake
add_subdirectory(hooksocket)
```

`linux/spikes/hooksocket/CMakeLists.txt`:
```cmake
qt_add_executable(probe-hook-server server.cpp)
target_link_libraries(probe-hook-server PRIVATE coucou_core Qt6::Network)
```

- [ ] **Step 2: Servidor**

`linux/spikes/hooksocket/server.cpp`:
```cpp
#include "Paths.h"

#include <QCoreApplication>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLocalServer>
#include <QLocalSocket>
#include <QTimer>
#include <cstdio>
#include <sys/socket.h>
#include <unistd.h>

using coucou::Paths;

static void say(const QString &s) { std::printf("%s\n", qPrintable(s)); std::fflush(stdout); }

static uid_t peerUid(QLocalSocket *s)
{
    ucred cred{};
    socklen_t len = sizeof(cred);
    if (getsockopt(int(s->socketDescriptor()), SOL_SOCKET, SO_PEERCRED, &cred, &len) != 0)
        return uid_t(-1);
    return cred.uid;
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    const QString path = Paths::socketPath();
    if (!Paths::fitsUnixSocket(path)) { say("socket path too long: " + path); return 1; }
    if (!Paths::ensurePrivateDir(Paths::dataDir())) { say("cannot create " + Paths::dataDir()); return 1; }

    QLocalServer::removeServer(path);  // stale socket from a crashed run
    QLocalServer server;
    server.setSocketOptions(QLocalServer::UserAccessOption);
    if (!server.listen(path)) { say("listen failed: " + server.errorString()); return 1; }
    say("listening on " + path);

    QObject::connect(&server, &QLocalServer::newConnection, &app, [&server]() {
        while (QLocalSocket *s = server.nextPendingConnection()) {
            const uid_t uid = peerUid(s);
            if (uid != getuid()) { say(QStringLiteral("rejected uid %1").arg(uid)); s->abort(); s->deleteLater(); continue; }
            QObject::connect(s, &QLocalSocket::readyRead, s, [s]() {
                if (!s->canReadLine()) return;
                const QByteArray line = s->readLine().trimmed();
                const QJsonObject ev = QJsonDocument::fromJson(line).object();
                const QString name = ev.value("hook_event_name").toString();
                say(QStringLiteral("event %1 source=%2 cwd=%3").arg(name, ev.value("coucou_source").toString(),
                                                                  ev.value("cwd").toString()));
                if (name == "PermissionRequest") {
                    // Simulate the user clicking "Autorizar" after 2 s.
                    QTimer::singleShot(2000, s, [s]() {
                        s->write(R"({"decision":"allow"})" "\n");
                        s->flush();
                        s->disconnectFromServer();
                    });
                } else {
                    s->disconnectFromServer();
                }
            });
            QObject::connect(s, &QLocalSocket::disconnected, s, &QObject::deleteLater);
        }
    });
    return app.exec();
}
```

- [ ] **Step 3: Cliente Python (mesmas regras do `nb-hook`)**

`linux/spikes/hooksocket/probe_client.py`:
```python
#!/usr/bin/env python3
"""L0 probe: send one hook-like event to the Coucou socket, the way nb-hook will.

Usage: probe_client.py <EventName> [decision_timeout_s]
Prints the elapsed time on stderr; prints the decision JSON on stdout only for an
allow/deny answer to PermissionRequest. Never exits non-zero.
"""
import json
import os
import socket
import sys
import time


def main() -> None:
    event = sys.argv[1] if len(sys.argv) > 1 else "PreToolUse"
    decision_timeout = float(sys.argv[2]) if len(sys.argv) > 2 else 110.0
    # Built from HOME on purpose: XDG_* are remapped inside the VSCodium Flatpak.
    sock_path = os.path.join(os.environ["HOME"], ".local/share/coucou/nb.sock")
    payload = {
        "hook_event_name": event,
        "session_id": "probe",
        "cwd": os.getcwd(),
        "coucou_source": "vscodium" if os.environ.get("CLAUDE_CODE_ENTRYPOINT", "").startswith("claude-vscode") else "terminal",
        "flatpak_id": os.environ.get("FLATPAK_ID", ""),
    }
    start = time.monotonic()
    out = ""
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(0.3)
        s.connect(sock_path)
        s.sendall((json.dumps(payload) + "\n").encode())
        if event == "PermissionRequest":
            s.settimeout(decision_timeout)
            buf = b""
            while b"\n" not in buf:
                chunk = s.recv(4096)
                if not chunk:
                    break
                buf += chunk
            answer = json.loads(buf.decode().strip() or "{}")
            if answer.get("decision") in ("allow", "deny"):
                out = json.dumps({"hookSpecificOutput": {"hookEventName": "PermissionRequest",
                                                         "decision": {"behavior": answer["decision"]}}})
        s.close()
    except Exception as exc:  # app absent, timeout, bad JSON: stay silent
        print(f"(silent: {type(exc).__name__})", file=sys.stderr)
    print(f"elapsed={time.monotonic() - start:.3f}s", file=sys.stderr)
    if out:
        print(out)


if __name__ == "__main__":
    main()
    sys.exit(0)
```

- [ ] **Step 4: Cenário "app ausente" — de dentro do sandbox (agente)**

Garantir que nenhum `probe-hook-server` está rodando, depois, **sem** `host.sh`:
```sh
python3 linux/spikes/hooksocket/probe_client.py PermissionRequest; echo "exit=$?"
```
Expected: stdout vazio, stderr `(silent: FileNotFoundError)` ou `ConnectionRefusedError`, `elapsed` < 0.5 s, `exit=0`.

- [ ] **Step 5: Cenário normal — servidor no host, cliente no sandbox e no host (agente)**

Rodar o servidor em background: `linux/scripts/host.sh linux/build/spikes/hooksocket/probe-hook-server`
Depois:
```sh
python3 linux/spikes/hooksocket/probe_client.py PreToolUse
python3 linux/spikes/hooksocket/probe_client.py PermissionRequest
linux/scripts/host.sh python3 linux/spikes/hooksocket/probe_client.py PreToolUse
linux/scripts/host.sh stat -c '%a %n' "$HOME/.local/share/coucou" "$HOME/.local/share/coucou/nb.sock"
```
Expected: servidor loga `event PreToolUse source=vscodium ...` (do sandbox) e `source=terminal` (do host); o `PermissionRequest` imprime `{"hookSpecificOutput": {"hookEventName": "PermissionRequest", "decision": {"behavior": "allow"}}}` após ~2 s; pasta `700`; socket sem permissão para grupo/outros.

- [ ] **Step 6: Cenário "socket velho" (agente)**

Matar o servidor com `kill -9` (via `host.sh pkill -9 -f probe-hook-server`), confirmar que `nb.sock` ainda existe, iniciar o servidor de novo. Expected: `listening on ...` (sem `listen failed`) e o Step 5 volta a funcionar.

- [ ] **Step 7: Commit**

```sh
git add linux/spikes/CMakeLists.txt linux/spikes/hooksocket
git commit -m "linux(spike): hook socket reachable from the VSCodium Flatpak

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 6: Probe do script do KWin — cursor, janela sob o cursor, ativar janela

**Files:**
- Create: `linux/spikes/kwinbridge/CMakeLists.txt`, `linux/spikes/kwinbridge/main.cpp`, `linux/spikes/kwinbridge/BridgeReceiver.h`, `linux/spikes/kwinbridge/BridgeReceiver.cpp`, `linux/spikes/kwinbridge/coucou-bridge-spike/metadata.json`, `linux/spikes/kwinbridge/coucou-bridge-spike/contents/code/main.js`
- Modify: `linux/spikes/CMakeLists.txt`

**Interfaces:**
- Consumes: D-Bus `org.kde.KWin /Scripting org.kde.kwin.Scripting` — `loadScript(s filePath, s pluginName) → i`, `start()`, `unloadScript(s pluginName) → b`, `isScriptLoaded(s pluginName) → b` (confirmado por introspecção).
- Produces: executável `probe-kwin` (`probe-kwin <segundos>` ou `probe-kwin --activate <texto do resourceClass>`); serviço D-Bus `fr.louisraille.NotchBuddy.Spike`, objeto `/Bridge`, interface `fr.louisraille.NotchBuddy.Bridge` com `cursor(i x, i y)` e `window(s caption, s resourceClass, i x, i y, i w, i h)` — contrato que o L5 herda.

- [ ] **Step 1: Script do KWin**

`linux/spikes/kwinbridge/coucou-bridge-spike/metadata.json`:
```json
{
    "KPackageStructure": "KWin/Script",
    "KPlugin": {
        "Id": "coucou-bridge-spike",
        "Name": "Coucou bridge (spike)",
        "Description": "Pushes cursor position and the window under it to Coucou over D-Bus",
        "License": "MIT"
    },
    "X-Plasma-API": "javascript"
}
```

`linux/spikes/kwinbridge/coucou-bridge-spike/contents/code/main.js`:
```js
// Coucou bridge (L0 spike): pushes the cursor position and the window under it to
// the app over D-Bus. Loaded only while the island is visible.
const SERVICE = "fr.louisraille.NotchBuddy.Spike";
const PATH = "/Bridge";
const IFACE = "fr.louisraille.NotchBuddy.Bridge";

let lastX = -1, lastY = -1, lastWindowId = "";

function windowAt(x, y) {
    const stack = workspace.stackingOrder;       // bottom → top
    for (let i = stack.length - 1; i >= 0; i--) {
        const w = stack[i];
        if (!w.normalWindow || w.minimized) continue;
        const g = w.frameGeometry;
        if (x >= g.x && x < g.x + g.width && y >= g.y && y < g.y + g.height) return w;
    }
    return null;
}

function tick() {
    const p = workspace.cursorPos;
    const x = Math.round(p.x), y = Math.round(p.y);
    if (x === lastX && y === lastY) return;
    lastX = x; lastY = y;
    callDBus(SERVICE, PATH, IFACE, "cursor", x, y);

    const w = windowAt(x, y);
    const id = w ? String(w.internalId) : "";
    if (id === lastWindowId) return;
    lastWindowId = id;
    if (w) {
        const g = w.frameGeometry;
        callDBus(SERVICE, PATH, IFACE, "window", w.caption, String(w.resourceClass),
                 Math.round(g.x), Math.round(g.y), Math.round(g.width), Math.round(g.height));
    } else {
        callDBus(SERVICE, PATH, IFACE, "window", "", "", 0, 0, 0, 0);
    }
}

if (workspace.cursorPosChanged) {
    console.info("coucou-bridge-spike: using cursorPosChanged");
    workspace.cursorPosChanged.connect(tick);
} else {
    console.info("coucou-bridge-spike: using 16 ms timer");
    const timer = new QTimer();
    timer.interval = 16;
    timer.timeout.connect(tick);
    timer.start();
}
```

- [ ] **Step 2: Receptor D-Bus e carregador**

`linux/spikes/kwinbridge/BridgeReceiver.h`:
```cpp
#pragma once
#include <QObject>

class BridgeReceiver : public QObject {
    Q_OBJECT
    Q_CLASSINFO("D-Bus Interface", "fr.louisraille.NotchBuddy.Bridge")
public:
    using QObject::QObject;
    int cursorCalls = 0;

public slots:
    void cursor(int x, int y);
    void window(const QString &caption, const QString &resourceClass, int x, int y, int w, int h);
};
```

`linux/spikes/kwinbridge/BridgeReceiver.cpp`:
```cpp
#include "BridgeReceiver.h"
#include <cstdio>

void BridgeReceiver::cursor(int x, int y)
{
    ++cursorCalls;
    if (cursorCalls % 30 == 1) { std::printf("cursor %d,%d\n", x, y); std::fflush(stdout); }
}

void BridgeReceiver::window(const QString &caption, const QString &resourceClass, int x, int y, int w, int h)
{
    std::printf("window class=%s caption=\"%s\" geom=%d,%d %dx%d\n", qPrintable(resourceClass),
                qPrintable(caption), x, y, w, h);
    std::fflush(stdout);
}
```

`linux/spikes/kwinbridge/main.cpp`:
```cpp
#include "BridgeReceiver.h"

#include <QCoreApplication>
#include <QDBusConnection>
#include <QDBusInterface>
#include <QDBusReply>
#include <QDir>
#include <QElapsedTimer>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QTemporaryFile>
#include <QTimer>
#include <cstdio>

static const QString kPlugin = QStringLiteral("coucou-bridge-spike");

static void say(const QString &s) { std::printf("%s\n", qPrintable(s)); std::fflush(stdout); }

static QDBusInterface scripting()
{
    return QDBusInterface(QStringLiteral("org.kde.KWin"), QStringLiteral("/Scripting"),
                          QStringLiteral("org.kde.kwin.Scripting"));
}

static bool loadAndStart(const QString &file, const QString &plugin)
{
    auto kwin = scripting();
    kwin.call(QStringLiteral("unloadScript"), plugin);  // leftover from a crashed run
    QDBusReply<int> id = kwin.call(QStringLiteral("loadScript"), file, plugin);
    say(QStringLiteral("loadScript(%1) -> %2").arg(plugin).arg(id.isValid() ? QString::number(id.value())
                                                                              : id.error().message()));
    if (!id.isValid() || id.value() < 0)
        return false;
    kwin.call(QStringLiteral("start"));
    return true;
}

// One-shot script: activate the first normal window whose resourceClass contains `needle`.
static int runActivate(QCoreApplication &app, const QString &needle)
{
    QTemporaryFile js(QDir::tempPath() + "/coucou-activate-XXXXXX.js");
    js.setAutoRemove(false);
    if (!js.open()) return 1;
    js.write(QStringLiteral(
        "for (const w of workspace.windowList()) {"
        "  if (w.normalWindow && String(w.resourceClass).toLowerCase().includes(%1)) {"
        "    workspace.activeWindow = w; console.info('coucou-activate: ' + w.caption); break; } }")
                 .arg(QString::fromUtf8(QJsonDocument(QJsonArray{needle.toLower()}).toJson(QJsonDocument::Compact))
                          .mid(1).chopped(1))
                 .toUtf8());
    js.close();
    const QString plugin = QStringLiteral("coucou-activate-spike");
    const bool ok = loadAndStart(js.fileName(), plugin);
    QTimer::singleShot(500, &app, [&]() {
        scripting().call(QStringLiteral("unloadScript"), plugin);
        QFile::remove(js.fileName());
        app.quit();
    });
    app.exec();
    return ok ? 0 : 1;
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    const QStringList args = app.arguments();
    if (args.value(1) == "--activate")
        return runActivate(app, args.value(2));

    const int seconds = args.value(1, "10").toInt();
    BridgeReceiver receiver;
    auto bus = QDBusConnection::sessionBus();
    if (!bus.registerService(QStringLiteral("fr.louisraille.NotchBuddy.Spike")) ||
        !bus.registerObject(QStringLiteral("/Bridge"), &receiver, QDBusConnection::ExportAllSlots)) {
        say("D-Bus registration failed: " + bus.lastError().message());
        return 1;
    }

    const QString script = QStringLiteral(COUCOU_BRIDGE_DIR) + "/contents/code/main.js";
    if (!loadAndStart(script, kPlugin))
        return 1;

    QElapsedTimer clock;
    clock.start();
    QTimer::singleShot(seconds * 1000, &app, [&]() {
        QDBusReply<bool> unloaded = scripting().call(QStringLiteral("unloadScript"), kPlugin);
        const double rate = receiver.cursorCalls * 1000.0 / clock.elapsed();
        say(QStringLiteral("cursor calls=%1 rate=%2/s unloaded=%3")
                .arg(receiver.cursorCalls).arg(rate, 0, 'f', 1).arg(unloaded.isValid() && unloaded.value()));
        app.quit();
    });
    return app.exec();
}
```

`linux/spikes/kwinbridge/CMakeLists.txt`:
```cmake
qt_add_executable(probe-kwin main.cpp BridgeReceiver.cpp BridgeReceiver.h)
target_link_libraries(probe-kwin PRIVATE Qt6::DBus)
target_compile_definitions(probe-kwin PRIVATE
    COUCOU_BRIDGE_DIR="${CMAKE_CURRENT_SOURCE_DIR}/coucou-bridge-spike")
```

`linux/spikes/CMakeLists.txt` — acrescentar:
```cmake
add_subdirectory(kwinbridge)
```

- [ ] **Step 3: Compilar e rodar 15 s enquanto o João mexe o mouse 👤**

Run:
```sh
linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja
linux/scripts/host.sh cmake --build linux/build --target probe-kwin
linux/scripts/host.sh linux/build/spikes/kwinbridge/probe-kwin 15
```
Pedir ao João: mexer o mouse por várias janelas (VSCodium, Dolphin, Konsole) durante os 15 s.
Expected: linhas `cursor x,y`, linhas `window class=... caption=...` ao trocar de janela, e no fim `cursor calls=N rate=R/s unloaded=true`. Anotar: qual ramo o script usou (`journalctl --user -b | grep coucou-bridge-spike` via `host.sh`), a taxa R, e o `resourceClass` exato do VSCodium Flatpak e do Konsole.

- [ ] **Step 4: Custo de CPU do KWin com o script (agente)**

Criar `linux/scripts/measure.sh` (usado também no Task 7):
```sh
#!/bin/sh
# Usage: measure.sh <pid> <seconds> — prints average CPU% over the window and current PSS in MB.
pid=$1; secs=${2:-10}
tck=$(getconf CLK_TCK)
t0=$(awk '{print $14+$15}' /proc/$pid/stat)
sleep "$secs"
t1=$(awk '{print $14+$15}' /proc/$pid/stat)
cpu=$(echo "$t0 $t1 $tck $secs" | awk '{printf "%.2f", ($2-$1)/$3/$4*100}')
pss=$(awk '/^Pss:/ {printf "%.1f", $2/1024}' /proc/$pid/smaps_rollup)
echo "pid=$pid cpu=${cpu}% pss=${pss}MB"
```
Run: `chmod +x linux/scripts/measure.sh`, depois `linux/scripts/host.sh linux/scripts/measure.sh $(linux/scripts/host.sh pgrep -x kwin_wayland) 10` duas vezes: sem o probe, e com `probe-kwin 15` rodando enquanto o João mexe o mouse 👤. Anotar a diferença de CPU do `kwin_wayland`.

- [ ] **Step 5: Segunda execução após crash (agente)**

Rodar `probe-kwin 30` em background, matar com `kill -9` após 3 s, rodar `probe-kwin 5` de novo. Expected: `loadScript(...) -> <id ≥ 0>` na segunda vez (o `unloadScript` preventivo limpou o anterior) e `unloaded=true` no fim.

- [ ] **Step 6: Ativar janela (agente + 👤)**

Com o foco no Konsole (pedir ao João), rodar `linux/scripts/host.sh linux/build/spikes/kwinbridge/probe-kwin --activate codium` (ou o trecho do `resourceClass` anotado no Step 3). 👤 Expected: a janela do VSCodium vem para a frente com foco. Repetir com `konsole`. Registrar.

- [ ] **Step 7: Commit**

```sh
git add linux/spikes/CMakeLists.txt linux/spikes/kwinbridge linux/scripts/measure.sh
git commit -m "linux(spike): KWin script bridge for cursor, window-at-point and activation

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

### Task 7: Medições base, findings e `CLAUDE.md`

**Files:**
- Create: `linux/docs/L0-findings.md`
- Modify: `CLAUDE.md` (acrescentar seção no fim)

**Interfaces:**
- Consumes: `probe-island`, `linux/scripts/measure.sh`, anotações dos Tasks 2–6.
- Produces: `linux/docs/L0-findings.md` — entrada obrigatória do plano do L1.

- [ ] **Step 1: CPU e memória da ilha parada e animando (agente + 👤)**

Rodar `probe-island` em background, esperar 5 s sem tocar, depois:
```sh
PID=$(linux/scripts/host.sh pgrep -f spikes/island/probe-island)
linux/scripts/host.sh linux/scripts/measure.sh "$PID" 20
```
Expected: `cpu≈0.00%` parada. Depois pedir ao João 👤 para abrir e fechar a ilha várias vezes durante outra medição de 20 s e anotar a CPU. Anotar a PSS (base da meta < 100 MB).

- [ ] **Step 2: Escrever `linux/docs/L0-findings.md`**

Estrutura fixa (preencher todas as linhas com o que foi observado — nada de "a verificar"):
```markdown
# L0 — resultados do spike Wayland (Fedora 44, KDE Plasma 6.7)

| # | Mecanismo | Resultado | Evidência | Decisão para o L1+ |
|---|---|---|---|---|
| 1 | Layer surface overlay no topo, acima de janela maximizada e tela cheia | | | |
| 2 | Região de entrada: cliques fora da ilha atravessam; acompanha a animação | | | |
| 3 | Teclado None → OnDemand ao clicar; Esc; volta a None; sem roubo de foco | | | |
| 4 | DnD do Dolphin na pílula visível | | | |
| 5 | Hover e DnD pela faixa de 3 px (`--hot-strip`) | | | |
| 6 | QSoundEffect: carga, latência (ms), sobreposição | | | |
| 7 | QtKeychain ↔ KWallet: gravar/ler/apagar, diálogos | | | |
| 8 | Socket em ~/.local/share/coucou acessível do Flatpak e do host; 0700; socket velho | | | |
| 9 | App ausente: cliente mudo, < 0,5 s, exit 0 | | | |
| 10 | KWin: cursorPosChanged ou timer; taxa; custo de CPU no kwin_wayland | | | |
| 11 | KWin: janela sob o cursor (resourceClass do VSCodium e do Konsole) | | | |
| 12 | KWin: ativar janela por resourceClass | | | |
| 13 | Script órfão após crash é limpo no próximo início | | | |
| 14 | Ilha parada: CPU %, PSS MB; ilha animando: CPU % | | | |

## Desvios do design
(Cada linha "não funciona" vira aqui a alternativa escolhida e a seção da spec que muda.)
```
Se algum resultado muda a spec, editar também `docs/superpowers/specs/2026-09-29-coucou-linux-design.md` na seção afetada.

- [ ] **Step 3: Seção Linux no `CLAUDE.md`**

Acrescentar ao fim de `CLAUDE.md`:
```markdown

## Linux port (fork, `linux/`)
- Design: `docs/superpowers/specs/2026-09-29-coucou-linux-design.md`. Plans: `docs/superpowers/plans/`. Spike results: `linux/docs/L0-findings.md`.
- Stack: C++20 + Qt 6 (QML) + LayerShellQt + KF6, Fedora 44 KDE Plasma (Wayland) only. Never touch `NotchBuddy/` from Linux work.
- Claude Code runs inside the VSCodium Flatpak: build, test and run on the host through `linux/scripts/host.sh`:
  `linux/scripts/host.sh cmake -S linux -B linux/build -G Ninja && linux/scripts/host.sh cmake --build linux/build && linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure`
- All paths derive from `$HOME` (`coucou::Paths`), never from `XDG_*` — the Flatpak remaps them.
- The house rules above still apply (never block Claude Code, secrets only in KWallet, no telemetry, settings.json only with backup + diff + confirmation, 0 % CPU when hidden).
```

- [ ] **Step 4: Rodar a suíte inteira uma última vez**

Run:
```sh
linux/scripts/host.sh cmake --build linux/build
linux/scripts/host.sh ctest --test-dir linux/build --output-on-failure
```
Expected: build sem warnings novos; `100% tests passed`.

- [ ] **Step 5: Commit**

```sh
git add linux/docs/L0-findings.md CLAUDE.md docs/superpowers/specs/2026-09-29-coucou-linux-design.md
git commit -m "linux: L0 findings and Linux section in CLAUDE.md

Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>"
```

---

## Depois do L0

O plano do **L1 (ilha + Mochi)** é escrito só depois deste marco, a partir do `L0-findings.md` — as decisões de região de clique, zona de drop, foco e relógio de quadros dependem dos resultados acima.
