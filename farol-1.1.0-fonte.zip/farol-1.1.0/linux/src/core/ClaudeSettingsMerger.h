#pragma once
#include <QString>
#include <QStringList>

namespace farol {

struct MergeResult {
    bool ok = false;
    QString text;      // the new file text (== the input when nothing changes)
    QString error;
    bool changed = false;
};

// Adds/removes the Farol hooks in the text of ~/.claude/settings.json without touching anything else.
class ClaudeSettingsMerger {
public:
    // A hook command is "ours" when it contains this (the farol-hook path under $HOME).
    static constexpr const char *kMarker = ".local/share/farol/farol-hook";
    // The hook of the same app while it was called Coucou: replaced on install, removed on uninstall.
    static constexpr const char *kLegacyMarker = ".local/share/coucou/nb-hook";

    static const QStringList &events();
    // The same on Windows, where farol-hook is in Farol's folder of the profile.
    static constexpr const char *kWindowsMarker = "/Farol/farol-hook";

    // existing: the current file text ("" when the file is missing). hookPath: absolute path of farol-hook.
    // interpreter: the program that runs the script where the system does not read its first line (Windows: Python).
    static MergeResult install(const QString &existing, const QString &hookPath, int decisionTimeoutSec,
                               const QString &interpreter = {});
    static MergeResult uninstall(const QString &existing);
    static bool isInstalled(const QString &existing);
};

} // namespace farol
