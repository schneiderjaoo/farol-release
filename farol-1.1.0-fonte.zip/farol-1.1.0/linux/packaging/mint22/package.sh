#!/bin/sh
# Inside the farol-mint22 image: builds Farol against the image's Qt, tests it, and writes the package for Linux
# Mint 22 into linux/build-mint22/: farol_<version>_mint22_amd64.deb.
#   linux/packaging/mint22/run.sh linux/packaging/mint22/package.sh [--no-tests]
#
# The package installs everything under /opt/farol: the program and, beside it, the Qt it was built with (the
# libraries it loads, the X11 platform plugin, the QML modules the island imports). Mint 22's own Qt is too old for
# the island. Only /usr/bin/farol (a link), the menu entry and the icon are outside.
set -eu

cd "$(dirname "$0")/../../.."
qt=${QT_DIR:-/opt/qt/current}
build=linux/build-mint22

cmake -S linux -B "$build" -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_PREFIX_PATH="$qt" \
    -DCMAKE_INSTALL_PREFIX=/opt/farol -DFAROL_BUILD_SPIKES=OFF
cmake --build "$build"
if [ "${1:-}" != "--no-tests" ]; then
    ctest --test-dir "$build" --output-on-failure
    # ...and the X11 side against a real X server with Cinnamon's window manager.
    linux/packaging/mint22/session.sh "$build/tests/tst_x11"
fi

stage=$PWD/$build/deb
root=$stage/opt/farol
rm -rf "$stage"
DESTDIR="$stage" cmake --install "$build" --strip >/dev/null

# What Qt loads by name at run time, which no library says it needs.
mkdir -p "$root/plugins" "$root/qml/QtQuick"
for plugin in platforms/libqxcb.so platforms/libqoffscreen.so xcbglintegrations platformthemes platforminputcontexts \
              imageformats/libqsvg.so iconengines/libqsvgicon.so tls; do
    mkdir -p "$root/plugins/$(dirname "$plugin")"
    cp -a "$qt/plugins/$plugin" "$root/plugins/$(dirname "$plugin")/"
done
cp -a "$qt/qml/QtQml" "$root/qml/"
cp -a "$qt/qml/QtQuick/Window" "$qt/qml/QtQuick/Shapes" "$root/qml/QtQuick/"
find "$qt/qml/QtQuick" -maxdepth 1 -type f -exec cp -a {} "$root/qml/QtQuick/" \;
find "$root" -name '*.debug' -delete

# The Qt libraries all of that links to, and theirs: whatever ldd finds inside the Qt folder.
mkdir -p "$root/lib"
elf() { find "$1" -type f \( -name '*.so' -o -name '*.so.*' -o -perm -u+x \) -exec sh -c 'file -b "$1" | grep -q "^ELF"' _ {} \; -print; }
qtlibs=$(readlink -f "$qt")/lib
elf "$root" | while read -r f; do
    LD_LIBRARY_PATH="$qt/lib" ldd "$f" 2>/dev/null | awk '$2 == "=>" && $3 ~ /^\// { print $3 }'
done | while read -r lib; do
    real=$(readlink -f "$lib")
    case "$real" in "$qtlibs"/*) echo "$(basename "$lib") $real" ;; esac
done | sort -u | while read -r name real; do
    cp "$real" "$root/lib/$name"
done
strip --strip-unneeded "$root"/lib/*.so* 2>/dev/null || true
patchelf --set-rpath '$ORIGIN/../lib' "$root/bin/farol"
printf '[Paths]\nPrefix = ..\n' > "$root/bin/qt.conf"

# The menu entry and the icon go where the desktop looks for them; the program is on the PATH.
mkdir -p "$stage/usr/bin" "$stage/usr/share"
mv "$root/share/applications" "$root/share/icons" "$stage/usr/share/"
rmdir "$root/share"
ln -s /opt/farol/bin/farol "$stage/usr/bin/farol"

# The system libraries the package asks for are worked out from what its programs and libraries link to. OpenSSL
# is named by hand: Qt's TLS plugin loads it by name (the "Perguntar" tab's web services need it).
version=$(sed -n 's/^CMAKE_PROJECT_VERSION:STATIC=//p' "$build/CMakeCache.txt")
work=$PWD/$build/deb-work
rm -rf "$work" && mkdir -p "$work/debian" && touch "$work/debian/control"
depends=$(cd "$work" && dpkg-shlibdeps -O --ignore-missing-info -l"$root/lib" $(elf "$root") 2>/dev/null | sed -n 's/^shlibs:Depends=//p')
mkdir -p "$stage/DEBIAN"
cat > "$stage/DEBIAN/control" <<EOF
Package: farol
Version: $version
Section: devel
Priority: optional
Architecture: amd64
Maintainer: João Schneider <https://github.com/schneiderjaoo/farol>
Homepage: https://github.com/schneiderjaoo/farol
Installed-Size: $(du -sk "$stage" | cut -f1)
Depends: python3, libssl3t64, $depends
Description: An island at the edge of the screen that shows your Claude Code sessions
 Farol shows the Claude Code sessions that run on this machine in a small island at the edge of the screen: which
 ones work, which wait for you, which finished. Permission requests and questions are answered from it.
 .
 This package is for Linux Mint 22 (Cinnamon, X11) and carries the Qt libraries it needs under /opt/farol.
EOF
out=$build/farol_${version}_mint22_amd64.deb
dpkg-deb --root-owner-group --build "$stage" "$out" >/dev/null
rm -rf "$work"
echo "$out"
