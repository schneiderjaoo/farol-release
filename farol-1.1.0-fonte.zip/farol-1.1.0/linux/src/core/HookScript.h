#pragma once
#include <QByteArray>
#include <QString>

namespace farol {

// Writes the farol-hook script to `dest` (mode 0755; parent folder 0700) unless it already holds exactly `content`.
bool installHookScript(const QByteArray &content, const QString &dest, QString *error = nullptr);

} // namespace farol
