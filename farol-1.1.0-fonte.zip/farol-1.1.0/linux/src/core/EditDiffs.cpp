#include "EditDiffs.h"

#include "AppState.h"
#include "IslandController.h"

#include <algorithm>

namespace farol {

EditDiffs::EditDiffs(AppState *state, IslandController *controller, QObject *parent)
    : QObject(parent), m_state(state), m_controller(controller)
{
    // The island closed: what was open is dropped, and the next time it opens it is not on an empty diff.
    connect(m_state, &AppState::modeChanged, this, [this] {
        if (m_state->mode() == IslandMode::Expanded)
            return;
        drop();
        if (m_state->view() == IslandView::Diff)
            m_state->setView(m_controller->defaultView());
    });
    // The session of the open diff got another name (a title from Claude Code, a second session in its repository).
    connect(m_state->taskModel(), &QAbstractItemModel::dataChanged, this, [this] {
        if (!active() || nameOf(m_current.session) == m_current.name)
            return;
        m_current.name = nameOf(m_current.session);
        emit sessionChanged();
    });
}

qint64 EditDiffs::add(const QString &session, const EditDiff &diff)
{
    QList<Kept> &kept = m_kept[session];
    kept.append({++m_nextId, diff});
    while (kept.size() > kPerSession)
        kept.removeFirst();
    touch();
    return m_nextId;
}

void EditDiffs::forget(const QString &session)
{
    const bool known = m_kept.remove(session);
    if (m_current.session == session && active()) {
        drop();
        if (m_state->view() == IslandView::Diff)
            m_state->setView(m_controller->defaultView());
    }
    if (known)
        touch();
}

const EditDiffs::Kept *EditDiffs::find(qint64 id, QString *session) const
{
    for (auto it = m_kept.constBegin(); it != m_kept.constEnd(); ++it)
        for (const Kept &k : it.value())
            if (k.id == id) {
                if (session)
                    *session = it.key();
                return &k;
            }
    return nullptr;
}

bool EditDiffs::has(qint64 id) const
{
    return find(id) != nullptr;
}

int EditDiffs::kept(const QString &session) const
{
    return int(m_kept.value(session).size());
}

bool EditDiffs::open(qint64 id)
{
    QString session;
    const Kept *kept = find(id, &session);
    if (!kept)
        return false;
    show(session, *kept);
    m_controller->expand(IslandView::Diff);
    return true;
}

bool EditDiffs::openLatest(const QString &session)
{
    const QList<Kept> kept = m_kept.value(session);
    return !kept.isEmpty() && open(kept.last().id);
}

void EditDiffs::step(int delta)
{
    if (!active() || delta == 0)
        return;
    const QList<Kept> kept = m_kept.value(m_current.session);
    if (kept.isEmpty())
        return;
    // Ids only grow, so the list is in their order: where the open diff is, or would be were it still kept.
    const auto at = std::lower_bound(kept.begin(), kept.end(), m_current.id, [](const Kept &k, qint64 id) { return k.id < id; });
    const bool here = at != kept.end() && at->id == m_current.id;
    const qsizetype from = at - kept.begin();
    const qsizetype to = std::clamp<qsizetype>(from + delta - (!here && delta > 0 ? 1 : 0), 0, kept.size() - 1);
    if (kept.at(to).id == m_current.id || (!here && delta < 0))
        return;                                    // already the first or the last; nothing older than one that left
    show(m_current.session, kept.at(to));
    m_controller->resetActivity();
}

void EditDiffs::close()
{
    if (m_state->view() == IslandView::Diff)
        m_controller->showView(enumKey(m_controller->defaultView()));
}

QString EditDiffs::fileName() const
{
    return m_current.diff.file.section(QLatin1Char('/'), -1);
}

int EditDiffs::position() const
{
    const QList<Kept> kept = m_kept.value(m_current.session);
    for (qsizetype i = 0; active() && i < kept.size(); ++i)
        if (kept.at(i).id == m_current.id)
            return int(i);
    return -1;
}

// Copies the diff: nothing that is told about it below may still look at `kept`, which a newer edit can push out.
void EditDiffs::show(const QString &session, const Kept &kept)
{
    Current shown{kept.id, session, nameOf(session), kept.diff, {}, 0};
    for (const DiffRow &row : std::as_const(shown.diff.rows)) {
        shown.rows.append(QVariantMap{{QStringLiteral("kind"), QString(row.kind)}, {QStringLiteral("text"), row.text}});
        shown.columns = qMax(shown.columns, int(row.text.size()));
    }
    m_current = shown;
    emit currentChanged();
    emit sessionChanged();
    touch();
}

void EditDiffs::drop()
{
    if (!active())
        return;
    m_current = {};
    emit currentChanged();
    emit sessionChanged();
    touch();
}

QString EditDiffs::nameOf(const QString &session) const
{
    const AgentTask *task = m_state->taskModel()->find(session);
    return task ? task->name : QString();
}

void EditDiffs::touch()
{
    ++m_revision;
    emit changed();
}

} // namespace farol
