#pragma once
#include "Scheduler.h"

#include <QtGlobal>
#include <algorithm>
#include <functional>
#include <vector>

// Manual clock: nothing runs until advance() is called.
class FakeScheduler : public farol::IScheduler {
public:
    int singleShot(int ms, std::function<void()> fn) override
    {
        const int id = ++m_next;
        m_tasks.push_back({id, m_now + ms, std::move(fn)});
        return id;
    }
    void cancel(int id) override
    {
        m_tasks.erase(std::remove_if(m_tasks.begin(), m_tasks.end(), [id](const Task &t) { return t.id == id; }),
                      m_tasks.end());
    }
    void advance(int ms)
    {
        const qint64 target = m_now + ms;
        for (;;) {
            auto it = std::min_element(m_tasks.begin(), m_tasks.end(), [](const Task &a, const Task &b) {
                return a.due != b.due ? a.due < b.due : a.id < b.id;
            });
            if (it == m_tasks.end() || it->due > target)
                break;
            m_now = it->due;
            auto fn = std::move(it->fn);
            m_tasks.erase(it);
            fn();
        }
        m_now = target;
    }
    int pending() const { return int(m_tasks.size()); }
    qint64 now() const { return m_now; }

private:
    struct Task {
        int id;
        qint64 due;
        std::function<void()> fn;
    };
    std::vector<Task> m_tasks;
    qint64 m_now = 0;
    int m_next = 0;
};
