#pragma once
#include "IslandTypes.h"

#include <QList>
#include <QString>
#include <QStringList>

namespace farol {

enum class AgentSource { ClaudeCode, N8n };

// One line of what a session did (the session card shows the last three): a prompt, a tool call, a subagent. The
// step of an edit also says how many lines it added and removed, once the tool has run.
struct Step {
    QString label;
    QString toolUseId;               // the tool call it stands for, so that the call's PostToolUse finds it
    QString file;                    // the file an edit changed
    int added = -1, removed = -1;    // lines; -1: not an edit, or not done yet
    qint64 diff = 0;                 // the id EditDiffs keeps its diff under; 0 = none to open
};

struct AgentTask {
    QString id;
    QString name;
    bool titled = false;     // name is the session's own title, not a project name: it gets more room on screen
    QString color;   // "#RRGGBB"
    int boat = 0;    // which of the six boats (Boat.qml) stands for the session in the compact island
    int contextTokens = 0;   // what the session's last answer had in its context window; 0 = not known
    int contextWindow = 0;   // the size of that window, see AppState::contextWindowFor
    bool dormant = false;   // at rest for longer than Settings allows: no pill in the overview
    BotState state = BotState::Idle;
    int stepIndex = 0;
    QList<Step> steps;
    AgentSource source = AgentSource::ClaudeCode;
    bool isIntegration = false;
    QString pillBadge;   // "", "approval", "finished" or "error"
    QString sessionCwd;
    QString alertText;       // question text, finished summary or error message shown by the alert views
    QString finalMessage;    // what Claude said when the turn ended, as plain text (see plainMessage); empty = show the steps
    QStringList options;     // AskUserQuestion option labels (read-only in the island)
};

// The 8 permanent integration pills, Claude first (AgentTask.integrationAgents in AppState.swift).
QList<AgentTask> integrationAgents();
// Everything except Claude.
QStringList toggleableIntegrationIds();

} // namespace farol
