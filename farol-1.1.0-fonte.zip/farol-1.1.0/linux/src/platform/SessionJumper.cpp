#include "SessionJumper.h"

#include "ProcessWatcher.h"
#include "X11.h"

#include <QDBusConnection>
#include <QDBusMessage>
#include <QDBusPendingCall>
#include <QDBusReply>
#include <QProcess>
#include <QTemporaryFile>

namespace farol {

namespace {
const QString kKWin = QStringLiteral("org.kde.KWin");
const QString kPlugin = QStringLiteral("farol-jump");
constexpr int kKWinTimeoutMs = 1500;
// "Nova sessão": a folder that was not open yet takes a while to become a window (a cold editor start included).
constexpr int kLookAgainMs = 700;
constexpr int kMaxLooks = 40;
// The editor sends the URI to the window it believes has the focus: give it a moment to notice the one just raised.
constexpr int kRaisedSettleMs = 400;
constexpr int kNewWindowSettleMs = 1500;

void run(const JumpCommand &c)
{
    if (c.kind == JumpCommand::Kind::Process)
        QProcess::startDetached(c.program, c.args);
}

// The pids, on this side, of the processes above Claude Code that are still running.
QList<qint64> hostPids(const JumpTarget &target)
{
    QList<qint64> pids;
    for (const auto &[pid, start] : target.ancestors)
        if (const qint64 host = ProcessWatcher::hostPid(pid, start); host > 1)
            pids << host;
    return pids;
}

// Where there is no KWin to ask (Cinnamon): the same choice among the windows the X11 window manager lists.
bool raiseWithX11(const QStringList &folders, const QStringList &windowClasses, const QList<qint64> &pids, bool anyWindow)
{
    const QList<DesktopWindow> windows = x11::windows();
    const int hit = windowToRaise(windows, folders, windowClasses, pids, anyWindow);
    if (hit < 0)
        return false;
    x11::activate(windows[hit].id);
    return true;
}
} // namespace

SessionJumper::SessionJumper(QObject *parent) : QObject(parent)
{
    m_timeout.setSingleShot(true);
    m_timeout.setInterval(kKWinTimeoutMs);
    connect(&m_timeout, &QTimer::timeout, this, [this] { WindowResult(false); });   // KWin never answered
    m_lookAgain.setSingleShot(true);
    m_lookAgain.setInterval(kLookAgainMs);
    connect(&m_lookAgain, &QTimer::timeout, this, &SessionJumper::lookForSessionWindow);
    QDBusConnection bus = QDBusConnection::sessionBus();
    m_registered = bus.registerService(QStringLiteral("local.joao.Farol")) &&
                   bus.registerObject(QStringLiteral("/Jumper"), this, QDBusConnection::ExportScriptableSlots);
}

SessionJumper::~SessionJumper()
{
    finishKWinScript();
}

void SessionJumper::jump(const JumpTarget &target)
{
    m_lookAgain.stop();   // a jump takes over from a "Nova sessão" still looking for its window
    m_opening = {};
    const JumpCommand c = jumpCommandFor(target);
    switch (c.kind) {
    case JumpCommand::Kind::None:
        break;
    case JumpCommand::Kind::Process:
        // The script decides: the folder is only opened when no window names it.
        if (m_registered && activateWithKWin(windowFolderCandidates(target.cwd), c.windowClasses, hostPids(target), false,
                                             [c](bool found) { if (!found) run(c); }))
            break;
        if (!x11::available() || !raiseWithX11(windowFolderCandidates(target.cwd), c.windowClasses, hostPids(target), false))
            run(c);
        break;
    case JumpCommand::Kind::KonsoleDBus: {
        QDBusMessage m = QDBusMessage::createMethodCall(c.service, c.objectPath, QStringLiteral("org.kde.konsole.Window"),
                                                        QStringLiteral("setCurrentSession"));
        m << c.sessionId;
        QDBusConnection::sessionBus().asyncCall(m, 1000);
        [[fallthrough]];   // the tab is the right one: now bring its window forward
    }
    case JumpCommand::Kind::RaiseWindow:
        if (const QList<qint64> pids = hostPids(target); !pids.isEmpty()) {
            if (!(m_registered && activateWithKWin(windowFolderCandidates(target.cwd), {}, pids, true, nullptr)) && x11::available())
                raiseWithX11(windowFolderCandidates(target.cwd), {}, pids, true);
        }
        break;
    }
}

void SessionJumper::openSession(const QString &repo, const JumpTarget &editor)
{
    const JumpCommand openFolder = jumpCommandFor({QStringLiteral("vscodium"), repo, editor.flatpakId, {}, {}, {}, editor.editor, {}});
    if (openFolder.kind != JumpCommand::Kind::Process)
        return;
    m_lookAgain.stop();
    m_opening = {repo, openFolder, editor, 0};
    lookForSessionWindow();
}

void SessionJumper::lookForSessionWindow()
{
    if (m_opening.repo.isEmpty())
        return;
    if (m_registered && activateWithKWin(sessionWindowFolders(m_opening.repo), m_opening.openFolder.windowClasses, {}, false,
                                         [this](bool found) { sessionWindowLooked(found); }))
        return;
    if (x11::available()) {
        sessionWindowLooked(raiseWithX11(sessionWindowFolders(m_opening.repo), m_opening.openFolder.windowClasses, {}, false));
        return;
    }
    // Nobody to say when the window is there: the folder opens, the Claude tab is left to the user (a URI sent
    // blindly could start the session in another repository's window).
    if (m_opening.looks == 0)
        run(m_opening.openFolder);
    m_opening = {};
}

void SessionJumper::sessionWindowLooked(bool found)
{
    if (m_opening.repo.isEmpty())
        return;
    if (found) {
        const JumpCommand newTab = newClaudeTabCommand(m_opening.editor.flatpakId, m_opening.editor.editor);
        QTimer::singleShot(m_opening.looks == 0 ? kRaisedSettleMs : kNewWindowSettleMs, this, [newTab] { run(newTab); });
        m_opening = {};
        return;
    }
    if (m_opening.looks == 0)
        run(m_opening.openFolder);                   // not open yet: open the folder, then wait for its window
    if (++m_opening.looks > kMaxLooks) {
        qWarning("Nova sessão: the window of %s never showed up; no Claude tab was opened.", qPrintable(m_opening.repo));
        m_opening = {};
        return;
    }
    m_lookAgain.start();
}

bool SessionJumper::activateWithKWin(const QStringList &folders, const QStringList &windowClasses, const QList<qint64> &pids,
                                     bool anyWindow, Found then)
{
    finishKWinScript();   // a previous click that never got an answer
    auto *file = new QTemporaryFile(this);
    if (!file->open()) {
        delete file;
        return false;
    }
    file->write(kwinActivateScript(folders, windowClasses, pids, anyWindow).toUtf8());
    file->flush();

    QDBusConnection bus = QDBusConnection::sessionBus();
    QDBusMessage load = QDBusMessage::createMethodCall(kKWin, QStringLiteral("/Scripting"), QStringLiteral("org.kde.kwin.Scripting"),
                                                       QStringLiteral("loadScript"));
    load << file->fileName() << kPlugin;
    const QDBusReply<int> id = bus.call(load, QDBus::Block, 500);
    if (!id.isValid() || id.value() < 0) {
        delete file;
        return false;                                // no KWin (or no scripting): the caller falls back
    }
    m_script = file;
    m_then = std::move(then);
    m_waiting = true;
    m_timeout.start();
    QDBusMessage run = QDBusMessage::createMethodCall(kKWin, QStringLiteral("/Scripting/Script%1").arg(id.value()),
                                                      QStringLiteral("org.kde.kwin.Script"), QStringLiteral("run"));
    bus.asyncCall(run, 1000);
    return true;
}

void SessionJumper::WindowResult(bool found)
{
    if (!m_waiting)
        return;
    const Found then = std::move(m_then);
    finishKWinScript();
    if (then)
        then(found);
}

void SessionJumper::finishKWinScript()
{
    m_timeout.stop();
    m_waiting = false;
    m_then = nullptr;
    if (!m_script)
        return;
    QDBusMessage unload = QDBusMessage::createMethodCall(kKWin, QStringLiteral("/Scripting"), QStringLiteral("org.kde.kwin.Scripting"),
                                                         QStringLiteral("unloadScript"));
    unload << kPlugin;
    QDBusConnection::sessionBus().asyncCall(unload, 1000);
    delete m_script;   // removes the temporary file
    m_script = nullptr;
}

} // namespace farol
