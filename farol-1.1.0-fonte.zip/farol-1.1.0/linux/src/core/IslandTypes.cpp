#include "IslandTypes.h"

#include <algorithm>
#include <iterator>

namespace farol {

// Same order as enum IslandView. Values copied from IslandConst.viewLayouts in IslandTypes.swift.
static const ViewLayout kLayouts[] = {
    /* Overview  */ {160, 68,  std::nullopt, 58, AgentLayoutMode::Pills},
    /* Empty     */ {160, 70,  std::nullopt, 62, AgentLayoutMode::None},
    /* Approval  */ {160, 62,  std::nullopt, 56, AgentLayoutMode::Column},
    /* Question  */ {200, 62,  std::nullopt, 56, AgentLayoutMode::Column},   // Farol: up to 4 options to click
    /* Error     */ {160, 62,  std::nullopt, 58, AgentLayoutMode::Column},
    /* Finished  */ {160, 62,  std::nullopt, 58, AgentLayoutMode::Column},
    /* Confused  */ {160, 76,  std::nullopt, 66, AgentLayoutMode::Column},
    /* Upload    */ {280, 140, 104.0,        62, AgentLayoutMode::Column},   // Farol: "Nova sessão", the repository list
    /* Uploading */ {176, 46,  118.0,        20, AgentLayoutMode::None},
    /* Choose    */ {176, 60,  101.0,        52, AgentLayoutMode::Column},
    /* Mail      */ {240, 56,  std::nullopt, 46, AgentLayoutMode::Column},
    /* Prompt    */ {160, 52,  std::nullopt, 44, AgentLayoutMode::Column},
    /* Searching */ {160, 52,  std::nullopt, 44, AgentLayoutMode::Column},
    /* Result    */ {160, 52,  std::nullopt, 44, AgentLayoutMode::Column},
    /* Note      */ {160, 60,  std::nullopt, 50, AgentLayoutMode::Column},
    /* Settings  */ {300, 54,  std::nullopt, 46, AgentLayoutMode::None},   // Farol: the pages beside the options; what does not fit scrolls
    /* Skills    */ {280, 54,  std::nullopt, 46, AgentLayoutMode::None},   // Farol: the company's skills and the plugins (see SkillsView.qml)
    /* Ask       */ {300, 54,  std::nullopt, 46, AgentLayoutMode::None},   // Farol: files and questions about them (see AskView.qml)
    /* Diff      */ {300, 54,  std::nullopt, 46, AgentLayoutMode::None},   // Farol: the diff of an edit, as tall as Settings (see DiffView.qml)
    /* Greeting  */ {150, 320, 90.0,         0,  AgentLayoutMode::None},
};
static_assert(std::size(kLayouts) == int(IslandView::Greeting) + 1, "one layout per IslandView");

const ViewLayout &viewLayout(IslandView view)
{
    return kLayouts[int(view)];
}

// Farol: heights of the portrait island per view (same order as enum IslandView). The width is always 280.
static const qreal kPortraitHeights[] = {
    /* Overview */ 420, /* Empty */ 200, /* Approval */ 300, /* Question */ 400, /* Error */ 250, /* Finished */ 250,
    /* Confused */ 260, /* Upload */ 480, /* Uploading */ 220, /* Choose */ 260, /* Mail */ 380, /* Prompt */ 340,
    /* Searching */ 260, /* Result */ 260, /* Note */ 260, /* Settings */ 600, /* Skills */ 620, /* Ask */ 620, /* Diff */ 600,
    /* Greeting */ 300};
static_assert(std::size(kPortraitHeights) == int(IslandView::Greeting) + 1, "one portrait height per IslandView");

QSizeF islandSize(IslandMode mode, IslandView view, qreal nw, qreal nh, int chatCount, bool portrait)
{
    if (!(nw > 0))
        nw = IslandConst::notchWidth;
    if (!(nh > 0))
        nh = IslandConst::notchHeight;
    switch (mode) {
    case IslandMode::Hidden:
        return portrait ? QSizeF(nh, nw) : QSizeF(nw, nh);
    case IslandMode::Compact:
        return portrait ? QSizeF(36, 100) : QSizeF(nw + IslandConst::compactExtraWidth, nh);
    case IslandMode::Expanded: {
        if (portrait) {
            qreal h = kPortraitHeights[int(view)];
            if (view == IslandView::Prompt)
                h = std::min<qreal>(420, 340 + std::max(0, chatCount) * 40);
            return {IslandConst::expandedWidthPortrait, h};
        }
        qreal h = viewLayout(view).height;
        if (view == IslandView::Prompt)
            h = std::min<qreal>(300, 240 + std::max(0, chatCount) * 40);
        return {IslandConst::expandedWidth, h};
    }
    }
    return {nw, nh};
}

qreal islandCornerRadius(IslandMode mode)
{
    return mode == IslandMode::Expanded ? IslandConst::expandedCorner : IslandConst::roundedCorner;
}

QRectF hiddenStrip(IslandEdge edge, const QSizeF &window, qreal length)
{
    constexpr qreal t = 3;
    switch (edge) {
    case IslandEdge::Top: return {(window.width() - length) / 2, 0, length, t};
    case IslandEdge::Bottom: return {(window.width() - length) / 2, window.height() - t, length, t};
    case IslandEdge::Left: return {0, (window.height() - length) / 2, t, length};
    case IslandEdge::Right: return {window.width() - t, (window.height() - length) / 2, t, length};
    }
    return {};
}

// Farol deviates from the Swift layout table on purpose (the ViewLayout botX/botY/botDiameter stay as reference data):
//  * compact: the mascot hugs the left corner of the pill (Swift keeps it at cx = 40 to clear the physical notch);
//  * expanded: one spot for every view, on top of the rail, so Lumi does not move when the user changes tab. Only the upload in progress
//    (rides the progress bar) and the greeting keep their own placement.
BotPlacement botPosition(IslandMode mode, IslandView view, [[maybe_unused]] qreal islandH, double uploadProgress, bool portrait)
{
    if (portrait) {   // Farol: the portrait island has its own spots: the top corner when compact, on the rail when open
        switch (mode) {
        case IslandMode::Hidden: return {18, 16, 6, 0};
        case IslandMode::Compact: return {18, 16, 20, 1};
        case IslandMode::Expanded:
            if (view == IslandView::Greeting)
                return {viewLayout(view).botX, viewLayout(view).botY.value_or(0), viewLayout(view).botDiameter, 1};
            return {44, 44, 52, 1};   // top-left, on the rail; the tabs sit beside it
        }
    }
    switch (mode) {
    case IslandMode::Hidden:
        return {46, 16, 6, 0};
    case IslandMode::Compact:
        return {16, 16, 20, 1};
    case IslandMode::Expanded: {
        const ViewLayout &l = viewLayout(view);
        if (view == IslandView::Uploading)
            return {36 + uploadProgress * 526, l.botY.value_or(103), l.botDiameter, 1};
        if (view == IslandView::Greeting)
            return {l.botX, l.botY.value_or(0), l.botDiameter, 1};
        // On top of the rail (88 wide from x = 10); the tabs come under it.
        return {54, 48, 52, 1};
    }
    }
    return {46, 16, 6, 0};
}

} // namespace farol
