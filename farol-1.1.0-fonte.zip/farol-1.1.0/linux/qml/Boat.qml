import QtQuick

// One boat per session. `kind` picks one of the eight boats of the fleet (BoatArt.qml) and `tint`, the session's
// colour, paints its sail or stripe, so no two sessions look alike. The pennant at the stern says what the session
// is doing (`mood`, the session's signal): working, waiting for you, done, error, or at rest.
//   working  crosses the whole lane and back, again and again, for as long as the session runs
//   others   lie at their berth
// A session that turned dormant has no boat in the compact island (it fades out, its berth is kept); in the session
// list (`moored`) every session has its boat, tied up. Nothing moves off screen or with "Reduzir movimento".
Item {
    id: boat
    property int kind: 0               // 0 saveiro, 1 pirata, 2 fantasma, 3 jangada, 4 pesqueiro, 5 vapor, 6 rebocador, 7 canoa
    property color tint: theme.text
    property string mood: "idle"
    property bool dormant: false
    property real size: 1              // 1 = 18x14, the compact island; 2 = 36x28, the session list
    property real lane: width          // how far it travels; no wider than the boat means it only rocks
    property real berth: 0             // where along the lane it lies when it is not under sail
    property alias hullObjectName: hull.objectName
    property bool moored: false        // in the session list: always there, tied up, whatever the session does
    readonly property bool sailing: !moored && mood === "working"
    readonly property bool animated: visible && sailing && !appState.reduceMotion
    readonly property real travel: Math.max(0, lane - hull.width)
    readonly property color flagColor: mood === "working" ? theme.working : mood === "waiting" ? theme.lamp
                                     : mood === "done" ? theme.ok : mood === "error" ? theme.alert : theme.idle
    width: 18 * size
    height: 14 * size
    readonly property bool present: moored || !dormant
    opacity: present ? 1 : 0
    Behavior on opacity { NumberAnimation { duration: 250 } }

    Item {
        id: hull
        width: boat.width
        height: boat.height
        property real heading: 1       // 1 sails to the right, -1 to the left
        property real rockAngle: 0
        property real sailX: 0
        x: boat.animated ? sailX : boat.berth
        Behavior on x { enabled: !boat.animated && boat.visible; NumberAnimation { duration: 700; easing.type: Easing.OutCubic } }
        transform: [Scale { origin.x: hull.width / 2; xScale: hull.heading },
                    Rotation { origin.x: hull.width / 2; origin.y: hull.height * 0.85; angle: hull.rockAngle }]

        BoatArt {
            kind: boat.kind
            tint: boat.tint
            flag: boat.flagColor
            scale: boat.size / 2       // drawn on a 36x28 grid
            transformOrigin: Item.TopLeft
        }
    }

    // each kind of boat has its own pace, so two of them do not sail side by side for long
    readonly property int legMs: Math.max(600, travel * (60 + kind * 9))
    onAnimatedChanged: if (animated) hull.sailX = berth      // it leaves from where it lay
    SequentialAnimation {
        running: boat.animated && boat.travel > 0
        loops: Animation.Infinite
        onStopped: hull.heading = 1
        NumberAnimation { target: hull; property: "sailX"; to: boat.travel; duration: boat.legMs; easing.type: Easing.InOutSine }
        PropertyAction { target: hull; property: "heading"; value: -1 }
        NumberAnimation { target: hull; property: "sailX"; to: 0; duration: boat.legMs; easing.type: Easing.InOutSine }
        PropertyAction { target: hull; property: "heading"; value: 1 }
    }
    SequentialAnimation {
        running: boat.animated
        loops: Animation.Infinite
        onStopped: hull.rockAngle = 0
        NumberAnimation { target: hull; property: "rockAngle"; to: 4; duration: 900; easing.type: Easing.InOutSine }
        NumberAnimation { target: hull; property: "rockAngle"; to: -4; duration: 900; easing.type: Easing.InOutSine }
    }
}
