#include "AgentTask.h"

namespace farol {

static AgentTask pill(const char *id, const char *name, const char *color, AgentSource src)
{
    AgentTask t;
    t.id = QString::fromLatin1(id);
    t.name = QString::fromUtf8(name);
    t.color = QString::fromLatin1(color);
    t.source = src;
    t.isIntegration = true;
    return t;
}

QList<AgentTask> integrationAgents()
{
    return {
        pill("integration_claude", "VS Code", "#F5F6F8", AgentSource::ClaudeCode),
        pill("integration_resend", "Resend", "#22C55E", AgentSource::N8n),
        pill("integration_n8n", "n8n", "#F29B38", AgentSource::N8n),
        pill("integration_vercel", "Vercel", "#7C5CFF", AgentSource::N8n),
        pill("integration_github", "GitHub", "#F4505E", AgentSource::N8n),
        pill("integration_notion", "Notion", "#8C8C8C", AgentSource::N8n),
        pill("integration_calcom", "Cal.com", "#C9956A", AgentSource::N8n),
        pill("integration_stripe", "Stripe", "#0570DE", AgentSource::N8n),
    };
}

QStringList toggleableIntegrationIds()
{
    return {"integration_resend", "integration_n8n", "integration_vercel", "integration_github",
            "integration_notion", "integration_calcom", "integration_stripe"};
}

} // namespace farol
