#pragma once
#include "Scheduler.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QList>
#include <QObject>
#include <QSettings>
#include <QStringList>
#include <functional>

namespace farol {

struct ApprovalRequest {
    qint64 id = 0;
    QString sessionId, project, cwd, tool;
    QString command;   // all of it, as Claude Code sent it: the card shows ApprovalQueue::cardText() of it
};

// Release = "I did not decide": the hook prints nothing and Claude Code shows its own prompt.
enum class Decision { Allow, Deny, Release };

// FIFO of PermissionRequest hooks waiting for a click. One is in front (what the island shows); the rest wait.
class ApprovalQueue : public QObject {
    Q_OBJECT
    Q_PROPERTY(bool active READ active NOTIFY changed)
    Q_PROPERTY(QString project READ project NOTIFY changed)
    Q_PROPERTY(QString tool READ tool NOTIFY changed)
    Q_PROPERTY(QString command READ command NOTIFY changed)
    Q_PROPERTY(int commandChars READ commandChars NOTIFY changed)
    Q_PROPERTY(int commandLines READ commandLines NOTIFY changed)
    Q_PROPERTY(bool commandCut READ commandCut NOTIFY changed)
    Q_PROPERTY(int waiting READ waiting NOTIFY changed)

public:
    using Reply = std::function<void(Decision)>;
    // Below the hook's own 110 s wait, so the app releases first and the hook exits cleanly.
    static constexpr int kDefaultTimeoutMs = 105000;
    // How much of a command the card is given, and how many marks that take no room it keeps on one character.
    // A command is often longer, and "Sempre" is about all of it.
    static constexpr int kCardChars = 400;
    static constexpr int kCardMarks = 2;
    // From this length on "Sempre" keeps a command as a digest. It is what 1.0 cut a command to, and stays that
    // whatever the card is given: the rules 1.0 saved for shorter commands are the ones that still stand.
    static constexpr int kExactChars = 400;

    ApprovalQueue(IScheduler &scheduler, QSettings *settings, QObject *parent = nullptr);

    // Returns the request id. A request matching an "always allow" rule is answered (Allow) before returning
    // and never becomes visible.
    qint64 enqueue(ApprovalRequest request, Reply reply);
    // The hook went away (Claude Code killed it, the user answered in the editor): drop it, no reply.
    void cancel(qint64 id);

    bool active() const { return !m_entries.isEmpty(); }
    int pendingCount() const { return int(m_entries.size()); }
    int waiting() const { return m_entries.isEmpty() ? 0 : int(m_entries.size()) - 1; }
    QString project() const { return m_entries.isEmpty() ? QString() : m_entries.first().request.project; }
    QString tool() const { return m_entries.isEmpty() ? QString() : m_entries.first().request.tool; }
    QString command() const { return m_entries.isEmpty() ? QString() : cardText(m_entries.first().request.command); }
    // Of the whole command in front, for the card to say how much it does not show: its length, and how many of its
    // lines have something on them.
    int commandChars() const { return m_entries.isEmpty() ? 0 : int(m_entries.first().request.command.size()); }
    int commandLines() const;
    bool commandCut() const;   // cardText left something of it out, which the view cannot see by itself
    int alwaysCount() const { return int(m_always.size()); }
    void setTimeoutMs(int ms) { m_timeoutMs = ms; }

    static QString alwaysKey(const ApprovalRequest &r);
    // What the card shows of a command (or of a file name: text from outside either way), kCardChars at most. The
    // card has two lines, so a run of blanks takes one space and a line break one mark, and characters that are not
    // drawn or turn the text around (zero width, right-to-left override) count as blanks: what comes after them is
    // not pushed out of sight. Of marks piled on one character only kCardMarks are kept. `leftOut` says whether
    // anything that would be drawn did not get in (the end of a long command, the rest of a pile): the card then
    // says "Cortado" even when its two lines hold all it was given.
    static QString cardText(const QString &command, bool *leftOut = nullptr);

public slots:
    void allow();
    void deny();
    void always();
    void release();

signals:
    void changed();
    void shown(const farol::ApprovalRequest &request);
    void resolved(const farol::ApprovalRequest &request, farol::Decision decision);
    // After resolved(), when the request was handed back to Claude Code undecided (timeout or "Decide in editor"):
    // its own prompt is on screen now and the session still waits for the user. Not emitted for cancel().
    void leftToEditor(const farol::ApprovalRequest &request);

private:
    struct Entry {
        ApprovalRequest request;
        Reply reply;
        int timer = 0;
    };
    void resolve(qint64 id, Decision decision, bool sendReply);

    IScheduler &m_sched;
    QSettings *m_settings;
    QList<Entry> m_entries;
    QStringList m_always;
    qint64 m_nextId = 0;
    int m_timeoutMs = kDefaultTimeoutMs;
};

} // namespace farol
