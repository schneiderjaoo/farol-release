import QtQuick

Item {
    Card { anchors.fill: parent; wash: theme.alert }
    Column {
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: appState.vertical ? 12 : 16
        anchors.rightMargin: appState.vertical ? 12 : 16
        spacing: 5

        AgentWho {
            name: appState.focusTask.name || ""
            label: "stopped with an error"
            dot: appState.focusTask.color || theme.muted
        }
        Text {
            objectName: "errorTitle"
            width: parent.width
            textFormat: Text.PlainText
            text: appState.focusTask.alertText || "Claude Code stopped with an error"
            color: theme.alertText
            font.family: theme.titleFont
            font.pixelSize: 15
            font.weight: Font.DemiBold
            wrapMode: Text.Wrap
            maximumLineCount: appState.vertical ? 3 : 2
            elide: Text.ElideRight
        }
        Flow {   // the buttons wrap onto more lines in the portrait island
            width: parent.width
            spacing: 8
            PillButton {
                text: "Abrir sessão"
                primary: true
                onClicked: { sessions.jump(appState.focusId); controller.collapse() }
            }
            PillButton { text: "OK"; onClicked: controller.collapse() }
        }
    }
}
