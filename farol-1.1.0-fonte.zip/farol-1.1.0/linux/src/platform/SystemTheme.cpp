#include "SystemTheme.h"

#include <QDBusConnection>
#include <QDBusMessage>
#include <QDBusPendingCallWatcher>
#include <QDBusPendingReply>
#include <QDBusVariant>
#include <QGuiApplication>
#include <QStyleHints>

namespace farol {

namespace {
const QString kPortal = QStringLiteral("org.freedesktop.portal.Desktop");
const QString kPath = QStringLiteral("/org/freedesktop/portal/desktop");
const QString kSettings = QStringLiteral("org.freedesktop.portal.Settings");
const QString kGroup = QStringLiteral("org.freedesktop.appearance");
const QString kKey = QStringLiteral("color-scheme");

// The portal's answer is a number wrapped in a variant, once or twice: 0 no preference, 1 dark, 2 light.
bool saysDark(QVariant value)
{
    while (value.canConvert<QDBusVariant>())
        value = value.value<QDBusVariant>().variant();
    return value.toUInt() != 2;
}
} // namespace

SystemTheme::SystemTheme(QObject *parent) : QObject(parent)
{
#if QT_VERSION >= QT_VERSION_CHECK(6, 5, 0)
    const auto read = [this] { set(QGuiApplication::styleHints()->colorScheme() != Qt::ColorScheme::Light); };
    read();
    connect(QGuiApplication::styleHints(), &QStyleHints::colorSchemeChanged, this, read);
#else
    QDBusConnection bus = QDBusConnection::sessionBus();
    bus.connect(kPortal, kPath, kSettings, QStringLiteral("SettingChanged"), this, SLOT(portalSetting(QString, QString, QDBusVariant)));
    QDBusMessage ask = QDBusMessage::createMethodCall(kPortal, kPath, kSettings, QStringLiteral("Read"));
    ask << kGroup << kKey;
    auto *watcher = new QDBusPendingCallWatcher(bus.asyncCall(ask, 2000), this);
    connect(watcher, &QDBusPendingCallWatcher::finished, this, [this, watcher] {
        const QDBusPendingReply<QVariant> answer = *watcher;
        watcher->deleteLater();
        if (!answer.isError())
            set(saysDark(answer.value()));
    });
#endif
}

void SystemTheme::portalSetting(const QString &group, const QString &key, const QDBusVariant &value)
{
    if (group == kGroup && key == kKey)
        set(saysDark(value.variant()));
}

void SystemTheme::set(bool dark)
{
    if (dark == m_dark)
        return;
    m_dark = dark;
    emit changed();
}

} // namespace farol
