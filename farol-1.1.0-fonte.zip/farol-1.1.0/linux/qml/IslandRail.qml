import QtQuick

// The column on the left of every open view: Lumi on top (Island.qml puts it there, see botPosition) and the tabs
// under it, three across. In the portrait island the rail is a strip on top and the tabs are a row beside Lumi.
// The Skills tab carries a mark while the company's skills could not be updated or linked.
Item {
    id: rail
    readonly property bool vertical: appState.vertical

    Grid {
        objectName: "railTabs"
        x: rail.vertical ? 106 : 2
        y: rail.vertical ? 21 : 80
        columns: rail.vertical ? 5 : 3
        spacing: 3
        RailTab {
            objectName: "railTabSessions"
            icon: "sessions"
            // the diff of an edit is opened from a session's card: it belongs to this tab
            on: appState.viewName === "overview" || appState.viewName === "empty" || appState.viewName === "diff"
            onClicked: controller.showView("overview")
        }
        RailTab {
            objectName: "railTabNew"
            icon: "new-session"
            on: appState.viewName === "upload"
            onClicked: controller.showView("upload")
        }
        RailTab {
            objectName: "railTabAsk"
            icon: "ask"
            on: appState.viewName === "ask"
            onClicked: controller.showView("ask")
        }
        RailTab {
            objectName: "railTabSkills"
            icon: "skills"
            on: appState.viewName === "skills"
            mark: skills.warning
            onClicked: controller.showView("skills")
        }
        RailTab {
            objectName: "railTabSettings"
            icon: "settings"
            on: appState.viewName === "settings"
            onClicked: controller.showView("settings")
        }
    }
}
