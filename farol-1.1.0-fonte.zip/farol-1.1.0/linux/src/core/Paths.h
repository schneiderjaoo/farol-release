#pragma once
#include <QString>

namespace farol {

// Every path derives from $HOME, never from XDG_* variables: inside the VSCodium
// Flatpak those point to ~/.var/app/... and /run/user/UID is not shared, so the
// hook (sandbox) and the app (host) would disagree on where the socket lives.
// On Windows Farol's own files are all in %LOCALAPPDATA%\Farol and the "socket" is the name of a pipe; the paths
// in the comments below are the Linux ones.
struct Paths {
    static QString home();
    static QString dataDir();            // ~/.local/share/farol
    static QString socketPath();         // ~/.local/share/farol/farol.sock
    static QString hookScriptPath();     // ~/.local/share/farol/farol-hook
    static QString inboxDir();           // ~/.local/share/farol/inbox
    static QString configFile();         // ~/.config/farol/farol.conf
    static QString logFile();            // ~/.local/state/farol/farol.log
    static QString claudeSettingsPath(); // ~/.claude/settings.json
    static QString claudeSkillsDir();    // ~/.claude/skills

    // mkdir -p, then force mode 0700 (also on a directory that already existed).
    static bool ensurePrivateDir(const QString &path);
    // sockaddr_un.sun_path holds 108 bytes including the terminating NUL.
    static bool fitsUnixSocket(const QString &path);
};

} // namespace farol
