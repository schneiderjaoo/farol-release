#pragma once
#include "CommandRunner.h"

#include <QObject>

namespace farol {

// ICommandRunner with QProcess: nothing blocks, the answer comes once, a command over its time is killed.
class ProcessRunner : public QObject, public ICommandRunner {
    Q_OBJECT
public:
    explicit ProcessRunner(QObject *parent = nullptr) : QObject(parent) {}
    void run(const QString &program, const QStringList &arguments, const QStringList &env, int timeoutMs,
             std::function<void(const Result &)> done, const QByteArray &input = {}) override;
    void cancel() override;
};

} // namespace farol
