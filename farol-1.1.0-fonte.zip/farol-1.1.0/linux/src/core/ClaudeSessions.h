#pragma once
#include "ApprovalQueue.h"
#include "EditDiffs.h"
#include "HookEvent.h"
#include "IslandTypes.h"
#include "JumpTarget.h"
#include "ProcessWatch.h"
#include "QuestionDesk.h"
#include "Scheduler.h"

#include <QHash>
#include <QObject>
#include <QStringList>
#include <functional>

namespace farol {

class AppState;
class IslandController;

// Turns hook events into island state: one AgentTask ("pill") per Claude Code session, alerts (question, finished,
// error) and permission requests. Port of HookServer.processEvent in the Swift app, with one pill per session
// instead of the single permanent "VS Code" pill (deliberate divergence, see the L2 plan).
class ClaudeSessions : public QObject {
    Q_OBJECT
public:
    // A session at rest (idle or finished) for AppState::sessionIdleSeconds steps back: while its Claude Code
    // process is watched it turns dormant (no pill in the overview)
    // until its next event or the end of the process; when the process is not known it leaves the island, as does
    // any session of an unknown process after kExpiryMs of silence. Its next event brings it back.
    static constexpr int kExpiryMs = 30 * 60 * 1000;
    static constexpr int kFinishedMs = 5200;           // Swift: the finished state lasts 5.2 s
    // A session that waits for an answer calls again every AppState::waitReminderSeconds, this many times at most
    // (nobody is there after that: no sounds through the night).
    static constexpr int kMaxReminders = 5;

    // questions: AskUserQuestion answered with a click in the island (optional; without it the editor asks).
    // processes: ends a session the moment its Claude Code process exits, SessionEnd or not (optional; without it
    // a killed session waits for the timers above).
    // diffs: keeps the diff of every edit for the island to show (optional; without it an edit's step only counts).
    ClaudeSessions(AppState *state, IslandController *controller, IScheduler *scheduler, ApprovalQueue *queue,
                   QuestionDesk *questions = nullptr, IProcessWatch *processes = nullptr, EditDiffs *diffs = nullptr,
                   QObject *parent = nullptr);

    static QString taskId(const QString &sessionId) { return QStringLiteral("session_") + sessionId; }
    int sessionCount() const { return int(m_sessions.size()); }

    void handleEvent(const HookEvent &e);   // every event except PermissionRequest
    // Returns the request id (HookServer cancels it if the hook disconnects).
    qint64 handlePermission(const HookEvent &e, ApprovalQueue::Reply reply);
    // The PermissionRequest of an AskUserQuestion: held so the user can click an option in the island. The reply
    // gets the tool input with the answers, or {} to let the editor ask. Returns the id of the held question
    // (HookServer cancels it when the hook disconnects), 0 when it was left to the editor at once.
    qint64 handleQuestion(const HookEvent &e, QuestionDesk::Reply reply);
    void cancelQuestion(qint64 id);
    Q_INVOKABLE void jump(const QString &taskId);
    // Goes to the session that waits for an answer (the one most recently in focus), otherwise to the session in
    // focus. false when there is no session to go to.
    Q_INVOKABLE bool jumpToWaiting();
    // The editor of the session heard from last (Flatpak id or program); "Nova sessão" opens the same one. Empty
    // fields until an editor session was seen: VSCodium then.
    JumpTarget lastEditor() const { return m_lastEditor; }

signals:
    void playSound(const QString &name);
    void jumpRequested(const farol::JumpTarget &target);
    // The session calls for the user (question, permission, finished, error, a reminder): its name and one line
    // (pt-BR) saying why, for the desktop notification sent when nobody is looking at the island.
    void attention(const QString &session, const QString &text);

private:
    struct Session {
        JumpTarget jump;
        QString project;              // folder name; with `number` it makes the pill's name
        int number = 1;               // tells the sessions of one project apart: "farol", "farol 2", ...
        QString transcript;           // where Claude Code writes the session, title included
        QString title;                // the name Claude Code gave the session; empty until it has one
        qint64 pid = 0, start = 0;    // the Claude Code process of the last event
        int watch = 0;
        int expiry = 0;
        int finish = 0;
        int remind = 0;               // timer of the next "still waiting for you"
        int reminders = 0;            // how many were given during this wait
    };
    void ensure(const HookEvent &e);
    void watchProcess(const QString &sid, const HookEvent &e);
    int freeNumber(const QString &project, const QString &exceptSid = {}) const;
    void readTitle(const QString &sid, const HookEvent &e);
    QString nameOf(const QString &sid, bool *titled = nullptr) const;
    void refreshNames(const QString &project);
    bool atRest(const QString &sid) const;
    void arm(const QString &sid);
    void setDormant(const QString &sid, bool dormant);
    void end(const QString &sid);
    void setState(const QString &sid, BotState state);
    void appendStep(const QString &sid, const QString &label, const QString &toolUseId = {});
    void recordEdit(const QString &sid, const HookEvent &e);
    void dismissStale(const QString &sid);
    void focus(const QString &sid);
    void focusUnlessBusy(const QString &sid);
    void showQuestion(const QString &sid, const QString &text, const QStringList &options);
    void onStop(const QString &sid, const HookEvent &e);
    void onQuestionFinished(const QString &sid, bool answered);
    bool showWaiting();
    bool waitsElsewhere(const QString &sid) const;
    void onShown(const ApprovalRequest &r);
    void onResolved(const ApprovalRequest &r, Decision decision);
    void onLeftToEditor(const ApprovalRequest &r);
    void scheduleReminder(const QString &sid);
    void remind(const QString &sid);
    QString nextColor() const;
    int nextBoat(const QString &color) const;

    AppState *m_state;
    IslandController *m_controller;
    IScheduler *m_sched;
    ApprovalQueue *m_queue;
    QuestionDesk *m_questions;
    IProcessWatch *m_processes;
    EditDiffs *m_diffs;
    QHash<QString, Session> m_sessions;
    QStringList m_order;   // session ids, most recently focused first
    JumpTarget m_lastEditor;
};

} // namespace farol
