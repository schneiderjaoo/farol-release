#include "SoundEngine.h"

#include "SoundNames.h"

#include <QSoundEffect>
#include <QUrl>
#include <algorithm>
#include <cmath>

namespace farol {

SoundEngine::SoundEngine(const QString &soundsDir, QObject *parent) : QObject(parent), m_dir(soundsDir) {}

bool SoundEngine::isLoaded(const QString &name) const
{
    const auto it = m_pool.constFind(name);
    if (it == m_pool.constEnd())
        return false;
    return std::all_of(it->begin(), it->end(), [](QSoundEffect *fx) { return fx->status() == QSoundEffect::Ready; });
}

int SoundEngine::voiceCount() const
{
    int n = 0;
    for (const auto &voices : m_pool)
        n += int(voices.size());
    return n;
}

void SoundEngine::setVolume(double v)
{
    if (!std::isfinite(v))
        return;
    m_volume = std::clamp(v, 0.0, 0.2);
    for (const auto &voices : std::as_const(m_pool))
        for (QSoundEffect *fx : voices)
            fx->setVolume(float(m_volume));
}

void SoundEngine::play(const QString &name)
{
    if (!m_enabled)
        return;
    if (!soundNames().contains(name))
        return;
    QList<QSoundEffect *> &voices = m_pool[name];
    QSoundEffect *voice = nullptr;
    for (QSoundEffect *fx : voices) {
        if (!fx->isPlaying()) {
            voice = fx;
            break;
        }
    }
    if (!voice && voices.size() < kMaxVoices) {
        voice = new QSoundEffect(this);              // plays as soon as the file is loaded
        voice->setSource(QUrl::fromLocalFile(m_dir + "/" + name + ".wav"));
        voices << voice;
    }
    if (!voice)
        voice = voices.first();                      // all three busy: the oldest starts over
    voice->setVolume(float(m_volume));
    voice->play();
}

} // namespace farol
