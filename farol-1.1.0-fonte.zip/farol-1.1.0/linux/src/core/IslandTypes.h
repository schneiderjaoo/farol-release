#pragma once
#include <QMetaEnum>
#include <QObject>
#include <QRectF>
#include <QSizeF>
#include <QString>
#include <optional>

namespace farol {
Q_NAMESPACE

enum class IslandMode { Hidden, Compact, Expanded };
Q_ENUM_NS(IslandMode)

enum class IslandView {
    Overview, Empty, Approval, Question, Error, Finished, Confused, Upload, Uploading,
    Choose, Mail, Prompt, Searching, Result, Note, Settings, Skills, Ask, Diff, Greeting
};
Q_ENUM_NS(IslandView)

// The screen edge the island is docked to (Farol setting; the Swift app always hangs from the top).
enum class IslandEdge { Top, Bottom, Left, Right };
Q_ENUM_NS(IslandEdge)

enum class BotState { Idle, Working, Thinking, Searching, Approval, Question, Error, Finished, Ratelimit, Sleeping, Dizzy };
Q_ENUM_NS(BotState)

enum class BotEmote { Love, Surprised, Proud, Wink, Yawn, Happy, Annoyed };
Q_ENUM_NS(BotEmote)

enum class AgentLayoutMode { None, Grid, Pills, Column };

// "Overview" -> "overview": the form QML and QSettings use.
template <typename E>
QString enumKey(E e)
{
    QString k = QString::fromLatin1(QMetaEnum::fromType<E>().valueToKey(int(e)));
    if (!k.isEmpty())
        k[0] = k[0].toLower();
    return k;
}

template <typename E>
std::optional<E> enumFromKey(const QString &key)
{
    if (key.isEmpty())
        return std::nullopt;
    QString k = key;
    k[0] = k[0].toUpper();
    bool ok = false;
    const int v = QMetaEnum::fromType<E>().keyToValue(k.toLatin1().constData(), &ok);
    if (!ok)
        return std::nullopt;
    return E(v);
}

namespace IslandConst {
inline constexpr qreal notchWidth = 184;
inline constexpr qreal notchHeight = 32;
inline constexpr qreal expandedWidth = 640;
inline constexpr qreal expandedWidthPortrait = 280;   // Farol: docked to a side edge
inline constexpr qreal roundedCorner = 14;   // hidden / compact
inline constexpr qreal expandedCorner = 22;
inline constexpr qreal compactExtraWidth = 160;
} // namespace IslandConst

struct ViewLayout {
    qreal height;
    qreal botX;
    std::optional<qreal> botY;   // nullopt = centred on the card
    qreal botDiameter;
    AgentLayoutMode agentMode;
};

const ViewLayout &viewLayout(IslandView view);

// notchW/notchH <= 0 (or NaN) fall back to the Swift defaults 184x32.
// `portrait` = docked to a side edge (Farol): a narrow column instead of the landscape island.
QSizeF islandSize(IslandMode mode, IslandView view, qreal notchW, qreal notchH, int chatCount = 0, bool portrait = false);
qreal islandCornerRadius(IslandMode mode);

struct BotPlacement {
    qreal cx, cy, diameter, opacity;
};
// The 3 px strip, centred on `length`, along the docked edge of the window that wakes a hidden island.
QRectF hiddenStrip(IslandEdge edge, const QSizeF &window, qreal length);

BotPlacement botPosition(IslandMode mode, IslandView view, qreal islandH, double uploadProgress, bool portrait = false);

} // namespace farol
