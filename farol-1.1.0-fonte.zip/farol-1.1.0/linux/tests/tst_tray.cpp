#include <QtTest>
#include <QSettings>
#include <QTemporaryDir>
#include "AppState.h"
#include "FakeScheduler.h"
#include "IslandController.h"
#include "Tray.h"
#include <QAction>
#include <QMenu>

using namespace farol;

class TestTray : public QObject {
    Q_OBJECT
private slots:
    // KStatusNotifierItem owns the context menu it is given: deleting it a second time in ~Tray crashed on Quit.
    void createAndDestroyDoesNotCrash()
    {
        QTemporaryDir dir;
        QSettings settings(dir.path() + "/t.ini", QSettings::IniFormat);
        AppState state(&settings);
        FakeScheduler sched;
        IslandController ctl(&state, &sched, [] { return qint64(0); });
        auto *tray = new Tray(&state, &ctl);
        QTest::qWait(50);
        delete tray;
        QTest::qWait(50);
    }

    void menuHasNoDebugEntriesAndKeepsTheUsefulOnes()
    {
        QTemporaryDir dir;
        QSettings settings(dir.path() + "/t.ini", QSettings::IniFormat);
        AppState state(&settings);
        FakeScheduler sched;
        IslandController ctl(&state, &sched, [] { return qint64(0); });
        Tray tray(&state, &ctl);
        QStringList entries;
        for (QAction *a : tray.menu()->actions())
            if (!a->isSeparator())
                entries << a->text();
        QCOMPARE(entries, (QStringList{"Open Farol", "Settings…", "Claude Code hooks", "Quit"}));
    }

    void settingsEntryOpensTheSettingsView()
    {
        QTemporaryDir dir;
        QSettings settings(dir.path() + "/t.ini", QSettings::IniFormat);
        AppState state(&settings);
        FakeScheduler sched;
        IslandController ctl(&state, &sched, [] { return qint64(0); });
        Tray tray(&state, &ctl);
        QAction *entry = nullptr;
        for (QAction *a : tray.menu()->actions())
            if (a->text().startsWith("Settings"))
                entry = a;
        QVERIFY(entry);
        QVERIFY(entry->isEnabled());
        entry->trigger();
        QCOMPARE(state.viewName(), QStringLiteral("settings"));
        QVERIFY(state.mode() == IslandMode::Expanded);
    }

    void hooksSubmenuWiresInstallUninstallAndStatus()
    {
        QTemporaryDir dir;
        QSettings settings(dir.path() + "/t.ini", QSettings::IniFormat);
        AppState state(&settings);
        FakeScheduler sched;
        IslandController ctl(&state, &sched, [] { return qint64(0); });
        bool installCalled = false, uninstallCalled = false, installed = false, upToDate = true;
        TrayHooks hooks{[&] { installCalled = true; }, [&] { uninstallCalled = true; }, [&] { return installed; },
                        [&] { return upToDate; }};
        Tray tray(&state, &ctl, hooks);

        QAction *submenuAction = nullptr;
        for (QAction *a : tray.menu()->actions())
            if (a->menu() && a->text() == "Claude Code hooks")
                submenuAction = a;
        QVERIFY(submenuAction);
        QMenu *sub = submenuAction->menu();
        auto find = [&](const QString &prefix) -> QAction * {
            for (QAction *a : sub->actions())
                if (a->text().startsWith(prefix))
                    return a;
            return nullptr;
        };
        QVERIFY(find("Install")->isEnabled());
        find("Install")->trigger();
        find("Uninstall")->trigger();
        QVERIFY(installCalled && uninstallCalled);

        emit tray.menu()->aboutToShow();
        QCOMPARE(find("Hooks:")->text(), QStringLiteral("Hooks: not installed"));
        installed = true;
        emit tray.menu()->aboutToShow();
        QCOMPARE(find("Hooks:")->text(), QStringLiteral("Hooks: installed"));
        upToDate = false;                                    // written by an older Farol
        emit tray.menu()->aboutToShow();
        QCOMPARE(find("Hooks:")->text(), QStringLiteral("Hooks: update needed (Install…)"));
        QVERIFY(!find("Hooks:")->isEnabled());
    }

    void withoutHooksTheEntriesAreDisabled()
    {
        QTemporaryDir dir;
        QSettings settings(dir.path() + "/t.ini", QSettings::IniFormat);
        AppState state(&settings);
        FakeScheduler sched;
        IslandController ctl(&state, &sched, [] { return qint64(0); });
        Tray tray(&state, &ctl);
        for (QAction *a : tray.menu()->actions())
            if (a->menu() && a->text() == "Claude Code hooks")
                for (QAction *x : a->menu()->actions())
                    if (x->text().startsWith("Install") || x->text().startsWith("Uninstall"))
                        QVERIFY(!x->isEnabled());
    }
};

QTEST_MAIN(TestTray)
#include "tst_tray.moc"
