import QtQuick
import QtQuick.Shapes

// Small monochrome icons drawn in code. 24x24 design grid. The Farol set ("Ícones de interface") is stroke-only,
// 1.75 px, round caps and joins, and takes the text colour; "speaker" and "speaker-off" follow the same style.
Item {
    id: glyph
    property string name: ""
    property real size: 14
    property color color: theme.muted
    width: size
    height: size

    // Older names still used by the views map to the Farol set.
    readonly property var aliases: ({"house": "sessions", "bubble": "alerts", "plus": "new-session", "gear": "settings"})
    readonly property string icon: aliases[name] || name

    readonly property var strokes: ({
        "new-session": "M12 5v14M5 12h14",
        "sessions": "M6 4H18A3 3 0 0 1 21 7V17A3 3 0 0 1 18 20H6A3 3 0 0 1 3 17V7A3 3 0 0 1 6 4ZM7 10l3 2-3 2M13 15h4",
        "alerts": "M6 16v-5a6 6 0 0 1 12 0v5l1.5 2h-15zM10 21h4",
        "signal": "M9 21l1-10h4l1 10zM9 11V7l3-3 3 3v4M3 8l3 1M21 8l-3 1",
        "history": "M3 12a9 9 0 1 0 18 0a9 9 0 1 0 -18 0ZM12 7v5l3 2",
        "pause": "M9 6v12M15 6v12",
        "automations": "M13 3L5 13h6l-1 8 8-10h-6z",
        "skills": "M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.9l-5.2 2.7 1-5.8-4.3-4.1 5.9-.8z",
        "ask": "M5 4.5h14a2 2 0 0 1 2 2v9a2 2 0 0 1 -2 2h-7l-4.5 3.5v-3.5H5a2 2 0 0 1 -2 -2v-9a2 2 0 0 1 2 -2ZM9.8 9a2.3 2.3 0 1 1 3.4 2c-.8.5-1.2.9-1.2 1.7M12 14.9v.1",
        "settings": "M4 7h10M18 7h2M4 17h2M10 17h10M14 7a2 2 0 1 0 4 0a2 2 0 1 0 -4 0ZM6 17a2 2 0 1 0 4 0a2 2 0 1 0 -4 0Z",
        "speaker": "M3 10h3.5L11 6v12l-4.5-4H3zM15 9.5q2 2.5 0 5M17.5 7q4 5 0 10",
        "speaker-off": "M3 10h3.5L11 6v12l-4.5-4H3zM15.5 9.5l5 5M20.5 9.5l-5 5"
    })

    Shape {
        width: 24
        height: 24
        scale: glyph.size / 24
        transformOrigin: Item.TopLeft
        preferredRendererType: Shape.CurveRenderer
        ShapePath {
            fillColor: "transparent"
            strokeColor: glyph.strokes[glyph.icon] ? glyph.color : "transparent"
            strokeWidth: 1.75
            capStyle: ShapePath.RoundCap
            joinStyle: ShapePath.RoundJoin
            PathSvg { path: glyph.strokes[glyph.icon] || "" }
        }
    }
}
