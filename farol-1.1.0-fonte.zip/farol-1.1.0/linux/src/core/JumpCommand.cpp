#include "JumpCommand.h"

#include <QDir>
#include <QJsonArray>
#include <QJsonDocument>
#include <QRegularExpression>

namespace farol {

namespace {
bool isFlatpakId(const QString &id)
{
    static const QRegularExpression idPattern(QStringLiteral("^[A-Za-z0-9._-]+$"));
    return idPattern.match(id).hasMatch();
}

// VS Code and its relatives installed as plain programs: what to run, the URI scheme the editor answers to and what
// KWin calls its windows.
struct Editor {
    const char *program, *scheme;
    QStringList classes;
};
const Editor *nativeEditor(const QString &name)
{
    static const QList<Editor> editors = {
        {"code", "vscode", {"code", "code-url-handler"}},
        {"code-insiders", "vscode-insiders", {"code-insiders", "code - insiders"}},
        {"code-oss", "code-oss", {"code-oss", "code - oss"}},
        {"codium", "vscodium", {"codium", "vscodium"}},
        {"cursor", "cursor", {"cursor"}},
        {"windsurf", "windsurf", {"windsurf"}},
    };
    for (const Editor &e : editors)
        if (name == QLatin1String(e.program))
            return &e;
    return nullptr;
}

QString flatpakScheme(const QString &app)
{
    if (app == QLatin1String("com.visualstudio.code"))
        return QStringLiteral("vscode");
    if (app == QLatin1String("com.visualstudio.code.insiders"))
        return QStringLiteral("vscode-insiders");
    return QStringLiteral("vscodium");
}

// How to start the session's editor: its Flatpak when it has one, the program farol-hook saw otherwise, VSCodium's
// Flatpak when neither is known (or usable).
void editorLauncher(const QString &flatpakId, const QString &editor, JumpCommand &c, QString &scheme)
{
    const Editor *native = flatpakId.isEmpty() ? nativeEditor(editor) : nullptr;
    if (native) {
        c.program = QLatin1String(native->program);
        c.windowClasses = native->classes;
        scheme = QLatin1String(native->scheme);
        return;
    }
    const QString app = isFlatpakId(flatpakId) ? flatpakId : QStringLiteral("com.vscodium.codium");
    c.program = QStringLiteral("flatpak");
    c.args = {QStringLiteral("run"), app};
    c.windowClasses = {app};
    scheme = flatpakScheme(app);
}
} // namespace

JumpCommand jumpCommandFor(const JumpTarget &t)
{
    JumpCommand c;
    if (t.source == QLatin1String("vscodium")) {
        if (!t.cwd.startsWith(QLatin1Char('/')))
            return c;   // empty or relative: could be taken for an option by the editor
        QString scheme;
        editorLauncher(t.flatpakId, t.editor, c, scheme);
        c.kind = JumpCommand::Kind::Process;
        c.args << t.cwd;
        return c;
    }
    if (t.source == QLatin1String("konsole") && !t.konsoleService.isEmpty()) {
        static const QRegularExpression sessionPattern(QStringLiteral("^/Sessions/(\\d+)$"));
        static const QRegularExpression windowPattern(QStringLiteral("^/Windows/\\d+$"));
        const auto m = sessionPattern.match(t.konsoleSession);
        if (m.hasMatch()) {
            c.kind = JumpCommand::Kind::KonsoleDBus;
            c.service = t.konsoleService;
            c.objectPath = windowPattern.match(t.konsoleWindow).hasMatch() ? t.konsoleWindow : QStringLiteral("/Windows/1");
            c.sessionId = m.captured(1).toInt();
            return c;
        }
    }
    // Any other terminal (and a Konsole that did not say which tab): its window is found through the processes above
    // Claude Code. Without them there is nothing to go by.
    if ((t.source == QLatin1String("terminal") || t.source == QLatin1String("konsole")) && !t.ancestors.isEmpty())
        c.kind = JumpCommand::Kind::RaiseWindow;
    return c;
}

JumpCommand newClaudeTabCommand(const QString &flatpakId, const QString &editor)
{
    JumpCommand c;
    QString scheme;
    editorLauncher(flatpakId, editor, c, scheme);
    c.kind = JumpCommand::Kind::Process;
    // Each editor answers to its own URI scheme.
    c.args << QStringLiteral("--open-url") << scheme + QStringLiteral("://anthropic.claude-code/open");
    return c;
}

QStringList sessionWindowFolders(const QString &repo)
{
    return windowFolderCandidates(repo).mid(0, 1);
}

QStringList windowFolderCandidates(const QString &cwd)
{
    QStringList out;
    if (!cwd.startsWith(QLatin1Char('/')))
        return out;
    QString path = QDir::cleanPath(cwd);
    for (int i = 0; i < 3 && path != QLatin1String("/") && !path.isEmpty(); ++i) {
        const QString name = path.section(QLatin1Char('/'), -1);
        if (!name.isEmpty())
            out << name;
        path = QDir::cleanPath(path + QStringLiteral("/.."));
    }
    return out;
}

namespace {
// A JSON string is also a valid JS string literal, so this is the escaping for values placed in the script.
QString jsString(const QString &s)
{
    const QByteArray json = QJsonDocument(QJsonArray{s}).toJson(QJsonDocument::Compact);   // ["..."]
    return QString::fromUtf8(json.mid(1, json.size() - 2));
}
} // namespace

QString kwinActivateScript(const QStringList &folders, const QStringList &windowClasses, const QList<qint64> &pids, bool anyWindow)
{
    QStringList quotedFolders, quotedClasses, numbers;
    for (const QString &f : folders)
        quotedFolders << jsString(f);
    for (const QString &c : windowClasses)
        quotedClasses << jsString(c.toLower());
    for (qint64 pid : pids)
        numbers << QString::number(pid);
    return QStringLiteral(R"JS((function () {
    const folders = [%1];
    const classes = [%2];
    const pids = [%3];
    const anyWindow = %4;
    // Editor titles read "file - folder - Editor": the folder is one of the parts before the app name. A terminal's
    // title is whatever the shell wrote: the folder may be anywhere in it.
    function names(w, f) {
        const parts = w.caption.split(" - ");
        parts.pop();
        return parts.indexOf(f) >= 0 || (anyWindow && w.caption.indexOf(f) >= 0);
    }
    const windows = workspace.windowList().filter(function (w) {
        return classes.indexOf(String(w.resourceClass).toLowerCase()) >= 0 || pids.indexOf(w.pid) >= 0;
    });
    let hit = null;
    for (const f of folders) {
        hit = windows.find(function (w) { return names(w, f); }) || null;
        if (hit)
            break;
    }
    if (!hit && anyWindow) {
        for (const pid of pids) {              // closest process first
            hit = windows.find(function (w) { return w.pid === pid; }) || null;
            if (hit)
                break;
        }
    }
    if (hit) {
        if (hit.minimized)
            hit.minimized = false;
        workspace.activeWindow = hit;
    }
    callDBus("local.joao.Farol", "/Jumper", "local.joao.Farol.Jumper", "WindowResult", !!hit);
})();
)JS").arg(quotedFolders.join(QLatin1Char(',')), quotedClasses.join(QLatin1Char(',')), numbers.join(QLatin1Char(',')),
          anyWindow ? QStringLiteral("true") : QStringLiteral("false"));
}

int windowToRaise(const QList<DesktopWindow> &windows, const QStringList &folders, const QStringList &windowClasses,
                  const QList<qint64> &pids, bool anyWindow)
{
    QList<int> candidates;
    for (int i = 0; i < windows.size(); ++i)
        if (windowClasses.contains(windows[i].windowClass, Qt::CaseInsensitive) || pids.contains(windows[i].pid))
            candidates << i;
    // "file - folder - Editor": the folder is one of the parts before the app name; a terminal's title may say anything.
    const auto names = [anyWindow](const QString &title, const QString &folder) {
        QStringList parts = title.split(QStringLiteral(" - "));
        parts.removeLast();
        return parts.contains(folder) || (anyWindow && title.contains(folder));
    };
    for (const QString &folder : folders)
        for (int i : candidates)
            if (names(windows[i].title, folder))
                return i;
    if (anyWindow)
        for (qint64 pid : pids)                    // closest process first
            for (int i : candidates)
                if (windows[i].pid == pid)
                    return i;
    return -1;
}

} // namespace farol
