import QtQuick

// QuestionView: a question Claude asked (AskUserQuestion).
//  * While its hook is held by the island (questions.active for the focused session) the options are buttons: a click
//    answers, several questions come one by one, multi-select ones are ticked and confirmed. "Responder no editor"
//    hands it back to Claude Code's own dialog. Nothing is answered without a click.
//  * Otherwise (left to the editor, or a question that came as a notification) it is read-only and the way out is to
//    go back to the session.
Item {
    id: view
    readonly property bool live: questions.active && appState.focusId === "session_" + questions.sessionId
    readonly property var options: appState.focusTask.options || []
    readonly property real pillMax: appState.vertical ? column.width : 220

    function toEditor() {
        const id = appState.focusId
        if (view.live)
            questions.release()            // the hook prints nothing: Claude Code asks in its own UI
        sessions.jump(id)
        controller.collapse()
    }

    Card { anchors.fill: parent; wash: theme.lamp }
    Column {
        id: column
        anchors.left: parent.left
        anchors.right: parent.right
        anchors.verticalCenter: parent.verticalCenter
        anchors.leftMargin: appState.vertical ? 12 : 16
        anchors.rightMargin: appState.vertical ? 12 : 16
        spacing: 5

        AgentWho {
            name: appState.focusTask.name || ""
            // short: it shares a 172 px line with the session name in the portrait island
            label: (view.live && questions.count > 1 ? (questions.index + 1) + " de " + questions.count : "pergunta")
                   + (view.live && questions.multiSelect ? " · várias" : "")
            dot: appState.focusTask.color || theme.muted
        }
        Text {
            objectName: "questionTitle"
            width: parent.width
            textFormat: Text.PlainText
            text: view.live ? questions.question : (appState.focusTask.alertText || "")
            color: theme.text
            font.family: theme.titleFont
            font.pixelSize: 15
            font.weight: Font.DemiBold
            wrapMode: Text.Wrap
            maximumLineCount: appState.vertical ? 3 : 2
            elide: Text.ElideRight
        }
        Flow {   // the buttons wrap onto more lines in the portrait island
            width: parent.width
            spacing: 8
            // Held by the island: every option is a button.
            Repeater {
                model: view.live ? questions.options : []
                PillButton {
                    required property var modelData
                    required property int index
                    objectName: "questionOption" + index
                    maxWidth: view.pillMax
                    text: modelData.label
                    primary: modelData.selected
                    onClicked: questions.choose(modelData.label)
                }
            }
            PillButton {
                objectName: "questionConfirm"
                visible: view.live && questions.multiSelect
                text: "Confirmar"
                primary: true
                onClicked: questions.confirm()
            }
            // Read-only: what the options were.
            Repeater {
                model: view.live ? [] : view.options.slice(0, 4)
                Rectangle {
                    required property string modelData
                    width: Math.min(chip.implicitWidth + 24, 150)
                    height: 28
                    radius: 14
                    color: theme.subtleFill
                    Text {
                        id: chip
                        anchors.centerIn: parent
                        width: parent.width - 24
                        horizontalAlignment: Text.AlignHCenter
                        elide: Text.ElideRight
                        textFormat: Text.PlainText
                        text: modelData
                        color: theme.muted
                        font.family: theme.bodyFont
                        font.pixelSize: 12
                    }
                }
            }
            PillButton {
                objectName: "questionToEditor"
                maxWidth: view.pillMax
                text: "Responder no editor"
                primary: !view.live
                onClicked: view.toEditor()
            }
        }
    }
}
