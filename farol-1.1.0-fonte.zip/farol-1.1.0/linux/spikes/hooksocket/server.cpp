#include "Paths.h"

#include <QCoreApplication>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QLocalServer>
#include <QLocalSocket>
#include <QTimer>
#include <cstdio>
#include <sys/socket.h>
#include <unistd.h>

using farol::Paths;

static void say(const QString &s) { std::printf("%s\n", qPrintable(s)); std::fflush(stdout); }

static uid_t peerUid(QLocalSocket *s)
{
    ucred cred{};
    socklen_t len = sizeof(cred);
    if (getsockopt(int(s->socketDescriptor()), SOL_SOCKET, SO_PEERCRED, &cred, &len) != 0)
        return uid_t(-1);
    return cred.uid;
}

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    const QString path = Paths::socketPath();
    if (!Paths::fitsUnixSocket(path)) { say("socket path too long: " + path); return 1; }
    if (!Paths::ensurePrivateDir(Paths::dataDir())) { say("cannot create " + Paths::dataDir()); return 1; }

    QLocalServer::removeServer(path);  // stale socket from a crashed run
    QLocalServer server;
    server.setSocketOptions(QLocalServer::UserAccessOption);
    if (!server.listen(path)) { say("listen failed: " + server.errorString()); return 1; }
    say("listening on " + path);

    QObject::connect(&server, &QLocalServer::newConnection, &app, [&server]() {
        while (QLocalSocket *s = server.nextPendingConnection()) {
            const uid_t uid = peerUid(s);
            if (uid != getuid()) { say(QStringLiteral("rejected uid %1").arg(uid)); s->abort(); s->deleteLater(); continue; }
            QObject::connect(s, &QLocalSocket::readyRead, s, [s]() {
                if (!s->canReadLine()) return;
                const QByteArray line = s->readLine().trimmed();
                const QJsonObject ev = QJsonDocument::fromJson(line).object();
                const QString name = ev.value("hook_event_name").toString();
                say(QStringLiteral("event %1 source=%2 cwd=%3").arg(name, ev.value("farol_source").toString(),
                                                                  ev.value("cwd").toString()));
                if (name == "PermissionRequest") {
                    // Simulate the user clicking "Autorizar" after 2 s.
                    QTimer::singleShot(2000, s, [s]() {
                        s->write(R"({"decision":"allow"})" "\n");
                        s->flush();
                        s->disconnectFromServer();
                    });
                } else {
                    s->disconnectFromServer();
                }
            });
            QObject::connect(s, &QLocalSocket::disconnected, s, &QObject::deleteLater);
        }
    });
    return app.exec();
}
