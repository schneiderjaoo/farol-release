#include "AnswerText.h"

#include <QColor>
#include <QFont>
#include <QRegularExpression>
#include <QStringList>
#include <QTextBlock>
#include <QTextCursor>
#include <QTextDocument>
#include <QTextFragment>
#include <QTextList>
#include <QTextTable>
#include <QUrl>
#include <bitset>

namespace farol {

namespace {

constexpr int kBodyPx = 13;
constexpr int kCodePx = 12;
constexpr int kFrontMatter = 0x100000;   // QTextMarkdownImporter::FeatureFrontMatter, part of MarkdownDialectGitHub
constexpr int kSpellings = 16;        // ways of writing <br> one answer may use
constexpr char16_t kPrivateFirst = 0xE000, kPrivateEnd = 0xF800;   // where the marks for them are taken from

int headingPx(int level) { return level == 1 ? 16 : level == 2 ? 15 : 14; }

// A model writes "<br>" for a line break, most of all in a table. Qt's own hard break would not do: it starts a new
// block, which in a list is a new item. So each tag is swapped for a character the answer does not use before the
// conversion, and placeBreaks() decides afterwards, where the document says what is code and what is a table.
struct Breaks {
    QString text;            // the Markdown with the marks in it
    char16_t first = 0;      // mark first + i stands for spellings[i]; 0: there is no mark
    QStringList spellings;
    bool isMark(QChar c) const { return first && c.unicode() >= first && c.unicode() < first + spellings.size(); }
};

Breaks markBreaks(const QString &markdown)
{
    static const QRegularExpression tag(QStringLiteral("<br\\s*/?>"), QRegularExpression::CaseInsensitiveOption);
    Breaks out;
    out.text = markdown;
    if (!markdown.contains(tag))
        return out;
    std::bitset<(kPrivateEnd - kPrivateFirst) / kSpellings> taken;
    for (const QChar c : markdown)
        if (c.unicode() >= kPrivateFirst && c.unicode() < kPrivateEnd)
            taken.set((c.unicode() - kPrivateFirst) / kSpellings);
    size_t range = 0;
    while (range < taken.size() && taken.test(range))
        ++range;
    if (range == taken.size())
        return out;          // no character to spare: the tags stay text
    out.first = char16_t(kPrivateFirst + range * kSpellings);
    out.text.clear();
    qsizetype from = 0;
    for (auto found = tag.globalMatch(markdown); found.hasNext();) {
        const QRegularExpressionMatch match = found.next();
        int which = int(out.spellings.indexOf(match.captured()));
        if (which < 0 && out.spellings.size() < kSpellings) {
            which = int(out.spellings.size());
            out.spellings.append(match.captured());
        }
        if (which < 0)
            continue;        // one spelling too many: this one stays text
        out.text += QStringView(markdown).mid(from, match.capturedStart() - from);
        out.text += QLatin1Char(' ') + QChar(char16_t(out.first + which)) + QLatin1Char(' ');   // a word of its own
        from = match.capturedEnd();
    }
    out.text += QStringView(markdown).mid(from);
    return out;
}

// A mark in code is the tag again, as it was written; in a table cell, which is one line, a space; anywhere else a
// line break inside its paragraph (none at the paragraph's ends, where it would only be an empty line).
void placeBreaks(QTextDocument &doc, const Breaks &breaks)
{
    if (!breaks.first)
        return;
    QList<int> marks;
    for (QTextBlock block = doc.begin(); block.isValid(); block = block.next()) {
        const QString text = block.text();
        for (int i = 0; i < text.size(); ++i)
            if (breaks.isMark(text.at(i)))
                marks.append(block.position() + i);
    }
    const auto blank = [](QChar c) { return c == QLatin1Char(' ') || c == QLatin1Char('\t'); };
    for (auto mark = marks.crbegin(); mark != marks.crend(); ++mark) {   // from the end: the positions stay valid
        const QTextBlock block = doc.findBlock(*mark);
        const QString text = block.text();
        const int at = *mark - block.position();
        QTextCursor cursor(&doc);
        const auto formatAt = [&](int index) {   // of the block's character at `index`
            cursor.setPosition(block.position() + index + 1);
            return cursor.charFormat();
        };
        const auto isCode = [](const QTextCharFormat &f) { return f.hasProperty(QTextFormat::FontFixedPitch); };
        const QTextCharFormat format = formatAt(at);
        const bool code = isCode(format);
        int from = at, to = at + 1;
        if (code) {          // only the two spaces that came with the mark, where the code still has them
            from -= from > 0 && text.at(from - 1) == QLatin1Char(' ') && isCode(formatAt(from - 1));
            to += to < text.size() && text.at(to) == QLatin1Char(' ') && isCode(formatAt(to));
        } else {
            while (from > 0 && blank(text.at(from - 1)))
                --from;
            while (to < text.size() && blank(text.at(to)))
                ++to;
        }
        const bool inTable = cursor.currentTable() != nullptr;
        cursor.setPosition(block.position() + from);
        cursor.setPosition(block.position() + to, QTextCursor::KeepAnchor);
        if (code)
            cursor.insertText(breaks.spellings.at(text.at(at).unicode() - breaks.first), format);
        else if (from == 0 || to == text.size())
            cursor.removeSelectedText();
        else
            cursor.insertText(inTable ? QStringLiteral(" ") : QString(QChar::LineSeparator), format);
    }
}

// Rich text fetches whatever an image points to the moment it is shown, and reads a local file just the same: an
// image becomes its alt text. A link that is not a web link becomes the text it had.
void disarm(QTextDocument &doc, const AnswerStyle &style)
{
    struct Piece {
        int position;
        int length;
        QTextCharFormat format;
    };
    QList<Piece> pieces;
    for (QTextBlock block = doc.begin(); block.isValid(); block = block.next())
        for (auto it = block.begin(); !it.atEnd(); ++it) {
            const QTextFragment fragment = it.fragment();
            if (fragment.charFormat().isImageFormat() || fragment.charFormat().isAnchor())
                pieces.append({fragment.position(), fragment.length(), fragment.charFormat()});
        }
    for (auto piece = pieces.crbegin(); piece != pieces.crend(); ++piece) {   // from the end: the positions stay valid
        QTextCursor cursor(&doc);
        cursor.setPosition(piece->position);
        cursor.setPosition(piece->position + piece->length, QTextCursor::KeepAnchor);
        const bool web = piece->format.isAnchor() && isWebLink(piece->format.anchorHref());
        QTextCharFormat format = piece->format;
        if (piece->format.isImageFormat()) {
            format = QTextCharFormat();          // nothing of the image is kept but its alt text
            if (web) {
                format.setAnchor(true);
                format.setAnchorHref(piece->format.anchorHref());
            }
        }
        if (web) {
            format.setForeground(QColor(style.link));
            format.setFontUnderline(true);
        } else {
            format.setAnchor(false);
            for (const int property : {QTextFormat::AnchorHref, QTextFormat::AnchorName, QTextFormat::ForegroundBrush, QTextFormat::FontUnderline,
                                       QTextFormat::TextUnderlineStyle, QTextFormat::TextToolTip})
                format.clearProperty(property);
        }
        if (piece->format.isImageFormat()) {
            const QString alt = piece->format.property(QTextFormat::ImageAltText).toString().simplified();
            const QString label = alt.isEmpty() ? QStringLiteral("[imagem]") : QStringLiteral("[imagem: %1]").arg(alt);
            cursor.insertText(label.repeated(piece->length), format);   // equal images side by side are one piece
        } else {
            cursor.setCharFormat(format);
        }
    }
}

enum class Kind { None, Text, Heading, Item, Code, Cell };

// The room above a block, by what it is and what comes before it.
qreal gapAbove(Kind before, Kind now)
{
    if (before == Kind::None || now == Kind::Cell)
        return 0;
    if (before == Kind::Heading)
        return 3;
    if (now == Kind::Heading)
        return 10;
    if (now == Kind::Item && before == Kind::Item)
        return 0;
    return now == Kind::Code || before == Kind::Code ? 4 : 6;
}

// The lines of a code block, first to last, and where its box goes.
struct CodeRun {
    QTextBlock first, last;
    QString fence;   // its language and fence: what tells it from a block right after it
    qreal left;      // of the quote it is in
    qreal top;
};

// Qt Quick draws a block's background beside the block when the block has a left margin or an indent, and the code
// then runs out of it. A table's background is drawn where the table is: each code block goes into a table of one
// cell, which also gives it padding. (An empty block before or after a table takes no room.)
void boxCode(QTextDocument &doc, const CodeRun &run, const AnswerStyle &style)
{
    QStringList lines;
    for (QTextBlock block = run.first; block.isValid(); block = block.next()) {
        lines.append(block.text());
        if (block == run.last)
            break;
    }
    QTextCharFormat code;
    code.setFontFamilies({style.monoFont});
    code.setFontFixedPitch(true);
    code.setProperty(QTextFormat::FontPixelSize, kCodePx);
    QTextTableFormat box;
    box.setBorder(0);
    box.setCellSpacing(0);
    box.setCellPadding(6);
    box.setBackground(QColor(style.codeBg));
    box.setWidth(QTextLength(QTextLength::PercentageLength, 100));
    box.setLeftMargin(run.left);
    box.setTopMargin(run.top);

    // The table goes after the block before the code (at the very start when there is none), which puts one empty
    // block behind it; the code's own lines, now two characters further on, are taken out into that block.
    const int at = run.first.blockNumber() > 0 ? run.first.position() - 1 : 0;
    const int end = run.last.position() + run.last.length() - 1;
    QTextCursor cursor(&doc);
    cursor.setPosition(at);
    QTextTable *table = cursor.insertTable(1, 1, box);
    cursor.setPosition(at + 2);
    cursor.setPosition(end + 2, QTextCursor::KeepAnchor);
    cursor.removeSelectedText();
    cursor = table->cellAt(0, 0).firstCursorPosition();
    for (int i = 0; i < lines.size(); ++i) {
        if (i > 0) {
            cursor.insertBlock();
            cursor.mergeBlockCharFormat(code);   // an empty line is as high as the others
        }
        cursor.insertText(lines.at(i), code);
    }
}

// The looks: headings a little bigger than the body, code in the fixed-width font on the code background, room
// between the blocks, tables with a thin border.
// Once disarm() has run no image is left, so an object character (U+FFFC) still in the document is text of the
// answer. Qt's HTML writes nothing at all for a piece of text that holds one (a paragraph, a table cell, a line of
// code): it becomes the mark for a character nobody knows, and the text around it stays.
void plainObjects(QTextDocument &doc)
{
    QList<int> at;
    for (QTextBlock block = doc.begin(); block.isValid(); block = block.next()) {
        const QString text = block.text();
        for (qsizetype i = 0; i < text.size(); ++i)
            if (text.at(i) == QChar::ObjectReplacementCharacter)
                at.append(block.position() + int(i));
    }
    QTextCursor cursor(&doc);
    for (const int position : std::as_const(at)) {   // one character for one: no position moves
        cursor.setPosition(position);
        cursor.setPosition(position + 1, QTextCursor::KeepAnchor);
        const QTextCharFormat format = cursor.charFormat();
        cursor.insertText(QString(QChar::ReplacementCharacter), format);
    }
}

void dress(QTextDocument &doc, const AnswerStyle &style)
{
    const QColor codeBg(style.codeBg);
    QTextCursor cursor(&doc);
    Kind before = Kind::None;
    QList<CodeRun> boxes;
    for (QTextBlock block = doc.begin(); block.isValid(); block = block.next()) {
        QTextBlockFormat blockFormat = block.blockFormat();
        const int level = blockFormat.headingLevel();
        struct Run {
            int position;
            int length;
            QTextCharFormat format;
        };
        QList<Run> runs;
        bool fixed = true;
        for (auto it = block.begin(); !it.atEnd(); ++it) {
            runs.append({it.fragment().position(), it.fragment().length(), it.fragment().charFormat()});
            fixed = fixed && it.fragment().charFormat().hasProperty(QTextFormat::FontFixedPitch);
        }
        // Qt leaves the fence's block properties on the list item that follows it: the characters say what is code.
        // An empty line has none, and belongs to the code above it.
        const bool fenced = blockFormat.hasProperty(QTextFormat::BlockCodeLanguage) || blockFormat.hasProperty(QTextFormat::BlockCodeFence);
        const QString fence = blockFormat.stringProperty(QTextFormat::BlockCodeLanguage) + QLatin1Char('\n')
                              + blockFormat.stringProperty(QTextFormat::BlockCodeFence);
        const bool code = fenced && level == 0 && (runs.isEmpty() ? before == Kind::Code : fixed);
        cursor.setPosition(block.position());
        const bool inTable = cursor.currentTable() != nullptr;

        for (const Run &run : runs) {
            const bool mono = run.format.hasProperty(QTextFormat::FontFixedPitch);
            if (code || (!mono && level == 0))   // (a code block's lines are written again, in boxCode)
                continue;
            QTextCharFormat format = run.format;
            if (level > 0) {         // also the text after inline code, which Qt leaves at the body's size
                format.clearProperty(QTextFormat::FontSizeAdjustment);
                format.setProperty(QTextFormat::FontPixelSize, headingPx(level) - (mono ? 1 : 0));
                format.setFontWeight(QFont::DemiBold);
            }
            if (mono) {              // the family by name: without it the HTML says nothing of the font
                format.setFontFamilies({style.monoFont});
                format.setFontFixedPitch(true);
                if (level == 0)
                    format.setProperty(QTextFormat::FontPixelSize, kCodePx);
                format.setBackground(codeBg);
            }
            cursor.setPosition(run.position);
            cursor.setPosition(run.position + run.length, QTextCursor::KeepAnchor);
            cursor.setCharFormat(format);
        }

        if (fenced) {                // the item after a fence is a paragraph like any other, and wraps like one
            blockFormat.clearProperty(QTextFormat::BlockCodeLanguage);
            blockFormat.clearProperty(QTextFormat::BlockCodeFence);
            blockFormat.setNonBreakableLines(false);
        }
        // Qt hands a rule on to the list items that follow it, and gives one to a block that has text. Its HTML then
        // writes the rule and none of the block's text: the text wins, and a bare rule is no item of a list.
        if (blockFormat.hasProperty(QTextFormat::BlockTrailingHorizontalRulerWidth)) {
            if (block.length() > 1) {
                blockFormat.clearProperty(QTextFormat::BlockTrailingHorizontalRulerWidth);
            } else if (QTextList *list = block.textList()) {
                list->remove(block);
                blockFormat.setObjectIndex(-1);
            }
        }
        const Kind now = inTable ? Kind::Cell : code ? Kind::Code : level > 0 ? Kind::Heading : block.textList() ? Kind::Item : Kind::Text;
        if (code) {
            if (QTextList *list = block.textList()) {   // Qt counts the block as an item of the list it is in
                list->remove(block);
                blockFormat.setObjectIndex(-1);
            }
            // (inside a list the rich text item itself moves the box's text under the item's)
            if (before == Kind::Code && boxes.last().fence == fence && boxes.last().left == blockFormat.leftMargin())
                boxes.last().last = block;
            else
                boxes.append({block, block, fence, blockFormat.leftMargin(), gapAbove(before, now)});
        } else if (level > 0) {
            blockFormat.setHeadingLevel(0);   // a paragraph: an <h1> grows again when the rich text item reads it
        }
        if (!inTable) {
            blockFormat.setTopMargin(gapAbove(before, now));
            blockFormat.setBottomMargin(0);
        }
        cursor.setPosition(block.position());
        cursor.setBlockFormat(blockFormat);
        before = now;
    }
    for (QTextFrame *frame : doc.rootFrame()->childFrames())   // the answer's own tables; the code has no box yet
        if (auto *table = qobject_cast<QTextTable *>(frame)) {
            QTextTableFormat format = table->format();
            format.setBorder(1);
            format.setBorderBrush(QColor(style.line));
            format.setBorderCollapse(true);
            format.setCellPadding(4);
            format.setCellSpacing(0);
            format.setTopMargin(table->firstPosition() > 1 ? 6 : 0);
            table->setFormat(format);
        }
    for (auto box = boxes.crbegin(); box != boxes.crend(); ++box)   // from the end: the positions before stay valid
        boxCode(doc, *box, style);
}

} // namespace

bool isWebLink(const QString &href)
{
    const QUrl url(href, QUrl::StrictMode);
    if (!url.isValid() || url.host().isEmpty() || !url.userInfo().isEmpty() || url.authority().contains(QLatin1Char('@')))
        return false;
    return url.scheme() == QLatin1String("http") || url.scheme() == QLatin1String("https");
}

QString linkHost(const QString &href)
{
    if (!isWebLink(href))
        return {};
    return QUrl(href, QUrl::StrictMode).authority(QUrl::FullyEncoded);   // the host and its port: a web link has no user info
}

QString linkRest(const QString &href)
{
    if (!isWebLink(href))
        return {};
    const QUrl url(href, QUrl::StrictMode);
    QString rest = url.path(QUrl::FullyEncoded);
    if (url.hasQuery())
        rest += QLatin1Char('?') + url.query(QUrl::FullyEncoded);
    if (url.hasFragment())
        rest += QLatin1Char('#') + url.fragment(QUrl::FullyEncoded);
    return rest;
}

QString answerHtml(const QString &markdown, const AnswerStyle &style)
{
    if (markdown.trimmed().isEmpty())
        return {};
    QTextDocument doc;
    doc.setUndoRedoEnabled(false);
    QFont body(style.bodyFont);          // said here, so the HTML names it instead of the application's font
    body.setPixelSize(kBodyPx);
    doc.setDefaultFont(body);
    const Breaks breaks = markBreaks(markdown);
    // NoHTML: a tag is shown as the text it is. Qt's rich text would otherwise read it, and drops the rest of the
    // answer after the first one. No front matter either (a bit of the GitHub dialect that Qt gives no name): Qt
    // leaves out a block between two "---" lines at the top, and an answer has nothing that is not shown.
    const int features = (int(QTextDocument::MarkdownDialectGitHub) | int(QTextDocument::MarkdownNoHTML)) & ~kFrontMatter;
    doc.setMarkdown(breaks.text, QTextDocument::MarkdownFeatures::fromInt(features));
    // One edit for all the passes: outside of one, every move of a cursor asks the document to lay the block out
    // again, and a paragraph of some thousand pieces holds the island still for seconds.
    QTextCursor whole(&doc);
    whole.beginEditBlock();
    disarm(doc, style);
    plainObjects(doc);
    placeBreaks(doc, breaks);
    dress(doc, style);
    whole.endEditBlock();
    return doc.toHtml();
}

} // namespace farol
