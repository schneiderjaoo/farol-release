#include "Paths.h"

#include <QDir>
#include <QFile>

namespace farol {

QString Paths::home()
{
    const QString h = qEnvironmentVariable("HOME");
    return h.isEmpty() ? QDir::homePath() : QDir::fromNativeSeparators(h);   // a Git Bash gives HOME with backslashes
}

#ifdef Q_OS_WIN
// Everything of Farol's own is in one folder of the user's profile; Claude Code's files are where it keeps them.
QString Paths::dataDir()
{
    const QString local = qEnvironmentVariable("LOCALAPPDATA");
    return (local.isEmpty() ? home() + QStringLiteral("/AppData/Local") : QDir::fromNativeSeparators(local)) + QStringLiteral("/Farol");
}
// The name of a pipe (\.\pipe\<name>), one for each user of the machine.
QString Paths::socketPath()
{
    QString user;
    for (const QChar c : qEnvironmentVariable("USERNAME"))
        user += c.isLetterOrNumber() ? c.toLower() : QLatin1Char('_');
    return QStringLiteral("farol-") + user;
}
QString Paths::hookScriptPath() { return dataDir() + QStringLiteral("/farol-hook"); }
QString Paths::inboxDir() { return dataDir() + QStringLiteral("/inbox"); }
QString Paths::configFile() { return dataDir() + QStringLiteral("/farol.conf"); }
QString Paths::logFile() { return dataDir() + QStringLiteral("/farol.log"); }
#else
QString Paths::dataDir() { return home() + QStringLiteral("/.local/share/farol"); }
QString Paths::socketPath() { return dataDir() + QStringLiteral("/farol.sock"); }
QString Paths::hookScriptPath() { return dataDir() + QStringLiteral("/farol-hook"); }
QString Paths::inboxDir() { return dataDir() + QStringLiteral("/inbox"); }
QString Paths::configFile() { return home() + QStringLiteral("/.config/farol/farol.conf"); }
QString Paths::logFile() { return home() + QStringLiteral("/.local/state/farol/farol.log"); }
#endif
QString Paths::claudeSettingsPath() { return home() + QStringLiteral("/.claude/settings.json"); }
QString Paths::claudeSkillsDir() { return home() + QStringLiteral("/.claude/skills"); }

bool Paths::ensurePrivateDir(const QString &path)
{
    if (!QDir().mkpath(path))
        return false;
#ifdef Q_OS_WIN
    return true;   // a folder of the user's profile is the user's alone; there is no mode to set
#endif
    return QFile::setPermissions(path, QFile::ReadOwner | QFile::WriteOwner | QFile::ExeOwner);
}

bool Paths::fitsUnixSocket(const QString &path)
{
    return path.toUtf8().size() < 108;
}

} // namespace farol
