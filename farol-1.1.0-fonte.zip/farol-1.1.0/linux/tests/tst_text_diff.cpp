#include <QtTest>
#include "TextDiff.h"

using namespace farol;

class TestTextDiff : public QObject {
    Q_OBJECT
    static QString lines(int from, int to)
    {
        QStringList l;
        for (int i = from; i <= to; ++i)
            l << QStringLiteral("l%1").arg(i);
        return l.join('\n');
    }

private slots:
    void identicalTextsGiveNoDiff() { QVERIFY(unifiedDiff("a\nb", "a\nb", "A", "B").isEmpty()); }

    void insertion()
    {
        QCOMPARE(unifiedDiff("a\nb\nc\nd\ne", "a\nb\nX\nc\nd\ne", "A", "B"),
                 QStringLiteral("--- A\n+++ B\n@@ -1,5 +1,6 @@\n a\n b\n+X\n c\n d\n e\n"));
    }

    void replacement()
    {
        QCOMPARE(unifiedDiff("1\n2\n3", "1\nX\n3", "A", "B"),
                 QStringLiteral("--- A\n+++ B\n@@ -1,3 +1,3 @@\n 1\n-2\n+X\n 3\n"));
    }

    void removal()
    {
        QCOMPARE(unifiedDiff("1\n2\n3", "1\n3", "A", "B"),
                 QStringLiteral("--- A\n+++ B\n@@ -1,3 +1,2 @@\n 1\n-2\n 3\n"));
    }

    void farApartChangesMakeTwoHunks()
    {
        QString a = lines(1, 20);
        QString b = a;
        b.replace("l2\n", "L2\n");
        b.replace("l19\n", "L19\n");
        QCOMPARE(unifiedDiff(a, b, "A", "B").count("@@ -"), 2);
    }

    void nearbyChangesMergeIntoOneHunk()
    {
        QString a = lines(1, 20);
        QString b = a;
        b.replace("l2\n", "L2\n");
        b.replace("l6\n", "L6\n");
        QCOMPARE(unifiedDiff(a, b, "A", "B").count("@@ -"), 1);
    }

    void hugeInputsFallBackToWholeReplacement()
    {
        QStringList a, b;
        for (int i = 0; i < 2001; ++i) {
            a << QStringLiteral("a%1").arg(i);
            b << QStringLiteral("b%1").arg(i);
        }
        const QString d = unifiedDiff(a.join('\n'), b.join('\n'), "A", "B");
        QVERIFY(d.startsWith("--- A\n+++ B\n@@ -1,2001 +1,2001 @@\n-a0\n"));
    }
};

QTEST_APPLESS_MAIN(TestTextDiff)
#include "tst_text_diff.moc"
