#include <QtTest>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "AppState.h"
#include "FakeScheduler.h"
#include "IslandController.h"

using namespace farol;
using S = IslandStateMachine::State;

class TestController : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    std::unique_ptr<QSettings> settings;
    std::unique_ptr<AppState> state;
    std::unique_ptr<FakeScheduler> sched;
    std::unique_ptr<IslandController> ctl;
    std::unique_ptr<QSignalSpy> sounds;
    qint64 nowMs = 1000;

    QStringList soundList() const
    {
        QStringList out;
        for (const auto &args : *sounds)
            out << args.at(0).toString();
        return out;
    }
    int count(const QString &name) const { return soundList().count(name); }

private slots:
    void init()
    {
        QFile::remove(dir.path() + "/c.ini");
        settings = std::make_unique<QSettings>(dir.path() + "/c.ini", QSettings::IniFormat);
        state = std::make_unique<AppState>(settings.get());
        sched = std::make_unique<FakeScheduler>();
        nowMs = 1000;
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [this] { return nowMs; });
        sounds = std::make_unique<QSignalSpy>(ctl.get(), &IslandController::playSound);
    }

    void initialLayoutIsCompact()
    {
        QCOMPARE(ctl->islandWidth(), 344.0);
        QCOMPARE(ctl->islandHeight(), 32.0);
        QCOMPARE(ctl->cornerRadius(), 14.0);
        QVERIFY(!ctl->shrinking());
        QCOMPARE(ctl->botX(), 16.0);
        QCOMPARE(ctl->botY(), 16.0);
        QCOMPARE(ctl->botDiameter(), 20.0);
        QCOMPARE(ctl->botOpacity(), 1.0);
    }

    void sideEdgesUseThePortraitLayout()
    {
        state->setEdge("left");
        QCOMPARE(ctl->islandWidth(), 36.0);                  // compact pill, portrait
        QCOMPARE(ctl->islandHeight(), 100.0);
        QCOMPARE(ctl->botX(), 18.0);
        ctl->expand(IslandView::Overview);
        QCOMPARE(ctl->islandWidth(), 280.0);
        QCOMPARE(ctl->islandHeight(), 420.0);
        QCOMPARE(ctl->botX(), 44.0);
        state->setEdge("bottom");                            // back to landscape
        QCOMPARE(ctl->islandWidth(), 640.0);
        QCOMPARE(ctl->islandHeight(), 160.0);
        QCOMPARE(ctl->botX(), 54.0);
    }

    void launchOpensGreetingThenCollapsesToCompactAndHidesOnlyWhenAsked()
    {
        QSignalSpy interrupt(ctl.get(), &IslandController::greetingInterrupt);
        ctl->launch();
        QVERIFY(ctl->fsm().state() == S::Coucou);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Greeting);
        QCOMPARE(ctl->islandHeight(), 150.0);
        QCOMPARE(soundList(), QStringList{"open"});

        ctl->greetComplete();
        sched->advance(600);
        QVERIFY(ctl->fsm().state() == S::Petit);
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(state->view() == IslandView::Overview);      // defaultView()
        QCOMPARE(interrupt.count(), 1);
        QCOMPARE(soundList(), (QStringList{"open", "close"}));

        // the compact island stays on screen: hiding is a setting, off by default
        sched->advance(10 * 60000);
        QVERIFY(ctl->fsm().state() == S::Petit);
        QVERIFY(state->mode() == IslandMode::Compact);

        // "Esconder sem uso" turned on with the pointer elsewhere: the 60 s hide timer starts at once
        state->setAutoHide(true);
        sched->advance(59999);
        QVERIFY(state->mode() == IslandMode::Compact);
        sched->advance(1);
        QVERIFY(ctl->fsm().state() == S::Hidden);
        QVERIFY(state->mode() == IslandMode::Hidden);
        QCOMPARE(ctl->botOpacity(), 0.0);

        // turned off again: the hidden island comes back and stays
        state->setAutoHide(false);
        QVERIFY(ctl->fsm().state() == S::Petit);
        QVERIFY(state->mode() == IslandMode::Compact);
        sched->advance(10 * 60000);
        QVERIFY(state->mode() == IslandMode::Compact);
    }

    void autoHideSavedInSettingsHidesFromTheStart()
    {
        state->setAutoHide(true);
        ctl = std::make_unique<IslandController>(state.get(), sched.get(), [this] { return nowMs; });
        ctl->launch();
        ctl->greetComplete();
        sched->advance(600);
        QVERIFY(state->mode() == IslandMode::Compact);
        sched->advance(60000);
        QVERIFY(state->mode() == IslandMode::Hidden);
    }

    void hoverFromHiddenPeeksWithSound()
    {
        state->setMode(IslandMode::Hidden);
        sounds->clear();
        ctl->pointerEntered();
        QVERIFY(ctl->fsm().state() == S::Petit);
        QVERIFY(state->mode() == IslandMode::Compact);
        QCOMPARE(soundList(), QStringList{"peek"});
    }

    void clickOnCompactOpensOverview()
    {
        ctl->pointerEntered();                 // hidden(fsm) -> petit
        sounds->clear();
        ctl->islandClicked();
        QVERIFY(ctl->fsm().state() == S::Home);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Overview);
        QCOMPARE(ctl->islandWidth(), 640.0);
        QCOMPARE(ctl->islandHeight(), 160.0);
        QCOMPARE(ctl->cornerRadius(), 22.0);
        QCOMPARE(soundList(), QStringList{"open"});
        QCOMPARE(state->lastActivityMs(), qint64(1000));
    }

    void hoverAloneNeverOpensTheCompactIsland()
    {
        ctl->pointerEntered();
        sched->advance(5000);
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(ctl->fsm().state() == S::Petit);
    }

    void homeCollapsesAfter15sOncePointerLeaves()
    {
        ctl->pointerEntered();
        ctl->islandClicked();
        sounds->clear();
        ctl->pointerLeft();
        sched->advance(14999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(ctl->fsm().state() == S::Petit);
        QVERIFY(state->mode() == IslandMode::Compact);
        QCOMPARE(soundList(), QStringList{"close"});
    }

    void homeCollapseFollowsTheAutoCloseSetting()
    {
        state->setAutoCloseInterval(5);
        ctl->pointerEntered();
        ctl->islandClicked();
        ctl->pointerLeft();
        sched->advance(4999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(state->mode() == IslandMode::Compact);

        // changing it again applies to the next opening
        state->setAutoCloseInterval(20);
        ctl->pointerEntered();
        ctl->islandClicked();
        ctl->pointerLeft();
        sched->advance(19999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(state->mode() == IslandMode::Compact);
    }

    void pinnedAlertSurvivesTheIdleTimer()
    {
        ctl->expand(IslandView::Overview);            // opened from outside, pointer elsewhere: idle timer runs
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(5000);
        state->setPinned(true);                       // a permission request arrives...
        ctl->expand(IslandView::Approval);            // ...and asks for its view; the old timer is still armed
        sched->advance(60000);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(ctl->fsm().state() == S::Home);

        state->setPinned(false);                      // answered
        ctl->expand(IslandView::Overview);
        sched->advance(14999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(state->mode() == IslandMode::Compact);
    }

    void escapeClosesUnlessPinned()
    {
        ctl->pointerEntered();
        ctl->islandClicked();
        QSignalSpy kb(ctl.get(), &IslandController::keyboardOnDemandChanged);
        state->setPinned(true);
        ctl->escapePressed();
        QVERIFY(state->mode() == IslandMode::Expanded);
        QCOMPARE(kb.count(), 0);
        state->setPinned(false);
        ctl->escapePressed();
        QVERIFY(state->mode() == IslandMode::Compact);
        QCOMPARE(kb.count(), 1);
        QCOMPARE(kb.first().at(0).toBool(), false);
    }

    void escWhileHomeDoesNotDoubleClose()
    {
        state->setAutoHide(true);
        ctl->pointerEntered();
        ctl->islandClicked();
        ctl->pointerLeft();
        sounds->clear();
        ctl->escapePressed();                  // collapse() while the FSM is in Home
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(ctl->fsm().state() == S::Petit);   // the FSM follows the collapse
        QCOMPARE(count("close"), 1);
        sched->advance(15000);                 // the old home timer must be gone
        QCOMPARE(count("close"), 1);           // no second "close"
        sched->advance(45000);                 // pointer outside: the 60 s hide countdown started at Esc
        QVERIFY(ctl->fsm().state() == S::Hidden);
        QVERIFY(state->mode() == IslandMode::Hidden);
    }

    void escThenClickReopens()
    {
        ctl->pointerEntered();
        ctl->islandClicked();                  // Home, expanded
        ctl->escapePressed();                  // Esc with the pointer still on the pill
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(ctl->fsm().state() == S::Petit);
        ctl->islandClicked();                  // the pill must be clickable again
        QVERIFY(state->mode() == IslandMode::Expanded);
    }

    void escThenTrayOpenKeepsAFull15s()
    {
        ctl->pointerEntered();
        ctl->islandClicked();
        ctl->pointerLeft();
        sched->advance(3000);
        ctl->escapePressed();
        sched->advance(12000);
        ctl->expandTo("overview");             // "Open Farol" from the tray, 12 s after Esc
        sched->advance(14999);
        QVERIFY(state->mode() == IslandMode::Expanded);   // a stale 15 s timer would have closed it by now
        sched->advance(1);
        QVERIFY(state->mode() == IslandMode::Compact);
    }

    void externalExpandDuringGreetingTakesOverIt()
    {
        QSignalSpy interrupt(ctl.get(), &IslandController::greetingInterrupt);
        ctl->launch();                         // FSM Coucou, greeting view
        sounds->clear();
        ctl->expandTo("overview");             // "Open Farol" from the tray in the middle of the greeting
        QVERIFY(ctl->fsm().state() == S::Home);
        QCOMPARE(interrupt.count(), 1);
        QVERIFY(state->view() == IslandView::Overview);
        QCOMPARE(count("open"), 0);            // already expanded: no second open sound
        sched->advance(14999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(state->mode() == IslandMode::Compact);   // it does not stay open forever
    }

    void externalExpandWhileHomeRestartsTheIdleTimer()
    {
        ctl->pointerEntered();
        ctl->islandClicked();
        ctl->pointerLeft();
        sched->advance(10000);
        ctl->expandTo("upload");
        sched->advance(14999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(state->mode() == IslandMode::Compact);
    }

    void fsmDrivenCollapseReleasesTheKeyboard()
    {
        ctl->pointerEntered();
        ctl->islandClicked();
        ctl->requestKeyboard(true);            // the user clicked inside the open island
        QSignalSpy kb(ctl.get(), &IslandController::keyboardOnDemandChanged);
        ctl->pointerLeft();
        sched->advance(15000);                 // home -> petit by timer, not by Esc
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(!kb.isEmpty());
        QCOMPARE(kb.last().at(0).toBool(), false);
    }

    void shrinkingFlagOnlyForModeShrink()
    {
        ctl->expandTo("overview");
        QVERIFY(!ctl->shrinking());
        ctl->expandTo("upload");               // view change inside expanded uses the open curve
        QVERIFY(!ctl->shrinking());
        QCOMPARE(ctl->islandHeight(), 280.0);
        ctl->collapse();
        QVERIFY(ctl->shrinking());
        QCOMPARE(ctl->islandWidth(), 344.0);
        QCOMPARE(ctl->islandHeight(), 32.0);
        QCOMPARE(ctl->cornerRadius(), 14.0);
        ctl->expandTo("overview");
        QVERIFY(!ctl->shrinking());
    }

    void promptHeightFollowsChat()
    {
        ctl->expandTo("prompt");
        QCOMPARE(ctl->islandHeight(), 240.0);
        state->setChatCount(1);
        QCOMPARE(ctl->islandHeight(), 280.0);
        state->setChatCount(5);
        QCOMPARE(ctl->islandHeight(), 300.0);
    }

    void layoutStaysAtHeight160WhenViewSwitchesToEmpty()
    {
        ctl->expandTo("overview");
        for (const auto &t : integrationAgents())
            state->removeTask(t.id);
        QVERIFY(state->view() == IslandView::Empty);
        QVERIFY(state->mode() == IslandMode::Expanded);
        QCOMPARE(ctl->islandHeight(), 160.0);
        QCOMPARE(ctl->islandWidth(), 640.0);
    }

    void notchChangeResizesTheIsland()
    {
        state->setNotchSize(200, 38);
        QCOMPARE(ctl->islandWidth(), 360.0);
        QCOMPARE(ctl->islandHeight(), 38.0);
        state->setNotchSize(0, -1);            // detection failed: fall back to 184x32
        QCOMPARE(ctl->islandWidth(), 344.0);
        QCOMPARE(ctl->islandHeight(), 32.0);
    }

    void hookExpandSyncsTheFsmToHome()
    {
        ctl->expandTo("approval");             // alerts open the island regardless of the FSM (Swift .hookExpand)
        QVERIFY(state->mode() == IslandMode::Expanded);
        QVERIFY(state->view() == IslandView::Approval);
        QVERIFY(ctl->fsm().state() == S::Home); // ...and the FSM follows, so hover/timers cannot collapse it
    }

    void externalExpandSurvivesTheFirstHoverAndCollapsesAfter15s()
    {
        ctl->expandTo("upload");               // opened from the tray/debug menu while the FSM was Hidden
        ctl->pointerEntered();                 // used to trigger Hidden -> Petit -> setMode(Compact)
        QVERIFY(state->mode() == IslandMode::Expanded);
        ctl->pointerLeft();
        sched->advance(14999);
        QVERIFY(state->mode() == IslandMode::Expanded);
        sched->advance(1);
        QVERIFY(state->mode() == IslandMode::Compact);
    }

    void externalExpandWithoutPointerCollapsesAfter15sUnlessPinned()
    {
        ctl->expandTo("overview");
        sched->advance(15000);
        QVERIFY(state->mode() == IslandMode::Compact);
        state->setPinned(true);                // alerts pin the island
        ctl->expandTo("approval");
        sched->advance(120000);
        QVERIFY(state->mode() == IslandMode::Expanded);
    }

    void revealShowsCompactFromHidden()
    {
        state->setAutoHide(true);
        state->setMode(IslandMode::Hidden);
        ctl->reveal();
        QVERIFY(state->mode() == IslandMode::Compact);
        QVERIFY(ctl->fsm().state() == S::Petit);
        sched->advance(60000);
        QVERIFY(state->mode() == IslandMode::Hidden);
    }

    void showViewSetsViewAndResetsActivity()
    {
        ctl->expandTo("overview");
        nowMs = 5000;
        ctl->showView("upload");
        QVERIFY(state->view() == IslandView::Upload);
        QCOMPARE(state->lastActivityMs(), qint64(5000));
        ctl->showView("bogus");
        QVERIFY(state->view() == IslandView::Upload);
        ctl->showView("settings");
        QVERIFY(state->view() == IslandView::Settings);
    }

    void flappingHoverDoesNotInterruptTheGreeting()
    {
        ctl->launch();                         // FSM Coucou
        ctl->setPointerInside(true);           // hovering keeps the greeting open (10 s)
        ctl->setPointerInside(false);
        sched->advance(97);
        ctl->setPointerInside(true);           // came back before the 120 ms debounce
        sched->advance(200);
        QVERIFY(ctl->fsm().state() == S::Coucou);   // a raw leave would have interrupted it at once
        ctl->setPointerInside(false);
        sched->advance(120);
        QVERIFY(ctl->fsm().state() == S::Petit);    // a real leave still does
    }
};

QTEST_MAIN(TestController)
#include "tst_island_controller.moc"
