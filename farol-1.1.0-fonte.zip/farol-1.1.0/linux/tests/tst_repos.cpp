#include <QtTest>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include "AppState.h"
#include "Links.h"
#include "Repos.h"

using namespace farol;

class TestRepos : public QObject {
    Q_OBJECT
    std::unique_ptr<QTemporaryDir> dir;

    QString root() const { return dir->path() + "/workspace"; }
    void repo(const QString &relative) const { QVERIFY(QDir().mkpath(root() + "/" + relative + "/.git")); }
    void folder(const QString &relative) const { QVERIFY(QDir().mkpath(root() + "/" + relative)); }
    static QStringList labels(const QList<Repo> &repos)
    {
        QStringList out;
        for (const Repo &r : repos)
            out << r.label;
        return out;
    }
    static QStringList labels(const QVariantList &list)
    {
        QStringList out;
        for (const QVariant &v : list)
            out << v.toMap().value("label").toString();
        return out;
    }

private slots:
    void init()
    {
        dir = std::make_unique<QTemporaryDir>();
        QVERIFY(QDir().mkpath(root()));
    }

    // A repository is a folder with a ".git" in it; the list is sorted by name, whatever the case.
    void findsEveryFolderWithADotGit()
    {
        repo("farol");
        repo("Backend");
        repo("api");
        folder("notes");                                     // no .git: not a repository
        const QList<Repo> found = findRepos(root());
        QCOMPARE(labels(found), (QStringList{"api", "Backend", "farol"}));
        QCOMPARE(found.at(2).name, QStringLiteral("farol"));
        QCOMPARE(found.at(2).path, root() + "/farol");
    }

    // A worktree or a submodule has a ".git" file instead of a folder.
    void aDotGitFileCountsToo()
    {
        folder("worktree");
        QFile f(root() + "/worktree/.git");
        QVERIFY(f.open(QIODevice::WriteOnly));
        f.write("gitdir: /somewhere/else\n");
        f.close();
        QCOMPARE(labels(findRepos(root())), (QStringList{"worktree"}));
    }

    // Repositories grouped in folders are found too and show where they are; the search stops three levels down.
    void looksIntoGroupFoldersButNotTooDeep()
    {
        repo("clients/acme");
        repo("clients/internal/tools");
        repo("a/b/c/too-deep");
        const QList<Repo> found = findRepos(root());
        QCOMPARE(labels(found), (QStringList{"clients/acme", "clients/internal/tools"}));
        QCOMPARE(found.at(0).name, QStringLiteral("acme"));
    }

    // What is inside a repository belongs to it (submodules, vendored clones); hidden folders and node_modules are
    // never searched; a link is not followed (it could loop).
    void skipsWhatIsInsideARepositoryHiddenFoldersAndLinks()
    {
        repo("app");
        repo("app/vendor/lib");
        repo(".cache/tool");
        repo("node_modules/pkg");
        QVERIFY(links::make(root(), root() + "/loop"));
        QVERIFY(links::make(root() + "/app", root() + "/app-link"));
        QCOMPARE(labels(findRepos(root())), (QStringList{"app"}));
    }

    void theWorkspaceItselfCanBeTheRepository()
    {
        QVERIFY(QDir().mkpath(root() + "/.git"));
        repo("inner");
        const QList<Repo> found = findRepos(root());
        QCOMPARE(found.size(), 1);
        QCOMPARE(found.at(0).path, root());
        QCOMPARE(found.at(0).label, QStringLiteral("workspace"));
    }

    void aMissingOrRelativeFolderGivesNothing()
    {
        QVERIFY(findRepos(root() + "/nowhere").isEmpty());
        QVERIFY(findRepos("relative/dir").isEmpty());
        QVERIFY(findRepos(QString()).isEmpty());
    }

    // A huge folder must not hang the island: the search gives up after `budget` folders.
    void stopsAfterTheBudgetOfFolders()
    {
        for (int i = 0; i < 12; ++i)
            repo(QStringLiteral("r%1").arg(i, 2, 10, QLatin1Char('0')));
        QCOMPARE(findRepos(root(), 3, 5).size(), 4);         // the workspace folder itself is the first one looked at
    }

    // The list the island shows: scanned on refresh() and when the workspace folder changes, narrowed by the filter.
    void theListFollowsTheWorkspaceFolderAndTheFilter()
    {
        repo("farol");
        repo("superloja-backend");
        repo("superloja-frontend");
        QSettings settings(dir->path() + "/r.ini", QSettings::IniFormat);
        AppState state(&settings);
        Repos repos(&state);
        QCOMPARE(repos.total(), 0);                          // no workspace folder yet
        QSignalSpy changed(&repos, &Repos::changed);
        state.setWorkspaceDir(root());
        QCOMPARE(changed.count(), 1);
        QCOMPARE(repos.total(), 3);
        QCOMPARE(labels(repos.list()), (QStringList{"farol", "superloja-backend", "superloja-frontend"}));

        repos.setFilter("  SUPERLOJA ");                     // case and surrounding spaces do not matter
        QCOMPARE(labels(repos.list()), (QStringList{"superloja-backend", "superloja-frontend"}));
        QCOMPARE(repos.total(), 3);
        repos.setFilter("front");
        QCOMPARE(labels(repos.list()), (QStringList{"superloja-frontend"}));
        repos.setFilter("nothing like it");
        QVERIFY(repos.list().isEmpty());
        repos.setFilter(QString());

        repo("new-one");                                     // cloned while Farol runs: seen on the next refresh
        QCOMPARE(repos.total(), 3);
        repos.refresh();
        QCOMPARE(repos.total(), 4);
        state.setWorkspaceDir(QString());
        QCOMPARE(repos.total(), 0);
    }

    // Opening is only ever asked for a repository of the list, never for an arbitrary path.
    void openOnlyAsksForARepositoryOfTheList()
    {
        repo("farol");
        folder("notes");
        QSettings settings(dir->path() + "/r.ini", QSettings::IniFormat);
        AppState state(&settings);
        state.setWorkspaceDir(root());
        Repos repos(&state);
        QSignalSpy asked(&repos, &Repos::openRequested);
        repos.open(root() + "/notes");
        repos.open("/etc");
        repos.open(QString());
        QCOMPARE(asked.count(), 0);
        repos.open(root() + "/farol");
        QCOMPARE(asked.count(), 1);
        QCOMPARE(asked.at(0).at(0).toString(), root() + "/farol");
    }
};

QTEST_GUILESS_MAIN(TestRepos)
#include "tst_repos.moc"
