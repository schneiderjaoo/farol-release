#include "IslandStateMachine.h"

namespace farol {

IslandStateMachine::IslandStateMachine(IScheduler &scheduler) : m_sched(scheduler) {}

void IslandStateMachine::launch()
{
    cancelTimers();
    transition(State::Coucou);
}

void IslandStateMachine::mouseEntered()
{
    switch (m_state) {
    case State::Hidden:
        cancelTimers();
        transition(State::Petit);
        break;
    case State::Petit:
        cancel(m_petitHide);
        break;
    case State::Home:
        cancel(m_homeCollapse);
        break;
    case State::Coucou:
        // hovering during the greeting: replace the short auto-collapse with the long hover delay
        scheduleGreetCollapse(greetHoverCollapseDelayMs);
        break;
    }
}

void IslandStateMachine::mouseLeft()
{
    switch (m_state) {
    case State::Hidden:
        break;
    case State::Petit:
        schedulePetitHide();
        break;
    case State::Home:
        scheduleHomeCollapse();
        break;
    case State::Coucou:
        cancel(m_greetCollapse);
        transition(State::Petit);
        break;
    }
}

void IslandStateMachine::click()
{
    if (m_state != State::Petit)
        return;
    cancelTimers();
    transition(State::Home);
}

void IslandStateMachine::greetComplete()
{
    if (m_state != State::Coucou)
        return;
    // a longer hover timer already running must not be overridden
    if (m_greetCollapse == 0)
        scheduleGreetCollapse(greetAutoCollapseDelayMs);
}

void IslandStateMachine::reveal()
{
    if (m_state != State::Hidden)
        return;
    cancelTimers();
    transition(State::Petit);
    schedulePetitHide();
}

void IslandStateMachine::cancelTimers()
{
    cancel(m_petitHide);
    cancel(m_homeCollapse);
    cancel(m_greetCollapse);
}

bool IslandStateMachine::openExternally()
{
    if (m_state == State::Home)
        return false;
    cancelTimers();
    m_state = State::Home;
    return true;
}

bool IslandStateMachine::closeExternally()
{
    if (m_state != State::Home && m_state != State::Coucou)
        return false;
    cancelTimers();
    m_state = State::Petit;
    return true;
}

void IslandStateMachine::setHideWhenIdle(bool on)
{
    if (on == m_hideWhenIdle)
        return;
    m_hideWhenIdle = on;
    if (!on)
        cancel(m_petitHide);         // turned on, the countdown starts when the pointer next leaves the island
}

void IslandStateMachine::schedulePetitHide()
{
    cancel(m_petitHide);
    if (!m_hideWhenIdle)
        return;
    m_petitHide = m_sched.singleShot(petitToHiddenDelayMs, [this] {
        if (m_state == State::Petit)
            transition(State::Hidden);
    });
}

void IslandStateMachine::scheduleHomeCollapse()
{
    cancel(m_homeCollapse);
    m_homeCollapse = m_sched.singleShot(homeToPetitDelayMs, [this] {
        if (m_state == State::Home)
            transition(State::Petit);
    });
}

void IslandStateMachine::scheduleGreetCollapse(int delayMs)
{
    cancel(m_greetCollapse);
    m_greetCollapse = m_sched.singleShot(delayMs, [this] {
        if (m_state == State::Coucou)
            transition(State::Petit);
    });
}

void IslandStateMachine::cancel(int &id)
{
    if (id != 0)
        m_sched.cancel(id);
    id = 0;
}

void IslandStateMachine::transition(State to)
{
    if (to == m_state)
        return;
    const State from = m_state;
    m_state = to;
    if (onTransition)
        onTransition(from, to);
}

} // namespace farol
