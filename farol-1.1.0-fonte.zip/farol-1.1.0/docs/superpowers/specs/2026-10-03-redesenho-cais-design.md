# Farol — redesenho "Cais"

Data: 2026-10-03 · Status: implementado (2026-10-03) · Desenhos: https://claude.ai/artifact/Eb1G6j6Nwwn4Vo5Jd3fiTe

## 1. Decisão

Das duas direções desenhadas, o autor escolheu: mascote, ilha pequena, ilha de sessões e aba Skills da direção 1 ("Cais"); Ajustes com a organização da direção 2, mas dentro da ilha (§2.4). Cores, fontes, regra dos barcos e sinais das sessões não mudam.

Objetivo: abrir espaço na ilha (as abas deixam de ocupar uma faixa no topo), dar aos Ajustes o espaço que eles já não têm dentro da ilha, e deixar o estado das sessões legível sem abrir nada.

## 2. O que muda

### 2.1 Coluna do Lumi com as abas

A faixa de cabeçalho (`IslandHeader.qml`, 34 px) deixa de existir. À esquerda de toda view aberta fica uma coluna de 88 px: o Lumi em cima e, embaixo dele, as quatro abas numa grade 2×2: Sessões, Nova sessão, Skills, Ajustes. A aba da view atual fica preenchida; a de Skills leva o ponto de aviso (spec da aba Skills). A aba de Ajustes abre a view de Ajustes (§2.4).

A coluna aparece em todas as views abertas, inclusive pedido de permissão, pergunta, terminou e erro, para o Lumi não mudar de lugar entre elas. O conteúdo de cada view passa a começar depois da coluna, sem a margem de 116 px que hoje reserva o lugar do Lumi dentro do cartão.

Ilha lateral (retrato, 280 de largura): o Lumi fica em cima à esquerda e as quatro abas numa linha ao lado dele; o conteúdo vem embaixo.

Alturas: cada view perde os 34 px da faixa. As tabelas `kLayouts` e `kPortraitHeights` e os testes que fixam alturas são atualizados juntos.

### 2.2 Ilha de sessões

Dois cartões ao lado da coluna:

- **Sessão em foco**: nome (o título da sessão, ou a pasta), "pasta · Claude Code", os três últimos passos, o contador de passos, a linha e a barra de contexto, e o botão "Ir à sessão" (substitui a seta ↗ pequena).
- **Sessões**: uma linha por sessão, no lugar das pílulas: o barco dela (mesmo modelo e cor da ilha pequena), o nome e, embaixo dele, o estado ("trabalha", "permissão", "pergunta", "terminou", "erro", "parada"). Um clique põe a sessão em foco. Rola quando não cabe. No pé, "N inativas ocultas" quando houver sessões dormentes; um clique nesse texto mostra as dormentes até a ilha fechar.

### 2.3 Ilha pequena

Como hoje (Lumi à esquerda, os barcos), mais dois detalhes:

- Uma linha d'água fina sob os barcos.
- À direita, uma etiqueta quando alguma sessão precisa do usuário: "1 espera" (âmbar) ou "1 erro" (vermelho); com as duas coisas, o erro vence e o número soma. Sem nada pendente, não há etiqueta.

Na borda lateral a etiqueta não cabe: fica só um ponto da cor correspondente no canto do Lumi (embaixo dele ficam os barcos).

### 2.4 Ajustes na ilha, com o desenho novo

Emenda de 2026-10-03: os Ajustes chegaram a ser feitos como janela própria (direção 2) e o autor recusou ao ver: "a aba de ajustes não pode ser um modal". Ficam dentro da ilha, como uma view, com a organização da direção 2:

- Aberta pela aba de ajustes da coluna, pelo "Settings…" da bandeja e pelo botão de "Nova sessão" sem workspace.
- Barra lateral com as páginas Ilha, Sessões, Atalhos e Sobre (uma linha em cima na ilha lateral). "Sobre" mostra a versão do app e o estado dos hooks.
- A explicação de cada opção fica escrita embaixo do nome. O balão de ajuda ao parar o mouse saiu.
- O que não cabe rola: a ilha tem 300 de altura nos Ajustes (600 na lateral).
- O botão de som saiu da ilha e virou o interruptor "Sons" da página Ilha.

A pasta das skills e os plugins não entram nos Ajustes: ficam na aba Skills.

### 2.5 Mascote

O Lumi continua um farol com o rosto na casa da lâmpada. O traço muda: corpo mais largo e arredondado, duas listras escuras, telhado e galeria mais marcados. Os humores (`LumiLook`) e as cores da lâmpada não mudam. A arte final é desenhada a partir do esboço e conferida na tela antes de substituir a atual; o ícone do app e `identidade-visual.html` são atualizados no mesmo passo para não ficarem com o Lumi antigo.

## 3. O que não muda

- Paletas "Noite no cais" e "Amanhecer", fontes, cores dos sinais.
- Um barco por sessão que roda ou precisa do usuário, nunca dois iguais.
- Nada é aprovado, respondido ou aberto sem clique ou Enter.
- As views de permissão, pergunta, terminou, erro e "Nova sessão" mantêm conteúdo e comportamento; só ganham a coluna.
- Chaves de `farol.conf`: nenhuma é renomeada.

## 4. Componentes tocados

| Peça | Mudança |
|---|---|
| `qml/IslandRail.qml` (novo) | A coluna: Lumi + grade de abas; substitui `IslandHeader.qml` |
| `qml/Island.qml` | Monta a coluna e o conteúdo lado a lado (em cima/embaixo no retrato); etiqueta e linha d'água da ilha pequena |
| `qml/OverviewView.qml` | Cartão em foco + lista de sessões |
| `qml/SessionRow.qml` (novo) | Uma linha da lista: barco, nome, etiqueta |
| `qml/Lumi.qml` | Traço novo |
| `qml/SettingsView.qml` | Barra lateral de páginas, opções com explicação, rolagem |
| `core/IslandTypes` | `botPosition` na coluna; Ajustes com 300 de altura (600 no retrato) |
| `core/AppState` | `needsUserCount`/`errorCount` para a etiqueta; lista inclui o estado em texto |
| Demais views | Margem esquerda sem o espaço do Lumi |

## 5. Testes

- `tst_island_qml`: a coluna em todas as views (paisagem e retrato, nada sai da ilha); o Lumi no mesmo lugar em todas; clique em cada aba; a lista de sessões (ordem, etiqueta por estado, clique põe em foco, "N inativas ocultas"); a etiqueta da ilha pequena (espera, erro, os dois, nenhum, borda lateral).
- `tst_settings_view` (novo): cada página, cada opção altera o `AppState`, a explicação de cada opção existe e é alcançável nos dois tamanhos de ilha, captura de atalho.
- `tst_island_types`, `tst_island_controller`: alturas novas.
- Os testes da view `settings` passam para `tst_settings_view`; os do balão de ajuda saem com ele.

## 6. Ordem de entrega

1. Coluna com as abas e views sem a faixa do topo.
2. Ajustes com o desenho novo, dentro da ilha.
3. Lista de sessões.
4. Etiqueta e linha d'água da ilha pequena.
5. Aba Skills (spec própria: `2026-10-03-aba-skills-e-plugins-design.md`).
6. Traço novo do Lumi, ícone e folha de identidade.

Cada passo deixa o app utilizável. A primeira versão pública pode sair depois do passo 5; o passo 6 é arte e não bloqueia.
