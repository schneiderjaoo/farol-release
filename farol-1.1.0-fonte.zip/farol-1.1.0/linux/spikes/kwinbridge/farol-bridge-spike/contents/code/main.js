// Farol bridge (L0 spike): pushes the cursor position and the window under it to
// the app over D-Bus. Loaded only while the island is visible.
const SERVICE = "local.joao.Farol.Spike";
const PATH = "/Bridge";
const IFACE = "local.joao.Farol.Bridge";

let lastX = -1, lastY = -1, lastWindowId = "";

function windowAt(x, y) {
    const stack = workspace.stackingOrder;       // bottom → top
    for (let i = stack.length - 1; i >= 0; i--) {
        const w = stack[i];
        if (!w.normalWindow || w.minimized) continue;
        if (String(w.resourceClass) === "xwaylandvideobridge") continue;   // invisible helper window
        const g = w.frameGeometry;
        if (x >= g.x && x < g.x + g.width && y >= g.y && y < g.y + g.height) return w;
    }
    return null;
}

function tick() {
    const p = workspace.cursorPos;
    const x = Math.round(p.x), y = Math.round(p.y);
    if (x === lastX && y === lastY) return;
    lastX = x; lastY = y;
    callDBus(SERVICE, PATH, IFACE, "cursor", x, y);

    const w = windowAt(x, y);
    const id = w ? String(w.internalId) : "";
    if (id === lastWindowId) return;
    lastWindowId = id;
    if (w) {
        const g = w.frameGeometry;
        callDBus(SERVICE, PATH, IFACE, "window", w.caption, String(w.resourceClass),
                 Math.round(g.x), Math.round(g.y), Math.round(g.width), Math.round(g.height));
    } else {
        callDBus(SERVICE, PATH, IFACE, "window", "", "", 0, 0, 0, 0);
    }
}

// The signal fires on every pointer motion. Connect a wrapper function (not `tick` itself):
// the bare connect(tick) form delivered zero events in the first L0 run.
if (workspace.cursorPosChanged) {
    console.info("farol-bridge-spike: signal mode");
    workspace.cursorPosChanged.connect(function () { tick(); });
} else {
    console.info("farol-bridge-spike: 16 ms timer fallback");
    const timer = new QTimer();
    timer.interval = 16;
    timer.timeout.connect(function () { tick(); });
    timer.start();
}
