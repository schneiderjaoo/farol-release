#include "Theme.h"

#include "AppState.h"

namespace farol {

namespace {
// Session signals from the identity sheet; shared by both palettes.
const QString kLamp = QStringLiteral("#FFC233");
const QString kOk = QStringLiteral("#2FBF8F");
const QString kAlert = QStringLiteral("#FF5A4E");
const QString kWorking = QStringLiteral("#8FB3C7");
const QString kIdle = QStringLiteral("#5B7892");
} // namespace

const Theme::Palette &Theme::darkPalette()
{
    static const Palette p{
        .islandBg = "#0A1F36", .card = "#10304F", .line = "#22466B", .codeBg = "#071828",
        .text = "#EAF3F4", .textHover = "#C9DEE6", .muted = "#8FB3C7", .dim = "#7595AB",
        .hoverFill = "#12FFFFFF", .pillFill = "#17FFFFFF", .pillHoverFill = "#26FFFFFF", .subtleFill = "#0FFFFFFF", .countdown = "#59FFFFFF",
        .primary = "#EAF3F4", .primaryHover = "#FFFFFF", .primaryText = "#0A1F36", .primaryDim = "#4F6B82",
        .alertText = "#FF8A80", .link = "#8FB3C7",   // Bruma
        .lamp = kLamp, .ok = kOk, .alert = kAlert, .working = kWorking, .idle = kIdle};
    return p;
}

const Theme::Palette &Theme::lightPalette()
{
    static const Palette p{
        .islandBg = "#F4F8F9", .card = "#FFFFFF", .line = "#CFE0E6", .codeBg = "#E6EFF2",
        .text = "#0E2A47", .textHover = "#12344F", .muted = "#4F6B82", .dim = "#647D92",
        .hoverFill = "#120E2A47", .pillFill = "#1A0E2A47", .pillHoverFill = "#260E2A47", .subtleFill = "#0F0E2A47", .countdown = "#590E2A47",
        .primary = "#0E2A47", .primaryHover = "#12344F", .primaryText = "#F4F8F9", .primaryDim = "#8FB3C7",
        .alertText = "#C23B30", .link = "#3E7C9E",   // Correnteza
        .lamp = kLamp, .ok = kOk, .alert = kAlert, .working = kWorking, .idle = kIdle};
    return p;
}

Theme::Theme(AppState *state, QObject *parent) : QObject(parent), m_state(state)
{
    connect(m_state, &AppState::themeModeChanged, this, &Theme::changed);
}

bool Theme::dark() const
{
    const QString mode = m_state->themeMode();
    if (mode == QLatin1String("dark"))
        return true;
    if (mode == QLatin1String("light"))
        return false;
    return m_systemDark;
}

void Theme::setSystemDark(bool dark)
{
    if (dark == m_systemDark)
        return;
    const bool before = this->dark();
    m_systemDark = dark;
    if (this->dark() != before)
        emit changed();
}

} // namespace farol
