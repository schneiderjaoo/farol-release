# Cais 2 — Ajustes em janela — Implementation Plan

> **Emenda de 2026-10-03:** o autor recusou a janela ao vê-la ("a aba de ajustes não pode ser um modal"). O que este plano descreve foi desfeito no mesmo dia: os Ajustes são de novo uma view da ilha (`qml/SettingsView.qml`), com a organização desenhada para a janela. Ver a spec, §2.4.

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Os Ajustes saem da ilha e viram uma janela comum do desktop, aberta pela aba de ajustes da coluna, pela bandeja e pelo botão de "Nova sessão" sem workspace.

**Architecture:** `qml/SettingsWindow.qml` é o conteúdo (barra lateral + página, cada opção com a explicação escrita embaixo do nome), mostrado por `platform/SettingsWindow` num `QQuickView` do mesmo `QQmlEngine` da ilha, instância única. Quem quer os Ajustes chama `appState.openSettings()`, que emite `settingsRequested`; `main.cpp` mostra a janela e recolhe a ilha. A view `settings` da ilha, `SettingsView.qml` e `SettingLabel.qml` deixam de existir.

**Tech Stack:** C++20, Qt 6 QML (QQuickView), QtTest.

**Spec:** `docs/superpowers/specs/2026-10-03-redesenho-cais-design.md` (§2.4).

## Global Constraints

- Build e testes no host por `linux/scripts/host.sh`; nenhum commit; nenhuma captura de tela.
- Nunca um hex num `.qml`; texto de interface em pt-BR; código e comentários em inglês.
- As chaves de `farol.conf` não mudam; os `objectName` dos controles são os da view antiga, para os testes migrarem sem reescrita.
- Páginas: Ilha (tema, posição, reduzir movimento, esconder sem uso, recolher após, sons), Sessões (ocultar inativas, lembrar espera, notificar ausente, workspace), Atalhos (os dois atalhos), Sobre (versão, estado dos hooks).
- Tamanho inicial 640×420, mínimo 520×360, título "Ajustes · Farol"; reabrir traz a mesma janela, na página Ilha.
- O botão de som sai da coluna (vira o interruptor "Sons" da página Ilha); a quarta casa da coluna fica vazia até a aba Skills (passo 5).

## Review Focus

- Janela pequena (no mínimo de 520×360): toda opção continua alcançável (a página rola). Teste em `tst_settings_window`.
- Fechar a janela durante a captura de um atalho e reabrir: não pode voltar capturando. Teste.
- Abrir os Ajustes duas vezes: uma só janela. Teste.
- Tema trocado com a janela aberta: a janela acompanha na hora. Teste (cor de fundo).
- Estado dos hooks desconhecido ou arquivo ilegível: a página Sobre diz "não instalados", sem travar. Teste com o estado vazio.

## Tasks

### Task 1: `AppState::openSettings` e quem o chama
- [ ] `tst_app_state`: `openSettings()` emite `settingsRequested` uma vez. `tst_tray`: "Settings…" emite o sinal e não muda a view. `tst_island_qml`: `railTabSettings` e `repoSettings` emitem o sinal.
- [ ] `AppState.h`: `Q_INVOKABLE void openSettings() { emit settingsRequested(); }` e o sinal. `Tray.cpp`, `IslandRail.qml`, `RepositoriesView.qml` passam a chamá-lo.

### Task 2: O conteúdo da janela
- [ ] `tests/tst_settings_window.cpp` (novo): os testes de Ajustes de `tst_island_qml` migrados (tema, posição, movimento, recolher, esconder, ocultar inativas, lembrar espera, notificar, workspace, atalhos), mais: sons, explicação de cada opção presente e dentro da janela, troca de página, página Sobre, janela no tamanho mínimo, tema ao vivo.
- [ ] `core/HooksStatus.h` (novo): `Q_INVOKABLE QString state()` → `"installed"`, `"outdated"` ou `"missing"`, de uma função dada no construtor.
- [ ] `qml/SettingsWindow.qml` (novo), com o componente interno `Option` (nome, explicação, controles).

### Task 3: A janela e a ligação no app
- [ ] `tst_settings_window`: `SettingsWindow::show()` duas vezes dá uma janela só, visível, na página Ilha, sem captura pendente.
- [ ] `platform/SettingsWindow.{h,cpp}`; `main.cpp` liga `settingsRequested` → `show()` + `controller.collapse()`, registra `hooks` no contexto e define a versão do app.

### Task 4: Tirar a view da ilha
- [ ] `IslandView::Settings` sai do enum e das duas tabelas; `Island.qml` perde a entrada; `SettingsView.qml` e `SettingLabel.qml` são apagados; a casa do som sai de `IslandRail.qml`.
- [ ] Os testes que usavam `"settings"` como uma view qualquer passam a usar `"upload"`; os de Ajustes em `tst_island_qml` são apagados (migrados na Tarefa 2).
- [ ] Suíte inteira, `CLAUDE.md`, skill `farol-island-ui`, instalar e reiniciar.
