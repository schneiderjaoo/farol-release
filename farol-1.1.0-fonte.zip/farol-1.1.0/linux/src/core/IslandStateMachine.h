#pragma once
#include "Scheduler.h"

#include <functional>

namespace farol {

// Port of IslandStateMachine.swift. Pure logic: it only talks through onTransition.
class IslandStateMachine {
public:
    enum class State {
        Hidden,   // island invisible (notch size)
        Petit,    // compact island
        Home,     // expanded, overview
        Coucou    // expanded, greeting animation
    };

    explicit IslandStateMachine(IScheduler &scheduler);

    State state() const { return m_state; }
    std::function<void(State, State)> onTransition;   // (from, to)

    int homeToPetitDelayMs = 15000;
    int petitToHiddenDelayMs = 60000;
    int greetAutoCollapseDelayMs = 600;
    int greetHoverCollapseDelayMs = 10000;

    // Farol: false keeps the compact island on screen (Petit never goes to Hidden by itself). An island that is
    // already hidden stays so until reveal(). The Swift FSM always hides.
    void setHideWhenIdle(bool on);
    bool hideWhenIdle() const { return m_hideWhenIdle; }

    void launch();
    void mouseEntered();
    void mouseLeft();
    void click();
    void greetComplete();
    void reveal();
    void cancelTimers();
    // The island was opened from outside the FSM (tray/debug menu, hook alerts). Moves Hidden/Petit/Coucou to
    // Home without notifying (cancelling every timer), so a later pointer entry, the 60 s hide timer or the
    // greeting timers cannot collapse it. Returns true when the state changed. Not part of the Swift FSM.
    bool openExternally();
    // The island was collapsed outside the FSM (Esc). Moves Home/Coucou to Petit silently, cancelling timers.
    bool closeExternally();

private:
    void schedulePetitHide();
    void scheduleHomeCollapse();
    void scheduleGreetCollapse(int delayMs);
    void cancel(int &id);
    void transition(State to);

    IScheduler &m_sched;
    State m_state = State::Hidden;
    bool m_hideWhenIdle = true;
    int m_petitHide = 0;
    int m_homeCollapse = 0;
    int m_greetCollapse = 0;   // stays non-zero after it fires, exactly like greetCollapseWork in Swift
};

} // namespace farol
