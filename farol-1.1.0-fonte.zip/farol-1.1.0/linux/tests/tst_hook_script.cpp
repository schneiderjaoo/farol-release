#include <QtTest>
#include <QTemporaryDir>
#include <sys/stat.h>
#include "HookScript.h"

using namespace farol;

class TestHookScript : public QObject {
    Q_OBJECT
    static ino_t inode(const QString &p)
    {
        struct stat st{};
        return ::stat(p.toUtf8().constData(), &st) == 0 ? st.st_ino : 0;
    }

private slots:
    void writesAnExecutableScriptInAPrivateFolder()
    {
        QTemporaryDir dir;
        const QString dest = dir.path() + "/farol/farol-hook";
        QString err;
        QVERIFY2(installHookScript("#!/usr/bin/env python3\nprint(1)\n", dest, &err), qPrintable(err));
        QFile f(dest);
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(f.readAll(), QByteArray("#!/usr/bin/env python3\nprint(1)\n"));
#ifndef Q_OS_WIN   // Windows has no modes: what runs there is told by its name, and the profile is the user's alone
        const QFile::Permissions p = QFile::permissions(dest);
        QVERIFY(p & QFile::ExeOwner);
        QVERIFY(p & QFile::WriteOwner);
        QVERIFY(!(p & QFile::WriteGroup) && !(p & QFile::WriteOther));
        QCOMPARE(QFileInfo(dir.path() + "/farol").permissions() & (QFile::ReadGroup | QFile::ReadOther), QFile::Permissions());
#endif
    }

    void unchangedContentIsNotRewritten()
    {
        QTemporaryDir dir;
        const QString dest = dir.path() + "/farol-hook";
        QVERIFY(installHookScript("one", dest));
        const ino_t first = inode(dest);
        QVERIFY(installHookScript("one", dest));
        QCOMPARE(inode(dest), first);
    }

    void changedContentReplacesTheScript()
    {
        QTemporaryDir dir;
        const QString dest = dir.path() + "/farol-hook";
        QVERIFY(installHookScript("one", dest));
        QVERIFY(installHookScript("two", dest));
        QFile f(dest);
        QVERIFY(f.open(QIODevice::ReadOnly));
        QCOMPARE(f.readAll(), QByteArray("two"));
#ifndef Q_OS_WIN
        QVERIFY(QFile::permissions(dest) & QFile::ExeOwner);
#endif
    }

    void executableBitIsRestoredWhenContentIsTheSame()
    {
#ifdef Q_OS_WIN
        QSKIP("Windows has no executable bit");
#endif
        QTemporaryDir dir;
        const QString dest = dir.path() + "/farol-hook";
        QVERIFY(installHookScript("one", dest));
        QFile::setPermissions(dest, QFile::ReadOwner | QFile::WriteOwner);
        QVERIFY(installHookScript("one", dest));
        QVERIFY(QFile::permissions(dest) & QFile::ExeOwner);
    }

    void unwritableFolderReportsAnError()
    {
        QTemporaryDir dir;
        QFile inTheWay(dir.path() + "/file");   // a file where the folder would be: nothing can be made under it
        QVERIFY(inTheWay.open(QIODevice::WriteOnly));
        inTheWay.close();
        QString err;
        QVERIFY(!installHookScript("x", dir.path() + "/file/nope/farol-hook", &err));
        QVERIFY(!err.isEmpty());
    }
};

QTEST_MAIN(TestHookScript)
#include "tst_hook_script.moc"
