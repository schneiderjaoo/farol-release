import QtQuick
import QtQuick.Shapes

// The compact island's scene, from the design canvas: the sky, the sea, and the rock Lumi stands on. Night in the
// dark theme (stars, a moon, the lamp's beam), day in the light one (`day`: clouds, the sun, no beam). It is drawn in
// two layers so the boats sail between them: the back one (sky, far sea, rock, beam) under Lumi and the fleet, the
// front one (the near wave) over them. Its colours are the scene's own, like Lumi's. On a side edge there is only
// the sky. Nothing here moves.
Item {
    id: sea
    property bool front: false
    property bool landscape: true
    property bool day: false
    readonly property var sky: day ? ["#7CC4EE", "#B5E0F7", "#E3F4FB"] : ["#050F1E", "#0A1F36", "#113356"]
    readonly property color farSea: day ? "#5AAEDD" : "#163C62"
    readonly property color nearSea: day ? "#3B93C9" : "#0B2440"
    readonly property color foam: day ? "#CCEAF3F4" : "#B22E5F86"
    readonly property color stone: day ? "#6F8494" : "#17293F"
    // x as a share of the width, y, width, height, opacity: stars at night, clouds by day
    readonly property var stars: [[0.48, 11.5, 1.3, 1.3, 0.43], [0.03, 7.9, 1.0, 1.0, 0.8], [0.69, 10.8, 1.2, 1.2, 0.71], [0.16, 8.7, 0.9, 0.9, 0.85],
                                  [0.08, 13.6, 0.9, 0.9, 0.73], [0.34, 8.3, 1.5, 1.5, 0.36], [0.97, 15.3, 0.9, 0.9, 0.58], [0.21, 4.1, 1.3, 1.3, 0.44],
                                  [0.70, 3.7, 0.9, 0.9, 0.8], [0.40, 8.4, 1.3, 1.3, 0.61], [0.39, 3.4, 1.4, 1.4, 0.88], [0.96, 11.6, 1.1, 1.1, 0.55],
                                  [0.58, 5.2, 1.0, 1.0, 0.6], [0.85, 6.4, 1.2, 1.2, 0.7]]
    readonly property var clouds: [[0.27, 6, 22, 5, 0.9], [0.31, 9, 14, 4, 0.9], [0.56, 4.5, 18, 4, 0.8], [0.80, 8, 26, 5, 0.85], [0.84, 5, 13, 4, 0.85],
                                   [0.5, 12, 10, 3, 0.6]]
    property color beam: "transparent"      // the lamp's colour while a session is awake
    // the island's corner radii, so nothing pokes out of its rounded corners
    property real topLeftRadius: 0
    property real topRightRadius: 0
    property real bottomLeftRadius: 0
    property real bottomRightRadius: 0
    readonly property real topLeft: topLeftRadius
    readonly property real topRight: topRightRadius
    readonly property real bottomLeft: bottomLeftRadius
    readonly property real bottomRight: bottomRightRadius
    clip: true

    // a gentle swell along y, from beyond the left edge to beyond the right one
    function swell(y, step) {
        let d = "M-6 " + y
        for (let x = -6, up = true; x < width + 6; x += step, up = !up)
            d += "q" + step / 2 + " " + (up ? -1 : 1) + " " + step + " 0"
        return d
    }
    // how far a rounded bottom corner of radius r cuts in at height y
    function inset(r, y) {
        const dy = y - (height - r)
        return r > 0 && dy > 0 ? r - Math.sqrt(Math.max(0, r * r - dy * dy)) : 0
    }
    // closes a swell into the water under it, following the island's bottom corners
    function water(y, step) {
        const w = width, h = height, br = bottomRight, bl = bottomLeft
        let d = swell(y, step)
        d += br > 0 ? "L" + (w - inset(br, y)) + " " + y + (y < h - br ? "V" + (h - br) : "") + "A" + br + " " + br + " 0 0 1 " + (w - br) + " " + h
                    : "L" + w + " " + y + "V" + h
        d += bl > 0 ? "H" + bl + "A" + bl + " " + bl + " 0 0 1 " + (y < h - bl ? "0 " + (h - bl) + "V" + y : inset(bl, y) + " " + y)
                    : "H0V" + y
        return d + "Z"
    }
    function rock() {
        const h = height, bl = bottomLeft, top = h - 7
        return "M" + inset(bl, top) + " " + top + "C6 " + (h - 11) + " 16 " + (h - 12) + " 30 " + (h - 8) + "L34 " + h
             + (bl > 0 ? "H" + bl + "A" + bl + " " + bl + " 0 0 1 " + inset(bl, top) + " " + top : "H0") + "Z"
    }

    Rectangle {
        visible: !sea.front
        anchors.fill: parent
        topLeftRadius: sea.topLeft
        topRightRadius: sea.topRight
        bottomLeftRadius: sea.bottomLeft
        bottomRightRadius: sea.bottomRight
        gradient: Gradient {
            GradientStop { position: 0.0; color: sea.sky[0] }
            GradientStop { position: 0.6; color: sea.sky[1] }
            GradientStop { position: 1.0; color: sea.sky[2] }
        }
    }
    Repeater {
        model: sea.front ? [] : !sea.day ? sea.stars : sea.landscape ? sea.clouds : []   // no room for clouds on a side edge
        Rectangle {
            required property var modelData
            x: modelData[0] * sea.width - width / 2
            y: modelData[1] - height / 2
            width: Math.min(modelData[2], sea.width * 0.6)
            height: modelData[3]
            radius: height / 2
            color: sea.day ? "#FFFFFF" : "#EAF3F4"
            opacity: modelData[4]
        }
    }
    Shape {
        visible: !sea.front && sea.landscape
        preferredRendererType: Shape.CurveRenderer
        // the moon, or the sun in its glow
        ShapePath { fillColor: sea.day ? "#55FFC233" : "transparent"; strokeColor: "transparent"; PathSvg { path: "M37.5 7a6.5 6.5 0 1 0 13 0a6.5 6.5 0 1 0 -13 0z" } }
        ShapePath {
            fillColor: sea.day ? "#FFC233" : "#EBF3EBC9"; strokeColor: "transparent"
            PathSvg { path: sea.day ? "M40.5 7a3.5 3.5 0 1 0 7 0a3.5 3.5 0 1 0 -7 0z" : "M44 3.5A3.5 3.5 0 1 0 44 10.5A4.6 4.6 0 0 1 44 3.5Z" }
        }
        ShapePath {
            // no beam in daylight
            fillColor: Qt.rgba(sea.beam.r, sea.beam.g, sea.beam.b, sea.day ? 0 : sea.beam.a * 0.06); strokeColor: "transparent"
            PathSvg { path: "M15 14L" + sea.width + " 2V26Z" }
        }
        ShapePath { fillColor: sea.farSea; strokeColor: "transparent"; PathSvg { path: sea.water(sea.height - 9, 20) } }
        ShapePath { fillColor: sea.stone; strokeColor: "transparent"; PathSvg { path: sea.rock() } }
    }
    Shape {
        objectName: sea.front ? "nearWave" : ""
        visible: sea.front && sea.landscape
        preferredRendererType: Shape.CurveRenderer
        ShapePath { fillColor: sea.nearSea; strokeColor: "transparent"; PathSvg { path: sea.water(sea.height - 4, 15) } }
        ShapePath { fillColor: "transparent"; strokeColor: sea.foam; strokeWidth: 0.7; PathSvg { path: sea.swell(sea.height - 4, 15) } }
    }
}
