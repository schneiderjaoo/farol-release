import QtQuick
import QtQuick.Shapes

// The session signal of "Estados das sessões": a coloured disc whose symbol says what is going on without opening
// anything. `signal` is one of working, waiting, done, error, idle (see LumiLook).
Item {
    id: badge
    property string signal: "idle"
    property real size: 16
    width: size
    height: size

    readonly property color fill: ({
        "working": theme.working, "waiting": theme.lamp, "done": theme.ok, "error": theme.alert, "idle": theme.idle
    })[signal] || theme.idle
    readonly property color ink: signal === "idle" ? "#EAF3F4" : "#0E2A47"
    readonly property var glyphs: ({
        "working": "M32 18a14 14 0 1 1-14 14",
        "waiting": "M32 17v18",
        "done": "M21 33l8 8 15-17",
        "error": "M22 22l20 20M42 22L22 42",
        "idle": "M22 32h20"
    })

    Rectangle {
        anchors.fill: parent
        radius: width / 2
        color: badge.fill
    }

    Item {
        id: glyphBox
        objectName: "badgeGlyph"
        width: 64
        height: 64
        anchors.centerIn: parent
        scale: badge.size / 64
        visible: badge.size >= 14     // tiny discs are just a colour
        Shape {
            preferredRendererType: Shape.CurveRenderer
            ShapePath {
                fillColor: "transparent"
                strokeColor: badge.ink
                strokeWidth: 4.5
                capStyle: ShapePath.RoundCap
                joinStyle: ShapePath.RoundJoin
                PathSvg { path: badge.glyphs[badge.signal] || badge.glyphs.idle }
            }
            ShapePath {   // the dot under the "waiting" exclamation mark
                fillColor: badge.signal === "waiting" ? badge.ink : "transparent"
                strokeColor: "transparent"
                PathSvg { path: "M29.4 45a2.6 2.6 0 1 0 5.2 0a2.6 2.6 0 1 0 -5.2 0Z" }
            }
        }
        RotationAnimation on rotation {
            running: glyphBox.visible && badge.visible && badge.signal === "working" && !appState.reduceMotion
            from: 0; to: 360; duration: 1600
            loops: Animation.Infinite
            onRunningChanged: if (!running) glyphBox.rotation = 0
        }
    }
}
