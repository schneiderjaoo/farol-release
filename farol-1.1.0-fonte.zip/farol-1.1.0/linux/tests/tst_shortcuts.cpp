#include <QtTest>
#include <QSettings>
#include <QSignalSpy>
#include <QTemporaryDir>
#include <memory>
#include "Shortcuts.h"

using namespace farol;

class TestShortcuts : public QObject {
    Q_OBJECT
    QTemporaryDir dir;
    QList<QPair<QString, int>> bound;     // what the desktop was asked for
    QList<int> taken;                     // combos another program has

    std::unique_ptr<QSettings> settings() { return std::make_unique<QSettings>(dir.path() + "/s.ini", QSettings::IniFormat); }
    Shortcuts::Bind desktop()
    {
        return [this](const QString &action, int combo) {
            bound << qMakePair(action, combo);
            return taken.contains(combo) ? QString() : QStringLiteral("combo-%1").arg(combo);
        };
    }
    static constexpr int kMetaF = int(Qt::MetaModifier) | int(Qt::Key_F);
    static constexpr int kCtrlAltJ = int(Qt::ControlModifier) | int(Qt::AltModifier) | int(Qt::Key_J);

private slots:
    void init()
    {
        QFile::remove(dir.path() + "/s.ini");
        bound.clear();
        taken.clear();
    }

    void aKeyWithAModifierBecomesTheShortcutAndIsRemembered()
    {
        {
            auto s = settings();
            Shortcuts sc(s.get(), desktop());
            QCOMPARE(sc.toggleKey(), QString());
            QSignalSpy spy(&sc, &Shortcuts::changed);
            QVERIFY(sc.assign("toggle", Qt::Key_F, Qt::MetaModifier));
            QCOMPARE(sc.toggleKey(), QStringLiteral("combo-%1").arg(kMetaF));
            QCOMPARE(sc.combo("toggle"), kMetaF);
            QCOMPARE(spy.count(), 1);
            QVERIFY(sc.assign("jump", Qt::Key_J, Qt::ControlModifier | Qt::AltModifier | Qt::KeypadModifier));   // keypad bit dropped
            QCOMPARE(sc.combo("jump"), kCtrlAltJ);
            QCOMPARE(bound, (QList<QPair<QString, int>>{{"toggle", kMetaF}, {"jump", kCtrlAltJ}}));
        }
        bound.clear();
        auto s = settings();
        Shortcuts sc(s.get(), desktop());
        QCOMPARE(sc.toggleKey(), QString());               // nothing is registered before restore()
        sc.restore();
        QCOMPARE(bound, (QList<QPair<QString, int>>{{"toggle", kMetaF}, {"jump", kCtrlAltJ}}));
        QCOMPARE(sc.jumpKey(), QStringLiteral("combo-%1").arg(kCtrlAltJ));
    }

    void loneModifiersWaitAndPlainKeysAreRefused()
    {
        auto s = settings();
        Shortcuts sc(s.get(), desktop());
        QVERIFY(!sc.assign("toggle", Qt::Key_Meta, Qt::MetaModifier));      // still pressing: no error
        QVERIFY(!sc.assign("toggle", Qt::Key_Shift, Qt::ShiftModifier));
        QCOMPARE(sc.error(), QString());
        QVERIFY(!sc.assign("toggle", Qt::Key_F, Qt::NoModifier));           // a letter alone would eat typing
        QVERIFY(!sc.error().isEmpty());
        sc.clearError();
        QVERIFY(!sc.assign("toggle", Qt::Key_F, Qt::ShiftModifier));        // so would Shift+letter
        QVERIFY(!sc.assign("toggle", Qt::Key_Escape, Qt::ControlModifier)); // Esc cancels in the view
        QVERIFY(!sc.assign("nothing", Qt::Key_F, Qt::MetaModifier));        // unknown action
        QVERIFY(bound.isEmpty());
        QVERIFY(sc.assign("toggle", Qt::Key_F9, Qt::NoModifier));           // a function key is fine alone
        QCOMPARE(sc.error(), QString());
    }

    void takenKeysAndTheOtherShortcutAreRefused()
    {
        auto s = settings();
        Shortcuts sc(s.get(), desktop());
        taken << kMetaF;
        QVERIFY(!sc.assign("toggle", Qt::Key_F, Qt::MetaModifier));         // another program has it
        QVERIFY(!sc.error().isEmpty());
        QCOMPARE(sc.toggleKey(), QString());
        QVERIFY(sc.assign("toggle", Qt::Key_J, Qt::ControlModifier | Qt::AltModifier));
        QCOMPARE(sc.error(), QString());
        QVERIFY(!sc.assign("jump", Qt::Key_J, Qt::ControlModifier | Qt::AltModifier));   // already the other one
        QVERIFY(!sc.error().isEmpty());
        QCOMPARE(sc.combo("jump"), 0);
    }

    void clearUnregistersAndForgets()
    {
        {
            auto s = settings();
            Shortcuts sc(s.get(), desktop());
            QVERIFY(sc.assign("toggle", Qt::Key_F, Qt::MetaModifier));
            bound.clear();
            sc.clear("toggle");
            QCOMPARE(bound, (QList<QPair<QString, int>>{{"toggle", 0}}));
            QCOMPARE(sc.toggleKey(), QString());
        }
        bound.clear();
        auto s = settings();
        Shortcuts sc(s.get(), desktop());
        sc.restore();
        QVERIFY(bound.isEmpty());
    }

    void aSavedShortcutTakenMeanwhileShowsAsNone()
    {
        {
            auto s = settings();
            Shortcuts sc(s.get(), desktop());
            QVERIFY(sc.assign("toggle", Qt::Key_F, Qt::MetaModifier));
        }
        taken << kMetaF;
        auto s = settings();
        Shortcuts sc(s.get(), desktop());
        sc.restore();
        QCOMPARE(sc.toggleKey(), QString());
    }
};

QTEST_GUILESS_MAIN(TestShortcuts)
#include "tst_shortcuts.moc"
