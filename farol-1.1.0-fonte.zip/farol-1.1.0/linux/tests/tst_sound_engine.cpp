#include <QtTest>
#include <QDir>
#include <QMediaDevices>
#include <QAudioDevice>
#include "SoundEngine.h"
#include "SoundNames.h"

using farol::SoundEngine;

class TestSoundEngine : public QObject {
    Q_OBJECT
private slots:
    // Every QSoundEffect may hold an audio stream of its own (about 20 file descriptors each with a Bluetooth
    // headset as the output): 28 sounds x 3 voices opened at start ran the process out of descriptors and Qt crashed.
    void opensNoSoundUntilOneIsPlayed()
    {
        SoundEngine engine(QStringLiteral(FAROL_SOUNDS_DIR));
        QCOMPARE(engine.voiceCount(), 0);
        engine.setEnabled(false);
        engine.play("peek");
        engine.setEnabled(true);
        engine.play("does-not-exist");
        QCOMPARE(engine.voiceCount(), 0);
    }
    void aSoundIsLoadedTheFirstTimeItPlays()
    {
        if (QDir(QStringLiteral(FAROL_SOUNDS_DIR)).entryList({"*.wav"}, QDir::Files).isEmpty())
            QSKIP("no sounds installed in linux/sounds");   // the WAVs are not part of the repository
        if (QMediaDevices::audioOutputs().isEmpty())
            QSKIP("nothing to play a sound on here");       // a build machine: a sound is never ready without an output
        SoundEngine engine(QStringLiteral(FAROL_SOUNDS_DIR));
        QVERIFY(!engine.isLoaded("peek"));
        engine.play("peek");
        QCOMPARE(engine.voiceCount(), 1);
        QTRY_VERIFY_WITH_TIMEOUT(engine.isLoaded("peek"), 5000);
        QVERIFY(!engine.isLoaded("finish"));                 // the others stay closed
    }
    // The same sound can overlap itself, on at most three voices.
    void aSoundNeverTakesMoreThanThreeVoices()
    {
        SoundEngine engine(QStringLiteral(FAROL_SOUNDS_DIR));
        for (int i = 0; i < 10; ++i)
            engine.play("peek");
        QVERIFY(engine.voiceCount() >= 1 && engine.voiceCount() <= 3);
    }
    void volumeIsClampedToTwoTenths()
    {
        SoundEngine engine(QStringLiteral(FAROL_SOUNDS_DIR));
        QCOMPARE(engine.volume(), 0.12);
        engine.setVolume(5);
        QCOMPARE(engine.volume(), 0.2);
        engine.setVolume(-1);
        QCOMPARE(engine.volume(), 0.0);
    }
    void nonFiniteVolumeIsIgnored()
    {
        SoundEngine engine(QStringLiteral(FAROL_SOUNDS_DIR));
        engine.setVolume(qQNaN());
        QCOMPARE(engine.volume(), 0.12);
        engine.setVolume(qInf());
        QCOMPARE(engine.volume(), 0.12);
    }
    void unknownNameAndDisabledAreHarmless()
    {
        SoundEngine engine(QStringLiteral(FAROL_SOUNDS_DIR));
        engine.play("does-not-exist");
        engine.setEnabled(false);
        QVERIFY(!engine.enabled());
        engine.play("peek");
    }
};

QTEST_MAIN(TestSoundEngine)
#include "tst_sound_engine.moc"
