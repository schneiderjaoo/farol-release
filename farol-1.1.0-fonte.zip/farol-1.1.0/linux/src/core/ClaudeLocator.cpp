#include "ClaudeLocator.h"

#include <QDir>
#include <QFileInfo>
#include <algorithm>

namespace farol {

namespace {

bool runnable(const QString &path)
{
    const QFileInfo f(path);
    return !path.isEmpty() && f.isFile() && f.isExecutable();
}

// Whether the name `a` is of a newer version than `b`: runs of digits compare as numbers ("v22.3.0" after "v9.1.0",
// "2.1.285" after "2.1.9"). Done by hand: QCollator's numeric mode does nothing in the C locale, which is what a
// machine without a language set has.
bool newer(const QString &a, const QString &b)
{
    qsizetype i = 0, j = 0;
    while (i < a.size() && j < b.size()) {
        if (a[i].isDigit() && b[j].isDigit()) {
            qsizetype endA = i, endB = j;
            while (endA < a.size() && a[endA].isDigit())
                ++endA;
            while (endB < b.size() && b[endB].isDigit())
                ++endB;
            while (i < endA - 1 && a[i] == QLatin1Char('0'))
                ++i;
            while (j < endB - 1 && b[j] == QLatin1Char('0'))
                ++j;
            if (endA - i != endB - j)
                return endA - i > endB - j;         // more digits: the larger number
            for (; i < endA; ++i, ++j)
                if (a[i] != b[j])
                    return a[i] > b[j];
            continue;
        }
        if (a[i] != b[j])
            return a[i] > b[j];
        ++i;
        ++j;
    }
    return a.size() - i > b.size() - j;
}

// Subfolders of `dir` matching `pattern`, newest version first.
QStringList newestFirst(const QString &dir, const QString &pattern)
{
    QStringList names = QDir(dir).entryList({pattern}, QDir::Dirs | QDir::NoDotAndDotDot);
    std::sort(names.begin(), names.end(), newer);
    return names;
}

} // namespace

#ifdef Q_OS_WIN
// Claude Code's own installer and the editor extension have a claude.exe; npm has a claude.cmd beside its node.
QString findClaude(const QString &home, const QStringList &pathDirs, const QString &saved)
{
    if (runnable(saved))
        return saved;
    QStringList folders;
    for (const QString &dir : pathDirs)
        if (!dir.isEmpty())
            folders << QDir::fromNativeSeparators(dir);
    folders << home + QStringLiteral("/.local/bin") << home + QStringLiteral("/.claude/local")
            << home + QStringLiteral("/AppData/Roaming/npm");
    for (const QString &editor : {QStringLiteral("/.vscode"), QStringLiteral("/.vscode-oss"), QStringLiteral("/.cursor")}) {
        const QString extensions = home + editor + QStringLiteral("/extensions");
        for (const QString &extension : newestFirst(extensions, QStringLiteral("anthropic.claude-code-*")))
            folders << extensions + QLatin1Char('/') + extension + QStringLiteral("/resources/native-binary");
    }
    for (const QString &folder : std::as_const(folders))
        for (const QString &name : {QStringLiteral("/claude.exe"), QStringLiteral("/claude.cmd")})
            if (runnable(folder + name))
                return folder + name;
    return {};
}
#else
QString findClaude(const QString &home, const QStringList &pathDirs, const QString &saved)
{
    if (runnable(saved))
        return saved;
    QStringList candidates;
    for (const QString &dir : pathDirs)
        if (!dir.isEmpty())
            candidates << dir + QStringLiteral("/claude");
    candidates << home + QStringLiteral("/.local/bin/claude") << home + QStringLiteral("/.claude/local/claude");
    const QString nvm = home + QStringLiteral("/.nvm/versions/node");
    for (const QString &version : newestFirst(nvm, QStringLiteral("v*")))
        candidates << nvm + QLatin1Char('/') + version + QStringLiteral("/bin/claude");
    QStringList extensionDirs{home + QStringLiteral("/.vscode-oss/extensions"), home + QStringLiteral("/.vscode/extensions"),
                              home + QStringLiteral("/.cursor/extensions")};
    const QString flatpaks = home + QStringLiteral("/.var/app");
    for (const QString &app : QDir(flatpaks).entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name)) {
        const QString data = flatpaks + QLatin1Char('/') + app + QStringLiteral("/data");
        for (const QString &editor : QDir(data).entryList(QDir::Dirs | QDir::NoDotAndDotDot, QDir::Name))
            extensionDirs << data + QLatin1Char('/') + editor + QStringLiteral("/extensions");
    }
    for (const QString &extensions : extensionDirs)
        for (const QString &extension : newestFirst(extensions, QStringLiteral("anthropic.claude-code-*")))
            candidates << extensions + QLatin1Char('/') + extension + QStringLiteral("/resources/native-binary/claude");
    for (const QString &candidate : candidates)
        if (runnable(candidate))
            return candidate;
    return {};
}
#endif

QStringList claudeEnvironment(const QString &claude, const QString &path)
{
    const QString dir = QDir::toNativeSeparators(QFileInfo(claude).absolutePath());
    return {QStringLiteral("PATH=") + (path.isEmpty() ? dir : dir + QDir::listSeparator() + path)};
}

} // namespace farol
