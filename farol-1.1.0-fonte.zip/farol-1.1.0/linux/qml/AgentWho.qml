import QtQuick

// Coloured dot + agent name + grey label ("pede permissão").
Row {
    id: who
    property string name: ""
    property string label: ""
    property color dot: theme.muted
    property alias nameObjectName: nameText.objectName
    // What is left for the name on the line this row sits on: a session's title can be long, the label stays whole.
    readonly property real nameRoom: (parent ? parent.width : 400) - 13 - (who.label !== "" ? labelText.implicitWidth + 6 : 0)
    spacing: 6
    height: 16

    Item {
        width: 7
        height: 16
        Rectangle { anchors.centerIn: parent; width: 7; height: 7; radius: 3.5; color: who.dot }
    }
    Text {
        id: nameText
        height: 16
        verticalAlignment: Text.AlignVCenter
        width: Math.min(implicitWidth, Math.max(40, who.nameRoom))
        elide: Text.ElideRight
        textFormat: Text.PlainText
        text: who.name
        color: theme.text
        font.family: theme.bodyFont
        font.pixelSize: 12
        font.weight: Font.DemiBold
    }
    Text {
        id: labelText
        height: 16
        verticalAlignment: Text.AlignVCenter
        textFormat: Text.PlainText
        text: who.label
        color: theme.muted
        font.family: theme.bodyFont
        font.pixelSize: 11
    }
}
