#include "IslandProbe.h"

#include <LayerShellQt/Window>
#include <QDateTime>
#include <QQuickWindow>
#include <QRegion>
#include <cstdio>

IslandProbe::IslandProbe(QObject *parent) : QObject(parent) {}

void IslandProbe::attach(QQuickWindow *window) { m_window = window; }

void IslandProbe::setInputRect(qreal x, qreal y, qreal w, qreal h)
{
    if (!m_window)
        return;
    // 6 px of slack around the island, like the macOS hit test (SPEC §1).
    QRect r = QRectF(x, y, w, h).toAlignedRect().adjusted(-6, -6, 6, 6);
    r = r.intersected(QRect(QPoint(0, 0), m_window->size()));
    m_window->setMask(QRegion(r));
}

void IslandProbe::setKeyboardOnDemand(bool on)
{
    if (!m_window)
        return;
    auto *layer = LayerShellQt::Window::get(m_window);
    layer->setKeyboardInteractivity(on ? LayerShellQt::Window::KeyboardInteractivityOnDemand
                                       : LayerShellQt::Window::KeyboardInteractivityNone);
    log(QStringLiteral("keyboard -> %1").arg(on ? "OnDemand" : "None"));
}

void IslandProbe::log(const QString &message)
{
    std::printf("%s %s\n", qPrintable(QTime::currentTime().toString("HH:mm:ss.zzz")),
                qPrintable(message));
    std::fflush(stdout);
}
