import QtQuick

// Provisional card for a view (real content arrives in L1c). It already animates like the Swift views:
// enter = 300 ms after a 160 ms delay, exit = 160 ms; scale 0.97 <-> 1.
Item {
    id: card
    property string viewName: ""
    property bool active: false
    property string contentSource: ""

    opacity: active ? 1 : 0
    scale: active ? 1 : 0.97
    visible: opacity > 0.001
    enabled: active

    Behavior on opacity {
        SequentialAnimation {
            PauseAnimation { duration: card.active ? 160 : 0 }
            NumberAnimation { duration: card.active ? 300 : 160; easing.type: card.active ? Easing.OutCubic : Easing.InCubic }
        }
    }
    Behavior on scale {
        SequentialAnimation {
            PauseAnimation { duration: card.active ? 160 : 0 }
            NumberAnimation { duration: card.active ? 300 : 160; easing.type: card.active ? Easing.OutCubic : Easing.InCubic }
        }
    }

    Rectangle {
        visible: card.contentSource === ""
        anchors.fill: parent
        radius: 20
        color: theme.card
        border.color: theme.line
        border.width: 1
        Text {
            anchors.centerIn: parent
            textFormat: Text.PlainText
            text: card.viewName
            color: theme.dim
            font.family: theme.bodyFont
            font.pixelSize: 13
        }
    }

    Loader {
        anchors.fill: parent
        active: card.contentSource !== "" && card.visible
        source: card.contentSource
    }
}
