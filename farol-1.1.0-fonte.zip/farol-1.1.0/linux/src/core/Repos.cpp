#include "Repos.h"

#include "AppState.h"
#include "Links.h"

#include <QDir>
#include <QFileInfo>
#include <algorithm>

namespace farol {

namespace {
bool isRepo(const QString &dir) { return QFileInfo::exists(dir + QStringLiteral("/.git")); }

void search(const QString &dir, const QString &label, int depthLeft, int &budget, QList<Repo> &out)
{
    if (budget <= 0)
        return;
    --budget;
    if (isRepo(dir)) {
        out.append({QFileInfo(dir).fileName(), dir, label.isEmpty() ? QFileInfo(dir).fileName() : label});
        return;                                              // what is inside a repository belongs to it
    }
    if (depthLeft <= 0)
        return;
    const QStringList children = QDir(dir).entryList(QDir::Dirs | QDir::NoDotAndDotDot | QDir::NoSymLinks, QDir::Name);
    for (const QString &name : children) {
        if (name == QLatin1String("node_modules"))
            continue;
#ifdef Q_OS_WIN
        // A dot folder is not hidden to Windows, and a junction is a folder like any other: neither is searched.
        if (name.startsWith(QLatin1Char('.')) || links::isLink(dir + QLatin1Char('/') + name))
            continue;
#endif
        search(dir + QLatin1Char('/') + name, label.isEmpty() ? name : label + QLatin1Char('/') + name, depthLeft - 1,
               budget, out);
    }
}
} // namespace

QList<Repo> findRepos(const QString &root, int maxDepth, int budget)
{
    QList<Repo> out;
    if (!QDir::isAbsolutePath(root) || !QFileInfo(root).isDir())
        return out;
    search(QDir::cleanPath(root), QString(), maxDepth, budget, out);
    std::sort(out.begin(), out.end(), [](const Repo &a, const Repo &b) {
        const int c = a.label.compare(b.label, Qt::CaseInsensitive);
        return c != 0 ? c < 0 : a.label < b.label;
    });
    return out;
}

Repos::Repos(AppState *state, QObject *parent) : QObject(parent), m_state(state)
{
    connect(m_state, &AppState::workspaceDirChanged, this, &Repos::refresh);
    m_repos = findRepos(m_state->workspaceDir());
}

QVariantList Repos::list() const
{
    QVariantList out;
    for (const Repo &r : m_repos)
        if (m_filter.isEmpty() || r.label.contains(m_filter, Qt::CaseInsensitive))
            out.append(QVariantMap{{"name", r.name}, {"path", r.path}, {"label", r.label}});
    return out;
}

void Repos::setFilter(const QString &text)
{
    const QString filter = text.trimmed();
    if (filter == m_filter)
        return;
    m_filter = filter;
    emit changed();
}

void Repos::refresh()
{
    m_repos = findRepos(m_state->workspaceDir());
    emit changed();
}

void Repos::open(const QString &path)
{
    for (const Repo &r : m_repos) {
        if (r.path == path) {
            emit openRequested(path);
            return;
        }
    }
}

} // namespace farol
