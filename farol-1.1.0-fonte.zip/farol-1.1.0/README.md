# Farol

Uma ilha na borda da tela que mostra suas sessões do Claude Code. O mascote **Lumi** acende quando uma
sessão termina, trava ou espera por você, e dali mesmo dá para aprovar permissões, responder perguntas e voltar para a
sessão.

Feito para **Fedora KDE Plasma 6 (Wayland)** e para **Linux Mint 22 (Cinnamon, X11)**.

## Linux Mint 22

Baixe o `farol_<versão>_mint22_amd64.deb` (na página de releases, ou nos artefatos da pipeline) e instale:

```sh
sudo apt install ./farol_*_mint22_amd64.deb
```

O **Farol** aparece no menu de aplicativos. O pacote ocupa uns 90 MB porque leva junto o Qt de que precisa (o do
Mint 22 é antigo demais para a ilha); tudo fica em `/opt/farol`. Depois siga em [Ligar ao Claude Code](#ligar-ao-claude-code).
Para tirar: `sudo apt remove farol`.

No Mint a ilha é uma janela sem moldura, sempre por cima e em todas as áreas de trabalho; os atalhos de
**Settings… → Atalhos** são pegos direto do servidor X (combinações que o Cinnamon já usa são recusadas, e
`Ctrl+Alt+F1`…`F12` não servem: o X fica com elas).

## Fedora KDE Plasma: instalação rápida

Três comandos, sem `sudo` depois do primeiro. Leva uns dois minutos.

**1. Dependências**

```sh
sudo dnf install git cmake ninja-build gcc-c++ python3 \
    qt6-qtbase-devel qt6-qtdeclarative-devel qt6-qtmultimedia-devel \
    layer-shell-qt-devel kf6-kstatusnotifieritem-devel kf6-kglobalaccel-devel kf6-kidletime-devel
```

**2. Baixar e compilar**

```sh
git clone https://github.com/schneiderjaoo/farol.git && cd farol
cmake -S linux -B linux/build -G Ninja -DCMAKE_BUILD_TYPE=Release -DFAROL_BUILD_SPIKES=OFF
cmake --build linux/build
```

**3. Instalar no seu usuário**

```sh
cmake --install linux/build --prefix ~/.local
```

Pronto: o **Farol** aparece no menu de aplicativos (ou rode `farol` no terminal). A ilha fica no topo da tela e
o ícone na bandeja do sistema.

## Ligar ao Claude Code

Na primeira vez, clique com o botão direito no ícone do Farol na bandeja e escolha
**Claude Code hooks → Install…**. O Farol mostra o que vai mudar no `~/.claude/settings.json`, faz um backup e só
grava depois que você confirma. Abra uma sessão nova do Claude Code para os hooks valerem.

Se a bandeja mostrar **Hooks: update needed**, repita o **Install…** (acontece depois de atualizar o Farol).

## Abrir junto com o sistema

```sh
mkdir -p ~/.config/autostart
cp ~/.local/share/applications/local.joao.Farol.desktop ~/.config/autostart/
```

Ou em *Configurações do Sistema → Inicialização automática → Adicionar aplicativo* (no Mint: *Aplicativos de
inicialização*; o arquivo está em `/usr/share/applications/local.joao.Farol.desktop`).

## Atualizar

No Mint, instale o `.deb` novo por cima. No Fedora, a partir do código:

```sh
git pull
cmake --build linux/build && cmake --install linux/build --prefix ~/.local
```

Depois feche o Farol pela bandeja (**Quit**) e abra de novo.

## Desinstalar

Primeiro tire os hooks pela bandeja (**Claude Code hooks → Uninstall…**), feche o Farol e então:

```sh
rm -f ~/.local/bin/farol \
   ~/.local/share/applications/local.joao.Farol.desktop \
   ~/.local/share/icons/hicolor/scalable/apps/local.joao.Farol.svg \
   ~/.config/autostart/local.joao.Farol.desktop
rm -rf ~/.local/share/farol ~/.config/farol ~/.local/state/farol
```

## Bom saber

- **Sons:** os arquivos de som não vêm no repositório; sem eles o Farol funciona em silêncio. Veja
  [linux/sounds/README.md](linux/sounds/README.md).
- **Nova sessão:** escolha a pasta da sua workspace em **Settings… → Workspace**. A aba **+** da ilha passa a listar
  todo repositório (pasta com `.git`) dela; um clique abre o repositório no VSCodium com uma sessão nova do Claude Code.
- **Skills da empresa e plugins:** na aba da estrela, escolha a pasta onde está clonado o repositório de skills. O
  Farol liga cada skill em `~/.claude/skills`, atualiza a pasta com `git pull` e avisa quando não consegue. Na mesma aba
  ficam os plugins do Claude Code: ligar, desligar, remover e instalar pelo catálogo.
- **Perguntar sobre arquivos:** na aba do balão, solte arquivos (texto, código, imagem ou PDF) na ilha e pergunte. Quem
  responde é o serviço que você escolher em **Settings… → IA** (Anthropic, ChatGPT ou Gemini), com a sua chave de API,
  guardada no cofre de senhas do sistema. Os arquivos só são enviados quando você pergunta, e só para esse serviço.
- **Posição e tema:** bandeja → **Settings…** (topo, base ou laterais; tema claro, escuro ou o do sistema).
- **`farol` não é encontrado:** confira se `~/.local/bin` está no seu `PATH`.
- **Mensagens do app:** `journalctl --user -b | grep "farol\["`. Se o Farol fechar sozinho: `coredumpctl list farol`.

## Desenvolvimento

Regras do projeto, arquitetura e como rodar os testes estão em [CLAUDE.md](CLAUDE.md). Para compilar com os testes:

```sh
cmake -S linux -B linux/build -G Ninja && cmake --build linux/build
ctest --test-dir linux/build --output-on-failure
```

Os pacotes (RPM do Fedora, DEB do Mint 22) saem da pipeline em `.github/workflows/build.yml`; como gerar cada um à
mão está em [linux/packaging/README.md](linux/packaging/README.md).

## Licença

[MIT](LICENSE). O Farol nasceu a partir do [Coucou](https://github.com/Louis-CFM/coucou), de Louis Raillé, um app para macOS também sob licença MIT; o aviso de copyright dele está no `LICENSE`.

O Farol é um projeto independente: não é afiliado à Anthropic nem endossado por ela. "Claude" e "Claude Code" são marcas da Anthropic.
