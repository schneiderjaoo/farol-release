#pragma once
#include "AgentTask.h"
#include "IslandTypes.h"
#include "TaskModel.h"

#include <QAbstractItemModel>
#include <QObject>
#include <QVariantList>
#include <QVariantMap>
#include <functional>
#include <optional>

class QSettings;

namespace farol {

// Port of AppState.swift (the parts the island shell needs). Persisted through QSettings.
class AppState : public QObject {
    Q_OBJECT
    Q_PROPERTY(QString modeName READ modeName NOTIFY modeChanged)
    Q_PROPERTY(QString viewName READ viewName WRITE setViewName NOTIFY viewChanged)
    Q_PROPERTY(QString focusId READ focusId NOTIFY focusChanged)
    Q_PROPERTY(bool soundEnabled READ soundEnabled WRITE setSoundEnabled NOTIFY soundEnabledChanged)
    Q_PROPERTY(double soundVolume READ soundVolume WRITE setSoundVolume NOTIFY soundVolumeChanged)
    Q_PROPERTY(double autoCloseInterval READ autoCloseInterval WRITE setAutoCloseInterval NOTIFY autoCloseIntervalChanged)
    Q_PROPERTY(QString themeMode READ themeMode WRITE setThemeMode NOTIFY themeModeChanged)
    Q_PROPERTY(QString edge READ edge WRITE setEdge NOTIFY edgeChanged)
    Q_PROPERTY(bool vertical READ vertical NOTIFY edgeChanged)
    Q_PROPERTY(bool reduceMotion READ reduceMotion WRITE setReduceMotion NOTIFY reduceMotionChanged)
    Q_PROPERTY(QString workspaceDir READ workspaceDir WRITE setWorkspaceDir NOTIFY workspaceDirChanged)
    Q_PROPERTY(QString workspaceDirLabel READ workspaceDirLabel NOTIFY workspaceDirChanged)
    Q_PROPERTY(QString skillsDir READ skillsDir WRITE setSkillsDir NOTIFY skillsDirChanged)
    Q_PROPERTY(QString skillsDirLabel READ skillsDirLabel NOTIFY skillsDirChanged)
    Q_PROPERTY(int sessionIdleSeconds READ sessionIdleSeconds WRITE setSessionIdleSeconds NOTIFY sessionIdleSecondsChanged)
    Q_PROPERTY(bool autoHide READ autoHide WRITE setAutoHide NOTIFY autoHideChanged)
    Q_PROPERTY(bool notifyAway READ notifyAway WRITE setNotifyAway NOTIFY notifyAwayChanged)
    Q_PROPERTY(int waitReminderSeconds READ waitReminderSeconds WRITE setWaitReminderSeconds NOTIFY waitReminderSecondsChanged)
    Q_PROPERTY(bool isPinned READ isPinned WRITE setPinned NOTIFY pinnedChanged)
    Q_PROPERTY(int chatCount READ chatCount WRITE setChatCount NOTIFY chatCountChanged)
    Q_PROPERTY(double uploadProgress READ uploadProgress WRITE setUploadProgress NOTIFY uploadProgressChanged)
    Q_PROPERTY(qint64 lastActivityMs READ lastActivityMs WRITE setLastActivityMs NOTIFY lastActivityChanged)
    Q_PROPERTY(QString effectiveStateName READ effectiveStateName NOTIFY effectiveStateChanged)
    Q_PROPERTY(QVariantList compactOthers READ compactOthers NOTIFY compactOthersChanged)
    // Claude Code sessions in the island, and whether one of them is at work (compactOthersChanged is emitted on
    // every change of the task list, so it serves these two as well).
    Q_PROPERTY(int sessionCount READ sessionCount NOTIFY compactOthersChanged)
    Q_PROPERTY(int awakeSessionCount READ awakeSessionCount NOTIFY compactOthersChanged)   // without the dormant ones
    Q_PROPERTY(bool sessionBusy READ sessionBusy NOTIFY compactOthersChanged)
    // for the compact island's chip: sessions that wait for an answer, and sessions that stopped on an error
    Q_PROPERTY(int waitingCount READ waitingCount NOTIFY compactOthersChanged)
    Q_PROPERTY(int errorCount READ errorCount NOTIFY compactOthersChanged)
    Q_PROPERTY(QAbstractItemModel *tasks READ tasksModel CONSTANT)
    Q_PROPERTY(QVariantMap focusTask READ focusTask NOTIFY focusTaskChanged)

public:
    explicit AppState(QSettings *settings, QObject *parent = nullptr);

    IslandMode mode() const { return m_mode; }
    QString modeName() const { return enumKey(m_mode); }
    void setMode(IslandMode m);

    IslandView view() const { return m_view; }
    QString viewName() const { return enumKey(m_view); }
    void setView(IslandView v);
    void setViewName(const QString &name);

    QString focusId() const { return m_focusId; }
    Q_INVOKABLE void setFocus(const QString &id);
    QVariantMap focusTask() const;
    void modifyTask(const QString &id, const std::function<void(AgentTask &)> &fn);

    QAbstractItemModel *tasksModel() const { return m_tasks; }
    TaskModel *taskModel() const { return m_tasks; }
    void addTask(const AgentTask &task);
    void removeTask(const QString &id);
    void updateTask(const QString &id, BotState state);
    BotState effectiveState() const;
    QString effectiveStateName() const { return enumKey(effectiveState()); }
    void setStateOverride(std::optional<BotState> s);

    bool soundEnabled() const { return m_soundEnabled; }
    void setSoundEnabled(bool on);
    double soundVolume() const { return m_soundVolume; }
    void setSoundVolume(double v);           // clamped to 0..0.2
    double autoCloseInterval() const { return m_autoClose; }
    void setAutoCloseInterval(double seconds);
    // "system" (default), "dark" or "light"; anything else is rejected.
    QString themeMode() const { return m_themeMode; }
    void setThemeMode(const QString &mode);
    // Screen edge the island is docked to: "top" (default), "bottom", "left" or "right"; anything else is rejected.
    QString edge() const { return m_edge; }
    void setEdge(const QString &edge);
    // Docked to a side edge: the island is a portrait column (see islandSize).
    bool vertical() const { return m_edge == QLatin1String("left") || m_edge == QLatin1String("right"); }
    bool reduceMotion() const { return m_reduceMotion; }
    void setReduceMotion(bool on);
    // Settings -> Workspace: the folder where the developer keeps the repositories. An absolute path, or empty (none
    // chosen). It is not required to exist here: a disk that is not mounted right now must not erase the setting.
    QString workspaceDir() const { return m_workspaceDir; }
    void setWorkspaceDir(const QString &dir);
    QString workspaceDirLabel() const;       // for the screen: "~/dev" instead of the whole home path
    // The island has no folder picker of its own: the app answers workspaceDirRequested with the desktop's dialog.
    Q_INVOKABLE void chooseWorkspaceDir() { emit workspaceDirRequested(); }
    // The company's skills folder (a git clone, one folder per skill) that Claude Code is kept linked to; empty = none.
    QString skillsDir() const { return m_skillsDir; }
    void setSkillsDir(const QString &dir);
    QString skillsDirLabel() const;
    Q_INVOKABLE void chooseSkillsDir() { emit skillsDirRequested(); }
    // Settings -> "Ocultar inativas": how long a session at rest (idle or finished) stays in the island. 0 keeps it
    // until it ends; otherwise 10 s to 24 h, anything else is rejected.
    int sessionIdleSeconds() const { return m_sessionIdle; }
    void setSessionIdleSeconds(int seconds);
    // Settings -> "Esconder sem uso": the compact island turns invisible a minute after the pointer leaves it (what
    // the Mac app does behind its notch) and comes back on a hook event or when the pointer touches the screen edge.
    // Off by default: on a screen without a notch an island that vanishes looks like an app that closed.
    bool autoHide() const { return m_autoHide; }
    void setAutoHide(bool on);
    // Settings -> "Lembrar espera": a session that waits for an answer (permission, question) calls again every so
    // many seconds. 0 never; otherwise 30 s to 1 h, anything else is rejected.
    int waitReminderSeconds() const { return m_waitReminder; }
    void setWaitReminderSeconds(int seconds);
    // The context window of a model, in tokens. Nothing in the hooks or the transcript says it, so it is learnt:
    // 200 000 until a session of that model is seen with more in its context, 1 000 000 from then on (remembered
    // in farol.conf, key largeContextModels).
    int contextWindowFor(const QString &model, int tokens);
    // Settings -> "Notificar ausente": what the island would call for (question, permission, finished, error) also
    // goes to the desktop's notifications while the screen is locked or nobody touched the computer for a while.
    bool notifyAway() const { return m_notifyAway; }
    void setNotifyAway(bool on);
    bool isPinned() const { return m_pinned; }
    void setPinned(bool on);
    int chatCount() const { return m_chatCount; }
    void setChatCount(int n);
    double uploadProgress() const { return m_uploadProgress; }
    void setUploadProgress(double p);
    qint64 lastActivityMs() const { return m_lastActivityMs; }
    void setLastActivityMs(qint64 ms);

    qreal notchWidth() const { return m_notchW; }
    qreal notchHeight() const { return m_notchH; }
    void setNotchSize(qreal w, qreal h);
    bool isPresent() const { return m_present; }
    void setPresent(bool on);

    QStringList activeIntegrations() const { return m_activeIntegrations; }
    Q_INVOKABLE void toggleIntegration(const QString &id);
    void loadIntegrationTasks();
    void syncMode();
    void syncView();
    QVariantList compactOthers() const;
    int sessionCount() const;
    int awakeSessionCount() const;
    bool sessionBusy() const;
    int waitingCount() const;
    int errorCount() const;

signals:
    void modeChanged();
    void viewChanged();
    void focusChanged();
    void focusTaskChanged();
    void soundEnabledChanged();
    void soundVolumeChanged();
    void themeModeChanged();
    void reduceMotionChanged();
    void workspaceDirChanged();
    void workspaceDirRequested();
    void skillsDirChanged();
    void skillsDirRequested();
    void sessionIdleSecondsChanged();
    void autoHideChanged();
    void notifyAwayChanged();
    void waitReminderSecondsChanged();
    void edgeChanged();
    void autoCloseIntervalChanged();
    void pinnedChanged();
    void chatCountChanged();
    void uploadProgressChanged();
    void lastActivityChanged();
    void notchChanged();
    void effectiveStateChanged();
    void compactOthersChanged();

private:
    void setFocusInternal(const QString &id);
    void load();
    void persist();

    QSettings *m_settings;
    TaskModel *m_tasks;
    IslandMode m_mode = IslandMode::Hidden;
    IslandView m_view = IslandView::Overview;
    QString m_focusId;
    std::optional<BotState> m_stateOverride;
    bool m_soundEnabled = true;
    double m_soundVolume = 0.12;
    double m_autoClose = 15;
    QString m_themeMode = QStringLiteral("system");
    bool m_reduceMotion = false;
    QString m_workspaceDir;
    QString m_skillsDir;
    int m_sessionIdle = 30;
    bool m_autoHide = false;
    bool m_notifyAway = true;
    int m_waitReminder = 120;
    QStringList m_largeContextModels;
    QString m_edge = QStringLiteral("top");
    bool m_pinned = false;
    int m_chatCount = 0;
    double m_uploadProgress = 0;
    qint64 m_lastActivityMs = 0;
    qreal m_notchW = IslandConst::notchWidth;
    qreal m_notchH = IslandConst::notchHeight;
    bool m_present = true;
    QStringList m_activeIntegrations;
};

} // namespace farol
