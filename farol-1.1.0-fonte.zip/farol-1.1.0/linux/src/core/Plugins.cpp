#include "Plugins.h"

#include "ClaudeLocator.h"

#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QVariantMap>
#include <algorithm>

namespace farol {

namespace {

PluginInfo fromId(const QString &id)
{
    PluginInfo p;
    p.id = id;
    const int at = id.lastIndexOf(QLatin1Char('@'));
    p.name = at > 0 ? id.left(at) : id;
    p.marketplace = at > 0 ? id.mid(at + 1) : QString();
    return p;
}

} // namespace

PluginListing parsePluginListing(const QByteArray &json)
{
    PluginListing out;
    const QJsonDocument doc = QJsonDocument::fromJson(json);
    if (!doc.isObject() || !doc.object().value(QLatin1String("installed")).isArray())
        return out;
    out.ok = true;
    for (const QJsonValue &v : doc.object().value(QLatin1String("installed")).toArray()) {
        const QJsonObject o = v.toObject();
        const QString id = o.value(QLatin1String("id")).toString();
        if (id.isEmpty() || o.value(QLatin1String("scope")).toString(QStringLiteral("user")) != QLatin1String("user"))
            continue;   // project and local plugins belong to a repository, not to this list
        PluginInfo p = fromId(id);
        p.enabled = o.value(QLatin1String("enabled")).toBool();
        out.installed.append(p);
    }
    for (const QJsonValue &v : doc.object().value(QLatin1String("available")).toArray()) {
        const QJsonObject o = v.toObject();
        const QString id = o.value(QLatin1String("pluginId")).toString();
        if (id.isEmpty())
            continue;
        PluginInfo p = fromId(id);
        const QString name = o.value(QLatin1String("name")).toString();
        if (!name.isEmpty())
            p.name = name;
        p.description = o.value(QLatin1String("description")).toString().simplified();
        out.available.append(p);
    }
    const auto byName = [](const PluginInfo &a, const PluginInfo &b) { return a.name.compare(b.name, Qt::CaseInsensitive) < 0; };
    std::sort(out.installed.begin(), out.installed.end(), byName);
    std::sort(out.available.begin(), out.available.end(), byName);
    return out;
}

Plugins::Plugins(ICommandRunner *runner, std::function<QString()> locate, const QString &path, QObject *parent)
    : QObject(parent), m_runner(runner), m_locate(std::move(locate)), m_path(path)
{
}

QVariantList Plugins::installed() const
{
    QVariantList out;
    for (const PluginInfo &p : m_listing.installed)
        out << QVariantMap{{"id", p.id}, {"name", p.name}, {"marketplace", p.marketplace}, {"enabled", p.enabled},
                           {"busy", p.id == m_busyId}, {"error", m_errors.value(p.id)}};
    return out;
}

QVariantList Plugins::catalog() const
{
    const QString needle = m_filter.trimmed();
    QVariantList out;
    for (const PluginInfo &p : m_listing.available) {
        if (!needle.isEmpty() && !p.name.contains(needle, Qt::CaseInsensitive) && !p.description.contains(needle, Qt::CaseInsensitive)
            && !p.marketplace.contains(needle, Qt::CaseInsensitive))
            continue;
        out << QVariantMap{{"id", p.id}, {"name", p.name}, {"marketplace", p.marketplace}, {"description", p.description},
                           {"busy", p.id == m_busyId}, {"error", m_errors.value(p.id)}};
    }
    return out;
}

void Plugins::setFilter(const QString &text)
{
    if (text == m_filter)
        return;
    m_filter = text;
    emit changed();
}

void Plugins::refresh()
{
    if (busy())
        return;
    m_notice.clear();
    list();
}

void Plugins::list()
{
    m_claude = m_locate();
    m_hasClaude = !m_claude.isEmpty();
    if (!m_hasClaude) {
        m_listing = {};
        m_error.clear();
        emit changed();
        return;
    }
    m_loading = true;
    emit changed();
    m_runner->run(m_claude, {QStringLiteral("plugin"), QStringLiteral("list"), QStringLiteral("--json"), QStringLiteral("--available")},
                  claudeEnvironment(m_claude, m_path), kListTimeoutMs, [this](const ICommandRunner::Result &r) {
                      m_loading = false;
                      const PluginListing listing = r.started && !r.timedOut && r.exitCode == 0 ? parsePluginListing(r.out.toUtf8()) : PluginListing{};
                      if (listing.ok) {
                          m_listing = listing;
                          m_error.clear();
                      } else if (!r.started) {
                          m_hasClaude = false;
                      } else if (r.timedOut) {
                          m_error = QStringLiteral("O Claude Code demorou demais para responder.");
                      } else if (r.exitCode != 0) {
                          m_error = QStringLiteral("O Claude Code não listou os plugins: ") + lastLine(r);
                      } else {
                          m_error = QStringLiteral("Não entendi a resposta do Claude Code. Atualize o Farol ou o Claude Code.");
                      }
                      emit changed();
                  });
}

void Plugins::setEnabled(const QString &id, bool on)
{
    act(id, {QStringLiteral("plugin"), on ? QStringLiteral("enable") : QStringLiteral("disable"), id},
        on ? QStringLiteral("Ligado: %1") : QStringLiteral("Desligado: %1"));
}

void Plugins::remove(const QString &id)
{
    act(id, {QStringLiteral("plugin"), QStringLiteral("uninstall"), id}, QStringLiteral("Removido: %1"));
}

void Plugins::install(const QString &id)
{
    act(id, {QStringLiteral("plugin"), QStringLiteral("install"), id}, QStringLiteral("Instalado: %1"));
}

void Plugins::act(const QString &id, const QStringList &arguments, const QString &done)
{
    if (busy() || id.isEmpty() || m_claude.isEmpty())
        return;   // one command at a time
    m_busyId = id;
    m_errors.remove(id);
    m_notice.clear();
    emit changed();
    m_runner->run(m_claude, arguments, claudeEnvironment(m_claude, m_path), kActionTimeoutMs, [this, id, done](const ICommandRunner::Result &r) {
        m_busyId.clear();
        if (r.started && !r.timedOut && r.exitCode == 0) {
            m_notice = done.arg(fromId(id).name) + QStringLiteral(". Vale para as sessões abertas a partir de agora.");
        } else if (r.timedOut) {
            m_errors.insert(id, QStringLiteral("O Claude Code demorou demais."));
        } else {
            const QString why = lastLine(r);
            // a marketplace may declare a command to run at install time: that is never accepted from here
            m_errors.insert(id, (r.err + r.out).contains(QLatin1String("accept-command"))
                                    ? QStringLiteral("Este plugin pede para rodar um comando ao instalar. Instale pelo Claude Code (/plugin).")
                                    : (why.isEmpty() ? QStringLiteral("O Claude Code recusou.") : why));
        }
        list();   // what is true now, whatever happened
    });
}

QString Plugins::lastLine(const ICommandRunner::Result &r)
{
    for (const QString &text : {r.err, r.out}) {
        const QStringList lines = text.split(QLatin1Char('\n'), Qt::SkipEmptyParts);
        for (auto it = lines.crbegin(); it != lines.crend(); ++it)
            if (!it->trimmed().isEmpty())
                return it->trimmed().left(200);
    }
    return {};
}

} // namespace farol
