#include <QtTest>
#include <QDir>
#include <QSet>
#include "SoundNames.h"

class TestSoundNames : public QObject {
    Q_OBJECT
private slots:
    void thereAreTwentyEightUniqueNames()
    {
        const auto &names = farol::soundNames();
        QCOMPARE(names.size(), 28);
        QCOMPARE(QSet<QString>(names.begin(), names.end()).size(), 28);
    }
    void everyNameHasAWavAndNoWavIsUnlisted()
    {
        const QDir dir(QStringLiteral(FAROL_SOUNDS_DIR));
        // The WAVs are not part of the repository (see sounds/README.md): without them there is nothing to check.
        if (dir.entryList({"*.wav"}, QDir::Files).isEmpty())
            QSKIP("no sounds installed in linux/sounds");
        for (const QString &n : farol::soundNames())
            QVERIFY2(dir.exists(n + ".wav"), qPrintable(n));
        const QStringList wavs = dir.entryList({"*.wav"}, QDir::Files);
        QCOMPARE(wavs.size(), farol::soundNames().size());
    }
};

QTEST_APPLESS_MAIN(TestSoundNames)
#include "tst_sound.moc"
