#pragma once
#include "HttpClient.h"
#include <QByteArray>
#include <QList>
#include <QString>
#include <QStringList>

namespace farol {

// The "Perguntar" tab talks to the AI service the user gave a key for. This file only builds the request each
// service wants and reads its answer: no network, no state.

// "claude", "anthropic", "openai", "gemini".
QStringList aiProviders();
QString aiProviderLabel(const QString &provider);     // "Claude Code", "Anthropic", "ChatGPT", "Gemini"
// "claude" is the Claude Code installed on this machine, with the account it is logged in with: no key, no request
// of Farol's own. The others are web services that want the user's API key.
bool aiNeedsKey(const QString &provider);
QString aiDefaultModel(const QString &provider);
// The three models offered for each service, the newest of each line: what Settings -> IA lets the user pick from.
struct AiModel {
    QString id, label;
};
QList<AiModel> aiModels(const QString &provider);

struct AskFile {
    enum Kind { Text, Image, Pdf };
    QString name;
    Kind kind = Text;
    QString mime;        // of an image or a PDF
    QByteArray data;     // UTF-8 text, or the raw bytes of an image or a PDF
};

struct AskTurn {
    bool user = true;
    QString text;
};

// The files go with the first question; the turns after it are the conversation so far, ending with the question
// being asked.
HttpRequest buildAiRequest(const QString &provider, const QString &model, const QString &key, const QList<AskFile> &files,
                           const QList<AskTurn> &turns);

struct AiAnswer {
    bool ok = false;
    QString text;        // the answer, or what went wrong in the service's own words
};
AiAnswer parseAiReply(const QString &provider, int status, const QByteArray &body);

// The same question for Claude Code: `claude -p` with no tools, none of the user's hooks, plugins or MCP servers (a
// question must not show in the island as a session of its own) and nothing kept on disk. The files and the
// conversation so far go in one message on its standard input, and the answer is the "result" line it prints.
QStringList claudeArguments(const QString &model);
QByteArray claudeInput(const QList<AskFile> &files, const QList<AskTurn> &turns);
AiAnswer parseClaudeOutput(int exitCode, const QString &out, const QString &err);

} // namespace farol
